import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

class EncryptedBackupCodec {
  const EncryptedBackupCodec._();

  static const magic = 'KABAS-BACKUP-ENC';
  static const formatVersion = 1;
  static const _iterations = 120000;
  static const _saltBytes = 16;
  static const _nonceBytes = 12;
  static const _maxPlaintextBytes = 200 * 1024 * 1024;

  static Future<String> encryptJson(
    String json, {
    required String password,
  }) async {
    _requirePassword(password);
    final plaintext = utf8.encode(json);
    if (plaintext.length > _maxPlaintextBytes) {
      throw const FormatException('حجم النسخة الاحتياطية يتجاوز الحد المسموح');
    }

    final salt = _randomBytes(_saltBytes);
    final nonce = _randomBytes(_nonceBytes);
    final key = await _deriveKey(password, salt);
    final algorithm = AesGcm.with256bits();
    final header = <String, Object?>{
      'magic': magic,
      'version': formatVersion,
      'kdf': 'PBKDF2-HMAC-SHA256',
      'iterations': _iterations,
      'cipher': 'AES-256-GCM',
      'salt': base64Encode(salt),
      'nonce': base64Encode(nonce),
    };
    final associatedData = utf8.encode(jsonEncode(header));
    final box = await algorithm.encrypt(
      plaintext,
      secretKey: key,
      nonce: nonce,
      aad: associatedData,
    );
    final container = <String, Object?>{
      'header': header,
      'ciphertext': base64Encode(box.cipherText),
      'tag': base64Encode(box.mac.bytes),
    };
    return '$magic\n${base64Encode(utf8.encode(jsonEncode(container)))}';
  }

  static Future<String> decryptJson(
    String source, {
    required String password,
  }) async {
    _requirePassword(password);
    final separator = source.indexOf('\n');
    if (separator <= 0 || source.substring(0, separator) != magic) {
      throw const FormatException('هذه ليست نسخة كباس مشفرة');
    }
    final encoded = source.substring(separator + 1).trim();
    final decoded = jsonDecode(utf8.decode(base64Decode(encoded)));
    if (decoded is! Map || decoded['header'] is! Map) {
      throw const FormatException('حاوية النسخة المشفرة غير صالحة');
    }
    final header = Map<String, Object?>.from(decoded['header'] as Map);
    if (header['magic'] != magic || header['version'] != formatVersion) {
      throw const FormatException('إصدار النسخة المشفرة غير مدعوم');
    }
    if (header['kdf'] != 'PBKDF2-HMAC-SHA256' ||
        header['cipher'] != 'AES-256-GCM' ||
        header['iterations'] != _iterations) {
      throw const FormatException('معلمات تشفير غير مدعومة');
    }
    final salt = _decodeBounded(header['salt'], _saltBytes);
    final nonce = _decodeBounded(header['nonce'], _nonceBytes);
    final ciphertext = _decodeBounded(
      decoded['ciphertext'],
      _maxPlaintextBytes,
    );
    final tag = _decodeBounded(decoded['tag'], 32);
    final key = await _deriveKey(password, salt);
    final algorithm = AesGcm.with256bits();
    final associatedData = utf8.encode(jsonEncode(header));
    try {
      final plaintext = await algorithm.decrypt(
        SecretBox(ciphertext, nonce: nonce, mac: Mac(tag)),
        secretKey: key,
        aad: associatedData,
      );
      if (plaintext.length > _maxPlaintextBytes) {
        throw const FormatException('البيانات المفكوكة تتجاوز الحد المسموح');
      }
      return utf8.decode(plaintext);
    } on SecretBoxAuthenticationError {
      throw const FormatException('كلمة المرور خاطئة أو النسخة تعرضت للعبث');
    }
  }

  static Future<SecretKey> _deriveKey(String password, List<int> salt) {
    final kdf = Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: _iterations,
      bits: 256,
    );
    return kdf.deriveKeyFromPassword(password: password, nonce: salt);
  }

  static List<int> _randomBytes(int length) {
    final random = Random.secure();
    return List<int>.generate(length, (_) => random.nextInt(256));
  }

  static List<int> _decodeBounded(Object? value, int maxBytes) {
    if (value is! String || value.isEmpty) {
      throw const FormatException('حقل تشفير ناقص');
    }
    final bytes = base64Decode(value);
    if (bytes.isEmpty || bytes.length > maxBytes) {
      throw const FormatException('حقل تشفير يتجاوز الحد المسموح');
    }
    return Uint8List.fromList(bytes);
  }

  static void _requirePassword(String password) {
    if (password.trim().length < 8) {
      throw const FormatException(
        'كلمة مرور النسخة يجب أن تكون 8 أحرف على الأقل',
      );
    }
  }
}
