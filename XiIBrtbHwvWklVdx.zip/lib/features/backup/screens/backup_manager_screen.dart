import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../services/backup_service.dart';

class BackupManagerScreen extends StatefulWidget {
  const BackupManagerScreen({super.key});

  @override
  State<BackupManagerScreen> createState() => _BackupManagerScreenState();
}

class _BackupManagerScreenState extends State<BackupManagerScreen> {
  List<LocalBackupRecord> _records = const [];
  bool _loading = true;
  Object? _loadError;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    try {
      final records = await BackupService.listLocalBackups();
      if (!mounted) return;
      setState(() {
        _records = records;
        _loadError = null;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loadError = error;
        _loading = false;
      });
    }
  }

  Future<String?> _password() async {
    final controller = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('كلمة مرور النسخة'),
        content: TextField(
          controller: controller,
          obscureText: true,
          decoration: const InputDecoration(labelText: 'كلمة المرور'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () {
              if (controller.text.trim().length >= 8) {
                Navigator.pop(context, controller.text);
              }
            },
            child: const Text('متابعة'),
          ),
        ],
      ),
    );
    controller.dispose();
    return value;
  }

  Future<void> _restore(LocalBackupRecord record) async {
    try {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('استعادة النسخة؟'),
          content: const Text('سيتم استبدال البيانات الحالية ببيانات النسخة.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('استعادة'),
            ),
          ],
        ),
      );
      if (confirmed != true) return;
      final bytes = await File(record.path).readAsBytes();
      final backup = await BackupService.decodeAnyBackup(
        utf8.decode(bytes),
        passwordProvider: _password,
      );
      await BackupService.restoreBackup(backup);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تمت استعادة ${record.name} بنجاح')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('تعذر استعادة النسخة: $error')));
    }
  }

  Future<void> _shareCopy(LocalBackupRecord record) async {
    try {
      final bytes = await File(record.path).readAsBytes();
      final uri = await FilePicker.saveFile(
        dialogTitle: 'حفظ نسخة للمشاركة',
        fileName: record.name,
        type: FileType.custom,
        allowedExtensions: [
          record.name.toLowerCase().endsWith('.json') ? 'json' : 'kabas',
        ],
        bytes: Uint8List.fromList(bytes),
      );
      if (!mounted || uri == null) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('تم تجهيز نسخة للمشاركة في $uri')));
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر تجهيز النسخة للمشاركة: $error')),
      );
    }
  }

  Future<void> _delete(LocalBackupRecord record) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف النسخة؟'),
        content: Text('سيتم حذف الملف ${record.name} من الجهاز.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      await BackupService.deleteLocalBackup(record);
      await _reload();
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('تعذر حذف النسخة: $error')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مدير النسخ الاحتياطية'),
        actions: [
          IconButton(onPressed: _reload, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _loadError != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline, size: 48),
                    const SizedBox(height: 12),
                    const Text('تعذر تحميل النسخ الاحتياطية المحلية'),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: () {
                        setState(() {
                          _loading = true;
                          _loadError = null;
                        });
                        _reload();
                      },
                      icon: const Icon(Icons.refresh),
                      label: const Text('إعادة المحاولة'),
                    ),
                  ],
                ),
              ),
            )
          : _records.isEmpty
          ? const _EmptyBackups()
          : RefreshIndicator(
              onRefresh: _reload,
              child: ListView.separated(
                padding: const EdgeInsets.all(16),
                itemCount: _records.length,
                separatorBuilder: (_, _) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  final record = _records[index];
                  return Card(
                    child: ListTile(
                      leading: Icon(
                        record.name.toLowerCase().endsWith('.json')
                            ? Icons.backup_outlined
                            : Icons.lock_clock_outlined,
                      ),
                      title: Text(record.name),
                      subtitle: Text(_formatDate(record.createdAt)),
                      trailing: PopupMenuButton<String>(
                        onSelected: (value) {
                          switch (value) {
                            case 'restore':
                              _restore(record);
                            case 'share':
                              _shareCopy(record);
                            case 'delete':
                              _delete(record);
                          }
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem(
                            value: 'restore',
                            child: Text('استعادة'),
                          ),
                          PopupMenuItem(
                            value: 'share',
                            child: Text('مشاركة نسخة'),
                          ),
                          PopupMenuItem(value: 'delete', child: Text('حذف')),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
    );
  }

  String _formatDate(DateTime value) {
    final local = value.toLocal();
    return '${local.year}/${local.month.toString().padLeft(2, '0')}/${local.day.toString().padLeft(2, '0')} '
        '${local.hour.toString().padLeft(2, '0')}:${local.minute.toString().padLeft(2, '0')}';
  }
}

class _EmptyBackups extends StatelessWidget {
  const _EmptyBackups();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.backup_outlined,
              size: 56,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 12),
            Text(
              'لا توجد نسخ محلية مسجلة بعد',
              style: Theme.of(context).textTheme.titleMedium,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 6),
            const Text(
              'بعد تصدير نسخة احتياطية ستظهر هنا لإدارتها.',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
