import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';

import '../../backup/screens/backup_manager_screen.dart';
import '../../backup/services/backup_service.dart';
import '../../backup/services/google_drive_backup_service.dart';
import '../../debts/screens/debt_settings_screen.dart';
import '../../debts/services/debt_store.dart';
import '../../expense_request/services/request_store.dart';
import '../../expense_request/services/quick_statement_store.dart';
import '../../notes/services/notes_store.dart';
import '../../reminders/services/reminder_store.dart';
import '../models/app_settings.dart';
import '../models/template_configuration.dart';
import '../services/pattern_store.dart';
import '../services/settings_store.dart';
import '../../product_catalog/screens/product_catalog_screen.dart';
import 'memo_preview_screen.dart';
import 'template_preview_screen.dart';
import '../widgets/color_picker_dropdown.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({this.templateKind, super.key});

  final TemplateKind? templateKind;

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _formKey = GlobalKey<FormState>();
  final _companyController = TextEditingController();
  final _issueDateController = TextEditingController();
  final _versionController = TextEditingController();
  final _currencyController = TextEditingController();
  final _fractionController = TextEditingController();
  final _representativeMedRepController = TextEditingController();
  final _representativeCityController = TextEditingController();
  final _representativeDistrictController = TextEditingController();
  final _representativeSectionController = TextEditingController();

  AppSettings _settings = AppSettings.defaults();
  bool _isLoading = true;
  bool _isSaving = false;
  String? _loadError;
  bool _editingBottomCopy = false;
  bool _editingCustomerFields = false;
  List<SavedPattern> _savedPatterns = const [];
  Future<void> _scopedSaveQueue = Future<void>.value();
  Map<String, int> _printedColorsByScope = const {};

  static const _printedColorScopes = <String>[
    'expenseRequest',
    'clearanceRequest',
    'serviceRequest',
    'fuelRequest',
    'customerApplication',
    'sampleRequest',
    'sampleRequestSinglePage',
    'travelAllowance',
    'internalMemo',
  ];

  static const _printedColorLabels = <String, String>{
    'expenseRequest': 'نموذج طلب الصرف',
    'clearanceRequest': 'نموذج طلب الإخلاء',
    'serviceRequest': 'نموذج طلب الخدمة',
    'fuelRequest': 'نموذج طلب المحروقات',
    'customerApplication': 'طلب العميل',
    'sampleRequest': 'نموذج طلب عينات — ثلاث صفحات',
    'sampleRequestSinglePage': 'نموذج طلب عينات — صفحة واحدة',
    'travelAllowance': 'نموذج طلب بدل السفر',
    'internalMemo': 'المذكرة الداخلية',
  };

  bool get _isScoped => widget.templateKind != null;
  bool get _isCustomer =>
      widget.templateKind == TemplateKind.customerApplication;
  bool get _isMemo => widget.templateKind == TemplateKind.internalMemo;

  String get _settingsScope => switch (widget.templateKind) {
    TemplateKind.customerApplication => 'customerApplication',
    TemplateKind.expenseRequest => 'expenseRequest',
    TemplateKind.clearanceRequest => 'clearanceRequest',
    TemplateKind.serviceRequest => 'serviceRequest',
    TemplateKind.fuelRequest => 'fuelRequest',
    TemplateKind.sampleRequest => 'sampleRequest',
    TemplateKind.sampleRequestSinglePage => 'sampleRequestSinglePage',
    TemplateKind.travelAllowance => 'travelAllowance',
    TemplateKind.internalMemo => 'internalMemo',
    null => 'global',
  };

  String get _driveAccountLabel {
    final account = GoogleDriveBackupService.instance.currentUser;
    return account == null
        ? 'سيتم اختيار حساب Google عند أول عملية Drive.'
        : 'الحساب المتصل: ${account.email}';
  }

  Future<void> _queueScopedSave(AppSettings settings) {
    _scopedSaveQueue = _scopedSaveQueue.then(
      (_) => SettingsStore.save(settings, scope: _settingsScope),
    );
    return _scopedSaveQueue;
  }

  static const _serviceOrderedFieldKeys = [
    'date',
    'receiver',
    'serviceTypeHospitality',
    'serviceTypeCashSupport',
    'serviceTypeInKindGift',
    'doctorNames',
    'worksIn',
    'specialty',
    'serviceItemName1',
    'serviceItemName2',
    'serviceItemName3',
    'serviceItemName4',
    'serviceItemName5',
    'serviceItemName6',
    'statement',
    'amountNumber',
    'amountWords',
    'branch',
    'requesterName',
    'directManagerName',
    'approvedAuthorityName',
  ];

  static const _fuelOrderedFieldKeys = [
    'fuelBranch',
    'vehicleNumber',
    'collector',
    'fuelType',
    'fuelTypePetrol',
    'fuelTypeDiesel',
    'fuelTypeGas',
    'periodFrom',
    'periodTo',
    'beneficiary',
    'branchAccountant',
    'branchManager',
    'administrationAccountant',
    'accountsManager',
    'systemTimestamp',
  ];
  static const _sampleSinglePageOrderedFieldKeys = [
    'date',
    'receiver',
    'reason',
    'requesterName',
    'sampleUsageMarketing',
    'sampleUsageDoctors',
    'sampleUsageEmployees',
    'sampleUsageOther',
  ];
  static final _travelAllowanceOrderedFieldKeys = [
    'branch',
    'month',
    'year',
    'beneficiary',
    'branchManager',
    'departmentManager',
    'administrationAccountant',
    'accountsManager',
    'totalAmount',
    'totalDays',
    for (var i = 1; i <= 10; i++) ...[
      'travelDay$i',
      'travelDate$i',
      'travelDailyAmount$i',
      'travelRegion$i',
      'travelStatement$i',
    ],
  ];
  static const _orderedFieldKeys = [
    'dateLabel',
    'date',
    'receiver',
    'amountNumber',
    'amountWords',
    'reason',
    'statement',
    'branch',
    'account',
    'requesterName',
    'directManagerName',
    'approvedAuthorityName',
    'accountsManagerName',
  ];

  @override
  void initState() {
    super.initState();
    _editingCustomerFields =
        widget.templateKind == TemplateKind.customerApplication;
    _loadSettings();
  }

  @override
  void dispose() {
    _companyController.dispose();
    _issueDateController.dispose();
    _versionController.dispose();
    _currencyController.dispose();
    _fractionController.dispose();
    _representativeMedRepController.dispose();
    _representativeCityController.dispose();
    _representativeDistrictController.dispose();
    _representativeSectionController.dispose();
    super.dispose();
  }

  Future<void> _loadSettings() async {
    try {
      final settings = await SettingsStore.load(scope: _settingsScope);
      final savedPatterns = await PatternStore.load(scope: _settingsScope);
      final printedColors = <String, int>{};
      if (!_isScoped) {
        for (final scope in _printedColorScopes) {
          printedColors[scope] = (await SettingsStore.load(
            scope: scope,
          )).printedTextColorValue;
        }
      }
      if (!mounted) return;
      setState(() {
        _settings = settings;
        _savedPatterns = savedPatterns;
        _printedColorsByScope = printedColors;
        _loadError = null;
      });
      _fillControllers(settings);
    } catch (error, stackTrace) {
      debugPrint('تعذر تحميل إعدادات الشاشة: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (mounted) {
        setState(() => _loadError = 'تعذر تحميل الإعدادات. أعد المحاولة.');
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _savePrintedColor(String scope, int colorValue) async {
    final previousColor =
        _printedColorsByScope[scope] ??
        SettingsStore.notifierFor(scope).value.printedTextColorValue;
    if (!mounted) return;
    setState(() {
      _printedColorsByScope = {..._printedColorsByScope, scope: colorValue};
    });
    try {
      final current = await SettingsStore.load(
        scope: scope,
        inheritGlobalIfMissing: true,
      );
      await SettingsStore.save(
        current.copyWith(printedTextColorValue: colorValue),
        scope: scope,
      );
    } catch (error, stackTrace) {
      debugPrint('تعذر حفظ لون الكتابة المطبوعة للنطاق $scope: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (!mounted) return;
      setState(() {
        _printedColorsByScope = {
          ..._printedColorsByScope,
          scope: previousColor,
        };
      });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('تعذر حفظ لون الكتابة المطبوعة، أُعيد اللون السابق.'),
        ),
      );
    }
  }

  void _fillControllers(AppSettings settings) {
    _companyController.text = settings.companyName;
    _issueDateController.text = settings.issueDate;
    _versionController.text = settings.issueVersion;
    _currencyController.text = settings.currencyName;
    _fractionController.text = settings.fractionName;
    _representativeMedRepController.text = settings.representativeReportMedRep;
    _representativeCityController.text = settings.representativeReportCity;
    _representativeDistrictController.text =
        settings.representativeReportDistrict;
    _representativeSectionController.text =
        settings.representativeReportSection;
  }

  Map<String, FieldSetting> get _activeFields => _editingCustomerFields
      ? _settings.customerFieldSettings
      : _settings.fieldSettings;

  List<String> get _structuredFieldKeys => switch (_settingsScope) {
    'clearanceRequest' => [
      for (var i = 1; i <= 6; i++) ...[
        'clearanceAmount$i',
        'clearanceDate$i',
        'clearanceStatement$i',
      ],
    ],
    'serviceRequest' => const [],
    'sampleRequest' => [
      for (var i = 1; i <= 53; i++) ...[
        'sampleItemName$i',
        'sampleItemForm$i',
        'sampleItemQuantity$i',
        'sampleItemQuantityWords$i',
        'sampleItemNotes$i',
      ],
    ],
    'sampleRequestSinglePage' => [
      for (var i = 1; i <= 25; i++) ...[
        'sampleItemName$i',
        'sampleItemForm$i',
        'sampleItemQuantity$i',
        'sampleItemQuantityWords$i',
        'sampleItemNotes$i',
      ],
    ],
    'fuelRequest' => [
      for (var i = 1; i <= 7; i++) ...[
        'fuelDate$i',
        'fuelMeter$i',
        'fuelLiters$i',
        'fuelPrice$i',
        'fuelAmount$i',
        'fuelCollection$i',
        'fuelSales$i',
        'fuelRoute$i',
      ],
    ],
    _ => const [],
  };

  Future<void> _openSamplePositionEditor() async {
    final scope = _settingsScope;
    final settings = await SettingsStore.load(scope: scope);
    if (!mounted) return;
    final updated = await Navigator.of(context).push<AppSettings>(
      MaterialPageRoute<AppSettings>(
        builder: (_) => TemplatePreviewScreen(
          settings: settings,
          templateScope: scope,
          sampleRequest: true,
          documentTitle: scope == 'sampleRequestSinglePage'
              ? 'محرر مواضع طلب العينات — صفحة واحدة'
              : 'محرر مواضع طلب العينات — الصفحات الثلاث',
        ),
      ),
    );
    if (updated != null) {
      setState(() => _settings = updated);
      await _queueScopedSave(updated);
    }
  }

  Map<String, FieldSetting> get _activeMemoFields =>
      _settings.memoFullA4FieldSettings;

  Future<void> _saveSettings() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;

    setState(() => _isSaving = true);
    final updated = _settings.copyWith(
      companyName: _companyController.text.trim(),
      formTitle: AppSettings.fixedFormTitle,
      documentNumber: AppSettings.fixedDocumentNumber,
      issueDate: AppSettings.fixedIssueDate,
      issueVersion: AppSettings.fixedIssueVersion,
      currencyName: _currencyController.text.trim(),
      fractionName: _fractionController.text.trim(),
      representativeReportMedRep: _representativeMedRepController.text.trim(),
      representativeReportCity: _representativeCityController.text.trim(),
      representativeReportDistrict: _representativeDistrictController.text
          .trim(),
      representativeReportSection: _representativeSectionController.text.trim(),
    );
    await SettingsStore.save(updated, scope: _settingsScope);
    if (!mounted) return;
    setState(() {
      _settings = updated;
      _isSaving = false;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('تم حفظ إعدادات التطبيق بنجاح'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _addCustomField() async {
    final controller = TextEditingController();
    final label = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('إضافة حقل مخصص'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'اسم الحقل',
            hintText: 'مثال: مركز التكلفة',
          ),
          onSubmitted: (value) => Navigator.pop(context, value.trim()),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('إضافة'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (label == null || label.trim().isEmpty) return;

    final key = 'custom_${DateTime.now().microsecondsSinceEpoch}';
    final newField = FieldSetting(
      label: label.trim(),
      visible: true,
      required: false,
    );
    if (_editingCustomerFields) {
      final fields = Map<String, FieldSetting>.from(
        _settings.customerFieldSettings,
      )..[key] = newField;
      setState(
        () => _settings = _settings.copyWith(customerFieldSettings: fields),
      );
    } else {
      final fields = Map<String, FieldSetting>.from(_settings.fieldSettings)
        ..[key] = newField;
      final bottomFields = Map<String, FieldSetting>.from(
        _settings.fieldsForCopy(bottom: true),
      )..[key] = newField;
      setState(
        () => _settings = _settings.copyWith(
          fieldSettings: fields,
          bottomFieldSettings: bottomFields,
        ),
      );
    }
    await _queueScopedSave(_settings);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('تمت إضافة الحقل «${label.trim()}» وحفظه فعلياً'),
        ),
      );
    }
  }

  Future<void> _editReceiverOption({int? index, String? group}) async {
    final role = group ?? 'المقدم إليه';
    final current = index == null
        ? ''
        : _settings.stakeholderOptions[role]![index];
    final controller = TextEditingController(text: current);
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          index == null ? 'إضافة اسم لجهة معنية' : 'تعديل اسم جهة معنية',
        ),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'اسم الجهة أو الشخص'),
          onSubmitted: (value) => Navigator.pop(context, value.trim()),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
    controller.dispose();
    final clean = value?.trim() ?? '';
    if (!mounted || clean.isEmpty) return;
    final grouped = <String, List<String>>{
      for (final entry in _settings.stakeholderOptions.entries)
        entry.key: [...entry.value],
    };
    final options = grouped[role] ?? <String>[];
    final duplicate = options.indexWhere(
      (item) => item == clean && item != current,
    );
    if (duplicate >= 0) return;
    if (index == null) {
      options.add(clean);
    } else {
      options[index] = clean;
    }
    grouped[role] = options;
    setState(
      () => _settings = _settings.copyWith(
        stakeholderOptions: grouped,
        receiverOptions: grouped['المقدم إليه'] ?? const [],
        requesterHistory: grouped['مقدم الطلب'] ?? const [],
      ),
    );
  }

  void _removeReceiverOption(int index, String group) {
    final grouped = <String, List<String>>{
      for (final entry in _settings.stakeholderOptions.entries)
        entry.key: [...entry.value],
    };
    final options = grouped[group] ?? <String>[];
    if (index < 0 || index >= options.length) return;
    options.removeAt(index);
    grouped[group] = options;
    setState(
      () => _settings = _settings.copyWith(
        stakeholderOptions: grouped,
        receiverOptions: grouped['المقدم إليه'] ?? const [],
        requesterHistory: grouped['مقدم الطلب'] ?? const [],
      ),
    );
  }

  void _changeField(
    String key,
    FieldSetting Function(FieldSetting current) change, {
    bool preserveGeometry = true,
  }) {
    final current = _activeFields[key];
    if (current == null) return;
    final fields = Map<String, FieldSetting>.from(_activeFields);
    final changed = change(current);
    fields[key] = preserveGeometry
        ? changed.copyWith(
            x: current.x,
            y: current.y,
            width: current.width,
            height: current.height,
            bottomX: current.bottomX,
            bottomY: current.bottomY,
            bottomWidth: current.bottomWidth,
            geometryConfigured: current.geometryConfigured,
          )
        : changed;
    var updated = _editingCustomerFields
        ? _settings.copyWith(customerFieldSettings: fields)
        : _settings.copyWith(fieldSettings: fields);
    if (!_editingCustomerFields && key == 'account') {
      updated = updated.copyWith(
        showAccountField: fields[key]!.visible,
        requireAccountField: fields[key]!.required,
      );
    }
    if (!_editingCustomerFields && key == 'signatures') {
      updated = updated.copyWith(
        showSignatures: fields[key]!.visible,
        requireApprovals: fields[key]!.required,
      );
    }
    setState(() => _settings = updated);
    _queueScopedSave(updated);
  }

  void _changeMemoField(
    String key,
    FieldSetting Function(FieldSetting current) change, {
    bool preserveGeometry = true,
  }) {
    final current = _activeMemoFields[key];
    if (current == null) return;
    final fields = Map<String, FieldSetting>.from(_activeMemoFields);
    final changed = change(current);
    fields[key] = preserveGeometry
        ? changed.copyWith(
            x: current.x,
            y: current.y,
            width: current.width,
            height: current.height,
            bottomX: current.bottomX,
            bottomY: current.bottomY,
            bottomWidth: current.bottomWidth,
            geometryConfigured: current.geometryConfigured,
          )
        : changed;
    final updated = _settings.copyWith(memoFullA4FieldSettings: fields);
    setState(() => _settings = updated);
    _queueScopedSave(updated);
  }

  String? get _commonFontFamily {
    final fields = _isMemo ? _settings.memoFullA4FieldSettings : _activeFields;
    if (fields.isEmpty) return null;
    final first = fields.values.first.fontFamily;
    return fields.values.every((field) => field.fontFamily == first)
        ? first
        : null;
  }

  void _applyGlobalFontFamily(String fontFamily) {
    final fields = _isMemo ? _settings.memoFullA4FieldSettings : _activeFields;
    if (fields.isEmpty) return;
    final updatedFields = <String, FieldSetting>{
      for (final entry in fields.entries)
        entry.key: entry.value.copyWith(fontFamily: fontFamily),
    };
    final updated = _isMemo
        ? _settings.copyWith(memoFullA4FieldSettings: updatedFields)
        : _editingCustomerFields
        ? _settings.copyWith(customerFieldSettings: updatedFields)
        : _settings.copyWith(fieldSettings: updatedFields);
    setState(() => _settings = updated);
    _queueScopedSave(updated);
  }

  Widget _buildMemoFieldEditor(String key) {
    final setting = _activeMemoFields[key];
    if (setting == null) return const SizedBox.shrink();
    return _FieldSettingEditor(
      key: ValueKey('memo_a4_$key'),
      id: key,
      setting: setting,
      maxY: 841.89,
      maxX: 595.28,
      onVisibleChanged: (value) =>
          _changeMemoField(key, (current) => current.copyWith(visible: value)),
      onRequiredChanged: (value) =>
          _changeMemoField(key, (current) => current.copyWith(required: value)),
      onFontSizeChanged: (value) =>
          _changeMemoField(key, (current) => current.copyWith(fontSize: value)),
      onLabelChanged: (value) =>
          _changeMemoField(key, (current) => current.copyWith(label: value)),
      onColorChanged: (value) => _changeMemoField(
        key,
        (current) => current.copyWith(colorValue: value),
      ),
      onXChanged: (value) => _changeMemoField(
        key,
        (current) => current.copyWith(x: value, geometryConfigured: true),
        preserveGeometry: false,
      ),
      onYChanged: (value) => _changeMemoField(
        key,
        (current) => current.copyWith(y: value, geometryConfigured: true),
        preserveGeometry: false,
      ),
      onWidthChanged: (value) => _changeMemoField(
        key,
        (current) => current.copyWith(width: value, geometryConfigured: true),
        preserveGeometry: false,
      ),
      onHeightChanged: (value) => _changeMemoField(
        key,
        (current) => current.copyWith(height: value, geometryConfigured: true),
        preserveGeometry: false,
      ),
      onMaxLengthChanged: (value) => _changeMemoField(
        key,
        (current) => current.copyWith(maxLength: value),
      ),
      onFontFamilyChanged: (value) => _changeMemoField(
        key,
        (current) => current.copyWith(fontFamily: value),
      ),
      onFontWeightChanged: (value) => _changeMemoField(
        key,
        (current) => current.copyWith(fontWeight: value),
      ),
      onFontStyleChanged: (value) => _changeMemoField(
        key,
        (current) => current.copyWith(fontStyle: value),
      ),
      onAlignmentChanged: (value) => _changeMemoField(
        key,
        (current) => current.copyWith(alignment: value),
      ),
      onLineHeightChanged: (value) => _changeMemoField(
        key,
        (current) => current.copyWith(lineHeight: value),
      ),
      onInputTypeChanged: (value) => _changeMemoField(
        key,
        (current) => current.copyWith(inputType: value),
      ),
      onDelete: () => _deleteMemoField(key),
    );
  }

  Future<void> _deleteField(String key) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف الحقل؟'),
        content: Text(
          'سيختفي حقل «${_activeFields[key]?.label ?? key}» من الإدخال والمعاينة والطباعة.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف نهائي'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final fields = Map<String, FieldSetting>.from(_activeFields)..remove(key);
    setState(() {
      if (_editingCustomerFields) {
        _settings = _settings.copyWith(customerFieldSettings: fields);
      } else if (_editingBottomCopy) {
        final topFields = Map<String, FieldSetting>.from(
          _settings.fieldSettings,
        );
        if (key.startsWith('custom_')) topFields.remove(key);
        _settings = _settings.copyWith(
          fieldSettings: topFields,
          bottomFieldSettings: fields,
        );
      } else {
        final bottomFields = Map<String, FieldSetting>.from(
          _settings.bottomFieldSettings,
        );
        if (key.startsWith('custom_')) bottomFields.remove(key);
        _settings = _settings.copyWith(
          fieldSettings: fields,
          bottomFieldSettings: bottomFields,
        );
      }
    });
    await _queueScopedSave(_settings);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حذف الحقل وحفظ التغيير فعلياً')),
      );
    }
  }

  Future<void> _deleteMemoField(String key) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف الحقل؟'),
        content: Text(
          'سيختفي حقل «${_activeMemoFields[key]?.label ?? key}» من المذكرة والمعاينة والطباعة.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف نهائي'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final fields = Map<String, FieldSetting>.from(_activeMemoFields)
      ..remove(key);
    final updated = _settings.copyWith(memoFullA4FieldSettings: fields);
    setState(() => _settings = updated);
    await _queueScopedSave(updated);
  }

  Widget _buildFieldEditor(String key) {
    final setting = _activeFields[key];
    if (setting == null) return const SizedBox.shrink();

    return _FieldSettingEditor(
      key: ValueKey('${_editingBottomCopy ? 'bottom' : 'top'}_$key'),
      id: key,
      setting: setting,
      maxY: _settingsScope == 'travelAllowance'
          ? 595.28
          : _editingCustomerFields
          ? 792
          : 841.89,
      maxX: _settingsScope == 'travelAllowance'
          ? 841.89
          : _editingCustomerFields
          ? 612
          : 595.28,
      onVisibleChanged: (value) =>
          _changeField(key, (current) => current.copyWith(visible: value)),
      onRequiredChanged: (value) =>
          _changeField(key, (current) => current.copyWith(required: value)),
      onFontSizeChanged: (value) =>
          _changeField(key, (current) => current.copyWith(fontSize: value)),
      onLabelChanged: (value) =>
          _changeField(key, (current) => current.copyWith(label: value)),
      onColorChanged: (value) =>
          _changeField(key, (current) => current.copyWith(colorValue: value)),
      onXChanged: (value) => _changeField(
        key,
        (current) => current.copyWith(x: value, geometryConfigured: true),
        preserveGeometry: false,
      ),
      onYChanged: (value) => _changeField(
        key,
        (current) => current.copyWith(y: value, geometryConfigured: true),
        preserveGeometry: false,
      ),
      onWidthChanged: (value) => _changeField(
        key,
        (current) => current.copyWith(width: value, geometryConfigured: true),
        preserveGeometry: false,
      ),
      onHeightChanged: (value) => _changeField(
        key,
        (current) => current.copyWith(height: value, geometryConfigured: true),
        preserveGeometry: false,
      ),
      onMaxLengthChanged: (value) =>
          _changeField(key, (current) => current.copyWith(maxLength: value)),
      onFontFamilyChanged: (value) =>
          _changeField(key, (current) => current.copyWith(fontFamily: value)),
      onFontWeightChanged: (value) =>
          _changeField(key, (current) => current.copyWith(fontWeight: value)),
      onFontStyleChanged: (value) =>
          _changeField(key, (current) => current.copyWith(fontStyle: value)),
      onAlignmentChanged: (value) =>
          _changeField(key, (current) => current.copyWith(alignment: value)),
      onLineHeightChanged: (value) =>
          _changeField(key, (current) => current.copyWith(lineHeight: value)),
      onInputTypeChanged: (value) =>
          _changeField(key, (current) => current.copyWith(inputType: value)),
      onDelete: () => _deleteField(key),
    );
  }

  Future<void> _exportPatterns() async {
    try {
      final password = await _backupPassword(confirm: true);
      if (password == null) return;
      final uri = await PatternExport.exportEncryptedPatterns(
        password: password,
      );
      if (!mounted || uri == null) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تم تصدير الأنماط والمواضع إلى $uri')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('تعذر تصدير الأنماط: $error')));
    }
  }

  Future<void> _importPatterns() async {
    try {
      final password = await _backupPassword(confirm: false);
      if (password == null) return;
      final count = await PatternExport.importEncryptedPatterns(
        password: password,
      );
      if (!mounted || count == null) return;
      final refreshed = await PatternStore.load(scope: _settingsScope);
      if (!mounted) return;
      setState(() => _savedPatterns = refreshed);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تم استيراد $count نمطاً وموضعاً')),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('تعذر استيراد الأنماط: $error')));
    }
  }

  Future<String?> _backupPassword({required bool confirm}) async {
    final password = TextEditingController();
    final confirmation = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(confirm ? 'تشفير النسخة الاحتياطية' : 'كلمة مرور النسخة'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: password,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'كلمة المرور'),
            ),
            if (confirm)
              TextField(
                controller: confirmation,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'تأكيد كلمة المرور',
                ),
              ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () {
              if (password.text.trim().length < 8) return;
              if (confirm && password.text != confirmation.text) return;
              Navigator.pop(context, password.text);
            },
            child: const Text('متابعة'),
          ),
        ],
      ),
    );
    password.dispose();
    confirmation.dispose();
    return value;
  }

  Future<void> _exportBackup({bool toGoogleDrive = false}) async {
    try {
      final settingsByScope = <String, AppSettings>{
        for (final scope in backupSettingsScopes)
          scope: await SettingsStore.load(scope: scope),
      };
      final masterPatterns = <String, SavedPattern>{};
      for (final scope in {...requiredBackupScopes, 'global'}) {
        final pattern = await PatternStore.loadMaster(scope: scope);
        if (pattern != null) masterPatterns[scope] = pattern;
      }
      final json = await BackupService.buildPlainBackupJson(
        settings: settingsByScope['expenseRequest'] ?? _settings,
        requests: await RequestStore.load(),
        reminders: await ReminderStore.load(),
        debts: await DebtStore.load(),
        notes: await NotesStore.load(),
        quickStatements: {
          for (final scope in requiredBackupScopes)
            scope: await QuickStatementStore.load(scope),
        },
        settingsByScope: settingsByScope,
        savedPatterns: await PatternStore.load(),
        masterPatternsByScope: masterPatterns,
      );

      final localPath = await BackupService.saveLocalJsonBackup(json);
      if (toGoogleDrive) {
        final record = await GoogleDriveBackupService.instance.upload(
          bytes: Uint8List.fromList(utf8.encode(json)),
          fileName: 'alfa_expense_app_backup_v4.json',
        );
        if (!mounted) return;
        setState(() {});
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'تم رفع النسخة غير المشفرة إلى Google Drive وحفظ نسخة محلية: ${record.name}',
            ),
          ),
        );
        return;
      }

      final uri = await FilePicker.saveFile(
        dialogTitle: 'حفظ نسخة احتياطية غير مشفرة خارج التطبيق',
        fileName: 'alfa_expense_app_backup_v4.json',
        type: FileType.custom,
        allowedExtensions: ['json'],
        bytes: Uint8List.fromList(utf8.encode(json)),
      );
      if (!mounted) return;
      final message = uri == null
          ? 'تم حفظ نسخة غير مشفرة داخل التطبيق. يمكنك إدارتها من مدير النسخ المحلية.'
          : 'تم تصدير نسخة غير مشفرة وحُفظت نسخة استعادة داخل التطبيق.';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('$message\nالمسار المحلي: $localPath'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('تعذر تصدير النسخة الاحتياطية: $error'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  Future<void> _importBackup({bool fromGoogleDrive = false}) async {
    try {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (context) => AlertDialog(
          title: const Text('استبدال البيانات؟'),
          content: const Text(
            'سيتم استبدال البيانات الحالية بالنسخة المستوردة.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('متابعة'),
            ),
          ],
        ),
      );
      if (confirmed != true) return;
      BackupData? backup;
      if (fromGoogleDrive) {
        final records = await GoogleDriveBackupService.instance.list();
        if (records.isEmpty) {
          throw StateError('لا توجد نسخ احتياطية في Google Drive');
        }
        if (!mounted) return;
        final selected = await showDialog<GoogleDriveBackupRecord>(
          context: context,
          builder: (context) => SimpleDialog(
            title: const Text('اختر نسخة من Google Drive'),
            children: records
                .map(
                  (record) => SimpleDialogOption(
                    onPressed: () => Navigator.pop(context, record),
                    child: ListTile(
                      title: Text(record.name),
                      subtitle: Text(
                        '${record.createdTime ?? 'تاريخ غير معروف'} — ${record.size ?? 0} بايت',
                      ),
                    ),
                  ),
                )
                .toList(),
          ),
        );
        if (selected == null) return;
        final bytes = await GoogleDriveBackupService.instance.download(
          selected.id,
        );
        backup = await BackupService.decodeAnyBackup(
          utf8.decode(bytes),
          passwordProvider: () => _backupPassword(confirm: false),
        );
      } else {
        backup = await BackupService.importAnyBackup(
          passwordProvider: () => _backupPassword(confirm: false),
        );
      }
      if (backup == null) return;
      await BackupService.restoreBackup(backup);
      if (!mounted) return;
      final restored = await SettingsStore.load(scope: _settingsScope);
      if (!mounted) return;
      setState(() => _settings = restored);
      _fillControllers(restored);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            fromGoogleDrive
                ? 'تم استيراد النسخة من Google Drive (${backup.requests.length} نموذج)'
                : 'تم استيراد ${backup.requests.length} نموذج وإعدادات التطبيق',
          ),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('تعذر استيراد النسخة الاحتياطية: $error'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  Future<void> _resetSettings() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('استعادة الإعدادات الافتراضية؟'),
        content: const Text(
          'سيتم استبدال الإعدادات العامة والمظهر والحقول بالقيم الافتراضية.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('استعادة'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    await SettingsStore.reset(scope: _settingsScope);
    final defaults = AppSettings.defaultsForScope(_settingsScope);
    if (!mounted) return;
    setState(() => _settings = defaults);
    _fillControllers(defaults);
  }

  Future<void> _saveCurrentPattern() async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حفظ نمط جديد'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'اسم النمط'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (name == null || name.isEmpty) return;
    await PatternStore.upsert(
      SavedPattern(name: name, scope: _settingsScope, settings: _settings),
    );
    if (!mounted) return;
    final refreshed = await PatternStore.load(scope: _settingsScope);
    if (!mounted) return;
    setState(() => _savedPatterns = refreshed);
  }

  Future<void> _applyPattern(SavedPattern pattern) async {
    await SettingsStore.save(pattern.settings, scope: _settingsScope);
    if (!mounted) return;
    setState(() => _settings = pattern.settings);
    _fillControllers(pattern.settings);
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text('تم تطبيق النمط: ${pattern.name}')));
  }

  Future<void> _saveMasterPattern() async {
    await PatternStore.saveMaster(_settings, scope: _settingsScope);
    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('تم حفظ النمط الرئيسي بنجاح')));
  }

  Future<void> _restoreMasterPattern() async {
    final pattern = await PatternStore.loadMaster(scope: _settingsScope);
    if (pattern == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('احفظ النمط الرئيسي أولًا من الإعدادات الحالية'),
        ),
      );
      return;
    }
    await _applyPattern(pattern);
  }

  Future<void> _deletePattern(SavedPattern pattern) async {
    if (pattern.name == 'نمط مواضع رقم 1') return;
    await PatternStore.delete(pattern.name, scope: _settingsScope);
    if (!mounted) return;
    setState(() {
      _savedPatterns = _savedPatterns
          .where((item) => item.name != pattern.name)
          .toList();
    });
  }

  Future<void> _clearAllRequests() async {
    final requests = await RequestStore.load();
    if (!mounted || requests.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('لا توجد نماذج سابقة لحذفها')),
        );
      }
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف جميع النماذج السابقة؟'),
        content: Text(
          'سيتم حذف ${requests.length} نموذجاً نهائياً، ولن تتأثر الإعدادات أو الأنماط المحفوظة.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف الكل'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await RequestStore.clear();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم حذف جميع النماذج السابقة')),
    );
  }

  Future<void> _saveSharedOptions(AppSettings updated) async {
    await SettingsStore.save(updated, scope: 'global');
    if (mounted) setState(() => _settings = updated);
  }

  Future<void> _editBranchOption({int? index}) async {
    final controller = TextEditingController(
      text: index == null ? '' : _settings.branchOptions[index],
    );
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(index == null ? 'إضافة فرع' : 'تعديل فرع'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'اسم الفرع'),
          onSubmitted: (value) => Navigator.pop(context, value.trim()),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
    controller.dispose();
    final clean = value?.trim() ?? '';
    if (!mounted || clean.isEmpty) return;
    final branches = [..._settings.branchOptions];
    if (branches.any(
      (item) => item == clean && item != (index == null ? '' : branches[index]),
    )) {
      return;
    }
    if (index == null) {
      branches.add(clean);
    } else if (index >= 0 && index < branches.length) {
      branches[index] = clean;
    }
    await _saveSharedOptions(_settings.copyWith(branchOptions: branches));
  }

  Future<void> _removeBranchOption(int index) async {
    if (index < 0 || index >= _settings.branchOptions.length) return;
    final branches = [..._settings.branchOptions]..removeAt(index);
    await _saveSharedOptions(_settings.copyWith(branchOptions: branches));
  }

  Future<void> _openQuickStatementsManager() async {
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('إعدادات العبارات السريعة'),
          content: SizedBox(
            width: 460,
            height: 460,
            child: ListView(
              children: QuickStatementStore.scopes.entries
                  .map(
                    (entry) => ListTile(
                      leading: const Icon(Icons.bolt_outlined),
                      title: Text(entry.value),
                      subtitle: const Text(
                        'إضافة وتعديل وحذف العبارات الجاهزة',
                      ),
                      onTap: () async {
                        var values = await QuickStatementStore.load(entry.key);
                        if (!context.mounted) return;
                        await showDialog<void>(
                          context: context,
                          builder: (scopeContext) => StatefulBuilder(
                            builder: (context, setScopeState) => AlertDialog(
                              title: Text('عبارات ${entry.value}'),
                              content: SizedBox(
                                width: 420,
                                height: 360,
                                child: ListView(
                                  children: [
                                    for (final value in values)
                                      ListTile(
                                        dense: true,
                                        title: Text(value),
                                        leading: const Icon(
                                          Icons.bolt_outlined,
                                        ),
                                        trailing: Wrap(
                                          children: [
                                            IconButton(
                                              tooltip: 'تعديل العبارة',
                                              icon: const Icon(
                                                Icons.edit_outlined,
                                              ),
                                              onPressed: () async {
                                                final controller =
                                                    TextEditingController(
                                                      text: value,
                                                    );
                                                final edited =
                                                    await showDialog<String>(
                                                      context: scopeContext,
                                                      builder: (context) =>
                                                          AlertDialog(
                                                            title: const Text(
                                                              'تعديل العبارة',
                                                            ),
                                                            content: TextField(
                                                              controller:
                                                                  controller,
                                                              autofocus: true,
                                                            ),
                                                            actions: [
                                                              TextButton(
                                                                onPressed: () =>
                                                                    Navigator.pop(
                                                                      context,
                                                                    ),
                                                                child:
                                                                    const Text(
                                                                      'إلغاء',
                                                                    ),
                                                              ),
                                                              FilledButton(
                                                                onPressed: () =>
                                                                    Navigator.pop(
                                                                      context,
                                                                      controller
                                                                          .text
                                                                          .trim(),
                                                                    ),
                                                                child:
                                                                    const Text(
                                                                      'حفظ',
                                                                    ),
                                                              ),
                                                            ],
                                                          ),
                                                    );
                                                controller.dispose();
                                                if (edited == null ||
                                                    edited.trim().isEmpty) {
                                                  return;
                                                }
                                                try {
                                                  await QuickStatementStore.update(
                                                    entry.key,
                                                    value,
                                                    edited,
                                                  );
                                                  values =
                                                      await QuickStatementStore.load(
                                                        entry.key,
                                                      );
                                                  setScopeState(() {});
                                                } catch (error) {
                                                  if (!mounted) return;
                                                  ScaffoldMessenger.of(
                                                    this.context,
                                                  ).showSnackBar(
                                                    SnackBar(
                                                      content: Text(
                                                        'تعذر حفظ تعديل العبارة: $error',
                                                      ),
                                                    ),
                                                  );
                                                }
                                              },
                                            ),
                                            IconButton(
                                              tooltip: 'حذف العبارة',
                                              icon: const Icon(
                                                Icons.delete_outline,
                                              ),
                                              onPressed: () async {
                                                try {
                                                  await QuickStatementStore.delete(
                                                    entry.key,
                                                    value,
                                                  );
                                                  values =
                                                      await QuickStatementStore.load(
                                                        entry.key,
                                                      );
                                                  setScopeState(() {});
                                                } catch (error) {
                                                  if (!mounted) return;
                                                  ScaffoldMessenger.of(
                                                    this.context,
                                                  ).showSnackBar(
                                                    SnackBar(
                                                      content: Text(
                                                        'تعذر حذف العبارة: $error',
                                                      ),
                                                    ),
                                                  );
                                                }
                                              },
                                            ),
                                          ],
                                        ),
                                      ),
                                    ListTile(
                                      leading: const Icon(Icons.add),
                                      title: const Text('إضافة عبارة'),
                                      onTap: () async {
                                        final controller =
                                            TextEditingController();
                                        final added = await showDialog<String>(
                                          context: scopeContext,
                                          builder: (context) => AlertDialog(
                                            title: const Text('إضافة عبارة'),
                                            content: TextField(
                                              controller: controller,
                                              autofocus: true,
                                            ),
                                            actions: [
                                              TextButton(
                                                onPressed: () =>
                                                    Navigator.pop(context),
                                                child: const Text('إلغاء'),
                                              ),
                                              FilledButton(
                                                onPressed: () => Navigator.pop(
                                                  context,
                                                  controller.text.trim(),
                                                ),
                                                child: const Text('حفظ'),
                                              ),
                                            ],
                                          ),
                                        );
                                        controller.dispose();
                                        if (added == null ||
                                            added.trim().isEmpty) {
                                          return;
                                        }
                                        try {
                                          await QuickStatementStore.add(
                                            entry.key,
                                            added,
                                          );
                                          values =
                                              await QuickStatementStore.load(
                                                entry.key,
                                              );
                                          setScopeState(() {});
                                        } catch (error) {
                                          if (!mounted) return;
                                          ScaffoldMessenger.of(
                                            this.context,
                                          ).showSnackBar(
                                            SnackBar(
                                              content: Text(
                                                'تعذر حفظ العبارة: $error',
                                              ),
                                            ),
                                          );
                                        }
                                      },
                                    ),
                                  ],
                                ),
                              ),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(scopeContext),
                                  child: const Text('إغلاق'),
                                ),
                              ],
                            ),
                          ),
                        );
                        setDialogState(() {});
                      },
                    ),
                  )
                  .toList(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('إغلاق'),
            ),
          ],
        ),
      ),
    );
  }

  String? _required(String? value) {
    if (value == null || value.trim().isEmpty) return 'هذا الحقل مطلوب';
    return null;
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_loadError != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('الإعدادات')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, size: 52),
                const SizedBox(height: 12),
                Text(_loadError!, textAlign: TextAlign.center),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: () {
                    setState(() {
                      _isLoading = true;
                      _loadError = null;
                    });
                    unawaited(_loadSettings());
                  },
                  icon: const Icon(Icons.refresh),
                  label: const Text('إعادة المحاولة'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.templateKind == null
              ? 'الإعدادات'
              : 'إعدادات ${widget.templateKind!.title}',
        ),
        actions: [
          IconButton(
            tooltip: 'حفظ الإعدادات',
            onPressed: _isSaving ? null : _saveSettings,
            icon: _isSaving
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.save_outlined),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1100),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
              children: [
                if (!_isScoped)
                  _SettingsSection(
                    title: 'إعدادات الحسابات والديون',
                    icon: Icons.account_balance_wallet_outlined,
                    children: [
                      const Text(
                        'إعدادات مستقلة للعملة وعنوان التقرير والمنازل العشرية لوحدة الحسابات والديون.',
                      ),
                      const SizedBox(height: 8),
                      OutlinedButton.icon(
                        onPressed: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => const DebtSettingsScreen(),
                          ),
                        ),
                        icon: const Icon(Icons.settings_outlined),
                        label: const Text('فتح إعدادات الحسابات والديون'),
                      ),
                    ],
                  ),
                if (!_isScoped)
                  _SettingsSection(
                    title: 'دليل الأصناف',
                    icon: Icons.inventory_2_outlined,
                    children: [
                      const Text(
                        'أدر أصناف نموذج طلب العينات واستوردها من ملفات Excel مع معاينة قبل الحفظ.',
                      ),
                      const SizedBox(height: 8),
                      OutlinedButton.icon(
                        onPressed: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => const ProductCatalogScreen(),
                          ),
                        ),
                        icon: const Icon(Icons.inventory_2_outlined),
                        label: const Text('فتح دليل الأصناف'),
                      ),
                    ],
                  ),
                if (!_isScoped) ...[
                  _SettingsSection(
                    title: 'الفروع المشتركة',
                    icon: Icons.account_balance_outlined,
                    children: [
                      const Text(
                        'تظهر هذه الفروع في النماذج التي تحتوي على خانة الفرع، مع الاحتفاظ بأي فروع خاصة محفوظة داخل نموذج سابق.',
                      ),
                      ..._settings.branchOptions.asMap().entries.map(
                        (entry) => ListTile(
                          contentPadding: EdgeInsets.zero,
                          title: Text(entry.value),
                          leading: const Icon(Icons.location_on_outlined),
                          trailing: Wrap(
                            spacing: 4,
                            children: [
                              IconButton(
                                tooltip: 'تعديل الفرع',
                                onPressed: () =>
                                    _editBranchOption(index: entry.key),
                                icon: const Icon(Icons.edit_outlined),
                              ),
                              IconButton(
                                tooltip: 'حذف الفرع',
                                onPressed: () => _removeBranchOption(entry.key),
                                icon: const Icon(Icons.delete_outline),
                              ),
                            ],
                          ),
                        ),
                      ),
                      OutlinedButton.icon(
                        onPressed: _editBranchOption,
                        icon: const Icon(Icons.add),
                        label: const Text('إضافة فرع'),
                      ),
                    ],
                  ),
                  _SettingsSection(
                    title: 'العبارات السريعة',
                    icon: Icons.bolt_outlined,
                    children: [
                      const Text(
                        'أدر العبارات الجاهزة لكل نموذج من مكان واحد. لن تتأثر العبارات القديمة المحفوظة في النماذج.',
                      ),
                      OutlinedButton.icon(
                        onPressed: _openQuickStatementsManager,
                        icon: const Icon(Icons.tune_outlined),
                        label: const Text('فتح إعدادات العبارات السريعة'),
                      ),
                    ],
                  ),
                  _SettingsSection(
                    title: 'الجهات المعنية',
                    icon: Icons.people_alt_outlined,
                    children: [
                      const Text(
                        'أدر أسماء الجهات والأشخاص حسب الدور. ستظهر القوائم المناسبة عند تعبئة كل حقل، مع بقاء الإدخال اليدوي متاحًا.',
                      ),
                      ..._settings.stakeholderOptions.entries.expand(
                        (group) => [
                          ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: Text(
                              group.key,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            leading: const Icon(Icons.account_tree_outlined),
                          ),
                          ...group.value.asMap().entries.map(
                            (entry) => ListTile(
                              contentPadding: EdgeInsets.zero,
                              title: Text(entry.value),
                              leading: const Icon(Icons.person_outline),
                              trailing: Wrap(
                                spacing: 4,
                                children: [
                                  IconButton(
                                    tooltip: 'تعديل',
                                    onPressed: () => _editReceiverOption(
                                      index: entry.key,
                                      group: group.key,
                                    ),
                                    icon: const Icon(Icons.edit_outlined),
                                  ),
                                  IconButton(
                                    tooltip: 'حذف',
                                    onPressed: () => _removeReceiverOption(
                                      entry.key,
                                      group.key,
                                    ),
                                    icon: const Icon(Icons.delete_outline),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                      OutlinedButton.icon(
                        onPressed: () async {
                          final group = await showDialog<String>(
                            context: context,
                            builder: (context) => SimpleDialog(
                              title: const Text('اختر الدور'),
                              children: _settings.stakeholderOptions.keys
                                  .map(
                                    (role) => SimpleDialogOption(
                                      onPressed: () =>
                                          Navigator.pop(context, role),
                                      child: Text(role),
                                    ),
                                  )
                                  .toList(),
                            ),
                          );
                          if (group != null && mounted) {
                            await _editReceiverOption(group: group);
                          }
                        },
                        icon: const Icon(Icons.add),
                        label: const Text('إضافة اسم لجهة معنية'),
                      ),
                    ],
                  ),
                ],
                if (_isScoped && !_isMemo) ...[
                  _SettingsSection(
                    title: _isCustomer
                        ? 'حقول نموذج العملاء'
                        : 'حقول $_settingsScope',
                    icon: Icons.view_list_outlined,
                    children: [
                      Text(
                        _settingsScope == 'sampleRequestSinglePage'
                            ? 'فعّل إظهار حقول نموذج طلب العينات ذي الصفحة الواحدة لتظهر في التعبئة والمعاينة وملف PDF.'
                            : 'فعّل إظهار أي حقل ليظهر في شاشة التعبئة والمعاينة وملف PDF. يعتمد طلب الصرف على تخطيط موحد للنسختين.',
                      ),
                      if (_settingsScope == 'sampleRequest' ||
                          _settingsScope == 'sampleRequestSinglePage')
                        OutlinedButton.icon(
                          onPressed: _openSamplePositionEditor,
                          icon: const Icon(Icons.open_with_outlined),
                          label: Text(
                            _settingsScope == 'sampleRequestSinglePage'
                                ? 'إعدادات مواضع الصفحة الواحدة'
                                : 'إعدادات المواضع اليدوية — الصفحات الثلاث',
                          ),
                        ),
                      OutlinedButton.icon(
                        onPressed: _addCustomField,
                        icon: const Icon(Icons.add_box_outlined),
                        label: const Text('إضافة حقل جديد'),
                      ),
                    ],
                  ),
                  if (_structuredFieldKeys.isNotEmpty)
                    _SettingsSection(
                      title: _settingsScope == 'clearanceRequest'
                          ? 'حقول صفوف إخلاء العهدة'
                          : _settingsScope == 'fuelRequest'
                          ? 'حقول صفوف تعبئة الوقود'
                          : _settingsScope == 'sampleRequestSinglePage'
                          ? 'حقول أصناف الصفحة الواحدة'
                          : 'حقول أسماء أصناف الخدمة',
                      icon: Icons.table_rows_outlined,
                      children: [
                        const Text(
                          'يمكن إظهار الحقول وتعديل تسمياتها ومواضعها، وستنعكس الإعدادات على الإدخال والمعاينة والطباعة.',
                        ),
                        ..._structuredFieldKeys
                            .where((key) => _activeFields.containsKey(key))
                            .map(_buildFieldEditor),
                      ],
                    ),
                  _SettingsSection(
                    title: _isCustomer
                        ? 'مواضع نموذج العملاء'
                        : 'مواضع $_settingsScope',
                    icon: Icons.edit_note_outlined,
                    children: [
                      Text(
                        _isCustomer
                            ? 'تظهر حقول نموذج العملاء فقط، ويمكن تعديل مواضعها مباشرة.'
                            : 'تظهر الحقول هنا حسب ترتيبها من أعلى النموذج إلى أسفله، ويشمل ذلك البيان.',
                      ),
                      ...(_settingsScope == 'serviceRequest'
                              ? _serviceOrderedFieldKeys
                              : _settingsScope == 'fuelRequest'
                              ? _fuelOrderedFieldKeys
                              : _settingsScope == 'sampleRequestSinglePage'
                              ? _sampleSinglePageOrderedFieldKeys
                              : _settingsScope == 'travelAllowance'
                              ? _travelAllowanceOrderedFieldKeys
                              : _orderedFieldKeys)
                          .where((key) => _activeFields.containsKey(key))
                          .map(_buildFieldEditor),
                      ..._activeFields.entries
                          .where(
                            (entry) =>
                                (_editingCustomerFields ||
                                    entry.key.startsWith('custom_')) &&
                                !(_settingsScope == 'serviceRequest'
                                        ? _serviceOrderedFieldKeys
                                        : _settingsScope == 'fuelRequest'
                                        ? _fuelOrderedFieldKeys
                                        : _settingsScope ==
                                              'sampleRequestSinglePage'
                                        ? _sampleSinglePageOrderedFieldKeys
                                        : _settingsScope == 'travelAllowance'
                                        ? _travelAllowanceOrderedFieldKeys
                                        : _orderedFieldKeys)
                                    .contains(entry.key),
                          )
                          .map((entry) => _buildFieldEditor(entry.key)),
                    ],
                  ),
                ],
                if (_isMemo) ...[
                  _SettingsSection(
                    title: 'المذكرة الداخلية',
                    icon: Icons.article_outlined,
                    children: [
                      const Text(
                        'هذه الإعدادات خاصة بالمذكرة ولا تغيّر مواضع طلب الصرف.',
                      ),
                      const Divider(),
                      const ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: Icon(Icons.description_outlined),
                        title: Text('مذكرة داخلية — A4 كاملة'),
                        subtitle: Text(
                          'قالب مستقل ثابت: صفحة واحدة بالطول — 595.28 × 841.89 نقطة',
                        ),
                      ),
                      ...[
                        'receiver',
                        'date',
                        'statement',
                        'requesterName',
                      ].map(_buildMemoFieldEditor),
                      const SizedBox(height: 10),
                      FilledButton.icon(
                        onPressed: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => MemoPreviewScreen(
                              settings: _settings,
                              layout: InternalMemoLayout.fullA4,
                            ),
                          ),
                        ),
                        icon: const Icon(Icons.picture_as_pdf_outlined),
                        label: const Text('معاينة PDF الحية للمذكرة'),
                      ),
                      OutlinedButton.icon(
                        onPressed: () async {
                          final messenger = ScaffoldMessenger.of(context);
                          final updated = await Navigator.of(context)
                              .push<AppSettings>(
                                MaterialPageRoute(
                                  builder: (_) => TemplatePreviewScreen(
                                    settings: _settings,
                                    templateScope: 'internalMemo',
                                    editMemoA4: true,
                                  ),
                                ),
                              );
                          if (!mounted || updated == null) return;
                          setState(() => _settings = updated);
                          await SettingsStore.save(
                            updated,
                            scope: _settingsScope,
                          );
                          if (!mounted) return;
                          messenger.showSnackBar(
                            const SnackBar(
                              content: Text('تم حفظ مواضع مذكرة A4 فعليًا'),
                              behavior: SnackBarBehavior.floating,
                            ),
                          );
                        },
                        icon: const Icon(Icons.open_with_outlined),
                        label: const Text('محرر مواضع مذكرة A4'),
                      ),
                    ],
                  ),
                ],
                if (!_isScoped) ...[
                  _SettingsSection(
                    title: 'العملة والمبالغ',
                    icon: Icons.currency_exchange_outlined,
                    children: [
                      _SettingsTextField(
                        controller: _currencyController,
                        label: 'اسم العملة',
                        validator: _required,
                      ),
                      _SettingsTextField(
                        controller: _fractionController,
                        label: 'اسم الجزء العشري',
                        validator: _required,
                      ),
                      SwitchListTile.adaptive(
                        contentPadding: EdgeInsets.zero,
                        title: const Text('التفقيط التلقائي'),
                        value: _settings.autoSpelling,
                        onChanged: (value) => setState(
                          () => _settings = _settings.copyWith(
                            autoSpelling: value,
                          ),
                        ),
                      ),
                      TextFormField(
                        initialValue: _settings.maxStructuredDataCharacters
                            .toString(),
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(
                          labelText:
                              'إجمالي أحرف صفوف إخلاء العهدة وأصناف الخدمة',
                          helperText:
                              'يمنع الحفظ والطباعة عند تجاوز المساحة المحددة للنموذج.',
                        ),
                        onChanged: (value) {
                          final parsed = int.tryParse(value);
                          if (parsed != null && parsed >= 100) {
                            setState(
                              () => _settings = _settings.copyWith(
                                maxStructuredDataCharacters: parsed,
                              ),
                            );
                          }
                        },
                      ),
                      const Text(
                        'تُستخدم هذه الإعدادات مع مبالغ طلب الصرف فقط.',
                      ),
                    ],
                  ),
                  _SettingsSection(
                    title: 'البيانات الافتراضية لتقارير المندوبين الجديدة',
                    icon: Icons.badge_outlined,
                    children: [
                      const Text(
                        'تُستخدم هذه القيم عند إنشاء تقرير مندوب جديد فقط، ولا تغيّر التقارير المحفوظة سابقًا.',
                      ),
                      _SettingsTextField(
                        controller: _representativeMedRepController,
                        label: 'اسم المندوب',
                      ),
                      _SettingsTextField(
                        controller: _representativeCityController,
                        label: 'المدينة',
                      ),
                      _SettingsTextField(
                        controller: _representativeDistrictController,
                        label: 'المنطقة أو المحافظة',
                      ),
                      _SettingsTextField(
                        controller: _representativeSectionController,
                        label: 'القسم',
                      ),
                    ],
                  ),
                  _SettingsSection(
                    title: 'الخطوط والألوان',
                    icon: Icons.palette_outlined,
                    children: [
                      Text(
                        'حجم الخط: ${_settings.fontSize.toStringAsFixed(0)}',
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                      Slider(
                        min: 10,
                        max: 22,
                        divisions: 24,
                        value: _settings.fontSize,
                        label: _settings.fontSize.toStringAsFixed(1),
                        onChanged: (value) => setState(
                          () => _settings = _settings.copyWith(fontSize: value),
                        ),
                      ),
                      DropdownButtonFormField<String>(
                        initialValue: _commonFontFamily,
                        isExpanded: true,
                        decoration: const InputDecoration(
                          labelText: 'الخط العام للنموذج',
                          helperText:
                              'يطبّق الخط على جميع حقول هذا النموذج دون تغيير مواضعها',
                        ),
                        items: const [
                          DropdownMenuItem(
                            value: 'Noto Kufi Arabic',
                            child: Text('Noto Kufi Arabic'),
                          ),
                          DropdownMenuItem(
                            value: 'Noto Sans Arabic',
                            child: Text('Noto Sans Arabic'),
                          ),
                          DropdownMenuItem(
                            value: 'Noto Naskh Arabic',
                            child: Text('نسخ واضح — Noto Naskh Arabic'),
                          ),
                          DropdownMenuItem(
                            value: 'Cairo',
                            child: Text('Cairo'),
                          ),
                          DropdownMenuItem(
                            value: 'Tajawal',
                            child: Text('Tajawal'),
                          ),
                          DropdownMenuItem(
                            value: 'Changa',
                            child: Text('Changa'),
                          ),
                          DropdownMenuItem(
                            value: 'El Messiri',
                            child: Text('El Messiri'),
                          ),
                          DropdownMenuItem(
                            value: 'Reem Kufi',
                            child: Text('Reem Kufi'),
                          ),
                          DropdownMenuItem(
                            value: 'Aref Ruqaa',
                            child: Text('Aref Ruqaa'),
                          ),
                          DropdownMenuItem(
                            value: 'Lateef',
                            child: Text('Lateef'),
                          ),
                          DropdownMenuItem(
                            value: 'Katibeh',
                            child: Text('Katibeh'),
                          ),
                          DropdownMenuItem(
                            value: 'Lemonada',
                            child: Text('Lemonada'),
                          ),
                        ],
                        onChanged: (value) {
                          if (value != null) _applyGlobalFontFamily(value);
                        },
                      ),
                      _ColorPalette(
                        label: 'لون التطبيق (الشريط والأزرار)',
                        selectedValue: _settings.primaryColorValue,
                        colors: const [
                          0xFF4A90E2,
                          0xFF5CB8E6,
                          0xFF1F4E79,
                          0xFF0D5961,
                          0xFF6A3D75,
                          0xFFD4AF37,
                        ],
                        onChanged: (value) => setState(
                          () => _settings = _settings.copyWith(
                            primaryColorValue: value,
                          ),
                        ),
                      ),
                      _ColorPalette(
                        label: 'لون الخط',
                        selectedValue: _settings.textColorValue,
                        colors: const [
                          0xFF202124,
                          0xFF263238,
                          0xFF0D47A1,
                          0xFF004D40,
                          0xFF5D4037,
                          0xFF6A1B9A,
                          0xFFB71C1C,
                          0xFFFFFFFF,
                        ],
                        onChanged: (value) => setState(
                          () => _settings = _settings.copyWith(
                            textColorValue: value,
                          ),
                        ),
                      ),
                      _ColorPalette(
                        label: 'لون الكتابة فوق النماذج',
                        selectedValue: _settings.printedTextColorValue,
                        colors: const [
                          0xFF000000,
                          0xFF202124,
                          0xFF0D47A1,
                          0xFF004D40,
                          0xFF5D4037,
                          0xFF6A1B9A,
                          0xFFB71C1C,
                          0xFFFFFFFF,
                        ],
                        onChanged: (value) => setState(
                          () => _settings = _settings.copyWith(
                            printedTextColorValue: value,
                          ),
                        ),
                      ),
                      _ColorPalette(
                        label: 'لون الخلفية',
                        selectedValue: _settings.backgroundColorValue,
                        colors: const [
                          0xFFD4AF37,
                          0xFFFFD700,
                          0xFFF6E7B0,
                          0xFFF4F7FB,
                          0xFFE3F2FD,
                          0xFFE8F5E9,
                          0xFFFCE4EC,
                          0xFFFFFFFF,
                        ],
                        onChanged: (value) => setState(
                          () => _settings = _settings.copyWith(
                            backgroundColorValue: value,
                          ),
                        ),
                      ),
                      _ColorPalette(
                        label: 'لون الخانات',
                        selectedValue: _settings.fieldBackgroundColorValue,
                        colors: const [
                          0xFFFFFFFF,
                          0xFFFFFDF5,
                          0xFFFFF3CD,
                          0xFFE3F2FD,
                          0xFFE8F5E9,
                          0xFFF3E5F5,
                        ],
                        onChanged: (value) => setState(
                          () => _settings = _settings.copyWith(
                            fieldBackgroundColorValue: value,
                          ),
                        ),
                      ),
                      DropdownButtonFormField<TemplateMode>(
                        initialValue: _settings.templateMode,
                        decoration: const InputDecoration(
                          labelText: 'طريقة بناء PDF',
                        ),
                        items: const [
                          DropdownMenuItem(
                            value: TemplateMode.original,
                            child: Text('القالب الأصلي عالي المطابقة'),
                          ),
                          DropdownMenuItem(
                            value: TemplateMode.editable,
                            child: Text('قالب متجهي قابل للتحرير'),
                          ),
                        ],
                        onChanged: (value) {
                          if (value != null) {
                            setState(
                              () => _settings = _settings.copyWith(
                                templateMode: value,
                              ),
                            );
                          }
                        },
                      ),
                      SwitchListTile.adaptive(
                        contentPadding: EdgeInsets.zero,
                        title: const Text('الوضع الداكن'),
                        value: _settings.darkMode,
                        onChanged: (value) => setState(
                          () => _settings = _settings.copyWith(darkMode: value),
                        ),
                      ),
                    ],
                  ),
                  _SettingsSection(
                    title: 'لون الكتابة المطبوعة لكل نموذج',
                    icon: Icons.format_color_text_outlined,
                    children: [
                      const Text(
                        'كل اختيار هنا محفوظ في نطاق مستقل، ولا يغيّر لون أي نموذج آخر.',
                      ),
                      for (final scope in _printedColorScopes)
                        _ColorPalette(
                          label: _printedColorLabels[scope]!,
                          selectedValue:
                              _printedColorsByScope[scope] ??
                              AppSettings.defaultsForScope(
                                scope,
                              ).printedTextColorValue,
                          colors: const [
                            0xFF000000,
                            0xFF202124,
                            0xFF0D47A1,
                            0xFF004D40,
                            0xFF5D4037,
                            0xFF6A1B9A,
                            0xFFB71C1C,
                            0xFFFFFFFF,
                          ],
                          onChanged: (value) => _savePrintedColor(scope, value),
                        ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  FilledButton.icon(
                    onPressed: _isSaving ? null : _saveSettings,
                    icon: _isSaving
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.save_outlined),
                    label: Text(_isSaving ? 'جارٍ الحفظ...' : 'حفظ التغييرات'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _resetSettings,
                    icon: const Icon(Icons.restore_outlined),
                    label: const Text('استعادة الإعدادات الافتراضية'),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'النسخ والاستيراد والتصدير والأنماط',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _exportBackup,
                    icon: const Icon(Icons.file_upload_outlined),
                    label: const Text('تصدير نسخة كاملة'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _exportPatterns,
                    icon: const Icon(Icons.style_outlined),
                    label: const Text('تصدير الإعدادات والمواضع والأنماط فقط'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: () => _exportBackup(toGoogleDrive: true),
                    icon: const Icon(Icons.cloud_upload_outlined),
                    label: const Text('تصدير النسخة إلى Google Drive'),
                  ),
                  const SizedBox(height: 4),
                  Text(_driveAccountLabel, textAlign: TextAlign.center),
                  const Padding(
                    padding: EdgeInsets.symmetric(horizontal: 12),
                    child: Text(
                      'Google Drive يحتاج إعداد OAuth Android لهذا التطبيق؛ بيانات OAuth غير مضمنة في هذه الحزمة. النسخ المحلية المشفرة متاحة.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _importBackup,
                    icon: const Icon(Icons.file_download_outlined),
                    label: const Text('استيراد نسخة كاملة'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _importPatterns,
                    icon: const Icon(Icons.style_outlined),
                    label: const Text(
                      'استيراد الإعدادات والمواضع والأنماط فقط',
                    ),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: () => _importBackup(fromGoogleDrive: true),
                    icon: const Icon(Icons.cloud_download_outlined),
                    label: const Text('استيراد النسخة من Google Drive'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const BackupManagerScreen(),
                      ),
                    ),
                    icon: const Icon(Icons.manage_history_outlined),
                    label: const Text('مدير النسخ الاحتياطية المحلية'),
                  ),
                  const SizedBox(height: 8),
                  const Divider(height: 24),
                  Text(
                    'الأنماط المحفوظة',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _saveCurrentPattern,
                    icon: const Icon(Icons.bookmark_add_outlined),
                    label: const Text('حفظ النمط الحالي'),
                  ),
                  const SizedBox(height: 8),
                  FilledButton.icon(
                    onPressed: _saveMasterPattern,
                    icon: const Icon(Icons.push_pin_outlined),
                    label: const Text('حفظ النمط الرئيسي الحالي'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _restoreMasterPattern,
                    icon: const Icon(Icons.restore_page_outlined),
                    label: const Text('استعادة النمط الرئيسي بضغطة واحدة'),
                  ),
                  if (_savedPatterns.isEmpty)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 8),
                      child: Text('لا توجد أنماط محفوظة بعد.'),
                    )
                  else
                    ..._savedPatterns.map(
                      (pattern) => ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const Icon(Icons.style_outlined),
                        title: Text(pattern.name),
                        trailing: Wrap(
                          spacing: 4,
                          children: [
                            IconButton(
                              tooltip: 'تطبيق',
                              onPressed: () => _applyPattern(pattern),
                              icon: const Icon(Icons.check_circle_outline),
                            ),
                            if (pattern.name != 'نمط مواضع رقم 1')
                              IconButton(
                                tooltip: 'حذف',
                                onPressed: () => _deletePattern(pattern),
                                icon: const Icon(Icons.delete_outline),
                              ),
                          ],
                        ),
                      ),
                    ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: _clearAllRequests,
                    icon: const Icon(Icons.delete_sweep_outlined),
                    label: const Text('حذف جميع النماذج السابقة'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Theme.of(context).colorScheme.error,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _SettingsSection extends StatelessWidget {
  const _SettingsSection({
    required this.title,
    required this.icon,
    required this.children,
  });

  final String title;
  final IconData icon;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        initiallyExpanded: false,
        leading: Icon(icon, color: scheme.primary),
        title: Text(
          title,
          style: Theme.of(
            context,
          ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
        ),
        childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        children: _withSpacing(children),
      ),
    );
  }

  List<Widget> _withSpacing(List<Widget> items) {
    final result = <Widget>[];
    for (var index = 0; index < items.length; index++) {
      result.add(items[index]);
      if (index != items.length - 1) {
        result.add(const SizedBox(height: 10));
      }
    }
    return result;
  }
}

class _FieldSettingEditor extends StatelessWidget {
  const _FieldSettingEditor({
    required this.id,
    required this.setting,
    this.maxY = 841.89,
    this.maxX = 595.28,
    required this.onVisibleChanged,
    required this.onRequiredChanged,
    required this.onFontSizeChanged,
    required this.onLabelChanged,
    required this.onColorChanged,
    required this.onXChanged,
    required this.onYChanged,
    required this.onWidthChanged,
    required this.onHeightChanged,
    required this.onMaxLengthChanged,
    required this.onFontFamilyChanged,
    required this.onFontWeightChanged,
    required this.onFontStyleChanged,
    required this.onAlignmentChanged,
    required this.onLineHeightChanged,
    required this.onInputTypeChanged,
    this.onDelete,
    super.key,
  });

  final String id;
  final FieldSetting setting;
  final double maxY;
  final double maxX;
  final ValueChanged<bool> onVisibleChanged;
  final ValueChanged<bool> onRequiredChanged;
  final ValueChanged<double> onFontSizeChanged;
  final ValueChanged<String> onLabelChanged;
  final ValueChanged<int> onColorChanged;
  final ValueChanged<double> onXChanged;
  final ValueChanged<double> onYChanged;
  final ValueChanged<double> onWidthChanged;
  final ValueChanged<double> onHeightChanged;
  final ValueChanged<int> onMaxLengthChanged;
  final ValueChanged<String> onFontFamilyChanged;
  final ValueChanged<int> onFontWeightChanged;
  final ValueChanged<String> onFontStyleChanged;
  final ValueChanged<String> onAlignmentChanged;
  final ValueChanged<double> onLineHeightChanged;
  final ValueChanged<FieldInputType> onInputTypeChanged;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    final title = setting.label.isEmpty ? id : setting.label;
    return Card(
      margin: const EdgeInsets.only(top: 8),
      child: ExpansionTile(
        title: Text(title),
        subtitle: Text('المعرف: $id'),
        trailing: onDelete == null
            ? null
            : IconButton(
                tooltip: 'حذف الحقل',
                onPressed: onDelete,
                icon: const Icon(Icons.delete_outline),
              ),
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextFormField(
              initialValue: setting.label,
              decoration: const InputDecoration(labelText: 'اسم الحقل الظاهر'),
              onChanged: onLabelChanged,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: TextFormField(
              initialValue: setting.maxLength.toString(),
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'الحد الأقصى للحروف',
                helperText: 'يظهر العداد داخل شاشة التعبئة',
              ),
              onChanged: (value) {
                final parsed = int.tryParse(value);
                if (parsed != null && parsed >= 1) {
                  onMaxLengthChanged(parsed.clamp(1, 5000));
                }
              },
            ),
          ),
          DropdownButtonFormField<FieldInputType>(
            initialValue: setting.inputType,
            isExpanded: true,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: const InputDecoration(labelText: 'نوع الإدخال'),
            items: const [
              DropdownMenuItem(
                value: FieldInputType.text,
                child: Text('حروف ونص'),
              ),
              DropdownMenuItem(
                value: FieldInputType.amount,
                child: Text('مبلغ / أرقام'),
              ),
              DropdownMenuItem(
                value: FieldInputType.stakeholder,
                child: Text('جهة معنية'),
              ),
              DropdownMenuItem(
                value: FieldInputType.date,
                child: Text('تاريخ'),
              ),
            ],
            onChanged: (value) {
              if (value != null) onInputTypeChanged(value);
            },
          ),
          SwitchListTile.adaptive(
            title: const Text('إظهار الحقل'),
            value: setting.visible,
            onChanged: onVisibleChanged,
          ),
          SwitchListTile.adaptive(
            title: const Text('الحقل إجباري'),
            value: setting.required,
            onChanged: setting.visible ? onRequiredChanged : null,
          ),
          DropdownButtonFormField<String>(
            initialValue: setting.fontFamily,
            isExpanded: true,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: const InputDecoration(labelText: 'نوع الخط'),
            items: const [
              DropdownMenuItem(
                value: 'Noto Kufi Arabic',
                child: Text('Noto Kufi Arabic'),
              ),
              DropdownMenuItem(
                value: 'Noto Sans Arabic',
                child: Text('Noto Sans Arabic'),
              ),
              DropdownMenuItem(
                value: 'Noto Naskh Arabic',
                child: Text('نسخ واضح — Noto Naskh Arabic'),
              ),
              DropdownMenuItem(value: 'Cairo', child: Text('Cairo')),
              DropdownMenuItem(value: 'Tajawal', child: Text('Tajawal')),
              DropdownMenuItem(value: 'Changa', child: Text('Changa')),
              DropdownMenuItem(value: 'El Messiri', child: Text('El Messiri')),
              DropdownMenuItem(value: 'Reem Kufi', child: Text('Reem Kufi')),
              DropdownMenuItem(value: 'Aref Ruqaa', child: Text('Aref Ruqaa')),
              DropdownMenuItem(value: 'Lateef', child: Text('Lateef')),
              DropdownMenuItem(value: 'Katibeh', child: Text('Katibeh')),
              DropdownMenuItem(value: 'Lemonada', child: Text('Lemonada')),
            ],
            onChanged: (value) {
              if (value != null) onFontFamilyChanged(value);
            },
          ),
          DropdownButtonFormField<int>(
            initialValue: setting.fontWeight,
            isExpanded: true,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: const InputDecoration(labelText: 'وزن الخط'),
            items: const [
              DropdownMenuItem(value: 400, child: Text('عادي 400')),
              DropdownMenuItem(value: 500, child: Text('متوسط 500')),
              DropdownMenuItem(value: 600, child: Text('متوسط 600')),
              DropdownMenuItem(value: 700, child: Text('غليظ 700')),
              DropdownMenuItem(value: 800, child: Text('غليظ جداً 800')),
              DropdownMenuItem(value: 900, child: Text('غليظ جداً 900')),
            ],
            onChanged: (value) {
              if (value != null) onFontWeightChanged(value);
            },
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                _FontStyleChoice(
                  label: 'عادي',
                  icon: Icons.text_format_outlined,
                  selected:
                      setting.fontStyle != 'italic' && setting.fontWeight < 700,
                  onTap: () {
                    onFontWeightChanged(400);
                    onFontStyleChanged('normal');
                  },
                ),
                _FontStyleChoice(
                  label: 'غليظ',
                  icon: Icons.format_bold,
                  selected:
                      setting.fontStyle != 'italic' &&
                      setting.fontWeight >= 700 &&
                      setting.fontWeight < 800,
                  onTap: () {
                    onFontWeightChanged(700);
                    onFontStyleChanged('normal');
                  },
                ),
                _FontStyleChoice(
                  label: 'غليظ جداً',
                  icon: Icons.font_download_outlined,
                  selected:
                      setting.fontStyle != 'italic' &&
                      setting.fontWeight >= 800,
                  onTap: () {
                    onFontWeightChanged(900);
                    onFontStyleChanged('normal');
                  },
                ),
                _FontStyleChoice(
                  label: 'مائل',
                  icon: Icons.format_italic,
                  selected: setting.fontStyle == 'italic',
                  onTap: () {
                    onFontWeightChanged(400);
                    onFontStyleChanged('italic');
                  },
                ),
              ],
            ),
          ),
          DropdownButtonFormField<String>(
            initialValue: setting.alignment,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            decoration: const InputDecoration(labelText: 'محاذاة النص'),
            items: const [
              DropdownMenuItem(value: 'right', child: Text('يمين')),
              DropdownMenuItem(value: 'center', child: Text('وسط')),
              DropdownMenuItem(value: 'left', child: Text('يسار')),
            ],
            onChanged: (value) {
              if (value != null) onAlignmentChanged(value);
            },
          ),
          _ColorPalette(
            label: 'لون نص الحقل',
            selectedValue: setting.colorValue,
            colors: const [
              0xFF202124,
              0xFF263238,
              0xFF0D47A1,
              0xFF004D40,
              0xFF5D4037,
              0xFF6A1B9A,
              0xFFB71C1C,
              0xFFD4AF37,
              0xFFFFFFFF,
            ],
            onChanged: onColorChanged,
          ),
          ListTile(
            title: Text('حجم الخط: ${setting.fontSize.toStringAsFixed(1)}'),
            subtitle: Slider(
              min: 8,
              max: 24,
              divisions: 32,
              value: setting.fontSize,
              onChanged: onFontSizeChanged,
            ),
          ),
          ListTile(
            title: Text(
              'تباعد الأسطر: ${setting.lineHeight.toStringAsFixed(2)}',
            ),
            subtitle: Slider(
              min: 0.2,
              max: 4.0,
              divisions: 38,
              value: setting.lineHeight.clamp(0.2, 4.0),
              onChanged: onLineHeightChanged,
            ),
          ),
          _NumericSettingControl(
            label: 'الموضع الأفقي X',
            value: setting.x,
            min: 0,
            max: maxX,
            onChanged: onXChanged,
          ),
          _NumericSettingControl(
            label: 'الموضع الرأسي Y',
            value: setting.y,
            min: 0,
            max: maxY,
            onChanged: onYChanged,
          ),
          _NumericSettingControl(
            label: 'عرض الحقل',
            value: setting.width <= 1 ? 250 : setting.width,
            min: 40,
            max: maxX,
            onChanged: onWidthChanged,
          ),
          _NumericSettingControl(
            label: 'ارتفاع الحقل',
            value: setting.height <= 1 ? 24 : setting.height,
            min: 12,
            max: 240,
            onChanged: onHeightChanged,
          ),
        ],
      ),
    );
  }
}

class _NumericSettingControl extends StatefulWidget {
  const _NumericSettingControl({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
  });

  final String label;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;

  @override
  State<_NumericSettingControl> createState() => _NumericSettingControlState();
}

class _NumericSettingControlState extends State<_NumericSettingControl> {
  late final TextEditingController _controller;
  late final FocusNode _focusNode;
  Timer? _repeatTimer;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: _format(widget.value));
    _focusNode = FocusNode()..addListener(_handleFocusChange);
  }

  void _handleFocusChange() {
    if (!_focusNode.hasFocus) _commitText();
  }

  @override
  void didUpdateWidget(covariant _NumericSettingControl oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value.round() != widget.value.round()) {
      _controller.value = TextEditingValue(
        text: _format(widget.value),
        selection: TextSelection.collapsed(
          offset: _format(widget.value).length,
        ),
      );
    }
  }

  String _format(double value) => value.round().toString();

  void _commit(double value) {
    final next = value.clamp(widget.min, widget.max).toDouble();
    _controller.value = TextEditingValue(
      text: _format(next),
      selection: TextSelection.collapsed(offset: _format(next).length),
    );
    widget.onChanged(next);
  }

  void _commitText() {
    final parsed = double.tryParse(_controller.text.trim());
    if (parsed == null) {
      _commit(widget.value);
    } else {
      _commit(parsed);
    }
  }

  void _startRepeating(double delta) {
    _stopRepeating();
    _commit(_currentValue() + delta);
    _repeatTimer = Timer.periodic(const Duration(milliseconds: 90), (_) {
      _commit(_currentValue() + delta);
    });
  }

  double _currentValue() => double.tryParse(_controller.text) ?? widget.value;

  void _stopRepeating() {
    _repeatTimer?.cancel();
    _repeatTimer = null;
  }

  @override
  void dispose() {
    _stopRepeating();
    _focusNode
      ..removeListener(_handleFocusChange)
      ..dispose();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16),
      title: Text(widget.label),
      subtitle: Row(
        children: [
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => _commit(widget.value - 1),
            onLongPressStart: (_) => _startRepeating(-1),
            onLongPressEnd: (_) => _stopRepeating(),
            onLongPressCancel: _stopRepeating,
            onLongPressUp: _stopRepeating,
            child: const SizedBox(
              width: 44,
              height: 48,
              child: Icon(Icons.keyboard_arrow_down),
            ),
          ),
          Expanded(
            child: TextField(
              controller: _controller,
              focusNode: _focusNode,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              textAlign: TextAlign.center,
              textDirection: TextDirection.ltr,
              decoration: const InputDecoration(
                isDense: true,
                border: OutlineInputBorder(),
              ),
              onSubmitted: (_) => _commitText(),
              onEditingComplete: _commitText,
            ),
          ),
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: () => _commit(widget.value + 1),
            onLongPressStart: (_) => _startRepeating(1),
            onLongPressEnd: (_) => _stopRepeating(),
            onLongPressCancel: _stopRepeating,
            onLongPressUp: _stopRepeating,
            child: const SizedBox(
              width: 44,
              height: 48,
              child: Icon(Icons.keyboard_arrow_up),
            ),
          ),
        ],
      ),
    );
  }
}

class _SettingsTextField extends StatelessWidget {
  const _SettingsTextField({
    required this.controller,
    required this.label,
    this.validator,
  });

  final TextEditingController controller;
  final String label;
  final String? Function(String?)? validator;

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      validator: validator,
      decoration: InputDecoration(labelText: label),
    );
  }
}

class _ColorPalette extends StatelessWidget {
  const _ColorPalette({
    required this.label,
    required this.selectedValue,
    required this.colors,
    required this.onChanged,
  });

  final String label;
  final int selectedValue;
  final List<int> colors;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return ColorPickerDropdown(
      label: label,
      color: Color(selectedValue),
      onColorSelected: (color) => onChanged(color.toARGB32()),
    );
  }
}

class _FontStyleChoice extends StatelessWidget {
  const _FontStyleChoice({
    required this.label,
    required this.icon,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ChoiceChip(
      selected: selected,
      onSelected: (_) => onTap(),
      avatar: Icon(icon, size: 18),
      label: Text(label),
      labelStyle: TextStyle(
        fontWeight: selected ? FontWeight.w800 : FontWeight.w500,
      ),
      visualDensity: VisualDensity.compact,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
    );
  }
}
