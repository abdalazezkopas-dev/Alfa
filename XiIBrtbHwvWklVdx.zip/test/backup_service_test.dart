import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:alfa_expense_app/features/backup/services/backup_service.dart';
import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/representative_reports/models/representative_report.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';

Map<String, Object?> _completeV4Payload() {
  final settings = AppSettings.defaults().toMap();
  return <String, Object?>{
    'format': 'alfa_expense_app_backup',
    'version': 4,
    'settings': settings,
    'settings_by_scope': {
      for (final scope in requiredBackupScopes) scope: settings,
    },
    'requests': <Object?>[],
    'reminders': <Object?>[],
    'debts': <Object?>[],
    'notes': <Object?>[],
    'quick_statements': <String, Object?>{},
    'saved_patterns': <Object?>[],
    'master_patterns_by_scope': <String, Object?>{},
    'debt_settings': <String, Object?>{},
    'calculator_history': <Object?>[],
    'attachments': <Object?>[],
    'product_catalog': <Object?>[],
  };
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const secureChannel = MethodChannel(
    'plugins.it_nomads.com/flutter_secure_storage',
  );
  final secureValues = <String, String>{};
  setUp(() async {
    secureValues.clear();
    SharedPreferences.setMockInitialValues({});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(secureChannel, (call) async {
          final arguments = (call.arguments as Map?)?.cast<String, Object?>();
          final key = arguments?['key'] as String?;
          switch (call.method) {
            case 'read':
              return key == null ? null : secureValues[key];
            case 'write':
              if (key != null) {
                secureValues[key] = arguments?['value'] as String? ?? '';
              }
              return null;
            case 'delete':
              if (key != null) secureValues.remove(key);
              return null;
            default:
              return null;
          }
        });
  });
  tearDown(
    () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(secureChannel, null),
  );

  test('decodes a complete v3 backup with all form scopes', () {
    final settings = AppSettings.defaults().toMap();
    final payload = <String, Object?>{
      'format': 'alfa_expense_app_backup',
      'version': 3,
      'settings': settings,
      'settings_by_scope': {
        for (final scope in requiredBackupScopes) scope: settings,
      },
      'requests': <Object?>[],
      'reminders': <Object?>[],
      'debts': <Object?>[],
      'notes': <Object?>[],
      'quick_statements': <String, Object?>{},
      'saved_patterns': <Object?>[],
      'master_patterns_by_scope': <String, Object?>{},
      'debt_settings': <String, Object?>{},
      'calculator_history': <Object?>[],
      'attachments': <Object?>[],
    };

    final decoded = BackupService.decodeBackup(jsonEncode(payload));

    expect(decoded.version, 3);
    expect(decoded.settingsByScope.keys, containsAll(requiredBackupScopes));
    expect(decoded.requests, isEmpty);
    expect(decoded.attachments, isEmpty);
    expect(decoded.hasProductCatalog, isFalse);
  });

  test('restores more than six clearance entries from a backup', () {
    final settings = AppSettings.defaults().toMap();
    final request = <String, Object?>{
      'documentType': ExpenseDocumentType.clearanceRequest.name,
      'clearanceEntries': [
        for (var i = 1; i <= 150; i++)
          {'amount': '$i', 'date': '01/09/2026', 'statement': 'بيان العهدة $i'},
      ],
    };
    final payload = <String, Object?>{
      'format': 'alfa_expense_app_backup',
      'version': 3,
      'settings': settings,
      'settings_by_scope': {
        for (final scope in requiredBackupScopes) scope: settings,
      },
      'requests': [request],
      'reminders': <Object?>[],
      'debts': <Object?>[],
      'notes': <Object?>[],
      'quick_statements': <String, Object?>{},
      'saved_patterns': <Object?>[],
      'master_patterns_by_scope': <String, Object?>{},
      'debt_settings': <String, Object?>{},
      'calculator_history': <Object?>[],
      'attachments': <Object?>[],
    };

    final decoded = BackupService.decodeBackup(jsonEncode(payload));
    final restored = decoded.requests.single;
    expect(restored.documentType, ExpenseDocumentType.clearanceRequest);
    expect(restored.clearanceEntries, hasLength(150));
    expect(restored.clearanceEntries.last.statement, 'بيان العهدة 150');
  });

  test(
    'decodes optional global settings while keeping older v4 backups valid',
    () {
      final settings = AppSettings.defaults().toMap();
      final scopedSettings = <String, Object?>{
        for (final scope in requiredBackupScopes) scope: settings,
        'global': settings,
      };
      final payload = <String, Object?>{
        'format': 'alfa_expense_app_backup',
        'version': 4,
        'settings': settings,
        'settings_by_scope': scopedSettings,
        'requests': <Object?>[],
        'reminders': <Object?>[],
        'debts': <Object?>[],
        'notes': <Object?>[],
        'quick_statements': <String, Object?>{},
        'saved_patterns': <Object?>[],
        'master_patterns_by_scope': <String, Object?>{},
        'debt_settings': <String, Object?>{},
        'calculator_history': <Object?>[],
        'attachments': <Object?>[],
        'product_catalog': <Object?>[],
      };

      final decoded = BackupService.decodeBackup(jsonEncode(payload));
      expect(decoded.settingsByScope.keys, containsAll(backupSettingsScopes));
      expect(decoded.hasRepresentativeReports, isFalse);

      final olderPayload = <String, Object?>{
        ...payload,
        'settings_by_scope': {
          for (final scope in requiredBackupScopes) scope: settings,
        },
      };
      final olderV4 = BackupService.decodeBackup(jsonEncode(olderPayload));
      expect(olderV4.settingsByScope.keys, containsAll(requiredBackupScopes));
      expect(olderV4.settingsByScope.containsKey('global'), isFalse);
      expect(olderV4.hasRepresentativeReports, isFalse);
    },
  );

  test('يحافظ على غياب دليل الأصناف في النسخة القديمة كحالة absent', () {
    final settings = AppSettings.defaults().toMap();
    final payload = <String, Object?>{
      'format': 'alfa_expense_app_backup',
      'version': 3,
      'settings': settings,
      'settings_by_scope': {
        for (final scope in requiredBackupScopes.take(6)) scope: settings,
      },
      'requests': <Object?>[],
      'attachments': <Object?>[],
    };

    final decoded = BackupService.decodeBackup(jsonEncode(payload));

    expect(decoded.hasProductCatalog, isFalse);
    expect(decoded.productCatalog, isEmpty);
  });

  test('النسخ القديمة التي لا تحتوي مخازن أحدث لا تستبدلها بقوائم فارغة', () {
    final settings = AppSettings.defaults().toMap();
    final v1 = BackupService.decodeBackup(
      jsonEncode({
        'format': 'alfa_expense_app_backup',
        'version': 1,
        'settings': settings,
        'requests': <Object?>[],
      }),
    );
    expect(v1.settingsByScope.keys, ['expenseRequest']);
    expect(v1.hasReminders, isFalse);
    expect(v1.hasDebts, isFalse);
    expect(v1.hasNotes, isFalse);
    expect(v1.hasQuickStatements, isFalse);
    expect(v1.hasSavedPatterns, isFalse);
    expect(v1.hasDebtSettings, isFalse);
    expect(v1.hasCalculatorHistory, isFalse);

    final v3 = BackupService.decodeBackup(
      jsonEncode({
        'format': 'alfa_expense_app_backup',
        'version': 3,
        'settings': settings,
        'settings_by_scope': {
          for (final scope in requiredBackupScopes.take(6)) scope: settings,
        },
        'requests': <Object?>[],
      }),
    );
    expect(v3.settingsByScope.keys, containsAll(requiredBackupScopes.take(6)));
    expect(v3.settingsByScope.keys, hasLength(6));
    expect(v3.hasReminders, isFalse);
    expect(v3.hasNotes, isFalse);
    expect(v3.hasQuickStatements, isFalse);
  });

  test(
    'encodes and decodes representative reports in plain and encrypted backups',
    () async {
      final settings = AppSettings.defaults();
      final report = RepresentativeReport.empty(
        id: 'representative-1',
        date: 'م2026/10/20',
      ).copyWith(medRep: 'مندوب صنعاء');

      final plain = await BackupService.buildPlainBackupJson(
        settings: settings,
        requests: const [],
        representativeReports: [report],
      );
      final decodedPlain = BackupService.decodeBackup(plain);
      expect(decodedPlain.hasRepresentativeReports, isTrue);
      expect(decodedPlain.representativeReports.single.toMap(), report.toMap());

      final encrypted = await BackupService.buildEncryptedBackupJson(
        settings: settings,
        requests: const [],
        password: 'backup-test-password',
        representativeReports: [report],
      );
      final decodedEncrypted = await BackupService.decodeEncryptedBackup(
        encrypted,
        password: 'backup-test-password',
      );
      expect(
        decodedEncrypted.representativeReports.single.toMap(),
        report.toMap(),
      );
    },
  );

  test(
    'building a backup does not migrate or delete legacy metadata',
    () async {
      SharedPreferences.setMockInitialValues({
        'alfa_debt_currency': 'دينار',
        'alfa_debt_report_title': 'تقرير تجريبي',
        'alfa_debt_decimals': 3,
        'alfa_debt_hide_zero': true,
        'alfa_calculator_history': <String>['1+2=3'],
      });

      await BackupService.buildPlainBackupJson(
        settings: AppSettings.defaults(),
        requests: const [],
      );

      final preferences = await SharedPreferences.getInstance();
      expect(preferences.getString('alfa_debt_currency'), 'دينار');
      expect(preferences.getString('alfa_debt_report_title'), 'تقرير تجريبي');
      expect(preferences.getInt('alfa_debt_decimals'), 3);
      expect(preferences.getBool('alfa_debt_hide_zero'), isTrue);
      expect(preferences.getStringList('alfa_calculator_history'), ['1+2=3']);
      expect(secureValues.keys, {'kabas_storage_key_v1'});
    },
  );

  test('rejects a malformed representative reports field before restore', () {
    final settings = AppSettings.defaults().toMap();
    final payload = <String, Object?>{
      'format': 'alfa_expense_app_backup',
      'version': 4,
      'settings': settings,
      'settings_by_scope': {
        for (final scope in requiredBackupScopes) scope: settings,
      },
      'requests': <Object?>[],
      'representative_reports': {'not': 'a list'},
    };

    expect(
      () => BackupService.decodeBackup(jsonEncode(payload)),
      throwsA(isA<FormatException>()),
    );
  });

  test(
    'rejects malformed backup records instead of silently dropping them',
    () {
      for (final field in [
        'requests',
        'reminders',
        'debts',
        'notes',
        'saved_patterns',
        'product_catalog',
        'representative_reports',
        'attachments',
      ]) {
        final payload = _completeV4Payload()..[field] = <Object?>['invalid'];
        expect(
          () => BackupService.decodeBackup(jsonEncode(payload)),
          throwsA(isA<FormatException>()),
          reason: field,
        );
      }

      final quickStatements = _completeV4Payload()
        ..['quick_statements'] = <String, Object?>{
          'expenseRequest': <Object?>['valid', 7],
        };
      expect(
        () => BackupService.decodeBackup(jsonEncode(quickStatements)),
        throwsA(isA<FormatException>()),
      );

      final masterPatterns = _completeV4Payload()
        ..['master_patterns_by_scope'] = <String, Object?>{
          'expenseRequest': 'invalid',
        };
      expect(
        () => BackupService.decodeBackup(jsonEncode(masterPatterns)),
        throwsA(isA<FormatException>()),
      );

      final calculatorHistory = _completeV4Payload()
        ..['calculator_history'] = <Object?>['entry', false];
      expect(
        () => BackupService.decodeBackup(jsonEncode(calculatorHistory)),
        throwsA(isA<FormatException>()),
      );

      final malformedAttachment = _completeV4Payload()
        ..['attachments'] = <Object?>[
          <String, Object?>{'id': 'attachment-1', 'base64': 'not-base64!'},
        ];
      expect(
        () => BackupService.decodeBackup(jsonEncode(malformedAttachment)),
        throwsA(isA<FormatException>()),
      );
    },
  );

  test('accepts 5000 requests and rejects 5001 without truncating', () {
    final atLimit = _completeV4Payload()
      ..['requests'] = List<Object?>.generate(5000, (_) => <String, Object?>{});
    expect(
      BackupService.decodeBackup(jsonEncode(atLimit)).requests,
      hasLength(5000),
    );

    final overLimit = _completeV4Payload()
      ..['requests'] = List<Object?>.generate(5001, (_) => <String, Object?>{});
    expect(
      () => BackupService.decodeBackup(jsonEncode(overLimit)),
      throwsA(isA<FormatException>()),
    );
  });

  test('applies the 5000-item limit to other backup lists', () {
    for (final field in [
      'reminders',
      'debts',
      'notes',
      'saved_patterns',
      'product_catalog',
      'representative_reports',
    ]) {
      final payload = _completeV4Payload()
        ..[field] = List<Object?>.generate(5001, (_) => <String, Object?>{});
      expect(
        () => BackupService.decodeBackup(jsonEncode(payload)),
        throwsA(isA<FormatException>()),
        reason: field,
      );
    }

    final calculatorHistory = _completeV4Payload()
      ..['calculator_history'] = List<Object?>.filled(5001, 'entry');
    expect(
      () => BackupService.decodeBackup(jsonEncode(calculatorHistory)),
      throwsA(isA<FormatException>()),
    );

    final quickStatements = _completeV4Payload()
      ..['quick_statements'] = <String, Object?>{
        'expenseRequest': List<Object?>.filled(5001, 'statement'),
      };
    expect(
      () => BackupService.decodeBackup(jsonEncode(quickStatements)),
      throwsA(isA<FormatException>()),
    );

    final tooManyScopes = _completeV4Payload()
      ..['master_patterns_by_scope'] = <String, Object?>{
        for (var i = 0; i < 5001; i++) 'scope-$i': <String, Object?>{},
      };
    expect(
      () => BackupService.decodeBackup(jsonEncode(tooManyScopes)),
      throwsA(isA<FormatException>()),
    );
  });

  test('retains the existing 100-attachment boundary', () {
    final atLimit = _completeV4Payload()
      ..['attachments'] = List<Object?>.generate(
        100,
        (index) => <String, Object?>{
          'id': 'attachment-$index',
          'base64': 'YQ==',
          if (index == 0) 'fileName': null,
          if (index == 0) 'mimeType': null,
        },
      );
    expect(
      BackupService.decodeBackup(jsonEncode(atLimit)).attachments,
      hasLength(100),
    );

    final overLimit = _completeV4Payload()
      ..['attachments'] = List<Object?>.generate(
        101,
        (index) => <String, Object?>{
          'id': 'attachment-$index',
          'base64': 'YQ==',
        },
      );
    expect(
      () => BackupService.decodeBackup(jsonEncode(overLimit)),
      throwsA(isA<FormatException>()),
    );
  });

  test(
    'refuses to build plain and encrypted backups above the item limit',
    () async {
      final requests = List.generate(
        5001,
        (_) => ExpenseRequest.fromMap(const <String, Object?>{}),
      );
      final settings = AppSettings.defaults();

      await expectLater(
        BackupService.buildPlainBackupJson(
          settings: settings,
          requests: requests,
        ),
        throwsA(isA<FormatException>()),
      );
      await expectLater(
        BackupService.buildEncryptedBackupJson(
          settings: settings,
          requests: requests,
          password: 'backup-test-password',
        ),
        throwsA(isA<FormatException>()),
      );
      await expectLater(
        BackupService.buildPlainBackupJson(
          settings: settings,
          requests: const [],
          quickStatements: <String, List<String>>{
            'expenseRequest': List<String>.filled(5001, 'statement'),
          },
        ),
        throwsA(isA<FormatException>()),
      );
    },
  );
}
