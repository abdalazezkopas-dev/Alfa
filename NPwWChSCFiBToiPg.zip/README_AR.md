# دليل تطبيق ShibaPharma / alfa_expense_app

## المتطلبات

- Flutter متوافق مع Dart 3.9 أو أحدث.
- Android SDK مع أدوات البناء المطلوبة.
- JDK مهيأ في البيئة، ويفضل JDK 17 أو النسخة المعتمدة في بيئة البناء.
- لا يحتاج المشروع إلى مسار JDK ثابت داخل `android/gradle.properties`.

## تثبيت الاعتمادات

من جذر المشروع:

```bash
flutter doctor -v
flutter pub get
```

يجب إبقاء `pubspec.lock` ضمن المشروع لضمان إعادة حل الاعتمادات بنفس الإصدارات.

## الفحص والاختبارات

```bash
dart format --output=none --set-exit-if-changed lib test
flutter analyze
flutter test
```

## بناء APK تجريبي

```bash
flutter build apk --debug
```

يظهر الملف في:

```text
build/app/outputs/flutter-apk/app-debug.apk
```

## بناء Release بتوقيع آمن

لا تضع ملفات JKS أو كلمات المرور داخل المستودع أو أرشيف التسليم. أنشئ ملفًا محليًا مستثنى من Git باسم `android/key.properties`، ثم عرّف فيه القيم المطلوبة من بيئتك الآمنة:

```properties
storePassword=...
keyPassword=...
keyAlias=...
storeFile=...
```

بعد تجهيز التوقيع:

```bash
flutter build apk --release
```

يفشل بناء Release إذا لم تكن بيانات التوقيع مهيأة، ولا يستخدم توقيع Debug تلقائيًا.

## نموذج طلب العينات

يدعم النموذج ثلاث خطوات:

1. البيانات العامة.
2. اختيار الأصناف والكميات من دليل الأصناف.
3. المعاينة والحفظ أو التصدير والطباعة.

يدعم دليل الأصناف استيراد Excel وCSV، ويجب أن يتوافق ملف Excel مع ترتيب الأعمدة الموضح داخل شاشة الاستيراد. ملف الأصناف المرجعي موجود في:

```text
assets/imports/قائمة_الأصناف_47.xlsx
```

القالب الحالي يدعم حتى 53 صنفًا عبر صفحات النموذج الثلاث. الكميات تدخل رقميًا وتظهر كتابةً في PDF.

## التثبيت على جهاز Android

بعد توفر `adb` وجهاز مصرح به:

```bash
adb install -r build/app/outputs/flutter-apk/app-debug.apk
```

## ملاحظات الأمان والتوزيع

- لا ترفع `android/key.properties` أو أي JKS أو أسرار إلى المستودع.
- لا تضع كلمات المرور في السجلات أو الملفات العامة.
- استبعد `.dart_tool` و`build` وملفات البيئة المحلية من أرشيف التسليم.
- حافظ على `applicationId` و`namespace` الحاليين عند إنشاء تحديثات مستقبلية.
