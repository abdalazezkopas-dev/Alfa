package com.shibapharma.formsuite

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.embedding.android.FlutterActivity
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            "com.shibapharma/formsuite/system_settings",
        ).setMethodCallHandler { call, result ->
            val action = when (call.method) {
                "openNotificationSettings" -> Settings.ACTION_APP_NOTIFICATION_SETTINGS
                "openExactAlarmSettings" -> Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM
                else -> null
            }
            if (action == null) {
                result.notImplemented()
                return@setMethodCallHandler
            }
            try {
                val intent = Intent(action).apply {
                    data = Uri.parse("package:$packageName")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
                result.success(true)
            } catch (_: Exception) {
                result.success(false)
            }
        }
    }
}
