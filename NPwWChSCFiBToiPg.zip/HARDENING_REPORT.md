# ShibaPharma Hardening & Data Integrity Report

## Scope

The existing Flutter source was modified in place under the current project structure. No application rewrite was performed, and protected identity values were preserved.

## Functional changes

| File or area | Change |
|---|---|
| `pdf_text_sanitizer.dart` | Preserves and sanitizes `clearanceEntries`, `serviceItems`, and nested `secondRequest` lists. |
| `expense_request_screen.dart` | Shows one clearance row initially, adds rows through a plus button up to six, supports row removal, and limits service items to item name only. Added lost-image recovery and attachment lifecycle handling. |
| `pdf_service.dart` | Renders service item names in the official service-request PDF path. |
| `app_settings.dart` and `settings_screen.dart` | Adds scoped structured-field settings, corrects empty-map fallback, uses scoped reset defaults, removes expense/memo field sections from general settings, and supports long-press position increment/decrement. |
| `request_store.dart` and storage services | Adds StoreMutex protection, migration locking, write-result validation, and orphan attachment cleanup. |
| `pattern_store.dart` | Adds scoped patterns with legacy fallback to `expenseRequest`. |
| `reminder_notification_service.dart` | Calculates next daily, weekly, and safe monthly occurrences without changing persisted `scheduledAt`; adds `cancelAll()`. |
| `backup_service.dart` | Adds Backup v3 payloads, required settings scopes, attachments, metadata, import remapping, and rollback cleanup/restoration. |
| `identity_report.txt` | Records protected application identity, signing, and timezone values. |
| `test/structured_forms_pdf_test.dart` | Adds sanitizer, nested-request, six-row, and six-item PDF tests. |

## Requested form behavior

The service-request structured form now contains only `اسم الصنف`. Quantity and item-notes fields are no longer shown, collected, configured, or rendered. Legacy stored quantity and notes remain readable through the model for backward compatibility.

Clearance rows now begin with the first visible `المبلغ / التاريخ / البيان` row. The plus button adds the next row, and subsequent rows can be removed. Structured field visibility and labels are available in the scoped clearance-request settings.

## Protected identity verification

- `applicationId`: `com.shibapharma.formsuite`
- Release signing: unchanged; release continues to use the configured debug signing.
- Timezone: `Asia/Riyadh` remains configured through `tz.setLocalLocation(tz.getLocation('Asia/Riyadh'))`.

## Verification status

The environment does not contain the Flutter or Dart executables. Therefore, `flutter pub get`, `flutter analyze`, `flutter test`, and `flutter build apk` could not be executed here. No successful Flutter or Dart test result is claimed.

Static checks completed in the environment confirmed that the identity report exists, the requested service quantity/notes fields no longer occur in the relevant Dart source and tests, and the new PDF test and attachment-manager files are non-empty.

## Human review note

The final Flutter analyzer and test run must be performed in a Flutter-enabled environment before release. The most important review targets are Backup v3 device-level attachment restoration, Android lost-image recovery, and the long-press gesture behavior on the target Flutter version.
