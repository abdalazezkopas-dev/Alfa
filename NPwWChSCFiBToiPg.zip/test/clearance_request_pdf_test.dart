import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/expense_request/services/pdf_service.dart';

int _pdfPageCount(Uint8List bytes) {
  final source = latin1.decode(bytes, allowInvalid: true);
  return RegExp(r'/Type\s*/Page(?:\s|/|>)').allMatches(source).length;
}

ExpenseRequest _clearanceRequest({
  required List<ClearanceEntry> entries,
  String amountWords = 'مائة وخمسة وعشرون ريالًا فقط',
  String requesterSignature = '',
  String directManagerSignature = '',
  String approvedAuthoritySignature = '',
  String accountsManagerSignature = '',
}) {
  return ExpenseRequest(
    date: '23/10/2026',
    receiver: 'فرع',
    amountNumber: '',
    amountWords: amountWords,
    reason: '',
    statement: '',
    branch: 'الفرع الرئيسي',
    account: '',
    requesterName: 'مقدم الطلب',
    requesterSignature: requesterSignature,
    directManagerName: 'المدير المباشر',
    directManagerSignature: directManagerSignature,
    approvedAuthorityName: 'الإدارة المعنية',
    approvedAuthoritySignature: approvedAuthoritySignature,
    accountsManagerName: 'مدير الحسابات',
    accountsManagerSignature: accountsManagerSignature,
    documentType: ExpenseDocumentType.clearanceRequest,
    clearanceEntries: entries,
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('ينشئ صفحة واحدة لإخلاء عهدة ضمن صفوف القالب الأصلي', () async {
    final request = _clearanceRequest(
      entries: const [
        ClearanceEntry(
          amount: '125.00',
          date: '22/10/2026',
          statement: 'شراء مستلزمات تشغيلية',
        ),
      ],
      requesterSignature: 'مقدم',
      directManagerSignature: 'مدير',
      approvedAuthoritySignature: 'جهة',
      accountsManagerSignature: 'حسابات',
    );

    final bytes = await PdfService.buildRequestPdf(request);

    expect(bytes, isNotEmpty);
    expect(bytes.sublist(0, 4), orderedEquals([37, 80, 68, 70]));
    expect(_pdfPageCount(bytes), 1);
  });

  test('ينشئ صفحات متتابعة عند تجاوز ستة بنود عهده', () async {
    final request = _clearanceRequest(
      entries: [
        for (var index = 1; index <= 7; index++)
          ClearanceEntry(
            amount: '$index.25',
            date: '22/10/2026',
            statement: 'بند عهده رقم $index',
          ),
      ],
    );

    final bytes = await PdfService.buildRequestPdf(request);

    expect(bytes, isNotEmpty);
    expect(_pdfPageCount(bytes), 2);
  });

  test('يقسم البيان الطويل ويزيد عدد الصفحات دون تكرار صفوف الإدخال', () async {
    final longStatement = List.filled(
      140,
      'جزء من البيان يوضح استمرار النص في الصفحة التالية',
    ).join(' ');
    final request = _clearanceRequest(
      entries: [
        ClearanceEntry(
          amount: '100.00',
          date: '20/10/2026',
          statement: longStatement,
        ),
      ],
    );

    final bytes = await PdfService.buildRequestPdf(request);

    expect(bytes, isNotEmpty);
    expect(_pdfPageCount(bytes), greaterThan(1));
  });

  test('تغيير المبلغ بالحروف والتوقيعات النصية يغير إخراج PDF', () async {
    const entry = ClearanceEntry(
      amount: '125.00',
      date: '22/10/2026',
      statement: 'بيان اختبار الحقول الأصلية',
    );
    final withoutText = await PdfService.buildRequestPdf(
      _clearanceRequest(entries: const [entry]),
    );
    final withText = await PdfService.buildRequestPdf(
      _clearanceRequest(
        entries: const [entry],
        amountWords: 'مائة وخمسة وعشرون ريالًا فقط لا غير',
        requesterSignature: 'أحمد',
        directManagerSignature: 'محمد',
        approvedAuthoritySignature: 'خالد',
        accountsManagerSignature: 'سعيد',
      ),
    );

    expect(withText, isNotEmpty);
    expect(withText, isNot(equals(withoutText)));
  });
}
