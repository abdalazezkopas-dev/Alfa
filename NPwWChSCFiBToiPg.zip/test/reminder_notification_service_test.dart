import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/reminders/services/reminder_notification_service.dart';
import 'package:alfa_expense_app/features/reminders/models/reminder.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('maps each selected reminder sound to a distinct versioned channel', () {
    final defaultProfile = ReminderNotificationService.soundProfileFor(
      'reminder_default',
    );
    final softProfile = ReminderNotificationService.soundProfileFor(
      'reminder_soft',
    );
    final urgentProfile = ReminderNotificationService.soundProfileFor(
      'reminder_urgent',
    );

    expect({
      defaultProfile.channelId,
      softProfile.channelId,
      urgentProfile.channelId,
    }, hasLength(3));
    expect(defaultProfile.channelId, 'spa_pharma_reminders_v2_default');
    expect(defaultProfile.resourceName, isNull);
    expect(defaultProfile.sound, isNull);
    expect(softProfile.resourceName, 'reminder_soft');
    expect(softProfile.sound, isA<RawResourceAndroidNotificationSound>());
    expect(urgentProfile.resourceName, 'reminder_urgent');
    expect(urgentProfile.sound, isA<RawResourceAndroidNotificationSound>());
  });

  test('maps large app reminder IDs into Android safe notification IDs', () {
    const reminderId = 1760000000123456;
    final mapped = ReminderNotificationService.notificationIdFor(reminderId);

    expect(mapped, inInclusiveRange(1, 2147483645));
    expect(mapped, ReminderNotificationService.notificationIdFor(reminderId));
    expect(mapped, isNot(2147483646));
    expect(
      ReminderNotificationService.snoozeNotificationIdFor(reminderId),
      isNot(mapped),
    );
  });

  test('supports persistent yearly recurrence and computes its next date', () {
    final service = ReminderNotificationService.instance;
    final reminder = Reminder(
      id: 7,
      title: 'تجديد سنوي',
      notes: '',
      scheduledAt: DateTime(2026, 4, 12, 9),
      repeat: 'yearly',
    );

    expect(
      ReminderNotificationService.repeatComponentsFor('yearly'),
      DateTimeComponents.dateAndTime,
    );
    expect(
      service.nextOccurrence(reminder, DateTime(2026, 4, 12, 9, 1)),
      DateTime(2027, 4, 12, 9),
    );
  });

  test(
    'keeps month-end and leap-day recurrence anchored to their original day',
    () {
      final service = ReminderNotificationService.instance;
      final monthEnd = Reminder(
        id: 8,
        title: 'آخر الشهر',
        notes: '',
        scheduledAt: DateTime(2026, 1, 31, 9),
        repeat: 'monthly',
      );
      final leapDay = Reminder(
        id: 9,
        title: 'موعد سنوي',
        notes: '',
        scheduledAt: DateTime(2024, 2, 29, 9),
        repeat: 'yearly',
      );

      expect(
        service.nextOccurrence(monthEnd, DateTime(2026, 2, 1)),
        DateTime(2026, 3, 31, 9),
      );
      expect(
        service.nextOccurrence(leapDay, DateTime(2026, 1, 1)),
        DateTime(2028, 2, 29, 9),
      );
    },
  );

  test('falls back safely for an unknown legacy sound identifier', () {
    final profile = ReminderNotificationService.soundProfileFor(
      'unknown_legacy_sound',
    );

    expect(profile.channelId, 'spa_pharma_reminders_v2_default');
    expect(profile.resourceName, isNull);
    expect(profile.sound, isNull);
  });

  test(
    'returns false safely when system settings channel is unavailable',
    () async {
      final service = ReminderNotificationService.instance;

      expect(await service.openNotificationSettings(), isFalse);
      expect(await service.openExactAlarmSettings(), isFalse);
    },
  );
}
