import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/features/notes/screens/notes_screen.dart';
import 'package:alfa_expense_app/features/reminders/screens/reminders_screen.dart';

void main() {
  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  testWidgets('يعرض حالة الفراغ المفيدة للملاحظات', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: NotesScreen()));
    await tester.pumpAndSettle();

    expect(find.text('ابدأ أول ملاحظة لك'), findsOneWidget);
    expect(find.text('إنشاء ملاحظة'), findsOneWidget);
  });

  testWidgets('يعرض حالة الفراغ المفيدة للتذكيرات', (tester) async {
    await tester.pumpWidget(const MaterialApp(home: RemindersScreen()));
    await tester.pumpAndSettle();

    expect(find.text('ابدأ بتنظيم يومك'), findsOneWidget);
    expect(find.text('إنشاء أول تذكير'), findsOneWidget);
  });
}
