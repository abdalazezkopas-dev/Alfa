import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/features/representative_reports/screens/representative_reports_screen.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('shows the empty state and a new-report action', (tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(
      const MaterialApp(home: RepresentativeReportsScreen()),
    );
    await tester.pumpAndSettle();

    expect(find.text('تقارير المندوبين'), findsOneWidget);
    expect(find.text('لا توجد تقارير محفوظة'), findsOneWidget);
    expect(find.text('تقرير جديد'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
