import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:alfa_expense_app/features/expense_request/services/quick_statement_store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const channel = MethodChannel('plugins.it_nomads.com/flutter_secure_storage');
  final secureValues = <String, String>{};

  setUp(() async {
    secureValues.clear();
    SharedPreferences.setMockInitialValues({});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
          final arguments = (call.arguments as Map?)?.cast<String, Object?>();
          final key = arguments?['key'] as String?;
          switch (call.method) {
            case 'read':
              return key == null ? null : secureValues[key];
            case 'write':
              if (key != null) {
                secureValues[key] = arguments?['value'] as String? ?? '';
              }
              return null;
            case 'delete':
              if (key != null) secureValues.remove(key);
              return null;
            default:
              return null;
          }
        });
  });

  tearDown(
    () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null),
  );

  test('تحفظ الإضافة والتعديل والحذف عند إعادة تحميل العبارة', () async {
    const scope = 'sampleRequest';
    await QuickStatementStore.add(scope, 'عبارة اختبار جديدة');
    expect(
      await QuickStatementStore.load(scope),
      contains('عبارة اختبار جديدة'),
    );

    await QuickStatementStore.update(
      scope,
      'عبارة اختبار جديدة',
      'عبارة اختبار معدلة',
    );
    final afterUpdate = await QuickStatementStore.load(scope);
    expect(afterUpdate, contains('عبارة اختبار معدلة'));
    expect(afterUpdate, isNot(contains('عبارة اختبار جديدة')));

    await QuickStatementStore.delete(scope, 'عبارة اختبار معدلة');
    final afterDelete = await QuickStatementStore.load(scope);
    expect(afterDelete, isNot(contains('عبارة اختبار معدلة')));
  });

  test(
    'تحافظ على القائمة الفارغة المحفوظة ولا تعيد القيم الافتراضية',
    () async {
      const scope = 'fuelRequest';
      await QuickStatementStore.save(scope, const []);
      expect(await QuickStatementStore.load(scope), isEmpty);
    },
  );

  test('تفصل العبارات بين نطاقات النماذج', () async {
    await QuickStatementStore.add('sampleRequest', 'عبارة العينات');
    expect(
      await QuickStatementStore.load('fuelRequest'),
      isNot(contains('عبارة العينات')),
    );
  });
}
