import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/settings/models/app_settings.dart';

void main() {
  test('يحفظ نوع الإدخال ويضيف أسماء الجهات المطلوبة دون حذف المحفوظات', () {
    final settings = AppSettings.defaults().copyWith(
      stakeholderOptions: {
        'مقدم الطلب': ['اسم محفوظ'],
        'مدير الحسابات': ['محاسب محفوظ'],
      },
    );
    final restored = AppSettings.fromMap(settings.toMap());
    expect(
      restored.customerFieldSettings['previousPurchases']?.inputType,
      FieldInputType.amount,
    );
    expect(restored.stakeholderOptions['مقدم الطلب'], contains('اسم محفوظ'));
    expect(
      restored.stakeholderOptions['مقدم الطلب'],
      contains('عبدالعزيز كباس'),
    );
    expect(
      restored.stakeholderOptions['مدير الحسابات'],
      contains('محاسب محفوظ'),
    );
    expect(
      restored.stakeholderOptions['مدير الحسابات'],
      isNot(contains('توفيق القاضي')),
    );
  });

  test('يحفظ ألوان التطبيق والبيان والقوائم في الإعدادات', () {
    final defaults = AppSettings.defaults();
    final settings = defaults.copyWith(
      textColorValue: 0xFF0D47A1,
      backgroundColorValue: 0xFFFFD700,
      fieldBackgroundColorValue: 0xFFFFFFFF,
      receiverOptions: const ['مدير مجلس الإدارة', 'خيار إضافي'],
      fieldSettings: {
        ...defaults.fieldSettings,
        'statement': defaults.fieldSettings['statement']!.copyWith(
          width: 420,
          height: 160,
          lineHeight: 0.7,
          fontFamily: 'Noto Naskh Arabic',
          fontWeight: 800,
          fontStyle: 'italic',
          bottomX: 120,
          bottomY: 180,
          bottomWidth: 380,
        ),
      },
      bottomFieldSettings: {
        ...defaults.fieldSettings,
        'statement': defaults.fieldSettings['statement']!.copyWith(
          label: 'بيان النموذج السفلي',
          visible: true,
          fontSize: 11,
          x: 125,
          y: 175,
          width: 375,
          height: 96,
          lineHeight: 0.7,
        ),
      },
    );

    final restored = AppSettings.fromMap(settings.toMap());
    expect(restored.textColorValue, 0xFF0D47A1);
    expect(restored.backgroundColorValue, 0xFFFFD700);
    expect(restored.fieldBackgroundColorValue, 0xFFFFFFFF);
    expect(restored.receiverOptions, contains('خيار إضافي'));
    expect(restored.fieldSettings['statement']?.width, 420);
    expect(restored.fieldSettings['statement']?.height, 160);
    expect(restored.fieldSettings['statement']?.lineHeight, 0.7);
    expect(
      restored.fieldSettings['statement']?.fontFamily,
      'Noto Naskh Arabic',
    );
    expect(restored.fieldSettings['statement']?.fontWeight, 800);
    expect(restored.fieldSettings['statement']?.fontStyle, 'italic');
    expect(restored.fieldSettings['statement']?.bottomX, 120);
    expect(restored.fieldSettings['statement']?.bottomY, 180);
    expect(restored.fieldSettings['statement']?.bottomWidth, 380);
    expect(
      restored.bottomFieldSettings['statement']?.label,
      'بيان النموذج السفلي',
    );
    expect(restored.bottomFieldSettings['statement']?.fontSize, 11);
    expect(restored.bottomFieldSettings['statement']?.y, 175);
    expect(restored.bottomFieldSettings['statement']?.height, 96);
  });

  test('لا يعيد الحقل المحذوف عند استعادة الإعدادات', () {
    final defaults = AppSettings.defaults();
    final fields = Map<String, FieldSetting>.from(defaults.fieldSettings)
      ..remove('statement');
    final restored = AppSettings.fromMap(
      defaults.copyWith(fieldSettings: fields).toMap(),
    );
    expect(restored.fieldSettings.containsKey('statement'), isFalse);
  });

  test('يفصل مخطط الإخلاء والخدمة عن مخطط طلب الصرف', () {
    final clearance = AppSettings.defaultsForScope('clearanceRequest');
    final service = AppSettings.defaultsForScope('serviceRequest');

    expect(clearance.fieldSettings.containsKey('amountNumber'), isFalse);
    expect(clearance.fieldSettings.containsKey('branch'), isFalse);
    expect(clearance.fieldSettings.containsKey('statement'), isFalse);
    expect(service.fieldSettings.containsKey('amountWords'), isTrue);
    expect(service.fieldSettings['reason']?.label, 'نوع طلب الخدمة');
  });

  test('يفصل إعدادات الصفحة الواحدة عن طلب الصرف والتوقيعات', () {
    final single = AppSettings.defaultsForScope('sampleRequestSinglePage');
    expect(single.fieldSettings, contains('sampleItemName25'));
    expect(single.fieldSettings, isNot(contains('amountNumber')));
    expect(single.fieldSettings, isNot(contains('amountWords')));
    expect(single.fieldSettings, isNot(contains('dateLabel')));
    expect(single.fieldSettings, isNot(contains('reasonPage3')));
    expect(single.fieldSettings, isNot(contains('requesterSignature')));
    expect(single.fieldSettings, isNot(contains('directManagerSignature')));
    expect(single.fieldSettings, isNot(contains('accountsManagerSignature')));
  });

  test('يحافظ كل نطاق نموذج على هندسته دون خلط مع النطاقات الأخرى', () {
    final expense = AppSettings.defaultsForScope('expenseRequest');
    final customer = AppSettings.defaultsForScope('customerApplication');
    final movedCustomer = customer.copyWith(
      customerFieldSettings: {
        ...customer.customerFieldSettings,
        'customer': customer.customerFieldSettings['customer']!.copyWith(
          x: 444,
          y: 333,
          width: 180,
          geometryConfigured: true,
        ),
      },
    );

    expect(movedCustomer.customerFieldSettings['customer']!.x, 444);
    expect(movedCustomer.customerFieldSettings['customer']!.y, 333);
    expect(expense.fieldSettings.containsKey('customer'), isFalse);
    expect(expense.fieldSettings['statement']!.x, isNot(444));
  });

  test('الخريطة الفارغة أو null تستخدم الحقول الافتراضية', () {
    final defaults = AppSettings.defaults();
    final empty = AppSettings.fromMap({
      ...defaults.toMap(),
      'fieldSettings': <String, Object?>{},
    });
    final nullValue = AppSettings.fromMap({
      ...defaults.toMap(),
      'fieldSettings': null,
    });
    expect(empty.fieldSettings.containsKey('statement'), isTrue);
    expect(nullValue.fieldSettings.containsKey('statement'), isTrue);
  });

  test('يصلح قيم lineHeight التالفة تلقائياً', () {
    final damaged = AppSettings.defaults().copyWith(
      fieldSettings: {
        'statement': const FieldSetting(
          label: 'البيان',
          visible: true,
          required: true,
          lineHeight: 0.2,
        ),
      },
    );

    final restored = AppSettings.fromMap(damaged.toMap());
    expect(restored.fieldSettings['statement']?.lineHeight, 0.2);
  });

  test('تغييرات الخط والتنسيق لا تغيّر هندسة الحقل المحفوظة', () {
    const original = FieldSetting(
      label: 'البيان',
      visible: true,
      required: false,
      fontSize: 11,
      x: 82,
      y: 162,
      width: 390,
      height: 180,
      bottomX: 82,
      bottomY: 162,
      bottomWidth: 390,
      fontFamily: 'Noto Naskh Arabic',
      fontWeight: 400,
      fontStyle: 'normal',
      alignment: 'right',
      lineHeight: 1.5,
      geometryConfigured: true,
    );

    final changed = original.copyWith(
      fontSize: 16,
      fontFamily: 'Cairo',
      fontWeight: 700,
      fontStyle: 'italic',
      alignment: 'center',
      lineHeight: 1.1,
      colorValue: 0xFFB71C1C,
    );

    expect(changed.x, original.x);
    expect(changed.y, original.y);
    expect(changed.width, original.width);
    expect(changed.height, original.height);
    expect(changed.bottomX, original.bottomX);
    expect(changed.bottomY, original.bottomY);
    expect(changed.bottomWidth, original.bottomWidth);
    expect(changed.geometryConfigured, isTrue);
  });

  test('يتجاهل تخصيصات bottom القديمة عند طباعة التخطيط الرئيسي', () {
    final defaults = AppSettings.defaults();
    final top = defaults.fieldSettings['statement']!;
    final legacyBottom = top.copyWith(
      x: 91,
      y: 170,
      width: 380,
      height: 140,
      geometryConfigured: true,
      fontSize: 18,
      colorValue: 0xFFB71C1C,
    );
    final migrated = defaults
        .copyWith(bottomFieldSettings: {'statement': legacyBottom})
        .withExpenseRequestMasterLayout();
    final result = migrated.fieldSettings['statement']!;

    expect(result.x, top.x);
    expect(result.y, top.y);
    expect(result.width, top.width);
    expect(result.height, top.height);
    expect(result.fontSize, top.fontSize);
    expect(result.colorValue, top.colorValue);
    expect(migrated.bottomFieldSettings['statement'], legacyBottom);
  });
  test('global stakeholder and branch suggestions are shared across forms', () {
    final settings = AppSettings.defaults();
    expect(
      settings.branchOptions,
      containsAll([
        'كبار العملاء',
        'الجنوبية',
        'الغربية',
        'الشمالية',
        'الوسطى',
        'إب أرياف',
      ]),
    );
    expect(
      settings.stakeholderOptions['مدير الحسابات'],
      contains('أ/ توفيق القاضي'),
    );
    expect(
      settings.stakeholderOptions['مقدم الطلب'],
      contains('عبدالعزيز كباس'),
    );
    expect(
      settings.stakeholderOptions['محاسب الإدارة'],
      contains('عبدالعزيز كباس'),
    );
    expect(
      settings.stakeholderOptions['مختص حسابات الفرع'],
      containsAll(settings.stakeholderOptions['محاسب الفرع']!),
    );
  });
}
