import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/expense_request/services/amount_to_words.dart';

void main() {
  test('يحوّل المبلغ الصحيح إلى كلمات عربية', () {
    expect(AmountToWords.fromNumber('1250'), 'ألف ومائتان وخمسون ريال');
  });

  test('يدعم الأرقام العربية والكسور العشرية', () {
    expect(
      AmountToWords.fromNumber('١٢٥٠٫٥٠'),
      'ألف ومائتان وخمسون ريال وخمسون فلس',
    );
  });

  test('يعالج الواحد والاثنين دون تكرار اسم العملة', () {
    expect(AmountToWords.fromNumber('1'), 'ريال واحد');
    expect(AmountToWords.fromNumber('2'), 'ريالان');
    expect(AmountToWords.fromNumber('1.50'), 'ريال واحد وخمسون فلس');
  });

  test('يعالج الصفر والمدخل غير الصالح', () {
    expect(AmountToWords.fromNumber('0'), 'صفر ريال');
    expect(AmountToWords.fromNumber('12.345'), isEmpty);
    expect(AmountToWords.fromNumber('-10'), isEmpty);
  });

  test('ينسق الأرقام بفواصل الآلاف', () {
    expect(AmountToWords.formatNumber('50000'), '50,000');
    expect(AmountToWords.formatNumber('١٢٥٠٫٥٠'), '1,250.50');
    expect(AmountToWords.formatNumber('12.345'), '12.345');
  });

  test('يزيل تنوين العملة والمقاييس', () {
    expect(AmountToWords.fromNumber('1000'), 'ألف ريال');
    expect(AmountToWords.fromNumber('11000'), 'أحد عشر ألف ريال');
    expect(AmountToWords.fromNumber('1000000'), 'مليون ريال');
    expect(AmountToWords.fromNumber('1250'), isNot(contains('ريالاً')));
    expect(AmountToWords.fromNumber('1250'), isNot(contains('ألفاً')));
  });

  test('لا يضيف واو قبل العملة ولا يضيف كلمة فقط', () {
    final words = AmountToWords.fromNumber('5213');
    expect(words, 'خمسة آلاف ومائتان وثلاثة عشر ريال');
    expect(words, isNot(contains('و ريال')));
    expect(words, isNot(contains('فقط')));
    expect(AmountToWords.fromNumber('50000'), 'خمسون ألف ريال');
  });
}
