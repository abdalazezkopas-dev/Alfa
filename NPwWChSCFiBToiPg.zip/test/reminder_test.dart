import 'package:flutter_test/flutter_test.dart';
import 'package:alfa_expense_app/features/reminders/models/reminder.dart';

void main() {
  test('reminder preserves its content, completion state, and snooze', () {
    final original = Reminder(
      id: 42,
      title: 'مراجعة الطلب',
      notes: 'التأكد من المرفقات',
      scheduledAt: DateTime(2026, 9, 13, 12, 30),
      isDone: true,
      snoozedUntil: DateTime(2026, 9, 13, 12, 40),
    );
    final restored = Reminder.fromMap(original.toMap());
    expect(restored.id, original.id);
    expect(restored.title, original.title);
    expect(restored.notes, original.notes);
    expect(restored.scheduledAt, original.scheduledAt);
    expect(restored.isDone, isTrue);
    expect(restored.snoozedUntil, original.snoozedUntil);
    expect(restored.copyWith(clearSnoozedUntil: true).snoozedUntil, isNull);
  });

  test('older reminders without a snooze field remain readable', () {
    final restored = Reminder.fromMap({
      'id': 12,
      'title': 'موعد قديم',
      'notes': '',
      'scheduledAt': DateTime(2026, 9, 13, 12).toIso8601String(),
    });

    expect(restored.id, 12);
    expect(restored.title, 'موعد قديم');
    expect(restored.snoozedUntil, isNull);
  });
}
