import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/features/settings/models/app_settings.dart';
import 'package:alfa_expense_app/features/settings/services/settings_store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  const secureStorageChannel = MethodChannel(
    'plugins.it_nomads.com/flutter_secure_storage',
  );
  final secureStorage = <String, String>{};

  setUp(() {
    SharedPreferences.setMockInitialValues({});
    secureStorage.clear();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(secureStorageChannel, (call) async {
          final arguments = call.arguments as Map<dynamic, dynamic>? ?? {};
          final key = arguments['key'] as String?;
          switch (call.method) {
            case 'read':
              return key == null ? null : secureStorage[key];
            case 'write':
              if (key != null) {
                secureStorage[key] = arguments['value'] as String;
              }
              return null;
            case 'delete':
              if (key != null) secureStorage.remove(key);
              return null;
            case 'deleteAll':
              secureStorage.clear();
              return null;
            case 'readAll':
              return Map<String, String>.from(secureStorage);
            default:
              return null;
          }
        });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(secureStorageChannel, null);
  });

  test(
    'preserves manually configured sample geometry during migration',
    () async {
      const scope = 'sampleRequest';
      const geometryRevisionKey = 'alfa_expense_app.sample_geometry_revision';
      final defaults = AppSettings.defaultsForScope(scope);
      final originalField = defaults.fieldSettings['sampleItemName1']!;
      final customField = originalField.copyWith(
        x: 477,
        y: 243,
        width: 188,
        height: 25,
        geometryConfigured: true,
      );
      final oldSettings = defaults.copyWith(
        fieldSettings: {
          ...defaults.fieldSettings,
          'sampleItemName1': customField,
        },
      );
      SharedPreferences.setMockInitialValues({
        'alfa_expense_app.settings.$scope': jsonEncode(oldSettings.toMap()),
        geometryRevisionKey: 1,
      });

      final migrated = await SettingsStore.load(scope: scope);
      final migratedField = migrated.fieldSettings['sampleItemName1']!;
      final preferences = await SharedPreferences.getInstance();

      expect(migratedField.x, 477);
      expect(migratedField.y, 243);
      expect(migratedField.width, 188);
      expect(migratedField.height, 25);
      expect(migratedField.geometryConfigured, isTrue);
      expect(preferences.getInt(geometryRevisionKey), 4);
    },
  );

  test(
    'refreshes unconfigured legacy sample geometry to current defaults',
    () async {
      const scope = 'sampleRequest';
      const geometryRevisionKey = 'alfa_expense_app.sample_geometry_revision';
      final defaults = AppSettings.defaultsForScope(scope);
      final defaultField = defaults.fieldSettings['sampleItemName1']!;
      final oldUnconfiguredField = defaultField.copyWith(
        x: 999,
        y: 999,
        geometryConfigured: false,
      );
      final oldSettings = defaults.copyWith(
        fieldSettings: {
          ...defaults.fieldSettings,
          'sampleItemName1': oldUnconfiguredField,
        },
      );
      SharedPreferences.setMockInitialValues({
        'alfa_expense_app.settings.$scope': jsonEncode(oldSettings.toMap()),
        geometryRevisionKey: 1,
      });

      final migrated = await SettingsStore.load(scope: scope);
      final migratedField = migrated.fieldSettings['sampleItemName1']!;

      expect(migratedField.x, defaultField.x);
      expect(migratedField.y, defaultField.y);
      expect(migratedField.geometryConfigured, defaultField.geometryConfigured);
    },
  );
}
