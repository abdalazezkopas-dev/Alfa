import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/representative_reports/models/representative_report.dart';

void main() {
  test('report round-trips all fields and retains the template row counts', () {
    final report =
        RepresentativeReport.empty(
          id: 'report-1',
          date: 'م2026/10/20',
        ).copyWith(
          medRep: 'مندوب تجريبي',
          day: 'الثلاثاء',
          city: 'صنعاء',
          district: 'التحرير',
          section: 'المبيعات',
          morningPhysicians: [
            const RepresentativePhysicianEntry(
              name: 'د. أحمد',
              specialty: 'باطنة',
              className: 'A',
              address: 'شارع 1',
              samplesDelivered: 'صنف تجريبي',
              observation: 'ملاحظة',
            ),
            ...List.generate(
              representativePhysicianRowCount - 1,
              (_) => const RepresentativePhysicianEntry(),
            ),
          ],
          morningPharmacies: [
            const RepresentativePharmacyEntry(
              name: 'صيدلية 1',
              notice: 'تمت الزيارة',
            ),
            ...List.generate(
              representativePharmacyRowCount - 1,
              (_) => const RepresentativePharmacyEntry(),
            ),
          ],
        );

    final restored = RepresentativeReport.fromMap(report.toMap());

    expect(restored.toMap(), report.toMap());
    expect(restored.morningPhysicians, hasLength(7));
    expect(restored.eveningPhysicians, hasLength(7));
    expect(restored.morningPharmacies, hasLength(5));
    expect(restored.eveningPharmacies, hasLength(5));
  });

  test(
    'fills missing rows and ignores rows beyond the fixed template size',
    () {
      final restored = RepresentativeReport.fromMap({
        'id': 'report-2',
        'morningPhysicians': [
          {'name': 'الأول'},
          for (var i = 0; i < 10; i++) {'name': 'طبيب $i'},
        ],
      });

      expect(restored.morningPhysicians, hasLength(7));
      expect(restored.morningPhysicians.first.name, 'الأول');
      expect(restored.morningPhysicians.last.name, 'طبيب 5');
      expect(restored.eveningPhysicians, hasLength(7));
      expect(restored.morningPharmacies, hasLength(5));
      expect(restored.eveningPharmacies, hasLength(5));
    },
  );
}
