import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/calculator/engine/calculator_engine.dart';

void main() {
  test('يحسب النسبة من الطرف السابق في الجمع والطرح', () {
    expect(CalculatorEngine.evaluate('200+10%'), 220);
    expect(CalculatorEngine.evaluate('200-10%'), 180);
  });

  test('يحسب النسبة المنفردة ومع الضرب والقسمة', () {
    expect(CalculatorEngine.evaluate('10%'), 0.1);
    expect(CalculatorEngine.evaluate('200*10%'), 20);
    expect(CalculatorEngine.evaluate('200/10%'), 2000);
  });

  test('يدعم السالب بعد الضرب وقبل الأقواس والأقواس المتداخلة', () {
    expect(CalculatorEngine.evaluate('12*-3'), -36);
    expect(CalculatorEngine.evaluate('(-12)+5'), -7);
    expect(CalculatorEngine.evaluate('-(2+3)*4'), -20);
    expect(CalculatorEngine.evaluate('2*(3+(4*5))'), 46);
  });

  test('يطبع ويفهم الكسور التي تبدأ أو تنتهي بفاصلة عشرية', () {
    expect(CalculatorEngine.evaluate('.5 + 1.'), 1.5);
    expect(CalculatorEngine.evaluate('٠٫١ + ٠٫٢'), 0.3);
  });

  test('يوحّد دقة الحساب لتفادي خطأ الفاصلة العائمة المعتاد', () {
    expect(CalculatorEngine.evaluate('0.1+0.2'), 0.3);
    expect(CalculatorEngine.evaluate('1/3'), 0.333333333333);
    expect(CalculatorEngine.formatForExpression(1 / 3), '0.333333333333');
  });

  test('يرفض القسمة على صفر بدل إنتاج NaN', () {
    expect(
      () => CalculatorEngine.evaluate('12/0'),
      throwsA(isA<FormatException>()),
    );
  });

  test('يرفض المعاملات والأقواس غير الصحيحة', () {
    for (final expression in ['12++3', '12+*3', '(12+3', '12+3)', '10%%']) {
      expect(
        () => CalculatorEngine.evaluate(expression),
        throwsA(isA<FormatException>()),
        reason: expression,
      );
    }
  });

  test('يحدّث الذاكرة إلى نص غير علمي قابل للقراءة كمُدخل', () {
    expect(CalculatorEngine.formatForExpression(1200), '1200');
    expect(CalculatorEngine.formatForExpression(0.125), '0.125');
  });
}
