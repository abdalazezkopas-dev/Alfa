import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/expense_request/services/pdf_service.dart';
import 'package:alfa_expense_app/features/expense_request/services/pdf_text_sanitizer.dart';
import 'package:alfa_expense_app/features/settings/models/template_configuration.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('يحوّل الصيغ العربية العرضية إلى حروف أساسية', () {
    expect(PdfTextSanitizer.normalize('ق\uFEF0'), 'قى');
    expect(PdfTextSanitizer.normalize('\uFEDB'), 'ك');
    expect(PdfTextSanitizer.normalize('م\uFEDB\uFEF0'), 'مكى');

    expect(PdfTextSanitizer.normalize('لا'), 'لا');
    expect(PdfTextSanitizer.normalize('للا'), 'للا');
    expect(PdfTextSanitizer.normalize('\uFEFC'), 'لا');
  });

  test('يحذف الرموز الخفية وغير الصالحة من النص المحفوظ', () {
    const value = 'بيان\uFFFE محفوظ\u202E لا للا';
    expect(PdfTextSanitizer.normalize(value), 'بيان محفوظ لا للا');
  });

  test('يطبع جميع حقول الطلب قبل تمريرها إلى مولد PDF', () {
    const request = ExpenseRequest(
      date: '26/08/2026',
      receiver: '\uFEDB',
      amountNumber: '1250.50',
      amountWords: 'ألف ومائتان وخمسون ريال وخمسون فلس',
      reason: 'اختبار رمز عربي عرضي \uFEDB',
      statement: 'بيان اختبار \uFEF0',
      branch: 'الفرع الرئيسي',
      account: 'المصروفات التشغيلية',
      requesterName: 'ق\uFEF0',
      requesterSignature: 'ق\uFEF0',
      directManagerName: 'محمد',
      directManagerSignature: 'محمد',
      approvedAuthorityName: 'خالد',
      approvedAuthoritySignature: 'خالد',
      accountsManagerName: 'سعيد',
      accountsManagerSignature: 'سعيد',
      customFields: {'custom_test': '\uFEDB'},
    );

    final sanitized = PdfTextSanitizer.normalizeRequest(request);
    expect(sanitized.receiver, 'ك');
    expect(sanitized.reason, 'اختبار رمز عربي عرضي ك');
    expect(sanitized.statement, 'بيان اختبار ى');
    expect(sanitized.customFields['custom_test'], 'ك');
  });

  test('ينشئ PDF للحرف العربي المفرد ب دون Missing glyph', () async {
    const request = ExpenseRequest(
      date: '26/08/2026',
      receiver: 'ب',
      amountNumber: '1',
      amountWords: 'ب',
      reason: 'ب',
      statement: 'ب',
      branch: 'ب',
      account: 'ب',
      requesterName: 'ب',
      requesterSignature: 'ب',
      directManagerName: 'ب',
      directManagerSignature: 'ب',
      approvedAuthorityName: 'ب',
      approvedAuthoritySignature: 'ب',
      accountsManagerName: 'ب',
      accountsManagerSignature: 'ب',
    );

    final bytes = await PdfService.buildRequestPdf(request);
    expect(bytes, isNotEmpty);
  });

  test('ينشئ PDF دون Missing glyph للنصوص العربية العرضية', () async {
    const request = ExpenseRequest(
      date: '26/08/2026',
      receiver: '\uFEFC',
      amountNumber: '1250.50',
      amountWords: 'لا يوجد أي مانع من صرف المبلغ، والله ولي التوفيق',
      reason: 'اختبار ligature عربي: الله لا يضيع أجر المحسنين ق\uFEDB',
      statement: 'بيان اختبار: لا إله إلا الله',
      branch: 'الفرع الرئيسي',
      account: 'المصروفات التشغيلية',
      requesterName: 'ق\uFEDB',
      requesterSignature: 'ق\uFEDB',
      directManagerName: 'محمد',
      directManagerSignature: 'محمد',
      approvedAuthorityName: 'خالد',
      approvedAuthoritySignature: 'خالد',
      accountsManagerName: 'سعيد',
      accountsManagerSignature: 'سعيد',
    );

    final bytes = await PdfService.buildRequestPdf(request);
    expect(bytes, isNotEmpty);
    await File('/tmp/alfa_font_fix_fecfc_sample.pdf').writeAsBytes(bytes);
  });

  test('يحافظ التطبيع على Snapshot وتخطيط A4 والمرفق والمفضلة', () {
    const request = ExpenseRequest(
      date: '09/09/2026',
      receiver: 'أ',
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: 'بيان',
      branch: '',
      account: '',
      requesterName: 'مقدم',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      isFavorite: true,
      attachmentPath: '/permanent/file.png',
      settingsSnapshot: {
        'memoFullA4FieldSettings': {
          'statement': {'x': 150, 'y': 600},
        },
      },
      documentType: ExpenseDocumentType.internalMemo,
      memoLayout: InternalMemoLayout.fullA4,
    );
    final normalized = PdfTextSanitizer.normalizeRequest(request);
    expect(normalized.memoLayout, InternalMemoLayout.fullA4);
    expect(normalized.isFavorite, isTrue);
    expect(normalized.attachmentPath, '/permanent/file.png');
    expect(normalized.settingsSnapshot, request.settingsSnapshot);
  });
}
