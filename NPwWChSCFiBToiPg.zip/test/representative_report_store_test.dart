import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/features/representative_reports/models/representative_report.dart';
import 'package:alfa_expense_app/features/representative_reports/services/representative_report_store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  const secureStorageChannel = MethodChannel(
    'plugins.it_nomads.com/flutter_secure_storage',
  );
  final secureStorage = <String, String>{};

  setUp(() {
    SharedPreferences.setMockInitialValues({});
    secureStorage.clear();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(secureStorageChannel, (call) async {
          final arguments = call.arguments as Map<dynamic, dynamic>? ?? {};
          final key = arguments['key'] as String?;
          switch (call.method) {
            case 'read':
              return key == null ? null : secureStorage[key];
            case 'write':
              if (key != null) {
                secureStorage[key] = arguments['value'] as String;
              }
              return null;
            case 'delete':
              if (key != null) {
                secureStorage.remove(key);
              }
              return null;
            case 'deleteAll':
              secureStorage.clear();
              return null;
            case 'readAll':
              return Map<String, String>.from(secureStorage);
            default:
              return null;
          }
        });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(secureStorageChannel, null);
  });

  test(
    'add and update persist reports through encrypted local storage',
    () async {
      final report = RepresentativeReport.empty(
        id: 'rep-1',
      ).copyWith(medRep: 'مندوب صنعاء', city: 'صنعاء');

      await RepresentativeReportStore.add(report);
      final loaded = await RepresentativeReportStore.load();
      expect(loaded, hasLength(1));
      expect(loaded.single.toMap(), report.toMap());

      final updated = report.copyWith(district: 'التحرير');
      expect(await RepresentativeReportStore.update(updated), isTrue);
      expect(
        (await RepresentativeReportStore.load()).single.district,
        'التحرير',
      );
    },
  );

  test('updating a missing report does not create a record', () async {
    final report = RepresentativeReport.empty(id: 'missing');
    expect(await RepresentativeReportStore.update(report), isFalse);
    expect(await RepresentativeReportStore.load(), isEmpty);
  });

  test(
    'duplicate report ids are rejected without replacing saved data',
    () async {
      final first = RepresentativeReport.empty(
        id: 'same',
      ).copyWith(medRep: 'الأول');
      await RepresentativeReportStore.add(first);

      await expectLater(
        RepresentativeReportStore.add(
          RepresentativeReport.empty(id: 'same').copyWith(medRep: 'الثاني'),
        ),
        throwsA(isA<StateError>()),
      );
      expect((await RepresentativeReportStore.load()).single.medRep, 'الأول');
    },
  );
}
