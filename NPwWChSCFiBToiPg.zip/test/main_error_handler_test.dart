import 'dart:ui' show PlatformDispatcher;

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/main.dart' show installFlutterErrorHandlers;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('installs PlatformDispatcher handler without swallowing errors', () {
    final dispatcher = PlatformDispatcher.instance;
    final previousPlatformHandler = dispatcher.onError;
    final previousFlutterHandler = FlutterError.onError;
    final previousErrorWidgetBuilder = ErrorWidget.builder;
    addTearDown(() {
      dispatcher.onError = previousPlatformHandler;
      FlutterError.onError = previousFlutterHandler;
      ErrorWidget.builder = previousErrorWidgetBuilder;
    });

    installFlutterErrorHandlers();
    final handler = dispatcher.onError;

    expect(handler, isNotNull);
    expect(
      handler!(StateError('private user-entered value'), StackTrace.current),
      isFalse,
      reason: 'The default platform handling should remain enabled.',
    );
  });
}
