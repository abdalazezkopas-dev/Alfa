import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/features/representative_reports/screens/representative_reports_screen.dart';
import 'package:alfa_expense_app/features/settings/screens/template_catalog_screen.dart';
import 'package:alfa_expense_app/features/sample_request/screens/sample_request_single_page_screen.dart';
import 'package:alfa_expense_app/features/sample_request/screens/sample_request_three_page_screen.dart';

void main() {
  testWidgets('sample request selection shows both PDF template buttons', (
    tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(home: TemplateCatalogScreen(selectionMode: true)),
    );
    await tester.pump();

    final singlePageButton = find.text('طلب عينات — صفحة واحدة');
    final threePageButton = find.text('طلب عينات — ثلاث صفحات');
    await tester.scrollUntilVisible(
      singlePageButton,
      500,
      scrollable: find.byType(Scrollable).first,
    );
    expect(singlePageButton, findsOneWidget);
    expect(threePageButton, findsOneWidget);
  });

  testWidgets('opens the three-page sample request form from the catalog', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(
      const MaterialApp(home: TemplateCatalogScreen(selectionMode: true)),
    );
    await tester.pump();
    final button = find.text('طلب عينات — ثلاث صفحات');
    await tester.scrollUntilVisible(
      button,
      500,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.tap(button);
    await tester.pumpAndSettle();

    expect(find.text('البيانات العامة'), findsWidgets);
    expect(find.widgetWithText(TextFormField, 'التاريخ'), findsOneWidget);
    expect(find.byType(SampleRequestThreePageScreen), findsOneWidget);
    expect(find.text('نوع نموذج طلب العينات'), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets('opens the single-page sample request form from the catalog', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(
      const MaterialApp(home: TemplateCatalogScreen(selectionMode: true)),
    );
    await tester.pump();
    final button = find.text('طلب عينات — صفحة واحدة');
    await tester.scrollUntilVisible(
      button,
      500,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.tap(button);
    await tester.pumpAndSettle();

    expect(find.text('البيانات العامة'), findsWidgets);
    expect(find.widgetWithText(TextFormField, 'التاريخ'), findsOneWidget);
    expect(find.byType(SampleRequestSinglePageScreen), findsOneWidget);
    expect(find.text('نوع نموذج طلب العينات'), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets('opens the independent representative reports module', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(
      const MaterialApp(home: TemplateCatalogScreen(selectionMode: true)),
    );
    final reportCard = find.text('تقارير المندوبين');
    await tester.scrollUntilVisible(
      reportCard,
      500,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.tap(reportCard);
    await tester.pumpAndSettle();

    expect(find.byType(RepresentativeReportsScreen), findsOneWidget);
    expect(find.text('لا توجد تقارير محفوظة'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
