import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:alfa_expense_app/features/expense_request/utils/clearance_amount_math.dart';

void main() {
  group('ClearanceAmountMath', () {
    test('normalizes Arabic digits and rounds each amount to two decimals', () {
      expect(ClearanceAmountMath.normalizeAmount('١٬٢٣٤٫٥٦٧'), '1234.57');
      expect(ClearanceAmountMath.normalizeAmount('-1.005'), '-1.01');
      expect(ClearanceAmountMath.normalizeAmount('-0.004'), '0.00');
    });

    test('sums already-rounded minor units and groups the display', () {
      final total = ClearanceAmountMath.sumMinorUnits(['0.105', '0.105', '-1']);
      expect(total, BigInt.from(-78));
      expect(
        ClearanceAmountMath.formatGroupedAmount('-1234567.5'),
        '-1,234,567.50',
      );
    });

    test('rejects malformed amounts', () {
      expect(
        () => ClearanceAmountMath.toMinorUnits('12-3'),
        throwsFormatException,
      );
    });
  });

  test('formatter accepts a negative Arabic-digit amount and groups it', () {
    final formatter = ClearanceAmountInputFormatter();
    final result = formatter.formatEditUpdate(
      TextEditingValue.empty,
      const TextEditingValue(
        text: '-١٢٣٤٫٥',
        selection: TextSelection.collapsed(offset: 7),
      ),
    );
    expect(result.text, '-1,234.5');
  });
}
