import 'package:flutter_test/flutter_test.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';

void main() {
  test('shared branch options survive settings serialization', () {
    final settings = AppSettings.defaults().copyWith(
      branchOptions: ['الفرع الرئيسي', 'فرع صنعاء'],
    );
    final restored = AppSettings.fromMap(settings.toMap());
    expect(restored.branchOptions, containsAll(['الفرع الرئيسي', 'فرع صنعاء']));
  });

  test('customer settings remain independently addressable', () {
    final settings = AppSettings.defaults();
    expect(settings.customerFieldSettings['customer']!.label, 'اسم العميل');
    expect(
      settings.branchOptions,
      containsAll([
        'كبار العملاء',
        'الجنوبية',
        'الغربية',
        'الشمالية',
        'الوسطى',
        'إب أرياف',
      ]),
    );
  });

  test('محاسب الفرع مستقل عن قائمة الفروع ويحافظ على سهم الاقتراحات', () {
    final settings = AppSettings.defaults().copyWith(
      branchOptions: ['الفرع الرئيسي'],
      stakeholderOptions: {
        ...AppSettings.defaults().stakeholderOptions,
        'محاسب الفرع': ['محاسب 1'],
      },
    );
    expect(settings.branchOptions, ['الفرع الرئيسي']);
    expect(settings.stakeholderOptions['محاسب الفرع'], ['محاسب 1']);
    expect(
      settings.stakeholderOptions['محاسب الفرع'],
      isNot(equals(settings.branchOptions)),
    );
  });

  test('كل نموذج يحتفظ بلقطة إعدادات مستقلة قابلة للاستعادة', () {
    final customer = AppSettings.defaultsForScope('customerApplication')
        .copyWith(
          customerFieldSettings: {
            ...AppSettings.defaultsForScope(
              'customerApplication',
            ).customerFieldSettings,
            'customer': AppSettings.defaultsForScope('customerApplication')
                .customerFieldSettings['customer']!
                .copyWith(x: 411, geometryConfigured: true),
          },
        );
    final expense = AppSettings.defaultsForScope('expenseRequest');
    final restoredCustomer = AppSettings.fromMap(customer.toMap());
    final restoredExpense = AppSettings.fromMap(expense.toMap());
    expect(restoredCustomer.customerFieldSettings['customer']!.x, 411);
    expect(restoredExpense.customerFieldSettings['customer']!.x, isNot(411));
    expect(restoredExpense.fieldSettings.containsKey('statement'), isTrue);
  });
}
