import 'dart:convert';

import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/representative_reports/models/representative_report.dart';
import 'package:alfa_expense_app/features/representative_reports/services/representative_report_pdf_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('builds a non-empty PDF for a one-page landscape report', () async {
    final report =
        RepresentativeReport.empty(
          id: 'pdf-report',
          date: 'م2026/10/20',
        ).copyWith(
          medRep: 'مندوب تجريبي',
          morningPhysicians: [
            const RepresentativePhysicianEntry(name: 'د. أحمد'),
            ...List.generate(
              representativePhysicianRowCount - 1,
              (_) => const RepresentativePhysicianEntry(),
            ),
          ],
        );

    final bytes = await RepresentativeReportPdfService.build(report);
    final header = String.fromCharCodes(bytes.take(8));
    final content = latin1.decode(bytes);
    final pageCount = RegExp(r'/Type\s*/Page\b').allMatches(content).length;
    final mediaBox = RegExp(
      r'/MediaBox\s*\[\s*0\s+0\s+([0-9.]+)\s+([0-9.]+)\s*\]',
    ).firstMatch(content);

    expect(bytes, isNotEmpty);
    expect(header, startsWith('%PDF-'));
    expect(pageCount, 1);
    expect(mediaBox, isNotNull);
    expect(
      double.parse(mediaBox!.group(1)!),
      greaterThan(double.parse(mediaBox.group(2)!)),
    );
  });
}
