import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/expense_request/services/pdf_service.dart';
import 'package:alfa_expense_app/features/fuel/screens/fuel_request_screen.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'fuel request preserves rows and renders an ISO landscape PDF',
    () async {
      const request = ExpenseRequest(
        date: '01/09/2026',
        receiver: 'المحصل',
        amountNumber: '12,500',
        amountWords: '',
        reason: 'محروقات',
        statement: '30/09/2026',
        branch: 'صنعاء',
        account: '',
        requesterName: 'الموظف المستفيد',
        requesterSignature: '',
        directManagerName: 'مدير الفرع',
        directManagerSignature: '',
        approvedAuthorityName: 'مختص حسابات الفرع',
        approvedAuthoritySignature: '',
        accountsManagerName: 'مدير الحسابات',
        accountsManagerSignature: '',
        documentType: ExpenseDocumentType.fuelRequest,
        customFields: {
          'fuelBranch': 'صنعاء',
          'collector': 'المحصل',
          'fuelType': 'ديزل',
          'administrationAccountant': 'عبدالعزيز كباس',
          'accountsManager': 'أ/ توفيق القاضي',
          'periodFrom': '01/09/2026',
          'periodTo': '30/09/2026',
        },
        fuelEntries: [
          FuelEntry(
            date: '05/09/2026',
            meter: '12000',
            liters: '80',
            literPrice: '1,500',
            fuelAmount: '120,000',
            collection: '120,000',
            sales: '130,000',
            route: 'صنعاء - عمران',
          ),
        ],
      );

      final restored = ExpenseRequest.fromMap(request.toMap());
      expect(restored.documentType, ExpenseDocumentType.fuelRequest);
      expect(restored.fuelEntries, hasLength(1));
      expect(restored.fuelEntries.single.route, 'صنعاء - عمران');

      final bytes = await PdfService.buildRequestPdf(restored);
      expect(bytes, isNotEmpty);
      expect(bytes.take(5).toList(), <int>[37, 80, 68, 70, 45]);
    },
  );

  test(
    'fuel request renders the selected fuel mark as a PDF text checkmark',
    () async {
      const request = ExpenseRequest(
        date: '01/09/2026',
        receiver: 'المحصل',
        amountNumber: '',
        amountWords: '',
        reason: 'محروقات',
        statement: '30/09/2026',
        branch: 'صنعاء',
        account: '',
        requesterName: '',
        requesterSignature: '',
        directManagerName: '',
        directManagerSignature: '',
        approvedAuthorityName: '',
        approvedAuthoritySignature: '',
        accountsManagerName: '',
        accountsManagerSignature: '',
        documentType: ExpenseDocumentType.fuelRequest,
        customFields: {'fuelType': 'بترول'},
      );
      final bytes = await PdfService.buildRequestPdf(request);
      expect(bytes, isNotEmpty);
      expect(bytes.take(5).toList(), <int>[37, 80, 68, 70, 45]);
    },
  );

  testWidgets('fuel meter field uses an English numeric keyboard', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const MaterialApp(home: FuelRequestScreen()));
    await tester.pump();
    await tester.pumpAndSettle();

    final editableFinder = find.byWidgetPredicate(
      (widget) =>
          widget is EditableText &&
          widget.keyboardType == TextInputType.number &&
          widget.textDirection == TextDirection.ltr,
    );
    expect(editableFinder, findsOneWidget);
    final editable = tester.widget<EditableText>(editableFinder);
    expect(editable.keyboardType, TextInputType.number);
    expect(editable.textDirection, TextDirection.ltr);
  }, skip: true);
}
