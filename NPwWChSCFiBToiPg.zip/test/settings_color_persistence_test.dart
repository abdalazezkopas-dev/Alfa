import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';
import 'package:alfa_expense_app/features/settings/models/template_configuration.dart';
import 'package:alfa_expense_app/features/settings/services/settings_store.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('الأزرق هو اللون الافتراضي للنص فوق النماذج والحقول', () {
    final settings = AppSettings.defaults();
    expect(settings.printedTextColorValue, 0xFF0070C0);
    expect(settings.fieldSettings['statement']!.colorValue, 0xFF0070C0);
    expect(settings.customerFieldSettings['customer']!.colorValue, 0xFF0070C0);
  });

  test('selected settings colors survive serialization and reload', () {
    final original = AppSettings.defaults().copyWith(
      primaryColorValue: 0xFF123456,
      textColorValue: 0xFF654321,
      backgroundColorValue: 0xFFF0F0F0,
      fieldBackgroundColorValue: 0xFFFFFFFF,
      printedTextColorValue: 0xFFAA1122,
    );
    final restored = AppSettings.fromMap(original.toMap());
    expect(restored.primaryColorValue, 0xFF123456);
    expect(restored.textColorValue, 0xFF654321);
    expect(restored.backgroundColorValue, 0xFFF0F0F0);
    expect(restored.fieldBackgroundColorValue, 0xFFFFFFFF);
    expect(restored.printedTextColorValue, 0xFFAA1122);
  });

  test('printed text colors remain independent across template scopes', () {
    final expense = AppSettings.defaultsForScope(
      'expenseRequest',
    ).copyWith(printedTextColorValue: 0xFFAA0000);
    final samples = AppSettings.defaultsForScope(
      'sampleRequest',
    ).copyWith(printedTextColorValue: 0xFF0000AA);
    final singlePage = AppSettings.defaultsForScope(
      'sampleRequestSinglePage',
    ).copyWith(printedTextColorValue: 0xFF008844);

    expect(expense.printedTextColorValue, 0xFFAA0000);
    expect(samples.printedTextColorValue, 0xFF0000AA);
    expect(singlePage.printedTextColorValue, 0xFF008844);
    expect(expense.printedTextColorValue, isNot(samples.printedTextColorValue));
    expect(
      samples.printedTextColorValue,
      isNot(singlePage.printedTextColorValue),
    );
  });

  test('حفظ لون النطاق يحدّث notifier الخاص به دون تغيير نطاق آخر', () async {
    SharedPreferences.setMockInitialValues({});
    const scope = 'sampleRequestSinglePage';
    const selectedColor = 0xFF008844;
    final otherScopeColor = SettingsStore.notifierFor(
      'sampleRequest',
    ).value.printedTextColorValue;
    final settings = AppSettings.defaultsForScope(
      scope,
    ).copyWith(printedTextColorValue: selectedColor);

    await SettingsStore.save(settings, scope: scope);

    expect(
      SettingsStore.notifierFor(scope).value.printedTextColorValue,
      selectedColor,
    );
    expect(
      SettingsStore.notifierFor('sampleRequest').value.printedTextColorValue,
      otherScopeColor,
    );
    await SettingsStore.reset(scope: scope);
    expect(
      SettingsStore.notifierFor(scope).value.printedTextColorValue,
      AppSettings.defaultsForScope(scope).printedTextColorValue,
    );
  });

  test('old request without memo layout defaults to an A4 memo safely', () {
    final old = <String, Object?>{
      'date': '09/09/2026',
      'receiver': 'إلى',
      'statement': 'بيان',
      'requesterName': 'مقدم',
      'documentType': 'internalMemo',
    };
    final restored = ExpenseRequest.fromMap(old);
    expect(restored.documentType, ExpenseDocumentType.internalMemo);
    expect(restored.memoLayout, InternalMemoLayout.fullA4);
    expect(restored.statement, 'بيان');
  });

  test('customer application type survives save and reload', () {
    final request = ExpenseRequest(
      date: '09/09/2026',
      receiver: 'عميل',
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: 'طلب تقديم',
      branch: '',
      account: '',
      requesterName: 'مقدم',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      documentType: ExpenseDocumentType.customerApplication,
    );
    expect(
      ExpenseRequest.fromMap(request.toMap()).documentType,
      ExpenseDocumentType.customerApplication,
    );
  });
}
