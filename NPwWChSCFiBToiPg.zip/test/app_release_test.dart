import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/core/app_release.dart';

void main() {
  test('release notes use the current application version', () {
    expect(appVersionLabel, '2.8.4+16');
    expect(appVersionName, '2.8.4');
    expect(appVersionCode, 16);
    expect(appReleaseHighlights, isNotEmpty);
    expect(appReleaseHighlights.first, contains('المعاينة الحية'));
  });
}
