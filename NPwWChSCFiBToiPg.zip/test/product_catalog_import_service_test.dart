import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/product_catalog/models/product_item.dart';
import 'package:alfa_expense_app/features/product_catalog/services/product_catalog_import_service.dart';

void main() {
  test('import service exposes ERP-style preview contract', () {
    expect(ProductCatalogImportService.fields['name'], 'اسم الصنف');
    const row = ProductCatalogImportRow(
      rowNumber: 2,
      values: {'اسم الصنف': 'صنف'},
      product: null,
      error: 'اسم الصنف مطلوب',
      duplicate: false,
    );
    expect(row.isValid, isFalse);
    expect(row.error, 'اسم الصنف مطلوب');
  });

  test('normalizes milliliter units to syrup without treating mg as ml', () {
    expect(
      ProductCatalogImportService.normalizePharmaceuticalForm(
        provided: '',
        name: 'صنف 100 مل',
      ),
      'شراب',
    );
    expect(
      ProductCatalogImportService.normalizePharmaceuticalForm(
        provided: '',
        unit: 'ملي',
        name: 'صنف',
      ),
      'شراب',
    );
    expect(
      ProductCatalogImportService.normalizePharmaceuticalForm(
        provided: '',
        name: 'صنف 250 ملجم',
      ),
      isEmpty,
    );
  });

  test('keeps explicit pharmaceutical forms ahead of milliliter inference', () {
    expect(
      ProductCatalogImportService.normalizePharmaceuticalForm(
        provided: '',
        name: 'صنف 20 مل قطر فموية',
      ),
      'قطرات',
    );
    expect(
      ProductCatalogImportService.normalizePharmaceuticalForm(
        provided: '',
        name: 'صنف 20 قرص',
      ),
      'أقراص',
    );
  });

  test(
    'uses a compound identity for same-name products with different strength',
    () {
      const tablets = ProductItem(
        id: 'a',
        name: 'صنف',
        pharmaceuticalForm: 'أقراص',
        strength: '100 mg',
      );
      const syrup = ProductItem(
        id: 'b',
        name: 'صنف',
        pharmaceuticalForm: 'شراب',
        strength: '100 ml',
      );

      expect(
        ProductCatalogImportService.identityKey(tablets),
        isNot(ProductCatalogImportService.identityKey(syrup)),
      );
    },
  );

  test(
    'preserves a source id and rejects UTF-16 CSV instead of corrupting text',
    () {
      expect(
        ProductCatalogImportService.stableProductId('صنف'),
        startsWith('product-'),
      );
      expect(
        () => ProductCatalogImportService.previewCsv(
          Uint8List.fromList([0xFF, 0xFE, 0x41, 0x00]),
        ),
        throwsA(isA<FormatException>()),
      );
    },
  );

  test('rejects catalog files larger than the bounded import size', () {
    final oversized = Uint8List(ProductCatalogImportService.maxImportBytes + 1);

    expect(
      () => ProductCatalogImportService.previewCsv(oversized),
      throwsA(isA<FormatException>()),
    );
  });
}
