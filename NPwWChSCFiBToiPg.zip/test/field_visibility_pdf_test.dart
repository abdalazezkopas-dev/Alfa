import 'package:flutter_test/flutter_test.dart';
import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/expense_request/services/pdf_service.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('renders standard fields when visibility is enabled', () async {
    final defaults = AppSettings.defaults();
    final fields = Map<String, FieldSetting>.from(defaults.fieldSettings);
    for (final key in ['reason', 'branch', 'account', 'requesterName']) {
      fields[key] = fields[key]!.copyWith(visible: true);
    }
    final settings = defaults.copyWith(fieldSettings: fields);
    const request = ExpenseRequest(
      date: '01/09/2026',
      receiver: 'مدير الحسابات',
      amountNumber: '5650020',
      amountWords: 'خمسة مليون وستمائة وخمسين ألف وعشرين ريال',
      reason: 'مستلزمات تشغيلية',
      statement: 'بيان اختبار الحقول المفعلة',
      branch: 'الفرع الرئيسي',
      account: 'مصروفات التشغيل',
      requesterName: 'عبدالعزيز كباس',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
    );

    final bytes = await PdfService.buildRequestPdf(request, settings: settings);

    expect(bytes, isNotEmpty);
    expect(bytes.sublist(0, 4), orderedEquals([37, 80, 68, 70]));
  });
}
