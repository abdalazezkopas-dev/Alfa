import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/settings/models/app_settings.dart';
import 'package:alfa_expense_app/features/settings/models/template_geometry.dart';

void main() {
  test('style-only copyWith preserves geometry and coordinates', () {
    const original = FieldSetting(
      label: 'البيان',
      visible: true,
      required: false,
      x: 82,
      y: 162,
      width: 390,
      height: 180,
    );

    final changed = original.copyWith(
      fontSize: 18,
      colorValue: 0xFF0D47A1,
      fontWeight: 700,
      alignment: 'center',
      lineHeight: 1.3,
    );

    expect(changed.geometryConfigured, isFalse);
    expect(changed.x, original.x);
    expect(changed.y, original.y);
    expect(changed.width, original.width);
    expect(changed.height, original.height);
  });

  test('explicit geometry edit enables configured coordinates', () {
    const original = FieldSetting(
      label: 'التاريخ',
      visible: true,
      required: false,
    );
    final changed = original.copyWith(
      x: 40,
      y: 50,
      width: 120,
      height: 24,
      geometryConfigured: true,
    );

    expect(changed.geometryConfigured, isTrue);
    expect(changed.x, 40);
    expect(changed.y, 50);
  });

  test('template defaults contain independent six-row structured geometry', () {
    final clearance = TemplateGeometry.forScope('clearanceRequest');
    final service = TemplateGeometry.forScope('serviceRequest');

    expect(
      clearance.keys,
      containsAll([
        for (var i = 1; i <= 6; i++) ...[
          'clearanceAmount$i',
          'clearanceDate$i',
          'clearanceStatement$i',
        ],
      ]),
    );
    expect(
      service.keys,
      containsAll([for (var i = 1; i <= 6; i++) 'serviceItemName$i']),
    );
    expect(service.keys, isNot(contains('serviceItemQuantity1')));
    expect(service.keys, isNot(contains('serviceItemNotes1')));
    expect(clearance['clearanceAmount1']!.y, 132);
    expect(clearance['clearanceAmount6']!.y, 372);
  });

  test('travel allowance geometry exposes ten rows and approval fields', () {
    final travel = TemplateGeometry.forScope('travelAllowance');
    expect(
      travel.keys,
      containsAll(['branch', 'month', 'year', 'totalAmount']),
    );
    expect(
      travel.keys,
      containsAll([
        for (var i = 1; i <= 10; i++) ...[
          'travelDay$i',
          'travelDate$i',
          'travelDailyAmount$i',
          'travelRegion$i',
          'travelStatement$i',
        ],
      ]),
    );
    expect(travel['travelDay1']!.y, 103);
    expect(travel['travelDay10']!.y, 328);
  });

  test('single-page sample rows seven through twenty-five move up by four', () {
    final sample = TemplateGeometry.forScope('sampleRequestSinglePage');
    expect(sample['sampleItemName7']!.y, closeTo(320.2, 0.0001));
    expect(sample['sampleItemName25']!.y, closeTo(647.8, 0.0001));
    expect(sample['sampleItemForm25']!.y, sample['sampleItemName25']!.y);
    expect(sample['sampleItemNotes25']!.y, sample['sampleItemName25']!.y);
  });

  test('bottom settings are independent and do not use bottomX heuristics', () {
    final top = AppSettings.defaults().copyWith(
      fieldSettings: {
        'date': const FieldSetting(
          label: 'التاريخ',
          visible: true,
          required: false,
          x: 10,
          y: 20,
          width: 100,
          bottomX: 400,
          bottomY: 300,
          bottomWidth: 200,
        ),
      },
      bottomFieldSettings: const {},
    );

    final bottom = top.fieldsForCopy(bottom: true);
    expect(bottom['date']!.x, 10);
    expect(bottom['date']!.y, 20);
    expect(bottom['date']!.width, 100);
  });

  test('scoped defaults do not use expense schema for structured forms', () {
    final clearance = AppSettings.defaultsForScope('clearanceRequest');
    final service = AppSettings.defaultsForScope('serviceRequest');

    expect(clearance.fieldSettings, contains('clearanceAmount1'));
    expect(clearance.fieldSettings, isNot(contains('amountWords')));
    expect(service.fieldSettings, contains('serviceItemName1'));
    expect(service.fieldSettings, isNot(contains('serviceItemQuantity1')));
    expect(
      service.fieldSettings['serviceItemName1']!.geometryConfigured,
      isFalse,
    );
  });

  test('fuel geometry matches the supplied coordinate sheet', () {
    final fuel = TemplateGeometry.forScope('fuelRequest');
    expect(
      fuel['fuelBranch'],
      const TemplateGeometry(x: 591, y: 60, width: 70, height: 22),
    );
    expect(
      fuel['vehicleNumber'],
      const TemplateGeometry(x: 237, y: 60, width: 80, height: 30),
    );
    expect(
      fuel['collector'],
      const TemplateGeometry(x: 468, y: 58, width: 110, height: 22),
    );
    expect(
      fuel['fuelTypePetrol'],
      const TemplateGeometry(x: 734, y: 44, width: 40, height: 30),
    );
    expect(
      fuel['branchManager'],
      const TemplateGeometry(x: 459, y: 437, width: 120, height: 22),
    );
    expect(
      fuel['administrationAccountant'],
      const TemplateGeometry(x: 330, y: 437, width: 120, height: 22),
    );
    expect(
      fuel['fuelDate1'],
      const TemplateGeometry(x: 738, y: 126, width: 80, height: 22),
    );
    expect(
      fuel['fuelRoute7'],
      const TemplateGeometry(x: 218, y: 341, width: 90, height: 35),
    );
    expect(
      fuel['systemTimestamp'],
      const TemplateGeometry(x: 80, y: 502, width: 120, height: 22),
    );
    final settings = AppSettings.defaultsForScope('fuelRequest');
    expect(settings.fieldSettings['fuelBranch']!.fontSize, 10);
    expect(settings.fieldSettings['vehicleNumber']!.fontSize, 10);
    expect(settings.fieldSettings['collector']!.fontSize, 10);
    expect(settings.fieldSettings['beneficiary']!.fontSize, 10.5);
    expect(settings.fieldSettings['branchAccountant']!.fontSize, 10.5);
    expect(settings.fieldSettings['branchManager']!.fontSize, 10.5);
    expect(settings.fieldSettings['administrationAccountant']!.fontSize, 10.5);
    expect(settings.fieldSettings['accountsManager']!.fontSize, 10.5);
    expect(settings.fieldSettings['fuelRoute1']!.fontSize, 8);
    expect(settings.fieldSettings['fuelRoute1']!.colorValue, 0xFF000066);
    expect(settings.fieldSettings['systemTimestamp']!.colorValue, 0xFF000000);
    for (var i = 1; i <= 7; i++) {
      expect(settings.fieldSettings['fuelDate$i']!.fontSize, 12);
      expect(settings.fieldSettings['fuelMeter$i']!.fontSize, 12);
      expect(settings.fieldSettings['fuelLiters$i']!.fontSize, 12);
      expect(settings.fieldSettings['fuelPrice$i']!.fontSize, 12);
      expect(settings.fieldSettings['fuelAmount$i']!.fontSize, 12);
      expect(settings.fieldSettings['fuelCollection$i']!.fontSize, 12);
      expect(settings.fieldSettings['fuelSales$i']!.fontSize, 12);
    }
  });

  test('fuel checkmark field accepts an explicit edited position and size', () {
    final settings = AppSettings.defaultsForScope('fuelRequest');
    final original = settings.fieldSettings['fuelTypePetrol']!;
    final edited = original.copyWith(
      x: 600,
      y: 80,
      width: 20,
      height: 15,
      geometryConfigured: true,
    );
    expect(edited.geometryConfigured, isTrue);
    expect(edited.x, 600);
    expect(edited.y, 80);
    expect(edited.width, 20);
    expect(edited.height, 15);
    expect(original.x, isNot(edited.x));
  });

  test('sample geometry covers exactly the three-page capacity', () {
    final sample = TemplateGeometry.forScope('sampleRequest');
    expect(sample['sampleItemName1'], isNotNull);
    expect(sample['sampleItemName11'], isNotNull);
    expect(sample['sampleItemName12'], isNotNull);
    expect(sample['sampleItemName33'], isNotNull);
    expect(sample['sampleItemName34'], isNotNull);
    expect(sample['sampleItemName53'], isNotNull);
    expect(sample, isNot(contains('sampleItemName54')));
  });

  test('single-page sample geometry covers exactly 25 rows', () {
    final sample = TemplateGeometry.forScope('sampleRequestSinglePage');
    expect(sample['sampleItemName1'], isNotNull);
    expect(sample['sampleItemName25'], isNotNull);
    expect(sample['sampleItemNotes25'], isNotNull);
    expect(sample, isNot(contains('sampleItemName26')));
  });
}
