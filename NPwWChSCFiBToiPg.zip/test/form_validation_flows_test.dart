import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/features/customer/screens/customer_application_screen.dart';
import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('يمنع حفظ نموذج العملاء عند إدخال تاريخ غير صالح', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    const request = ExpenseRequest(
      date: 'م2026/02/30',
      receiver: '',
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: 'بيان',
      branch: 'الفرع',
      account: '',
      requesterName: 'مقدم الطلب',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      documentType: ExpenseDocumentType.customerApplication,
      customFields: {
        'exceptionType': 'أخرى',
        'otherDetails': 'تفاصيل',
        'customer': 'عميل الاختبار',
        'branch': 'الفرع',
        'statementOne': 'البيان الأول',
        'requester': 'مقدم الطلب',
      },
    );

    await tester.pumpWidget(
      const MaterialApp(
        home: CustomerApplicationScreen(initialRequest: request),
      ),
    );
    await tester.pumpAndSettle();
    await tester.scrollUntilVisible(
      find.text('حفظ نموذج العملاء'),
      300,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.tap(find.text('حفظ نموذج العملاء'));
    await tester.pumpAndSettle();

    expect(find.text('أدخل تاريخاً صحيحاً قبل المتابعة'), findsOneWidget);
    expect(find.text('م2026/02/30'), findsOneWidget);
  });
}
