import 'package:flutter_test/flutter_test.dart';
import 'package:pdf/pdf.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/expense_request/services/pdf_service.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';

void main() {
  test('sample request attachments use Letter like the primary form', () {
    expect(
      PdfService.attachmentPageFormatFor(ExpenseDocumentType.sampleRequest),
      PdfPageFormat.letter,
    );
  });

  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'three-page sample request supports 53 rows and creates 3 pages',
    () async {
      final request = ExpenseRequest(
        date: '01/10/2026',
        receiver: 'الجهة المستلمة',
        amountNumber: '',
        amountWords: '',
        reason: 'تسويقية',
        statement: 'ملاحظات الطلب',
        branch: '',
        account: '',
        requesterName: 'مقدم الطلب',
        requesterSignature: '',
        directManagerName: '',
        directManagerSignature: '',
        approvedAuthorityName: '',
        approvedAuthoritySignature: '',
        accountsManagerName: '',
        accountsManagerSignature: '',
        customFields: const {
          'sampleTemplate': 'threePage',
          'sampleUsage': 'تسويقية',
        },
        documentType: ExpenseDocumentType.sampleRequest,
        sampleItems: [
          for (var i = 1; i <= 53; i++)
            SampleItem(
              productId: 'p$i',
              productName: 'صنف $i',
              pharmaceuticalForm: 'أقراص',
              quantityNumber: '$i',
              quantityWords: 'كمية $i',
            ),
        ],
      );
      final bytes = await PdfService.buildRequestPdf(request);
      expect(bytes, isNotEmpty);
      expect(bytes.take(4).toList(), <int>[37, 80, 68, 70]);
    },
  );

  test('Arabic item names render with a non-breaking leading space', () async {
    final request = ExpenseRequest(
      date: '01/10/2026',
      receiver: 'الجهة المستلمة',
      amountNumber: '',
      amountWords: '',
      reason: 'تسويقية',
      statement: '',
      branch: '',
      account: '',
      requesterName: 'مقدم الطلب',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      customFields: const {'sampleTemplate': 'threePage'},
      documentType: ExpenseDocumentType.sampleRequest,
      sampleItems: const [
        SampleItem(
          productId: 'arabic-1',
          productName: 'البيكس 200 ملجم 2 قرص',
          pharmaceuticalForm: 'أقراص',
          quantityNumber: '1',
          quantityWords: 'واحد',
        ),
      ],
    );
    final bytes = await PdfService.buildRequestPdf(request);
    expect(bytes, isNotEmpty);
    expect(bytes.take(4).toList(), <int>[37, 80, 68, 70]);
  });

  test(
    'single-page sample request uses the new template and 25-row limit',
    () async {
      final request = ExpenseRequest(
        date: '01/10/2026',
        receiver: 'الجهة المستلمة',
        amountNumber: '',
        amountWords: '',
        reason: '',
        statement: '',
        branch: '',
        account: '',
        requesterName: 'مقدم الطلب',
        requesterSignature: '',
        directManagerName: '',
        directManagerSignature: '',
        approvedAuthorityName: '',
        approvedAuthoritySignature: '',
        accountsManagerName: '',
        accountsManagerSignature: '',
        customFields: const {
          'sampleTemplate': 'singlePage',
          'sampleUsage': 'تسويقية',
        },
        documentType: ExpenseDocumentType.sampleRequest,
        sampleItems: [
          for (var i = 1; i <= 25; i++)
            SampleItem(
              productId: 'p$i',
              productName: 'صنف $i',
              pharmaceuticalForm: 'أقراص',
              quantityNumber: '$i',
              quantityWords: 'كمية $i',
            ),
        ],
      );
      final bytes = await PdfService.buildRequestPdf(
        request,
        settings: AppSettings.defaultsForScope('sampleRequestSinglePage'),
      );
      expect(bytes, isNotEmpty);
      expect(bytes.take(4).toList(), <int>[37, 80, 68, 70]);
    },
  );

  test('single-page sample request rejects the 26th row', () async {
    final request = ExpenseRequest(
      date: '01/10/2026',
      receiver: '',
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: '',
      branch: '',
      account: '',
      requesterName: '',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      customFields: const {'sampleTemplate': 'singlePage'},
      documentType: ExpenseDocumentType.sampleRequest,
      sampleItems: [
        for (
          var i = 1;
          i <= PdfService.sampleRequestSinglePageMaxItems + 1;
          i++
        )
          SampleItem(productId: 'p$i', productName: 'صنف $i'),
      ],
    );

    await expectLater(
      PdfService.buildRequestPdf(request),
      throwsA(isA<StateError>()),
    );
  });

  test(
    'sample request PDF rejects rows beyond the three-page template capacity',
    () async {
      final request = ExpenseRequest(
        date: '01/10/2026',
        receiver: '',
        amountNumber: '',
        amountWords: '',
        reason: '',
        statement: '',
        branch: '',
        account: '',
        requesterName: '',
        requesterSignature: '',
        directManagerName: '',
        directManagerSignature: '',
        approvedAuthorityName: '',
        approvedAuthoritySignature: '',
        accountsManagerName: '',
        accountsManagerSignature: '',
        documentType: ExpenseDocumentType.sampleRequest,
        sampleItems: [
          for (var i = 1; i <= PdfService.sampleRequestMaxItems + 1; i++)
            SampleItem(
              productId: 'p$i',
              productName: 'صنف $i',
              quantityNumber: '1',
            ),
        ],
      );

      await expectLater(
        PdfService.buildRequestPdf(request),
        throwsA(isA<StateError>()),
      );
    },
  );
}
