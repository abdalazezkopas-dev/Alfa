import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/debts/models/debt.dart';

void main() {
  test('يحسب المتبقي مع استبعاد الدفعات المسددة', () {
    final account = DebtAccount(
      id: 1,
      name: 'عميل',
      kind: 'عميل',
      phone: '',
      notes: '',
      entries: [
        DebtEntry(
          id: 1,
          amount: 500,
          type: DebtEntryType.owedToMe,
          date: DateTime(2026, 9, 1),
          note: 'فاتورة',
        ),
        DebtEntry(
          id: 2,
          amount: 100,
          type: DebtEntryType.iOwe,
          date: DateTime(2026, 9, 2),
          note: 'دفعة',
          settled: true,
        ),
      ],
    );

    expect(account.owedToMe, 500);
    expect(account.iOwe, 0);
    expect(account.balance, 500);
  });

  test('يحسب عدد الديون المتأخرة غير المسددة فقط', () {
    final account = DebtAccount(
      id: 1,
      name: 'جهة',
      kind: 'جهة',
      phone: '',
      notes: '',
      entries: [
        DebtEntry(
          id: 1,
          amount: 20,
          type: DebtEntryType.iOwe,
          date: DateTime(2026, 1, 1),
          note: 'قديم',
          dueDate: DateTime(2020, 1, 1),
        ),
        DebtEntry(
          id: 2,
          amount: 30,
          type: DebtEntryType.iOwe,
          date: DateTime(2026, 1, 1),
          note: 'مسدد',
          dueDate: DateTime(2020, 1, 1),
          settled: true,
        ),
      ],
    );

    expect(account.overdueCount, 1);
  });
}
