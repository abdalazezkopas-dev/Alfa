import 'dart:convert';

import 'package:crypto/crypto.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:alfa_expense_app/features/backup/services/backup_service.dart';
import 'package:alfa_expense_app/features/backup/services/encrypted_backup_codec.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';

Map<String, Object?> _payload(
  int version, {
  Map<String, Object?>? settingsByScope,
  List<Object?>? attachments,
  int? schemaVersion,
}) {
  final settings = AppSettings.defaults().toMap();
  return <String, Object?>{
    'format': 'alfa_expense_app_backup',
    'version': version,
    if (schemaVersion != null) 'schema_version': schemaVersion,
    'settings': settings,
    if (settingsByScope != null) 'settings_by_scope': settingsByScope,
    'requests': <Object?>[],
    if (attachments != null) 'attachments': attachments,
  };
}

void main() {
  test('migrates v1 settings without warnings for known legacy defaults', () {
    final decoded = BackupService.decodeBackup(
      jsonEncode(_payload(1)),
    );

    expect(decoded.version, 1);
    expect(decoded.settingsByScope.keys, containsAll(requiredBackupScopes));
    expect(decoded.migrationWarnings, isEmpty);
    expect(decoded.hasReminders, isFalse);
    expect(decoded.hasDebts, isFalse);
    expect(decoded.hasNotes, isFalse);
    expect(decoded.hasQuickStatements, isFalse);
    expect(decoded.hasSavedPatterns, isFalse);
    expect(decoded.hasDebtSettings, isFalse);
    expect(decoded.hasCalculatorHistory, isFalse);
    expect(decoded.hasProductCatalog, isFalse);
    expect(decoded.hasRepresentativeReports, isFalse);
  });

  test('migrates v3 missing form scopes without inventing optional sections', () {
    final settings = AppSettings.defaults().toMap();
    final decoded = BackupService.decodeBackup(
      jsonEncode(
        _payload(
          3,
          settingsByScope: {
            for (final scope in requiredBackupScopes.take(6)) scope: settings,
          },
        ),
      ),
    );

    expect(decoded.version, 3);
    expect(decoded.settingsByScope.keys, containsAll(requiredBackupScopes));
    expect(decoded.migrationWarnings, hasLength(3));
    expect(decoded.hasReminders, isFalse);
    expect(decoded.hasProductCatalog, isFalse);
    expect(decoded.hasRepresentativeReports, isFalse);
  });

  test('accepts v4 and v5, while preserving absent optional data markers', () {
    final settings = AppSettings.defaults().toMap();
    for (final version in [4, 5]) {
      final decoded = BackupService.decodeBackup(
        jsonEncode(
          _payload(
            version,
            settingsByScope: {
              for (final scope in requiredBackupScopes) scope: settings,
              if (version == 5) 'global': settings,
            },
            schemaVersion: version == 5 ? 5 : null,
          ),
        ),
      );
      expect(decoded.version, version);
      expect(decoded.migrationWarnings, isEmpty);
      expect(decoded.hasProductCatalog, isFalse);
      expect(decoded.hasRepresentativeReports, isFalse);
      expect(decoded.hasReminders, isFalse);
      expect(decoded.hasNotes, isFalse);
    }
  });

  test('rejects future and internally inconsistent schema versions', () {
    final future = _payload(6);
    expect(
      () => BackupService.decodeBackup(jsonEncode(future)),
      throwsA(isA<FormatException>()),
    );

    final inconsistent = _payload(4, schemaVersion: 4);
    expect(
      () => BackupService.decodeBackup(jsonEncode(inconsistent)),
      throwsA(isA<FormatException>()),
    );
  });

  test('validates checksums when supplied but remains compatible with old attachments', () {
    final settings = AppSettings.defaults().toMap();
    final bytes = <int>[1, 2, 3, 4];
    final attachment = <String, Object?>{
      'id': 'attachment-1',
      'fileName': 'proof.pdf',
      'mimeType': 'application/pdf',
      'base64': base64Encode(bytes),
      'sha256': sha256.convert(bytes).toString(),
    };
    final base = _payload(
      5,
      settingsByScope: {
        for (final scope in requiredBackupScopes) scope: settings,
      },
    );
    final valid = BackupService.decodeBackup(
      jsonEncode({...base, 'attachments': [attachment]}),
    );
    expect(valid.attachments.single['sha256'], attachment['sha256']);

    final oldWithoutChecksum = Map<String, Object?>.from(attachment)
      ..remove('sha256');
    expect(
      BackupService.decodeBackup(
        jsonEncode({...base, 'attachments': [oldWithoutChecksum]}),
      ).attachments,
      hasLength(1),
    );

    final tampered = Map<String, Object?>.from(attachment)
      ..['sha256'] = List.filled(64, '0').join();
    expect(
      () => BackupService.decodeBackup(
        jsonEncode({...base, 'attachments': [tampered]}),
      ),
      throwsA(isA<FormatException>()),
    );
  });

  test('recognizes encrypted legacy data after a transport BOM and whitespace', () async {
    final settings = AppSettings.defaults().toMap();
    final json = jsonEncode(
      _payload(
        5,
        settingsByScope: {
          for (final scope in requiredBackupScopes) scope: settings,
        },
      ),
    );
    final encrypted = await EncryptedBackupCodec.encryptJson(
      json,
      password: 'migration-regression-password',
    );
    final decoded = await BackupService.decodeAnyBackup(
      '\uFEFF  \n$encrypted',
      passwordProvider: () async => 'migration-regression-password',
    );

    expect(decoded.version, 5);
    expect(decoded.requests, isEmpty);
  });
}
