import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/expense_request/services/pdf_service.dart';
import 'package:alfa_expense_app/features/expense_request/services/pdf_text_sanitizer.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';

ExpenseRequest _request({
  ExpenseDocumentType type = ExpenseDocumentType.clearanceRequest,
  List<ClearanceEntry> clearanceEntries = const [],
  List<ServiceItem> serviceItems = const [],
  ExpenseRequest? secondRequest,
}) => ExpenseRequest(
  date: '19/09/2026',
  receiver: 'جهة الاختبار',
  amountNumber: '100',
  amountWords: 'مائة ريال',
  reason: 'اختبار',
  statement: 'بيان الاختبار',
  branch: 'القسم',
  account: '',
  requesterName: 'مقدم الطلب',
  requesterSignature: '',
  directManagerName: '',
  directManagerSignature: '',
  approvedAuthorityName: '',
  approvedAuthoritySignature: '',
  accountsManagerName: '',
  accountsManagerSignature: '',
  documentType: type,
  formCount: secondRequest == null ? 1 : 2,
  secondRequest: secondRequest,
  clearanceEntries: clearanceEntries,
  serviceItems: serviceItems,
);

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMessageHandler('flutter/assets', (message) async {
          if (message == null) return null;
          final encodedPath = utf8.decode(
            message.buffer.asUint8List(
              message.offsetInBytes,
              message.lengthInBytes,
            ),
          );
          final path = Uri.decodeFull(encodedPath);
          final file = File(path);
          if (!await file.exists()) return null;
          return ByteData.sublistView(await file.readAsBytes());
        });
  });
  tearDownAll(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMessageHandler('flutter/assets', null);
  });

  test('يحافظ التطبيع على ستة صفوف إخلاء العهدة وحقولها', () {
    final request = _request(
      clearanceEntries: [
        for (var i = 1; i <= 6; i++)
          ClearanceEntry(
            amount: '$i',
            date: '01/09/2026',
            statement: 'بيان $i',
          ),
      ],
    );
    final sanitized = PdfTextSanitizer.normalizeRequest(request);
    expect(sanitized.clearanceEntries, hasLength(6));
    expect(sanitized.clearanceEntries.last.statement, 'بيان 6');
  });

  test('يحافظ التطبيع على ستة أصناف خدمة باسم الصنف فقط', () {
    final request = _request(
      type: ExpenseDocumentType.serviceRequest,
      serviceItems: [for (var i = 1; i <= 6; i++) ServiceItem(name: 'صنف $i')],
    );
    final sanitized = PdfTextSanitizer.normalizeRequest(request);
    expect(sanitized.serviceItems, hasLength(6));
    expect(sanitized.serviceItems.map((item) => item.name), contains('صنف 6'));
  });

  test('يحافظ التطبيع على القوائم المنظمة داخل secondRequest', () {
    final request = _request(
      secondRequest: _request(
        type: ExpenseDocumentType.serviceRequest,
        serviceItems: const [ServiceItem(name: 'الصنف الثاني')],
      ),
    );
    final sanitized = PdfTextSanitizer.normalizeRequest(request);
    expect(sanitized.secondRequest?.serviceItems.single.name, 'الصنف الثاني');
  });

  test('ينشئ PDF غير فارغ لإخلاء العهدة بستة صفوف', () async {
    final bytes = await PdfService.buildRequestPdf(
      _request(
        clearanceEntries: [
          for (var i = 1; i <= 6; i++)
            ClearanceEntry(
              amount: '$i',
              date: '01/09/2026',
              statement: 'بيان $i',
            ),
        ],
      ),
      settings: AppSettings.defaultsForScope('clearanceRequest'),
    );
    expect(bytes, isNotEmpty);
  });

  test(
    'يقسم العهدة إلى صفحات متابعة عند تجاوز ستة صفوف ويمرر البيان الطويل',
    () async {
      final bytes = await PdfService.buildRequestPdf(
        _request(
          clearanceEntries: [
            for (var i = 1; i <= 13; i++)
              ClearanceEntry(
                amount: i.isEven ? '-$i.005' : '$i.004',
                date: '01/09/2026',
                statement: i == 1
                    ? List.filled(120, 'بيان ممتد').join(' ')
                    : 'بيان البند $i',
              ),
          ],
        ),
        settings: AppSettings.defaultsForScope('clearanceRequest'),
      );

      final source = latin1.decode(bytes);
      final pageCount = RegExp(r'/Type\s*/Page\b').allMatches(source).length;
      expect(bytes, isNotEmpty);
      expect(pageCount, greaterThan(1));
    },
  );

  test('ينشئ PDF غير فارغ لطلب خدمة بستة أسماء أصناف', () async {
    final bytes = await PdfService.buildRequestPdf(
      _request(
        type: ExpenseDocumentType.serviceRequest,
        serviceItems: [
          for (var i = 1; i <= 6; i++) ServiceItem(name: 'صنف $i'),
        ],
      ),
      settings: AppSettings.defaultsForScope('serviceRequest'),
    );
    expect(bytes, isNotEmpty);
  });
}
