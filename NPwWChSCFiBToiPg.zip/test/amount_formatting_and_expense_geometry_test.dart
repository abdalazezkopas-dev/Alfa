import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/core/utils/number_normalizer.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';
import 'package:alfa_expense_app/features/settings/models/template_geometry.dart';

void main() {
  test('formats monetary values with thousands separators', () {
    expect(NumberNormalizer.formatGrouped('5000000'), '5,000,000');
    expect(NumberNormalizer.formatGrouped('١٢٣٤٥٦٧'), '1,234,567');
    expect(NumberNormalizer.formatGrouped('5000000.50'), '5,000,000.50');
    expect(NumberNormalizer.parseDouble('5,000,000'), 5000000);
    expect(NumberNormalizer.formatGrouped('5,000'), '5,000');
    expect(NumberNormalizer.formatGrouped('5,0000'), '50,000');
    expect(NumberNormalizer.formatGrouped('500,0000'), '5,000,000');
    expect(NumberNormalizer.formatGrouped('50000'), '50,000');
    final formatter = ThousandsSeparatorInputFormatter();
    final rejected = formatter.formatEditUpdate(
      const TextEditingValue(text: '5,000'),
      const TextEditingValue(text: '5,000a'),
    );
    expect(rejected.text, '5,000');
  });

  test('uses the requested upper expense-form geometry', () {
    final geometry = TemplateGeometry.forScope('expenseRequest');
    expect(geometry['date']?.x, 70);
    expect(geometry['date']?.y, 56);
    expect(geometry['receiver']?.x, 105);
    expect(geometry['receiver']?.y, 70);
    expect(geometry['receiver']?.width, 350);
    expect(geometry['amountNumber']?.x, 385);
    expect(geometry['amountNumber']?.y, 102);
    expect(geometry['amountWords']?.x, 118);
    expect(geometry['amountWords']?.y, 113);
    expect(geometry['statement']?.x, 30);
    expect(geometry['statement']?.y, 137);
    expect(geometry['statement']?.width, 470);
    expect(geometry['statement']?.height, 80);
    expect(geometry['branch']?.x, 5);
    expect(geometry['branch']?.y, 282);
    expect(geometry['branch']?.width, 150);
    expect(geometry['branch']?.height, 22);
    expect(geometry['approvedAuthorityName']?.x, 57);
    expect(geometry['directManagerName']?.x, 222);
    expect(geometry['requesterName']?.x, 413);
    expect(geometry['accountsManagerName']?.x, 30);
    expect(
      AppSettings.defaultsForScope(
        'expenseRequest',
      ).fieldSettings['branch']?.visible,
      isTrue,
    );
    expect(
      AppSettings.defaultsForScope(
        'expenseRequest',
      ).fieldSettings['branch']?.required,
      isFalse,
    );
    expect(
      AppSettings.defaultsForScope(
        'expenseRequest',
      ).fieldSettings['amountNumber']?.alignment,
      'center',
    );
  });

  test('uses X=17 for both customer statement fields', () {
    final geometry = TemplateGeometry.forScope('customerApplication');
    expect(geometry['statementOne']?.x, 17);
    expect(geometry['statementTwo']?.x, 17);
  });
}
