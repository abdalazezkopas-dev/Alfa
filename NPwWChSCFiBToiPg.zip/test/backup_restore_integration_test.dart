import 'dart:convert';
import 'dart:io';

import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/features/backup/services/backup_service.dart';
import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/expense_request/services/request_store.dart';
import 'package:alfa_expense_app/features/debts/models/debt.dart';
import 'package:alfa_expense_app/features/debts/services/debt_store.dart';
import 'package:alfa_expense_app/features/notes/models/note.dart';
import 'package:alfa_expense_app/features/notes/services/notes_store.dart';
import 'package:alfa_expense_app/features/representative_reports/models/representative_report.dart';
import 'package:alfa_expense_app/features/representative_reports/services/representative_report_store.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';
import 'package:alfa_expense_app/features/settings/services/settings_store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late Directory root;
  late String support;
  const pathChannel = MethodChannel('plugins.flutter.io/path_provider');
  const notifications = MethodChannel(
    'dexterous.com/flutter/local_notifications',
  );
  const secureChannel = MethodChannel(
    'plugins.it_nomads.com/flutter_secure_storage',
  );
  final secureValues = <String, String>{};
  final messenger =
      TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger;

  setUp(() async {
    AndroidFlutterLocalNotificationsPlugin.registerWith();
    SharedPreferences.setMockInitialValues({});
    secureValues.clear();
    messenger.setMockMethodCallHandler(secureChannel, (call) async {
      final arguments = (call.arguments as Map?)?.cast<String, Object?>();
      final key = arguments?['key'] as String?;
      switch (call.method) {
        case 'read':
          return key == null ? null : secureValues[key];
        case 'write':
          if (key != null) {
            secureValues[key] = arguments?['value'] as String? ?? '';
          }
          return null;
        case 'delete':
          if (key != null) secureValues.remove(key);
          return null;
        default:
          return null;
      }
    });
    root = await Directory.systemTemp.createTemp('backup_restore_regression_');
    support = '${root.path}/source';
    await Directory(support).create();
    messenger.setMockMethodCallHandler(pathChannel, (_) async => support);
    messenger.setMockMethodCallHandler(notifications, (call) async {
      if (call.method == 'initialize') return true;
      if (call.method == 'pendingNotificationRequests') return <Object?>[];
      return null;
    });
  });

  tearDown(() async {
    messenger.setMockMethodCallHandler(pathChannel, null);
    messenger.setMockMethodCallHandler(notifications, null);
    messenger.setMockMethodCallHandler(secureChannel, null);
    await root.delete(recursive: true);
  });

  test(
    'full encrypted backup restores attachments on a different device root',
    () async {
      final attachments = Directory('$support/attachments');
      await attachments.create();
      final original = File('${attachments.path}/proof.pdf');
      final content = utf8.encode(
        'portable fixture attachment, not personal data',
      );
      await original.writeAsBytes(content);
      final longStatement = List.filled(50, 'بيان طويل').join(' ');
      final request = ExpenseRequest.fromMap({
        'receiver': 'المستلم التجريبي',
        'date': '17/10/2026',
        'statement': longStatement,
        'attachmentPaths': [original.path],
        'customFields': {'تفصيل': longStatement},
        'formCount': 2,
        'secondRequest': {
          'receiver': 'الثاني',
          'statement': 'بيان ثان',
          'attachmentPath': original.path,
        },
      });
      expect(request.statement, longStatement);
      expect(request.customFields['تفصيل'], longStatement);
      final debt = DebtAccount(
        id: 1,
        name: 'حساب تجريبي',
        kind: 'عميل',
        phone: '',
        notes: '',
        entries: [
          DebtEntry(
            id: 2,
            amount: 45.67,
            type: DebtEntryType.owedToMe,
            date: DateTime(2026, 10, 17),
            note: 'اختبار',
            attachmentPath: original.path,
          ),
        ],
      );
      final note = Note(
        id: 'note-fixture',
        title: 'ملاحظة تجريبية',
        body: 'نص\nمتعدد الأسطر',
        tasks: const [],
        createdAt: DateTime(2026),
        updatedAt: DateTime(2026),
        attachments: [
          NoteAttachment(name: 'inline.txt', base64: base64Encode(content)),
        ],
      );
      final settings = AppSettings.defaults().copyWith(
        companyName: 'شركة التوافق',
      );
      final representativeReport = RepresentativeReport.empty(
        id: 'restore-report',
        date: '2026/10/22',
      ).copyWith(medRep: 'مندوب اختبار');
      final encrypted = await BackupService.buildEncryptedBackupJson(
        settings: settings,
        requests: [request],
        debts: [debt],
        notes: [note],
        settingsByScope: {'global': settings},
        debtSettings: {
          'currency': 'عملة اختبار',
          'categories': 'اختبار',
          'decimals': 2,
        },
        calculatorHistory: ['20+5 = 25'],
        representativeReports: [representativeReport],
        password: 'integration-password',
      );
      final backup = await BackupService.decodeEncryptedBackup(
        encrypted,
        password: 'integration-password',
      );
      expect(backup.version, 5);
      expect(backup.migrationWarnings, isEmpty);
      expect(
        backup.attachments,
        hasLength(1),
      ); // Deduplicated across all references.
      expect(backup.attachments.single['sha256'], isA<String>());
      support = '${root.path}/target';
      await Directory(support).create();
      SharedPreferences.setMockInitialValues({});
      await BackupService.restoreBackup(backup);
      final requests = await RequestStore.load();
      expect(requests.single.statement, longStatement);
      expect(requests.single.customFields['تفصيل'], longStatement);
      final restoredPath = requests.single.attachmentPaths.single;
      expect(restoredPath, startsWith('$support/attachments/'));
      expect(await File(restoredPath).readAsBytes(), content);
      expect(requests.single.secondRequest!.attachmentPath, restoredPath);
      expect(
        (await DebtStore.load()).single.entries.single.attachmentPath,
        restoredPath,
      );
      expect(
        (await NotesStore.load()).single.attachments.single.base64,
        base64Encode(content),
      );
      expect((await SettingsStore.load()).companyName, 'شركة التوافق');
      final restoredReports = await RepresentativeReportStore.load();
      expect(restoredReports, hasLength(1));
      expect(restoredReports.single.toMap(), representativeReport.toMap());

      final legacyBackup = BackupService.decodeBackup(
        jsonEncode({
          'format': 'alfa_expense_app_backup',
          'version': 4,
          'settings': settings.toMap(),
          'settings_by_scope': {
            for (final scope in requiredBackupScopes) scope: settings.toMap(),
          },
          'requests': <Object?>[],
          'attachments': <Object?>[],
        }),
      );
      expect(legacyBackup.hasRepresentativeReports, isFalse);
      expect(legacyBackup.hasDebts, isFalse);
      expect(legacyBackup.hasNotes, isFalse);
      expect(legacyBackup.hasQuickStatements, isFalse);
      expect(legacyBackup.hasSavedPatterns, isFalse);
      expect(legacyBackup.hasDebtSettings, isFalse);
      expect(legacyBackup.hasCalculatorHistory, isFalse);
      final preferences = await SharedPreferences.getInstance();
      final metadataBeforeLegacyRestore = preferences.getString(
        'secure.v1.backup.metadata',
      );
      expect(metadataBeforeLegacyRestore, isNotNull);
      await BackupService.restoreBackup(legacyBackup);
      final reportsAfterLegacyRestore = await RepresentativeReportStore.load();
      expect(reportsAfterLegacyRestore, hasLength(1));
      expect(
        reportsAfterLegacyRestore.single.toMap(),
        representativeReport.toMap(),
      );
      expect((await DebtStore.load()), hasLength(1));
      expect(
        preferences.getString('secure.v1.backup.metadata'),
        metadataBeforeLegacyRestore,
      );
    },
    timeout: const Timeout(Duration(minutes: 3)),
  );

  test(
    'bad attachment references fail before touching current storage',
    () async {
      final request = ExpenseRequest.fromMap({
        'attachmentPath': '/missing/legacy/file.pdf',
      });
      final backup = BackupData(
        settings: AppSettings.defaults(),
        requests: [request],
      );
      final p = await SharedPreferences.getInstance();
      final beforeKeys = p.getKeys();
      await expectLater(
        BackupService.restoreBackup(backup),
        throwsFormatException,
      );
      expect(p.getKeys(), beforeKeys);
    },
  );
}
