import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/core/utils/number_normalizer.dart';
import 'package:alfa_expense_app/features/expense_request/utils/clearance_amount_math.dart';

void main() {
  test('يحافظ منسق الأرقام على موضع المؤشر وcomposing بعد التجميع', () {
    final formatter = ThousandsSeparatorInputFormatter();
    final oldValue = TextEditingValue(
      text: '123',
      selection: TextSelection.collapsed(offset: 3),
    );
    final newValue = TextEditingValue(
      text: '1234',
      selection: TextSelection.collapsed(offset: 4),
      composing: TextRange(start: 0, end: 4),
    );

    final result = formatter.formatEditUpdate(oldValue, newValue);

    expect(result.text, '1,234');
    expect(result.selection.baseOffset, 5);
    expect(result.selection.extentOffset, 5);
    expect(result.composing, const TextRange(start: 0, end: 5));
  });

  test('يحافظ منسق إخلاء العهدة على الاختيار النسبي عند الإدراج الداخلي', () {
    final formatter = ClearanceAmountInputFormatter();
    final oldValue = TextEditingValue(
      text: '1,234',
      selection: TextSelection.collapsed(offset: 1),
    );
    final newValue = TextEditingValue(
      text: '91234',
      selection: TextSelection(baseOffset: 1, extentOffset: 3),
    );

    final result = formatter.formatEditUpdate(oldValue, newValue);

    expect(result.text, '91,234');
    expect(result.selection.baseOffset, 1);
    expect(result.selection.extentOffset, 4);
  });
}
