import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/settings/models/app_settings.dart';
import 'package:alfa_expense_app/features/settings/models/template_geometry.dart';

void main() {
  test('service request uses every geometry value supplied by the report', () {
    final geometry = TemplateGeometry.forScope('serviceRequest');
    void expectGeometry(
      String key,
      double x,
      double y,
      double width,
      double height,
    ) {
      final value = geometry[key];
      expect(value, isNotNull, reason: 'Missing geometry for $key');
      expect(value!.x, x);
      expect(value.y, y);
      expect(value.width, width);
      expect(value.height, height);
    }

    expectGeometry('date', 66, 52, 120, 22);
    expectGeometry('receiver', 335, 74, 170, 22);
    expectGeometry('serviceTypeHospitality', 434, 147, 50, 10);
    expectGeometry('serviceTypeCashSupport', 222, 147, 50, 10);
    expectGeometry('serviceTypeInKindGift', 46, 147, 50, 10);
    expectGeometry('doctorNames', 19, 176, 394, 44);
    expectGeometry('worksIn', 288, 219, 266, 47);
    expectGeometry('specialty', 15, 212, 200, 60);
    expectGeometry('statement', 19, 292, 305, 150);
    expectGeometry('amountNumber', 442, 452, 80, 30);
    expectGeometry('amountWords', 207, 445, 200, 70);
    expectGeometry('branch', 20, 443, 166, 70);
    expectGeometry('requesterName', 414, 553, 145, 22);
    expectGeometry('directManagerName', 200, 553, 145, 22);
    expectGeometry('approvedAuthorityName', 15, 553, 145, 22);
    for (var i = 1; i <= 6; i++) {
      expectGeometry(
        'serviceItemName$i',
        364,
        const <double>[296, 320, 345, 371, 398, 423][i - 1],
        200,
        22,
      );
    }
  });

  test(
    'service request defaults include all report fields in the new order',
    () {
      final fields = AppSettings.defaultsForScope(
        'serviceRequest',
      ).fieldSettings;
      expect(
        fields.keys.toList(),
        containsAllInOrder([
          'date',
          'receiver',
          'reason',
          'serviceTypeHospitality',
          'serviceTypeCashSupport',
          'serviceTypeInKindGift',
          'doctorNames',
          'worksIn',
          'specialty',
          'statement',
          'amountNumber',
          'amountWords',
          'branch',
          'requesterName',
          'directManagerName',
          'approvedAuthorityName',
        ]),
      );
      expect(fields['doctorNames']?.label, 'أسماء الأطباء');
      expect(fields['worksIn']?.label, 'يعمل في');
      expect(fields['specialty']?.label, 'التخصص');
      expect(fields['statement']?.label, 'تفاصيل الخدمة');
      expect(fields['statement']?.maxLength, 400);
      expect(fields['branch']?.maxLength, 100);
      expect(fields['serviceItemName1']?.maxLength, 36);
      expect(fields['date']?.maxLength, 30);
      expect(fields['amountNumber']?.maxLength, 30);
      expect(fields['worksIn']?.height, 47);
      expect(fields['specialty']?.height, 60);
      expect(fields['statement']?.lineHeight, 0.2);
    },
  );
}
