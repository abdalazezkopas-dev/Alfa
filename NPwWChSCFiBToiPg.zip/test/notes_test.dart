import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/notes/models/note.dart';

void main() {
  test('note round-trips body, tasks, category, colors, and flags', () {
    final created = DateTime(2026, 9, 12, 10, 30);
    final note = Note(
      id: 'note-1',
      title: 'اجتماع الإدارة',
      body: 'متابعة البنود المفتوحة',
      tasks: const [
        NoteTask(id: 'task-1', text: 'إرسال التقرير', isDone: true),
      ],
      createdAt: created,
      updatedAt: created.add(const Duration(minutes: 5)),
      category: 'مهام',
      colorValue: 0xFFFFF3CD,
      isPinned: true,
    );

    final restored = Note.fromMap(note.toMap());
    expect(restored.id, note.id);
    expect(restored.title, note.title);
    expect(restored.body, note.body);
    expect(restored.tasks.single.text, 'إرسال التقرير');
    expect(restored.tasks.single.isDone, isTrue);
    expect(restored.category, 'مهام');
    expect(restored.colorValue, 0xFFFFF3CD);
    expect(restored.isPinned, isTrue);
  });

  test('task copyWith changes only requested values', () {
    const task = NoteTask(id: '1', text: 'مراجعة');
    final completed = task.copyWith(isDone: true);
    expect(completed.id, '1');
    expect(completed.text, 'مراجعة');
    expect(completed.isDone, isTrue);
  });
}
