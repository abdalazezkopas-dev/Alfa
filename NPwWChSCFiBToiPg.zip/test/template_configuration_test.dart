import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';
import 'package:alfa_expense_app/features/settings/models/template_configuration.dart';

void main() {
  test('customer application has an independent full-page configuration', () {
    final settings = AppSettings.defaults();
    final customer = TemplateConfiguration.customerApplication(settings);

    expect(customer.id, TemplateId.customerApplication);
    expect(customer.isFullPage, isTrue);
    expect(customer.paperWidth, closeTo(612, 0.01));
    expect(customer.paperHeight, closeTo(792, 0.01));
    expect(
      customer.assetPath,
      'assets/images/customer_application_sales_modified.png',
    );
  });

  test('internal memo half and full A4 have independent configurations', () {
    final settings = AppSettings.defaults();
    final half = TemplateConfiguration.internalMemoHalf(settings);
    final full = TemplateConfiguration.internalMemoA4(settings);

    expect(half.id, TemplateId.internalMemoHalf);
    expect(full.id, TemplateId.internalMemoA4);
    expect(half.paperHeight, lessThan(full.paperHeight));
    expect(full.paperWidth, closeTo(595.28, 0.01));
    expect(full.paperHeight, closeTo(841.89, 0.01));
    final changedFull = Map<String, FieldSetting>.from(full.fields);
    changedFull['statement'] = changedFull['statement']!.copyWith(x: 211);
    final changed = full.copyWith(fields: changedFull);
    expect(changed.fields['statement']!.x, 211);
    expect(half.fields['statement']!.x, isNot(211));
  });

  test('memo layout persists and legacy requests default safely to A4', () {
    final full = ExpenseRequest(
      date: '09/09/2026',
      receiver: 'إلى',
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: 'بيان',
      branch: '',
      account: '',
      requesterName: 'مقدم',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      documentType: ExpenseDocumentType.internalMemo,
      memoLayout: InternalMemoLayout.fullA4,
    );
    final restored = ExpenseRequest.fromMap(full.toMap());
    expect(restored.memoLayout, InternalMemoLayout.fullA4);
    expect(
      ExpenseRequest.fromMap({
        ...full.toMap()..remove('memoLayout'),
      }).memoLayout,
      InternalMemoLayout.fullA4,
    );
  });
}
