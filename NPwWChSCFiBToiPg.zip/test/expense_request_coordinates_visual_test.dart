import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/expense_request/services/pdf_service.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'generates a live expense-request PDF with the requested geometry',
    () async {
      const request = ExpenseRequest(
        date: '2026/09/26',
        receiver: 'الجهة المعتمدة - اختبار',
        amountNumber: '123456',
        amountWords: 'مائة وثلاثة وعشرون ألفًا وأربعمائة وستة وخمسون ريال',
        reason: 'سبب اختبار الإحداثيات',
        statement: 'بيان اختبار الطباعة الحية وإحداثيات النموذج العلوي.',
        branch: 'الفرع الرئيسي',
        account: 'حساب الاختبار',
        requesterName: 'مقدم الطلب - اختبار',
        requesterSignature: '',
        directManagerName: 'المدير المباشر - اختبار',
        directManagerSignature: '',
        approvedAuthorityName: 'الجهة المعتمدة - اختبار',
        approvedAuthoritySignature: '',
        accountsManagerName: 'مدير الحسابات - اختبار',
        accountsManagerSignature: '',
      );

      final bytes = await PdfService.buildRequestPdf(
        request,
        settings: AppSettings.defaults(),
      );
      expect(bytes, isNotEmpty);
      await File(
        '/tmp/expense_request_coordinates_live.pdf',
      ).writeAsBytes(bytes);
    },
  );
}
