import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/backup/services/backup_service.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';
import 'package:alfa_expense_app/features/settings/models/template_configuration.dart';
import 'package:alfa_expense_app/features/settings/services/pattern_store.dart';

void main() {
  test('prompt scopes remain stable while the sample template is added', () {
    expect(
      requiredBackupScopes,
      containsAll([
        'expenseRequest',
        'customerApplication',
        'clearanceRequest',
        'serviceRequest',
        'fuelRequest',
        'internalMemo',
        'sampleRequest',
        'sampleRequestSinglePage',
        'travelAllowance',
      ]),
    );
    expect(requiredBackupScopes, hasLength(9));
    expect(TemplateKind.values, hasLength(9));
  });

  test(
    'portable pattern export contains settings only, never requests or attachments',
    () {
      final pattern = SavedPattern(
        name: 'نمط اختبار',
        scope: 'fuelRequest',
        settings: AppSettings.defaultsForScope('fuelRequest'),
      );
      final portable = PatternExport.toPortableMap([pattern]);
      final encoded = portable.toString();

      expect(portable['format'], 'spapharma-patterns-v1');
      expect(portable['patterns'], isA<List>());
      expect(encoded, isNot(contains('requests')));
      expect(encoded, isNot(contains('attachments')));
    },
  );
}
