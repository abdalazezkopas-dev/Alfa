import 'package:flutter_test/flutter_test.dart';
import 'package:alfa_expense_app/core/utils/date_formatter.dart';

void main() {
  test('يعرض التاريخ بصيغة السنة ثم الشهر ثم اليوم مع م', () {
    expect(DateFormatter.date(DateTime(2026, 9, 26)), 'م2026/09/26');
    expect(
      DateFormatter.dateTime(DateTime(2026, 9, 26, 14, 5)),
      'م2026/09/26 14:05',
    );
  });

  test('يقرأ الصيغة الجديدة والقديمة دون كسر المستندات المحفوظة', () {
    expect(DateFormatter.parse('م2026/09/26'), DateTime(2026, 9, 26));
    expect(DateFormatter.parse('26/09/2026'), DateTime(2026, 9, 26));
    expect(DateFormatter.parse('2026/02/31م'), isNull);
  });
}
