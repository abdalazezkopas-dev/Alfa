import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:pdf/pdf.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/expense_request/services/pdf_service.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';
import 'package:alfa_expense_app/features/settings/screens/settings_screen.dart';
import 'package:alfa_expense_app/features/settings/widgets/color_picker_dropdown.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('uses the primary document page size for attachment pages', () {
    expect(
      PdfService.attachmentPageFormatFor(ExpenseDocumentType.sampleRequest),
      PdfPageFormat.letter,
    );
    expect(
      PdfService.attachmentPageFormatFor(
        ExpenseDocumentType.customerApplication,
      ),
      PdfPageFormat.letter,
    );
    expect(
      PdfService.attachmentPageFormatFor(ExpenseDocumentType.expenseRequest),
      PdfPageFormat.a4,
    );
  });

  test('ينشئ ملف PDF من بيانات طلب الصرف والقالبين', () async {
    const request = ExpenseRequest(
      date: '26/08/2026',
      receiver: 'مدير الحسابات',
      amountNumber: '1250.00',
      amountWords: 'ألف ومائتان وخمسون ريال',
      reason: 'شراء مستلزمات تشغيلية',
      statement: 'بيان تجريبي للطلب',
      branch: 'الفرع الرئيسي',
      account: 'المصروفات التشغيلية',
      requesterName: 'أحمد محمد',
      requesterSignature: 'أحمد',
      directManagerName: 'محمد علي',
      directManagerSignature: 'محمد',
      approvedAuthorityName: 'خالد حسن',
      approvedAuthoritySignature: 'خالد',
      accountsManagerName: 'سعيد عبدالله',
      accountsManagerSignature: 'سعيد',
    );

    final bytes = await PdfService.buildRequestPdf(request);

    expect(bytes, isNotEmpty);
    expect(bytes.sublist(0, 4), orderedEquals([37, 80, 68, 70]));
  });

  test('لون النموذج العام يطبّق فعليًا على PDF بدل لون الحقل القديم', () async {
    const request = ExpenseRequest(
      date: '26/08/2026',
      receiver: 'مدير الحسابات',
      amountNumber: '1250.00',
      amountWords: 'ألف ومائتان وخمسون ريال',
      reason: 'شراء مستلزمات تشغيلية',
      statement: 'بيان يختبر لون النموذج العام',
      branch: 'الفرع الرئيسي',
      account: 'المصروفات التشغيلية',
      requesterName: 'أحمد محمد',
      requesterSignature: 'أحمد',
      directManagerName: 'محمد علي',
      directManagerSignature: 'محمد',
      approvedAuthorityName: 'خالد حسن',
      approvedAuthoritySignature: 'خالد',
      accountsManagerName: 'سعيد عبدالله',
      accountsManagerSignature: 'سعيد',
    );
    final redPdf = await PdfService.buildRequestPdf(
      request,
      settings: AppSettings.defaults().copyWith(
        printedTextColorValue: 0xFFB71C1C,
      ),
    );
    final greenPdf = await PdfService.buildRequestPdf(
      request,
      settings: AppSettings.defaults().copyWith(
        printedTextColorValue: 0xFF00695C,
      ),
    );

    expect(redPdf, isNotEmpty);
    expect(greenPdf, isNotEmpty);
    expect(redPdf, isNot(equals(greenPdf)));
  });

  test(
    'لون النطاق يطبق على PDF العينات الثلاث صفحات والصفحة الواحدة',
    () async {
      ExpenseRequest sampleRequest({required bool singlePage}) =>
          ExpenseRequest(
            date: '06/10/2026',
            receiver: 'الجهة المستلمة',
            amountNumber: '',
            amountWords: '',
            reason: 'تسويقية',
            statement: 'طلب عينات لاختبار اللون',
            branch: '',
            account: '',
            requesterName: 'مقدم الطلب',
            requesterSignature: '',
            directManagerName: '',
            directManagerSignature: '',
            approvedAuthorityName: '',
            approvedAuthoritySignature: '',
            accountsManagerName: '',
            accountsManagerSignature: '',
            documentType: ExpenseDocumentType.sampleRequest,
            customFields: {
              'sampleUsage': 'تسويقية',
              if (singlePage) 'sampleTemplate': 'singlePage',
            },
            sampleItems: [
              SampleItem(
                productId: 'test',
                productName: 'صنف تجريبي',
                pharmaceuticalForm: 'أقراص',
                quantityNumber: '2',
                quantityWords: 'اثنان',
                notes: '',
              ),
            ],
          );

      for (final configuration in [
        (scope: 'sampleRequest', singlePage: false),
        (scope: 'sampleRequestSinglePage', singlePage: true),
      ]) {
        final defaults = AppSettings.defaultsForScope(configuration.scope);
        final request = sampleRequest(singlePage: configuration.singlePage);
        final redPdf = await PdfService.buildRequestPdf(
          request,
          settings: defaults.copyWith(printedTextColorValue: 0xFFB71C1C),
        );
        final greenPdf = await PdfService.buildRequestPdf(
          request,
          settings: defaults.copyWith(printedTextColorValue: 0xFF00695C),
        );

        expect(redPdf, isNotEmpty, reason: configuration.scope);
        expect(greenPdf, isNotEmpty, reason: configuration.scope);
        expect(redPdf, isNot(equals(greenPdf)), reason: configuration.scope);
      }
    },
  );

  test('ينشئ PDF لبيان عربي طويل مع أرقام هندية دون RangeError', () async {
    const longStatement =
        'جزء من ايجار شهر اغسطس ٢٠٢٦ للاخ محمد حمود علي الطيار من عبدالعزيز معمر كباس '
        'سدادا لسحبياته مواد غذائية من محلات الوشلي حسب طلبه جزء من ايجار شهر اغسطس '
        '٢٠٢٦ للاخ محمد حمود علي الطيار من عبدالعزيز معمر كباس سدادا لسحبياته مواد غذائية '
        'من محلات الوشلي حسب طلبه';
    const request = ExpenseRequest(
      date: '26/08/2026',
      receiver: 'مدير الحسابات',
      amountNumber: '1250.00',
      amountWords: 'ألف ومائتان وخمسون ريال',
      reason: '',
      statement: longStatement,
      branch: '',
      account: '',
      requesterName: 'عبدالعزيز كباس',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
    );

    final bytes = await PdfService.buildRequestPdf(request);
    expect(bytes, isNotEmpty);
    expect(bytes.sublist(0, 4), orderedEquals([37, 80, 68, 70]));
  });

  test('يرفض النص المهم الذي يتجاوز سعة حقل PDF بدل قصه صامتًا', () async {
    final request = ExpenseRequest(
      date: '26/08/2026',
      receiver: 'مدير الحسابات',
      amountNumber: '1250.00',
      amountWords: 'ألف ومائتان وخمسون ريال',
      reason: '',
      statement: List.filled(2000, 'نص طويل').join(' '),
      branch: '',
      account: '',
      requesterName: 'عبدالعزيز كباس',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
    );

    await expectLater(
      PdfService.buildRequestPdf(request),
      throwsA(isA<StateError>()),
    );
  });

  test('ينشئ PDF للمبلغ المفرد دون تكرار كلمة واحد', () async {
    const request = ExpenseRequest(
      date: '26/08/2026',
      receiver: 'مدير الحسابات',
      amountNumber: '1',
      amountWords: 'ريال واحد',
      reason: '',
      statement: 'شراء مستلزم واحد',
      branch: '',
      account: '',
      requesterName: 'عبدالعزيز كباس',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
    );

    final bytes = await PdfService.buildRequestPdf(request);
    expect(bytes, isNotEmpty);
    expect(bytes.sublist(0, 4), orderedEquals([37, 80, 68, 70]));
  });

  test('ينشئ نموذجين مستقلين عند اختيار نموذجين', () async {
    const second = ExpenseRequest(
      date: '27/08/2026',
      receiver: 'مدير المبيعات',
      amountNumber: '2500',
      amountWords: 'ألفان وخمسمائة ريال',
      reason: '',
      statement: 'البيان الثاني',
      branch: '',
      account: '',
      requesterName: 'مقدم ثانٍ',
      requesterSignature: '',
      directManagerName: 'مدير ثانٍ',
      directManagerSignature: '',
      approvedAuthorityName: 'جهة ثانية',
      approvedAuthoritySignature: '',
      accountsManagerName: 'حسابات ثانية',
      accountsManagerSignature: '',
    );
    const first = ExpenseRequest(
      date: '26/08/2026',
      receiver: 'مدير مجلس الإدارة',
      amountNumber: '50000',
      amountWords: 'خمسون ألف ريال',
      reason: '',
      statement: 'البيان الأول',
      branch: '',
      account: '',
      requesterName: 'مقدم أول',
      requesterSignature: '',
      directManagerName: 'مدير أول',
      directManagerSignature: '',
      approvedAuthorityName: 'جهة أولى',
      approvedAuthoritySignature: '',
      accountsManagerName: 'حسابات أولى',
      accountsManagerSignature: '',
      formCount: 2,
      secondRequest: second,
    );

    final defaults = AppSettings.defaults();
    final settings = defaults.copyWith(
      fieldSettings: {
        ...defaults.fieldSettings,
        'receiver': defaults.fieldSettings['receiver']!.copyWith(
          bottomX: 110,
          bottomY: 68,
          bottomWidth: 350,
        ),
        'statement': defaults.fieldSettings['statement']!.copyWith(
          bottomX: 82,
          bottomY: 165,
          bottomWidth: 390,
        ),
      },
    );
    final bytes = await PdfService.buildRequestPdf(first, settings: settings);
    expect(bytes, isNotEmpty);
  });

  test('ينشئ PDF بخط النسخ والنمط المائل والوزن الغامق', () async {
    const request = ExpenseRequest(
      date: '27/08/2026',
      receiver: 'مدير الحسابات',
      amountNumber: '50000',
      amountWords: 'خمسون ألف ريال',
      reason: '',
      statement: 'بيان بخط النسخ الواضح لا للا',
      branch: '',
      account: '',
      requesterName: 'عبدالعزيز كباس',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
    );
    final defaults = AppSettings.defaults();
    final settings = defaults.copyWith(
      fieldSettings: {
        ...defaults.fieldSettings,
        'statement': defaults.fieldSettings['statement']!.copyWith(
          fontFamily: 'Noto Naskh Arabic',
          fontWeight: 800,
          fontStyle: 'italic',
          height: 96,
        ),
      },
    );

    final bytes = await PdfService.buildRequestPdf(request, settings: settings);
    expect(bytes, isNotEmpty);
    expect(bytes.sublist(0, 4), orderedEquals([37, 80, 68, 70]));
  });

  test('يحمي PDF عند اختيار خط عربي زخرفي مع بيان طويل', () async {
    const request = ExpenseRequest(
      date: '26/08/2026',
      receiver: 'مدير الحسابات',
      amountNumber: '508812',
      amountWords: 'خمسمائة وثمانية آلاف وثمانمائة واثنا عشر ريال',
      reason: '',
      statement:
          'للأخ محمد حمود علي الطيار من عبدالعزيز كباس سدادا لسحبياته مواد غذائية من محلات الوشلي حسب طلبه',
      branch: '',
      account: '',
      requesterName: 'عبدالعزيز كباس',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
    );
    final defaults = AppSettings.defaults();
    final settings = defaults.copyWith(
      fieldSettings: {
        ...defaults.fieldSettings,
        'statement': defaults.fieldSettings['statement']!.copyWith(
          fontFamily: 'Aref Ruqaa',
          height: 180,
          lineHeight: 0.7,
        ),
      },
    );

    final bytes = await PdfService.buildRequestPdf(request, settings: settings);
    expect(bytes, isNotEmpty);
    expect(bytes.sublist(0, 4), orderedEquals([37, 80, 68, 70]));
  });

  test('ينشئ معاينة بيانات النموذجين بحجم بيان 14.5', () async {
    final statement = List.filled(10, 'عبدالعزيز معمر كباس').join('، ');
    ExpenseRequest sampleRequest() => ExpenseRequest(
      date: '28/08/2026',
      receiver: 'مدير الحسابات',
      amountNumber: '5650020',
      amountWords: 'خمسة مليون وستمائة وخمسين ألف وعشرين ريال',
      reason: '',
      statement: statement,
      branch: '',
      account: '',
      requesterName: 'عبدالعزيز كباس',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
    );
    final defaults = AppSettings.defaults();
    final settings = defaults.copyWith(
      fieldSettings: {
        ...defaults.fieldSettings,
        'statement': defaults.fieldSettings['statement']!.copyWith(
          fontSize: 14.5,
          height: 170,
        ),
      },
      bottomFieldSettings: {
        ...defaults.fieldsForCopy(bottom: true),
        'statement': defaults
            .fieldsForCopy(bottom: true)['statement']!
            .copyWith(fontSize: 14.5, height: 170),
      },
    );
    final request = sampleRequest();
    final bytes = await PdfService.buildRequestPdf(
      ExpenseRequest(
        date: request.date,
        receiver: request.receiver,
        amountNumber: request.amountNumber,
        amountWords: request.amountWords,
        reason: request.reason,
        statement: request.statement,
        branch: request.branch,
        account: request.account,
        requesterName: request.requesterName,
        requesterSignature: request.requesterSignature,
        directManagerName: request.directManagerName,
        directManagerSignature: request.directManagerSignature,
        approvedAuthorityName: request.approvedAuthorityName,
        approvedAuthoritySignature: request.approvedAuthoritySignature,
        accountsManagerName: request.accountsManagerName,
        accountsManagerSignature: request.accountsManagerSignature,
        formCount: 2,
        secondRequest: sampleRequest(),
      ),
      settings: settings,
    );
    expect(bytes, isNotEmpty);
  });

  test('يرفض البيان الذي يتجاوز سعة الحقل دون قص النص', () async {
    final statement = List.filled(500, 'س').join();
    final request = ExpenseRequest(
      date: '28/08/2026',
      receiver: 'مدير الحسابات',
      amountNumber: '100',
      amountWords: 'مائة ريال',
      reason: '',
      statement: statement,
      branch: '',
      account: '',
      requesterName: 'عبدالعزيز كباس',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
    );
    await expectLater(
      PdfService.buildRequestPdf(request, settings: AppSettings.defaults()),
      throwsA(isA<StateError>()),
    );
    expect(request.statement.runes.length, 500);
  });

  test('يحمي PDF من مواضع وأبعاد الحقول الخارجة عن صفحة A4', () async {
    const request = ExpenseRequest(
      date: '28/08/2026',
      receiver: 'مدير الحسابات',
      amountNumber: '9000',
      amountWords: 'تسعة آلاف ريال',
      reason: '',
      statement: 'اختبار حماية موضع الحقل',
      branch: '',
      account: '',
      requesterName: 'عبدالعزيز كباس',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
    );
    final defaults = AppSettings.defaults();
    final settings = defaults.copyWith(
      fieldSettings: {
        ...defaults.fieldSettings,
        'statement': defaults.fieldSettings['statement']!.copyWith(
          x: 9999,
          y: 9999,
          width: 9999,
          height: 9999,
        ),
      },
    );

    final bytes = await PdfService.buildRequestPdf(request, settings: settings);
    expect(bytes, isNotEmpty);
    expect(bytes.sublist(0, 4), orderedEquals([37, 80, 68, 70]));
  });

  testWidgets('فشل التخزين الآمن يعيد لون النطاق ويعرض تنبيهًا', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    const channel = MethodChannel(
      'plugins.it_nomads.com/flutter_secure_storage',
    );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
          if (call.method == 'read') return null;
          if (call.method == 'write') {
            throw PlatformException(
              code: 'storage_failure',
              message: 'فشل التخزين الآمن للاختبار',
            );
          }
          return null;
        });
    addTearDown(
      () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(channel, null),
    );

    await tester.pumpWidget(const MaterialApp(home: SettingsScreen()));
    final colorSection = find.text('لون الكتابة المطبوعة لكل نموذج');
    await tester.pumpAndSettle();
    await tester.scrollUntilVisible(colorSection, 300);

    expect(colorSection, findsOneWidget);
    await tester.ensureVisible(colorSection);
    await tester.tap(colorSection);
    await tester.pumpAndSettle();
    final expensePicker = find.byWidgetPredicate(
      (widget) =>
          widget is ColorPickerDropdown && widget.label == 'نموذج طلب الصرف',
    );
    await tester.ensureVisible(expensePicker);
    await tester.tap(expensePicker);
    await tester.pumpAndSettle();

    final redSwatch = find.byWidgetPredicate((widget) {
      if (widget is! Container || widget.decoration is! BoxDecoration) {
        return false;
      }
      return (widget.decoration! as BoxDecoration).color?.toARGB32() ==
          0xFFFF0000;
    });
    expect(redSwatch, findsOneWidget);
    await tester.tap(redSwatch);
    await tester.pumpAndSettle();

    expect(
      find.text('تعذر حفظ لون الكتابة المطبوعة، أُعيد اللون السابق.'),
      findsOneWidget,
    );
    expect(
      find.descendant(of: expensePicker, matching: find.text('#0070C0')),
      findsOneWidget,
    );
    expect(tester.takeException(), isNull);

    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump();
  });
}
