import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/features/backup/services/encrypted_backup_codec.dart';
import 'package:alfa_expense_app/features/debts/services/debt_store.dart';
import 'package:alfa_expense_app/features/finance/services/finance_store.dart';
import 'package:alfa_expense_app/features/notes/services/notes_store.dart';
import 'package:alfa_expense_app/features/reminders/services/reminder_store.dart';
import 'package:alfa_expense_app/features/settings/services/pattern_store.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const channel = MethodChannel('plugins.it_nomads.com/flutter_secure_storage');
  final keyValues = <String, String>{};
  var failSecureReads = false;

  setUp(() async {
    keyValues.clear();
    failSecureReads = false;
    SharedPreferences.setMockInitialValues({});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, (call) async {
          final arguments = (call.arguments as Map?)?.cast<String, Object?>();
          final key = arguments?['key'] as String?;
          switch (call.method) {
            case 'read':
              if (failSecureReads) {
                throw PlatformException(code: 'secure_storage_unavailable');
              }
              return key == null ? null : keyValues[key];
            case 'write':
              if (key != null) {
                keyValues[key] = arguments?['value'] as String? ?? '';
              }
              return null;
            case 'delete':
              if (key != null) keyValues.remove(key);
              return null;
            default:
              return null;
          }
        });
  });

  tearDown(
    () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(channel, null),
  );

  test('يرفض فساد الملاحظات ولا يحوله إلى قائمة قابلة للحفظ', () async {
    const corrupt = '[{"tasks":"not-a-list"}]';
    SharedPreferences.setMockInitialValues({
      'alfa_expense_app.notes.v1': corrupt,
    });

    await expectLater(NotesStore.load(), throwsA(isA<FormatException>()));

    final preferences = await SharedPreferences.getInstance();
    expect(preferences.getString('alfa_expense_app.notes.v1'), corrupt);
    expect(preferences.getString('secure.v1.notes'), isNull);
  });

  test('يرفض فساد التذكيرات والديون والسلف بدل إسقاط السجلات', () async {
    const corruptReminders = '[{"scheduledAt":false}]';
    const corruptDebts = '[{"entries":false}]';
    SharedPreferences.setMockInitialValues({
      'alfa_expense_app.reminders.v1': corruptReminders,
      'alfa_expense_app.debt_accounts.v1': corruptDebts,
    });

    await expectLater(ReminderStore.load(), throwsA(isA<FormatException>()));
    await expectLater(DebtStore.load(), throwsA(isA<FormatException>()));

    const password = 'test-storage-key-0123456789abcdef';
    keyValues['kabas_storage_key_v1'] = password;
    final corruptAdvance = await EncryptedBackupCodec.encryptJson(
      jsonEncode([
        {
          'amount': 10,
          'type': 'سلفة',
          'reason': 'اختبار',
          'startDate': '2026-10-22T00:00:00.000',
          'months': 'many',
          'frequency': 'monthly',
        },
      ]),
      password: password,
    );
    final preferences = await SharedPreferences.getInstance();
    await preferences.setString('secure.v1.finance.advances', corruptAdvance);

    await expectLater(
      FinanceStore.loadAdvances(),
      throwsA(isA<FormatException>()),
    );
    expect(
      preferences.getString('alfa_expense_app.reminders.v1'),
      corruptReminders,
    );
    expect(
      preferences.getString('alfa_expense_app.debt_accounts.v1'),
      corruptDebts,
    );
  });

  test(
    'لا يتجاوز فشل التخزين الآمن إلى legacy قابلة للكتابة فوق البيانات',
    () async {
      failSecureReads = true;
      SharedPreferences.setMockInitialValues({
        'secure.v1.notes': 'present',
        'secure.v1.reminders': 'present',
        'secure.v1.debts': 'present',
        'secure.v1.patterns': 'present',
        'alfa_expense_app.notes.v1': '[]',
        'alfa_expense_app.reminders.v1': '[]',
        'alfa_expense_app.debt_accounts.v1': '[]',
        'saved_patterns_v1': <String>[],
      });

      await expectLater(NotesStore.load(), throwsA(isA<PlatformException>()));
      await expectLater(
        ReminderStore.load(),
        throwsA(isA<PlatformException>()),
      );
      await expectLater(DebtStore.load(), throwsA(isA<PlatformException>()));
      await expectLater(PatternStore.load(), throwsA(isA<PlatformException>()));
      expect(keyValues, isEmpty);

      final preferences = await SharedPreferences.getInstance();
      expect(preferences.getString('alfa_expense_app.notes.v1'), '[]');
      expect(preferences.getString('alfa_expense_app.reminders.v1'), '[]');
      expect(preferences.getString('alfa_expense_app.debt_accounts.v1'), '[]');
      expect(preferences.getStringList('saved_patterns_v1'), <String>[]);
    },
  );
}
