import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/app.dart';

void main() {
  testWidgets('يعرض الترحيب ثم الشاشة الرئيسية وأزرارها الأساسية', (
    WidgetTester tester,
  ) async {
    SharedPreferences.setMockInitialValues({
      'alfa_expense_app.first_run': true,
    });
    await tester.pumpWidget(const AlfaExpenseApp());

    expect(find.text('يا مرحبا'), findsOneWidget);

    await tester.pump(const Duration(milliseconds: 2300));
    await tester.pumpAndSettle();

    expect(find.text('النماذج والمستندات'), findsOneWidget);
    expect(find.text('اختار نموذجك وقدم'), findsOneWidget);
    expect(
      find.text(
        'اختر نموذج العملاء أو طلب الصرف أو طلب العينات أو المذكرة الداخلية A4',
      ),
      findsOneWidget,
    );
    expect(find.text('نماذج العملاء'), findsNothing);
    expect(find.text('المستندات السابقة'), findsOneWidget);
    expect(find.text('النوتة والملاحظات'), findsOneWidget);
    expect(find.text('الإعدادات'), findsAtLeastNWidgets(1));
    expect(find.byType(NavigationBar), findsNothing);
  });
}
