import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/expense_request/screens/expense_request_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const secureStorageChannel = MethodChannel(
    'plugins.it_nomads.com/flutter_secure_storage',
  );
  final secureValues = <String, String>{};

  setUp(() {
    secureValues.clear();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(secureStorageChannel, (call) async {
          final arguments = (call.arguments as Map?)?.cast<String, Object?>();
          final key = arguments?['key'] as String?;
          if (call.method == 'read') {
            return key == null ? null : secureValues[key];
          }
          if (call.method == 'write' && key != null) {
            secureValues[key] = arguments?['value'] as String? ?? '';
          }
          return null;
        });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(secureStorageChannel, null);
  });

  testWidgets('يمنع معاينة نموذجين قبل اعتماد النموذج الثاني', (tester) async {
    SharedPreferences.setMockInitialValues({});
    const request = ExpenseRequest(
      date: '2026/10/18م',
      receiver: 'جهة الاختبار',
      amountNumber: '50000',
      amountWords: 'خمسون ألفاً',
      reason: '',
      statement: 'بيان الاختبار',
      branch: '',
      account: '',
      requesterName: '',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      documentType: ExpenseDocumentType.expenseRequest,
      formCount: 2,
    );

    await tester.pumpWidget(
      const MaterialApp(home: ExpenseRequestScreen(initialRequest: request)),
    );
    await tester.pumpAndSettle();

    await tester.tap(find.byTooltip('معاينة PDF'));
    await tester.pumpAndSettle();

    expect(find.text('أدخل بيانات النموذج الثاني أولاً'), findsOneWidget);
    expect(find.text('معاينة طلب الصرف'), findsNothing);
    expect(tester.takeException(), isNull);
  });

  testWidgets('زر النموذج الأول يعيد تمرير الشاشة إلى بداية النموذج', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    const request = ExpenseRequest(
      date: '01/10/2026',
      receiver: 'جهة الاختبار',
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: '',
      branch: '',
      account: '',
      requesterName: '',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      documentType: ExpenseDocumentType.expenseRequest,
      formCount: 2,
    );

    await tester.pumpWidget(
      const MaterialApp(home: ExpenseRequestScreen(initialRequest: request)),
    );
    await tester.pumpAndSettle();

    final firstFormButton = find.text('النموذج الأول');
    for (var i = 0; i < 100 && !tester.any(firstFormButton); i++) {
      await tester.pump(const Duration(milliseconds: 100));
    }
    expect(firstFormButton, findsOneWidget);
    await tester.ensureVisible(firstFormButton);
    await tester.tap(firstFormButton);
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
  });

  testWidgets('يعرض البند السابع عند فتح طلب عهدة محفوظ', (tester) async {
    SharedPreferences.setMockInitialValues({});
    final request = ExpenseRequest(
      date: '01/10/2026',
      receiver: 'جهة الاختبار',
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: '',
      branch: '',
      account: '',
      requesterName: '',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      documentType: ExpenseDocumentType.clearanceRequest,
      clearanceEntries: [
        for (var i = 1; i <= 7; i++)
          ClearanceEntry(
            amount: '$i',
            date: '01/10/2026',
            statement: 'بيان $i',
          ),
      ],
    );

    await tester.pumpWidget(
      MaterialApp(
        home: ExpenseRequestScreen(
          initialRequest: request,
          documentType: ExpenseDocumentType.clearanceRequest,
        ),
      ),
    );
    await tester.pumpAndSettle();

    expect(find.text('مجموعة العهدة 7'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('حاسبة المبلغ تعرض الأرقام والرموز كاملة بخط واتجاه ثابتين', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(const MaterialApp(home: ExpenseRequestScreen()));
    await tester.pumpAndSettle();

    final calculatorButton = find.byTooltip('آلة حاسبة');
    expect(calculatorButton, findsOneWidget);
    await tester.ensureVisible(calculatorButton);
    await tester.tap(calculatorButton);
    await tester.pumpAndSettle();
    expect(find.text('آلة حاسبة المبلغ'), findsOneWidget);

    for (final label in [
      '0',
      '1',
      '2',
      '3',
      '4',
      '5',
      '6',
      '7',
      '8',
      '9',
      '.',
      '+',
      '−',
      '×',
      '÷',
      '=',
    ]) {
      final labelFinder = find.descendant(
        of: find.byType(AlertDialog),
        matching: find.text(label),
      );
      expect(labelFinder, findsOneWidget);
      await tester.ensureVisible(labelFinder);
    }

    final oneButton = find.ancestor(
      of: find.descendant(
        of: find.byType(AlertDialog),
        matching: find.text('1'),
      ),
      matching: find.byType(FilledButton),
    );
    final oneText = tester.widget<Text>(
      find.descendant(of: oneButton, matching: find.byType(Text)),
    );
    expect(oneText.textDirection, TextDirection.ltr);
    expect(oneText.style?.fontFamily, 'Arial');

    final expression = tester.widget<TextField>(find.byType(TextField).last);
    expect(expression.textDirection, TextDirection.ltr);
    expect(expression.style?.fontFamily, 'Arial');
    expect(tester.takeException(), isNull);
  });
}
