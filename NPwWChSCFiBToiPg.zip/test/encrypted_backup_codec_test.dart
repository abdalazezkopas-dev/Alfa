import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/backup/services/encrypted_backup_codec.dart';

void main() {
  test('encrypts and decrypts a JSON payload', () async {
    const source = '{"format":"alfa_expense_app_backup","version":3}';
    final encrypted = await EncryptedBackupCodec.encryptJson(
      source,
      password: 'correct horse battery',
    );
    expect(encrypted, startsWith('${EncryptedBackupCodec.magic}\n'));
    expect(
      await EncryptedBackupCodec.decryptJson(
        encrypted,
        password: 'correct horse battery',
      ),
      source,
    );
  });

  test('rejects a wrong password and truncated container', () async {
    final encrypted = await EncryptedBackupCodec.encryptJson(
      '{"safe":true}',
      password: 'correct horse battery',
    );
    await expectLater(
      EncryptedBackupCodec.decryptJson(encrypted, password: 'wrong password'),
      throwsA(isA<FormatException>()),
    );
    await expectLater(
      EncryptedBackupCodec.decryptJson(
        encrypted.substring(0, encrypted.length ~/ 2),
        password: 'correct horse battery',
      ),
      throwsA(isA<FormatException>()),
    );
  });
}
