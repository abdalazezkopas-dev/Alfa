import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/settings/models/app_settings.dart';
import 'package:alfa_expense_app/features/settings/models/template_geometry.dart';

void main() {
  test('sample request exposes all 53 item rows across three pages', () {
    final settings = AppSettings.defaultsForScope('sampleRequest');
    final geometry = TemplateGeometry.forScope('sampleRequest');

    for (var index = 1; index <= 53; index++) {
      for (final suffix in [
        'Name',
        'Form',
        'Quantity',
        'QuantityWords',
        'Notes',
      ]) {
        expect(settings.fieldSettings, contains('sampleItem$suffix$index'));
        expect(geometry, contains('sampleItem$suffix$index'));
      }
    }

    expect(settings.fieldSettings, isNot(contains('accountsManagerName')));
    expect(settings.fieldSettings, isNot(contains('directManagerName')));
    expect(settings.fieldSettings, isNot(contains('amountNumber')));
    expect(settings.fieldSettings, isNot(contains('amountWords')));
    expect(settings.fieldSettings, contains('reason'));
    expect(settings.fieldSettings, contains('reasonPage3'));

    final pageOneName = geometry['sampleItemName1']!;
    expect(pageOneName.x, 383);
    expect(pageOneName.y, 331);
    expect(pageOneName.width, 166);
    expect(pageOneName.height, 22);

    final pageTwoName = geometry['sampleItemName12']!;
    expect(pageTwoName.x, 383);
    expect(pageTwoName.y, 55);
    expect(pageTwoName.width, 166);
    expect(pageTwoName.height, 22);

    final purposePageOne = geometry['reason']!;
    expect(purposePageOne.x, 44);
    expect(purposePageOne.y, 585);
    expect(purposePageOne.width, 450);
    expect(purposePageOne.height, 30);

    final purposePageThree = geometry['reasonPage3']!;
    expect(purposePageThree.x, 20);
    expect(purposePageThree.y, 496);
    expect(purposePageThree.width, 468);
    expect(purposePageThree.height, 56);
  });

  test('single-page item fields move down by ten points together', () {
    final geometry = TemplateGeometry.forScope('sampleRequestSinglePage');
    for (final suffix in [
      'Name',
      'Form',
      'Quantity',
      'QuantityWords',
      'Notes',
    ]) {
      expect(geometry['sampleItem${suffix}1']!.y, 215);
      expect(geometry['sampleItem${suffix}2']!.y, closeTo(233.2, 0.001));
    }
  });

  test('single-page header fields use the approved coordinates', () {
    final geometry = TemplateGeometry.forScope('sampleRequestSinglePage');
    expect(geometry['receiver']!.x, 352);
    expect(geometry['receiver']!.y, 135);
    expect(geometry['receiver']!.width, 150);
    expect(geometry['receiver']!.height, 22);
    expect(geometry['reason']!.x, 3);
    expect(geometry['reason']!.y, 668);
    expect(geometry['reason']!.width, 500);
    expect(geometry['reason']!.height, 33);
    expect(geometry['requesterName']!.x, 391);
    expect(geometry['requesterName']!.y, 704);
    expect(geometry['requesterName']!.width, 145);
    expect(geometry['date']!.x, 0);
    expect(geometry['date']!.y, 70);
  });
}
