import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/features/settings/models/template_configuration.dart';
import 'package:alfa_expense_app/features/settings/screens/settings_screen.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  const secureStorageChannel = MethodChannel(
    'plugins.it_nomads.com/flutter_secure_storage',
  );
  final secureValues = <String, String>{};

  setUp(() {
    secureValues.clear();
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(secureStorageChannel, (call) async {
          final arguments = (call.arguments as Map?)?.cast<String, Object?>();
          final key = arguments?['key'] as String?;
          if (call.method == 'read') {
            return key == null ? null : secureValues[key];
          }
          if (call.method == 'write' && key != null) {
            secureValues[key] = arguments?['value'] as String? ?? '';
          }
          return null;
        });
  });

  tearDown(() {
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(secureStorageChannel, null);
  });

  testWidgets('تبني شاشة الإعدادات بنجاح لكل نوع نموذج', (tester) async {
    SharedPreferences.setMockInitialValues({});

    for (final kind in TemplateKind.values) {
      await tester.pumpWidget(
        MaterialApp(
          home: SettingsScreen(key: ValueKey(kind), templateKind: kind),
        ),
      );
      final title = find.text('إعدادات ${kind.title}');
      for (var i = 0; i < 100 && !tester.any(title); i++) {
        await tester.pump(const Duration(milliseconds: 100));
      }

      expect(tester.takeException(), isNull, reason: kind.name);
      expect(title, findsOneWidget, reason: kind.name);
    }

    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump();
  });

  testWidgets('لا تعرض الإعدادات العامة قسم القوالب والنماذج', (tester) async {
    SharedPreferences.setMockInitialValues({});

    await tester.pumpWidget(const MaterialApp(home: SettingsScreen()));
    final loadedMarker = find.text('الفروع المشتركة');
    for (var i = 0; i < 300 && !tester.any(loadedMarker); i++) {
      await tester.pump(const Duration(milliseconds: 100));
    }

    expect(loadedMarker, findsOneWidget);
    expect(find.text('القوالب والنماذج'), findsNothing);
    expect(find.text('دليل الأصناف'), findsOneWidget);
    expect(find.text('الفروع المشتركة'), findsOneWidget);
    final backupButton = find.text('تصدير نسخة كاملة');
    for (var i = 0; i < 40 && !tester.any(backupButton); i++) {
      await tester.drag(find.byType(Scrollable).last, const Offset(0, -500));
      await tester.pump(const Duration(milliseconds: 50));
    }
    expect(find.text('تصدير نسخة كاملة'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
