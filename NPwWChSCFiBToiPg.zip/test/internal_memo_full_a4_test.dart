import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/expense_request/services/pdf_service.dart';
import 'package:alfa_expense_app/features/settings/models/template_configuration.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('full A4 memo renders one complete A4 page independently', () async {
    final request = ExpenseRequest(
      date: '09/09/2026',
      receiver: 'مدير الإدارة',
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: 'بيان طويل في منتصف وأسفل الصفحة',
      branch: '',
      account: '',
      requesterName: 'مقدم المذكرة',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      documentType: ExpenseDocumentType.internalMemo,
      memoLayout: InternalMemoLayout.fullA4,
    );
    final bytes = await PdfService.buildRequestPdf(request);
    final output = File('/tmp/internal_memo_full_a4_visual_test.pdf');
    await output.writeAsBytes(bytes, flush: true);
    expect(bytes, isNotEmpty);
    expect(await output.exists(), isTrue);
    expect(
      TemplateConfiguration.internalMemoA4(AppSettings.defaults()).isFullPage,
      isTrue,
    );
  });
}
