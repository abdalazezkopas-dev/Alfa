import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/representative_reports/models/representative_report.dart';
import 'package:alfa_expense_app/features/representative_reports/screens/representative_report_form_screen.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('prevents saving when Arabic day conflicts with date', (
    tester,
  ) async {
    final report = RepresentativeReport.empty(
      id: 'form-test',
      date: 'م2026/10/20',
    ).copyWith(day: 'الأحد');
    await tester.pumpWidget(
      MaterialApp(
        home: RepresentativeReportFormScreen(report: report, isNew: true),
      ),
    );
    await tester.pumpAndSettle();

    await tester.scrollUntilVisible(
      find.text('حفظ التقرير'),
      300,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.tap(find.text('حفظ التقرير'));
    await tester.pump();

    expect(find.textContaining('اليوم لا يطابق التاريخ'), findsOneWidget);
    expect(find.byType(RepresentativeReportFormScreen), findsOneWidget);
  });

  testWidgets('prevents preview and export when saved report date conflicts', (
    tester,
  ) async {
    final report = RepresentativeReport.empty(
      id: 'saved-form-test',
      date: 'م2026/10/20',
    ).copyWith(day: 'الأحد');
    await tester.pumpWidget(
      MaterialApp(home: RepresentativeReportFormScreen(report: report)),
    );
    await tester.pumpAndSettle();

    for (final tooltip in ['معاينة PDF', 'طباعة', 'مشاركة PDF']) {
      await tester.tap(find.byTooltip(tooltip));
      await tester.pump();
      expect(find.textContaining('اليوم لا يطابق التاريخ'), findsOneWidget);
    }
    expect(find.text('معاينة تقرير المندوب'), findsNothing);
  });
}
