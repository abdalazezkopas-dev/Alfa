import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/core/security/input_limits.dart';

void main() {
  test('rejects non-finite and out-of-range numbers', () {
    expect(InputLimits.finiteDouble(double.nan), 0);
    expect(InputLimits.finiteDouble(double.infinity), 0);
    expect(InputLimits.finiteDouble(-1), 0);
    expect(InputLimits.integer(-1), 0);
  });

  test('strict helpers reject persisted corruption without truncating', () {
    expect(
      () => InputLimits.strictString('abcd', field: 'name', maxLength: 3),
      throwsA(isA<FormatException>()),
    );
    expect(
      () => InputLimits.strictInteger(1.5, field: 'count'),
      throwsA(isA<FormatException>()),
    );
  });

  test('bounds strings and collections without throwing', () {
    expect(InputLimits.string(42), isEmpty);
    expect(InputLimits.string('abcdef', maxLength: 3), 'abc');
    expect(
      InputLimits.list(List<int>.generate(10, (index) => index), maxLength: 3),
      [0, 1, 2],
    );
  });
}
