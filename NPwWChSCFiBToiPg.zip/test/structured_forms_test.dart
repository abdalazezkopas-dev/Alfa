import 'package:flutter_test/flutter_test.dart';
import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';

void main() {
  test(
    'persists clearance entries and service items without losing legacy fields',
    () {
      const request = ExpenseRequest(
        date: '19/09/2026',
        receiver: 'الإدارة',
        amountNumber: '',
        amountWords: '',
        reason: '',
        statement: '',
        branch: '',
        account: '',
        requesterName: 'مقدم الطلب',
        requesterSignature: '',
        directManagerName: '',
        directManagerSignature: '',
        approvedAuthorityName: '',
        approvedAuthoritySignature: '',
        accountsManagerName: '',
        accountsManagerSignature: '',
        clearanceEntries: [
          ClearanceEntry(
            amount: '1500',
            date: '01/09/2026',
            statement: 'عهدة نقدية',
          ),
        ],
        serviceItems: [
          ServiceItem(name: 'صنف تجريبي', quantity: '2', notes: 'بيان الصنف'),
        ],
      );

      final restored = ExpenseRequest.fromMap(request.toMap());
      expect(restored.receiver, 'الإدارة');
      expect(restored.clearanceEntries.single.amount, '1500');
      expect(restored.serviceItems.single.quantity, '2');
    },
  );

  test('persists the structured form character budget', () {
    final settings = AppSettings.defaults().copyWith(
      maxStructuredDataCharacters: 900,
    );
    final restored = AppSettings.fromMap(settings.toMap());
    expect(restored.maxStructuredDataCharacters, 900);
  });
}
