import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/expense_request/services/request_store.dart';

ExpenseRequest _request(String receiver) {
  return ExpenseRequest(
    date: '26/08/2026',
    receiver: receiver,
    amountNumber: '500',
    amountWords: 'خمسمائة ريال',
    reason: 'اختبار',
    statement: 'بيان الاختبار',
    branch: 'الفرع الرئيسي',
    account: 'الحساب',
    requesterName: '',
    requesterSignature: '',
    directManagerName: '',
    directManagerSignature: '',
    approvedAuthorityName: '',
    approvedAuthoritySignature: '',
    accountsManagerName: '',
    accountsManagerSignature: '',
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('يحدّث النموذج المحفوظ في مكانه', () async {
    SharedPreferences.setMockInitialValues({});
    await RequestStore.saveAll([
      _request('المستلم القديم'),
      _request('الثاني'),
    ]);

    await RequestStore.updateAt(0, _request('المستلم المعدل'));
    final requests = await RequestStore.load();

    expect(requests, hasLength(2));
    expect(requests.first.receiver, 'المستلم المعدل');
    expect(requests.last.receiver, 'الثاني');
  });

  test('يحفظ ويستعيد نموذجين مستقلين من JSON', () {
    final second = _request('المرسل الثاني');
    final first = ExpenseRequest(
      date: '26/08/2026',
      receiver: 'المرسل الأول',
      amountNumber: '1,000',
      amountWords: 'ألف ريالاً',
      reason: '',
      statement: 'البيان الأول',
      branch: '',
      account: '',
      requesterName: 'مقدم أول',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      formCount: 2,
      secondRequest: second,
    );

    final restored = ExpenseRequest.fromMap(
      Map<String, Object?>.from(first.toMap()),
    );
    expect(restored.formCount, 2);
    expect(restored.secondRequest?.receiver, 'المرسل الثاني');
    expect(restored.statement, 'البيان الأول');
  });

  test('يرفض إضافة نموذج مطابق ويمنع تحديث نموذج إلى نسخة مكررة', () async {
    SharedPreferences.setMockInitialValues({});
    final first = _request('مستلم واحد');
    final second = _request('مستلم آخر');
    expect(await RequestStore.add(first), isTrue);
    expect(await RequestStore.add(first), isFalse);
    expect(await RequestStore.add(second), isTrue);
    // add inserts at the front, so the original record is now at index 1.
    expect(await RequestStore.updateAt(1, second), isFalse);
    expect(await RequestStore.load(), hasLength(2));
  });

  test('يرفض الكتابة فوق التخزين عند تلف JSON القديم', () async {
    SharedPreferences.setMockInitialValues({
      'alfa_expense_app.requests.v1': '{"corrupt":true}',
    });

    await expectLater(RequestStore.load(), throwsA(isA<FormatException>()));
    final preferences = await SharedPreferences.getInstance();
    expect(
      preferences.getString('alfa_expense_app.requests.v1'),
      '{"corrupt":true}',
    );
  });
}
