import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/features/product_catalog/data/default_product_catalog.dart';
import 'package:alfa_expense_app/features/product_catalog/models/product_item.dart';
import 'package:alfa_expense_app/features/product_catalog/services/product_catalog_store.dart';

void main() {
  test('product item round-trips without losing fields', () {
    const item = ProductItem(
      id: '1',
      name: 'صنف تجريبي',
      pharmaceuticalForm: 'أقراص',
      strength: '500 mg',
      category: 'مسكنات',
      unit: 'علبة',
      notes: 'ملاحظة',
      isActive: false,
    );
    final restored = ProductItem.fromMap(item.toMap());
    expect(restored.toMap(), item.toMap());
  });

  test('catalog store exposes independent API for product data', () {
    expect(ProductCatalogStore.load, isA<Function>());
    expect(ProductCatalogStore.saveAll, isA<Function>());
  });

  test('default product catalog contains the supplied 47 products', () {
    expect(DefaultProductCatalog.items, hasLength(47));
    expect(DefaultProductCatalog.items.first.name, 'البيكس 200 ملجم 2 قرص');
    expect(
      DefaultProductCatalog.items.where(
        (item) => item.pharmaceuticalForm == 'شراب',
      ),
      hasLength(23),
    );
  });

  test(
    'does not treat a malformed legacy catalog as an empty catalog',
    () async {
      SharedPreferences.setMockInitialValues({
        'alfa_expense_app.product_catalog.v1': '{"broken":true}',
      });

      await expectLater(
        ProductCatalogStore.load(),
        throwsA(isA<FormatException>()),
      );
      final preferences = await SharedPreferences.getInstance();
      expect(
        preferences.getString('alfa_expense_app.product_catalog.v1'),
        '{"broken":true}',
      );
    },
  );
}
