import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/features/calculator/screens/calculator_screen.dart';

void main() {
  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  Future<void> pumpCalculator(WidgetTester tester) async {
    await tester.pumpWidget(const MaterialApp(home: CalculatorScreen()));
    await tester.pumpAndSettle();
  }

  Future<void> tapKey(WidgetTester tester, String key) async {
    await tester.tap(find.widgetWithText(FilledButton, key));
    await tester.pump();
  }

  testWidgets('ينفذ عملية جديدة بعد = ويحافظ على الدقة المعروضة', (
    tester,
  ) async {
    await pumpCalculator(tester);
    for (final key in ['0', '.', '1', '+', '0', '.', '2', '=']) {
      await tapKey(tester, key);
    }
    expect(find.text('0.3'), findsOneWidget);

    await tapKey(tester, '1');
    expect(find.text('1'), findsWidgets);
  });

  testWidgets('يمنع تكرار الفاصلة ويعرض خطأ القسمة على صفر', (tester) async {
    await pumpCalculator(tester);
    for (final key in ['1', '.', '.', '2', '÷', '0', '=']) {
      await tapKey(tester, key);
    }
    expect(find.text('غير صالح'), findsOneWidget);
  });

  testWidgets('يفتح سجل العمليات بعد إجراء ناجح', (tester) async {
    await pumpCalculator(tester);
    for (final key in ['2', '+', '3', '=']) {
      await tapKey(tester, key);
    }
    await tester.tap(find.byTooltip('محفوظات العمليات'));
    await tester.pumpAndSettle();
    expect(find.text('محفوظات العمليات'), findsOneWidget);
    expect(find.text('2+3 = 5'), findsOneWidget);
  });
}
