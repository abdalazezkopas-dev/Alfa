import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/core/theme/app_theme.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';
import 'package:alfa_expense_app/features/product_catalog/models/product_item.dart';
import 'package:alfa_expense_app/features/product_catalog/screens/product_picker_screen.dart';

void main() {
  testWidgets('product picker exposes visible selection actions', (
    tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: ProductPickerScreen(availableProducts: _testProducts),
      ),
    );
    await tester.pump(const Duration(seconds: 2));

    expect(find.byTooltip('إلغاء'), findsOneWidget);
    expect(find.byTooltip('حفظ الاختيار'), findsOneWidget);
    expect(find.text('مسح التحديد'), findsOneWidget);
    expect(find.text('إضافة صنف'), findsOneWidget);
    expect(find.text('تعطيل المحدد'), findsOneWidget);
    expect(find.byType(ListView), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('tapping a product checkbox updates and clears the counter', (
    tester,
  ) async {
    await tester.pumpWidget(
      const MaterialApp(
        home: ProductPickerScreen(availableProducts: _testProducts),
      ),
    );
    await tester.pump(const Duration(seconds: 2));

    final checkbox = find.byType(CheckboxListTile).first;
    expect(checkbox, findsOneWidget);

    await tester.tap(checkbox);
    await tester.pump();
    expect(find.text('المحدد: 1 من 53'), findsOneWidget);
    expect(
      find.byWidgetPredicate(
        (widget) => widget is Checkbox && widget.value == true,
      ),
      findsOneWidget,
    );

    await tester.tap(checkbox);
    await tester.pump();
    expect(find.text('المحدد: 0 من 53'), findsOneWidget);
  });

  testWidgets('first product is positioned directly below the controls', (
    tester,
  ) async {
    final products = List<ProductItem>.generate(
      47,
      (index) => ProductItem(
        id: 'product-$index',
        name: 'صنف اختبار $index',
        pharmaceuticalForm: 'أقراص',
        category: 'اختبار',
      ),
    );
    await tester.pumpWidget(
      MaterialApp(home: ProductPickerScreen(availableProducts: products)),
    );
    await tester.pump();

    expect(find.text('تحديد النتائج (47)'), findsOneWidget);
    final counterText = find.text('المحدد: 0 من 53');
    expect(counterText, findsOneWidget);
    final counterRow = find
        .ancestor(of: counterText, matching: find.byType(Row))
        .first;
    final counterRowBottom = tester.getBottomLeft(counterRow).dy;
    final firstProduct = find.byKey(
      const ValueKey('product-checkbox-product-0'),
    );
    expect(firstProduct, findsOneWidget);
    expect(
      tester.getTopLeft(firstProduct).dy - counterRowBottom,
      inInclusiveRange(0.0, 16.0),
    );

    await tester.drag(find.byType(ListView), const Offset(0, -500));
    await tester.pump();
    await tester.enterText(find.byType(TextField), 'صنف اختبار 0');
    await tester.pump();
    expect(tester.getTopLeft(firstProduct).dy, lessThan(400));
  });

  testWidgets('يقيس أنماط النص والمسافة تحت Theme التطبيق الفعلي', (
    tester,
  ) async {
    const products = [
      ProductItem(
        id: 'typography-audit-product',
        name: 'اسم الصنف العربي',
        pharmaceuticalForm: 'أقراص',
        strength: '10 ملجم',
        category: 'تصنيف تجريبي',
      ),
    ];
    final appTheme = AppTheme.build(AppSettings.defaults());

    await tester.pumpWidget(
      MaterialApp(
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        theme: appTheme,
        home: const ProductPickerScreen(availableProducts: products),
      ),
    );
    await tester.pumpAndSettle();

    final screenContext = tester.element(find.byType(ProductPickerScreen));
    final media = MediaQuery.of(screenContext);
    final theme = Theme.of(screenContext);
    final expectedLetterSpacing = media.letterSpacingOverride ?? 0.0;
    expect(Directionality.of(screenContext), TextDirection.rtl);
    expect(Localizations.localeOf(screenContext), const Locale('ar'));

    debugPrint(
      'قياس النص Product Picker: '
      'MediaQuery.letterSpacingOverride=${media.letterSpacingOverride}, '
      'textScaler=${media.textScaler}, locale=${Localizations.localeOf(screenContext)}, '
      'direction=${Directionality.of(screenContext)}',
    );
    debugPrint(
      'مصادر Theme: fontFamily=${theme.textTheme.bodyLarge?.fontFamily}, '
      'bodyLarge=${theme.textTheme.bodyLarge?.letterSpacing}, '
      'bodyMedium=${theme.textTheme.bodyMedium?.letterSpacing}, '
      'bodySmall=${theme.textTheme.bodySmall?.letterSpacing}, '
      'labelLarge=${theme.textTheme.labelLarge?.letterSpacing}, '
      'listTileTitle=${theme.listTileTheme.titleTextStyle?.letterSpacing}, '
      'listTileSubtitle=${theme.listTileTheme.subtitleTextStyle?.letterSpacing}, '
      'inputLabel=${theme.inputDecorationTheme.labelStyle?.letterSpacing}, '
      'outlinedButton=${theme.outlinedButtonTheme.style?.textStyle?.resolve({})?.letterSpacing}, '
      'appFilledButtonMinWidth=${appTheme.filledButtonTheme.style?.minimumSize?.resolve({})?.width}',
    );

    void reportRenderedText(String label, Finder finder) {
      expect(finder, findsOneWidget);
      final paragraph = tester.renderObject<RenderParagraph>(finder);
      final textWidget = tester.widget<Text>(finder);
      final textContext = tester.element(finder);
      final style = paragraph.text.style;
      expect(style?.letterSpacing, expectedLetterSpacing);
      debugPrint(
        'قياس $label: effectiveLetterSpacing=${style?.letterSpacing}, '
        'effectiveFontFamily=${style?.fontFamily}, '
        'effectiveFontFamilyFallback=${style?.fontFamilyFallback}, '
        'direction=${paragraph.textDirection}, locale=${paragraph.locale}, '
        'explicitTextStyle=${textWidget.style}, '
        'inheritedDefaultTextStyle=${DefaultTextStyle.of(textContext).style}',
      );
    }

    reportRenderedText('اسم الصنف', find.text('اسم الصنف العربي'));
    reportRenderedText(
      'subtitle الصنف',
      find.text('أقراص — 10 ملجم — تصنيف تجريبي'),
    );
    reportRenderedText('زر تحديد النتائج', find.text('تحديد النتائج (1)'));
    reportRenderedText('زر مسح التحديد', find.text('مسح التحديد'));
    reportRenderedText(
      'تسمية البحث',
      find.text('ابحث باسم الصنف أو الشكل أو التصنيف'),
    );

    final editableFinder = find.byType(EditableText);
    expect(editableFinder, findsOneWidget);
    final editable = tester.widget<EditableText>(editableFinder);
    final editableState = tester.state<EditableTextState>(editableFinder);
    final renderEditable = editableState.renderEditable;
    expect(editable.style.letterSpacing, expectedLetterSpacing);
    debugPrint(
      'قياس نص البحث: RenderEditableSpanStyle=${renderEditable.text?.style}, '
      'EditableText effectiveLetterSpacing=${editable.style.letterSpacing}, '
      'effectiveFontFamily=${editable.style.fontFamily}, '
      'fontFamilyFallback=${editable.style.fontFamilyFallback}, '
      'direction=${renderEditable.textDirection}, locale=${editable.locale ?? Localizations.localeOf(screenContext)}',
    );

    final counterRow = find
        .ancestor(of: find.text('المحدد: 0 من 53'), matching: find.byType(Row))
        .first;
    final firstProduct = find.byKey(
      const ValueKey('product-checkbox-typography-audit-product'),
    );
    final firstCard = find
        .ancestor(of: firstProduct, matching: find.byType(Card))
        .first;
    final counterBottom = tester.getBottomLeft(counterRow).dy;
    final firstProductTop = tester.getTopLeft(firstCard).dy;
    final verticalGap = firstProductTop - counterBottom;
    debugPrint(
      'قياس المسافة تحت Theme التطبيق: counter bottom Y=$counterBottom, '
      'first product card top Y=$firstProductTop, vertical gap=$verticalGap',
    );

    expect(verticalGap, inInclusiveRange(0.0, 16.0));
    expect(tester.takeException(), isNull);
  });

  testWidgets('يحترم Product Picker تباعد الحروف الذي يفرضه النظام', (
    tester,
  ) async {
    const systemLetterSpacing = 1.25;
    await tester.pumpWidget(
      MaterialApp(
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: GlobalMaterialLocalizations.delegates,
        theme: AppTheme.build(AppSettings.defaults()),
        home: Builder(
          builder: (context) {
            final media = MediaQuery.of(context);
            return MediaQuery(
              data: media.applyTextStyleOverrides(
                lineHeightScaleFactorOverride:
                    media.lineHeightScaleFactorOverride,
                letterSpacingOverride: systemLetterSpacing,
                wordSpacingOverride: media.wordSpacingOverride,
                paragraphSpacingOverride: media.paragraphSpacingOverride,
              ),
              child: const ProductPickerScreen(
                availableProducts: _testProducts,
              ),
            );
          },
        ),
      ),
    );
    await tester.pumpAndSettle();

    final productName = tester.renderObject<RenderParagraph>(
      find.text('صنف اختبار'),
    );
    expect(productName.text.style?.letterSpacing, systemLetterSpacing);
    final selectButton = tester.renderObject<RenderParagraph>(
      find.text('تحديد النتائج (1)'),
    );
    expect(selectButton.text.style?.letterSpacing, systemLetterSpacing);
    final searchState = tester.state<EditableTextState>(
      find.byType(EditableText),
    );
    expect(
      searchState.renderEditable.text?.style?.letterSpacing,
      systemLetterSpacing,
    );
    expect(tester.takeException(), isNull);
  });

  testWidgets('تحميل دليل الأصناف من المخزن يعرض الأصناف المتاحة', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    const secureStorageChannel = MethodChannel(
      'plugins.it_nomads.com/flutter_secure_storage',
    );
    final secureStorage = <String, String>{};
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(secureStorageChannel, (call) async {
          final arguments = call.arguments as Map<dynamic, dynamic>;
          final key = arguments['key'] as String?;
          switch (call.method) {
            case 'read':
              return secureStorage[key];
            case 'write':
              secureStorage[key!] = arguments['value'] as String;
              return null;
            default:
              return null;
          }
        });
    addTearDown(
      () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(secureStorageChannel, null),
    );

    await tester.pumpWidget(const MaterialApp(home: ProductPickerScreen()));
    await tester.pumpAndSettle();

    expect(find.text('تحديد النتائج (47)'), findsOneWidget);
    expect(find.text('البيكس 200 ملجم 2 قرص'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('تعذر قراءة دليل الأصناف يعرض خطأ قابلًا لإعادة المحاولة', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({
      'alfa_expense_app.product_catalog.v1': '{"broken":true}',
    });
    await tester.pumpWidget(const MaterialApp(home: ProductPickerScreen()));
    await tester.pumpAndSettle();

    expect(find.text('تعذر تحميل دليل الأصناف'), findsOneWidget);
    expect(find.text('إعادة المحاولة'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('تنتهي مهلة التحميل بعد عشر ثوانٍ وتظهر إعادة المحاولة', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    const secureStorageChannel = MethodChannel(
      'plugins.it_nomads.com/flutter_secure_storage',
    );
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(
          secureStorageChannel,
          (_) => Completer<Object?>().future,
        );
    addTearDown(
      () => TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
          .setMockMethodCallHandler(secureStorageChannel, null),
    );

    await tester.pumpWidget(const MaterialApp(home: ProductPickerScreen()));
    await tester.pump();
    expect(find.byType(CircularProgressIndicator), findsOneWidget);

    await tester.pump(const Duration(seconds: 10));
    await tester.pump();

    expect(find.text('تعذر تحميل دليل الأصناف'), findsOneWidget);
    expect(find.text('إعادة المحاولة'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}

const _testProducts = [
  ProductItem(
    id: 'test-product-1',
    name: 'صنف اختبار',
    pharmaceuticalForm: 'أقراص',
    strength: '10 ملجم',
    category: 'اختبار',
  ),
];
