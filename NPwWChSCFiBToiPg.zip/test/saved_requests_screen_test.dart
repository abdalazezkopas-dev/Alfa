import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/requests/screens/saved_requests_screen.dart';
import 'package:alfa_expense_app/features/travel_allowance/models/travel_allowance_request.dart';

ExpenseRequest _request({
  required ExpenseDocumentType documentType,
  required String receiver,
  Map<String, String> customFields = const {},
}) {
  return ExpenseRequest(
    date: '07/10/2026',
    receiver: receiver,
    amountNumber: '',
    amountWords: '',
    reason: '',
    statement: 'اختبار شاشة المستندات السابقة',
    branch: '',
    account: '',
    requesterName: 'مقدم الاختبار',
    requesterSignature: '',
    directManagerName: '',
    directManagerSignature: '',
    approvedAuthorityName: '',
    approvedAuthoritySignature: '',
    accountsManagerName: '',
    accountsManagerSignature: '',
    documentType: documentType,
    customFields: customFields,
    sampleItems: documentType == ExpenseDocumentType.sampleRequest
        ? const [
            SampleItem(
              productId: 'sample-1',
              productName: 'صنف اختبار',
              quantityNumber: '1',
            ),
          ]
        : const [],
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  TravelAllowanceRequest travelRequest(
    String beneficiary, {
    String branch = 'فرع الاختبار',
  }) => TravelAllowanceRequest(
    branch: branch,
    month: 'أكتوبر',
    year: '2026',
    beneficiary: beneficiary,
    rows: const [
      TravelAllowanceRow(day: '1', date: '01/10/2026', dailyAmount: '25'),
    ],
  );

  testWidgets('يعرض أزرار إعدادات ومعاينة وتحرير مواضع نموذج العينات فقط', (
    tester,
  ) async {
    final requests = [
      _request(
        documentType: ExpenseDocumentType.sampleRequest,
        receiver: 'جهة العينات',
        customFields: const {'sampleTemplate': 'singlePage'},
      ),
      _request(
        documentType: ExpenseDocumentType.expenseRequest,
        receiver: 'جهة طلب الصرف',
      ),
    ];

    await tester.pumpWidget(
      MaterialApp(
        home: SavedRequestsScreen(
          expenseRequestsLoader: () async => requests,
          travelAllowanceLoader: () async => const [],
        ),
      ),
    );
    await tester.pump(const Duration(seconds: 2));

    expect(find.text('جهة العينات'), findsOneWidget);
    expect(find.text('جهة طلب الصرف'), findsOneWidget);
    expect(find.byTooltip('إعدادات نموذج طلب العينات'), findsOneWidget);
    expect(find.byTooltip('معاينة نموذج طلب العينات'), findsOneWidget);
    expect(find.byTooltip('تحرير مواضع نموذج طلب العينات'), findsOneWidget);
  });

  testWidgets('يعرض طلب بدل السفر المحفوظ ويفتح مسار تعديله', (tester) async {
    const travelRequest = TravelAllowanceRequest(
      branch: 'فرع الاختبار',
      month: 'أكتوبر',
      year: '2026',
      beneficiary: 'مستفيد الاختبار',
      rows: [
        TravelAllowanceRow(day: '1', date: '01/10/2026', dailyAmount: '25'),
      ],
    );
    await tester.pumpWidget(
      MaterialApp(
        home: SavedRequestsScreen(
          expenseRequestsLoader: () async => const [],
          travelAllowanceLoader: () async => const [travelRequest],
        ),
      ),
    );
    await tester.pump(const Duration(seconds: 2));

    expect(find.text('مستفيد الاختبار'), findsOneWidget);
    expect(find.textContaining('فرع الاختبار'), findsOneWidget);
    expect(find.byTooltip('تعديل طلب بدل السفر'), findsOneWidget);
    expect(find.byTooltip('معاينة طلب بدل السفر'), findsOneWidget);
  });

  testWidgets('يحرر طلب بدل السفر المطابق للبحث لا أول طلب في القائمة', (
    tester,
  ) async {
    final firstRequest = travelRequest('مستفيد أول', branch: 'فرع أول');
    final matchingRequest = travelRequest(
      'المستفيد المطابق',
      branch: 'فرع مطابق',
    );
    await tester.pumpWidget(
      MaterialApp(
        home: SavedRequestsScreen(
          expenseRequestsLoader: () async => const [],
          travelAllowanceLoader: () async => [firstRequest, matchingRequest],
        ),
      ),
    );
    await tester.pumpAndSettle();

    await tester.enterText(find.byType(TextField).first, 'المستفيد المطابق');
    await tester.pumpAndSettle();
    expect(find.text('المستفيد المطابق'), findsNWidgets(2));
    expect(find.text('مستفيد أول'), findsNothing);

    await tester.tap(find.byTooltip('تعديل طلب بدل السفر'));
    await tester.pumpAndSettle();

    final formValues = tester
        .widgetList<TextFormField>(find.byType(TextFormField))
        .map((field) => field.controller?.text)
        .toList();
    expect(formValues, contains('فرع مطابق'));
    expect(formValues, isNot(contains('فرع أول')));
  });

  testWidgets('يحذف طلب بدل السفر المطابق للبحث ويبقي الطلب الآخر', (
    tester,
  ) async {
    final firstRequest = travelRequest('مستفيد أول');
    final matchingRequest = travelRequest('المستفيد المطابق');
    final requests = [firstRequest, matchingRequest];
    int? deletedIndex;

    await tester.pumpWidget(
      MaterialApp(
        home: SavedRequestsScreen(
          expenseRequestsLoader: () async => const [],
          travelAllowanceLoader: () async => requests,
          travelAllowanceDeleteAt: (index) async {
            deletedIndex = index;
            requests.removeAt(index);
          },
        ),
      ),
    );
    await tester.pumpAndSettle();

    await tester.enterText(find.byType(TextField).first, 'المستفيد المطابق');
    await tester.pumpAndSettle();
    expect(find.text('المستفيد المطابق'), findsNWidgets(2));
    expect(find.text('مستفيد أول'), findsNothing);

    await tester.tap(find.byTooltip('حذف'));
    await tester.pumpAndSettle();
    await tester.tap(find.widgetWithText(FilledButton, 'حذف'));
    await tester.pumpAndSettle();

    expect(deletedIndex, 1);
    expect(requests, hasLength(1));
    expect(requests.single.beneficiary, 'مستفيد أول');
    await tester.enterText(find.byType(TextField).first, '');
    await tester.pumpAndSettle();
    expect(find.text('مستفيد أول'), findsOneWidget);
  });
}
