import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:alfa_expense_app/core/id_generator.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  test('ينشئ معرفات متسلسلة وغير مكررة', () async {
    SharedPreferences.setMockInitialValues({});
    final first = await IdGenerator.next('test');
    final second = await IdGenerator.next('test');
    expect(second, first + 1);
    expect(second, isNot(first));
  });
}
