import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/expense_request/services/pdf_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test(
    'internal memo PDF uses memo document type and renders one A4 page',
    () async {
      final top = ExpenseRequest(
        date: '2026/09/05',
        receiver: 'المقدم إليه العلوي',
        amountNumber: '',
        amountWords: '',
        reason: '',
        statement: 'بيان المذكرة العلوية',
        branch: '',
        account: '',
        requesterName: 'مقدم الطلب العلوي',
        requesterSignature: '',
        directManagerName: '',
        directManagerSignature: '',
        approvedAuthorityName: '',
        approvedAuthoritySignature: '',
        accountsManagerName: '',
        accountsManagerSignature: '',
        documentType: ExpenseDocumentType.internalMemo,
        formCount: 2,
        secondRequest: ExpenseRequest(
          date: '2026/09/06',
          receiver: 'المقدم إليه السفلي',
          amountNumber: '',
          amountWords: '',
          reason: '',
          statement: 'بيان المذكرة السفلية',
          branch: '',
          account: '',
          requesterName: 'مقدم الطلب السفلي',
          requesterSignature: '',
          directManagerName: '',
          directManagerSignature: '',
          approvedAuthorityName: '',
          approvedAuthoritySignature: '',
          accountsManagerName: '',
          accountsManagerSignature: '',
          documentType: ExpenseDocumentType.internalMemo,
        ),
      );

      final bytes = await PdfService.buildRequestPdf(top);
      expect(bytes, isNotEmpty);
      final output = File('/tmp/internal_memo_visual_test.pdf');
      await output.writeAsBytes(bytes, flush: true);
      expect(await output.exists(), isTrue);
    },
  );
}
