import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/expense_request/services/pdf_service.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('customer application renders the official customer template', () async {
    final request = ExpenseRequest(
      date: '09/09/2026',
      receiver: 'مدير المبيعات المحترم',
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: 'البيان الرسمي الأول',
      branch: '',
      account: '',
      requesterName: 'مقدم الطلب',
      requesterSignature: '',
      directManagerName: 'مدير الفرع',
      directManagerSignature: '',
      approvedAuthorityName: 'محاسب الفرع',
      approvedAuthoritySignature: '',
      accountsManagerName: 'مدير المبيعات',
      accountsManagerSignature: '',
      documentType: ExpenseDocumentType.customerApplication,
      settingsSnapshot: AppSettings.defaults().toMap(),
      customFields: const {
        'date': '09/09/2026',
        'exceptionType': 'أخرى',
        'otherDetails': 'طلب دعم خاص للعميل',
        'receiver': 'مدير المبيعات المحترم',
        'customer': 'شركة تجريبية',
        'branch': 'الفرع',
        'customerType': 'جديد',
        'statementOne': 'البيان الأول',
        'statementTwo': 'وعليه نرجو منكم الاعتماد',
        'requester': 'مقدم الطلب',
        'branchManager': 'مدير الفرع - اختبار',
        'branchAccountant': 'محاسب الفرع - اختبار',
        'salesManager': 'مدير الحسابات - اختبار',
      },
    );
    final bytes = await PdfService.buildRequestPdf(
      request,
      settings: AppSettings.defaults(),
    );
    expect(bytes, isNotEmpty);

    final longBranchRequest = ExpenseRequest.fromMap({
      ...request.toMap(),
      'customFields': {
        ...request.customFields,
        'branch': 'فرع صنعاء الرئيسي - منطقة التحرير',
      },
    });
    final longBranchBytes = await PdfService.buildRequestPdf(
      longBranchRequest,
      settings: AppSettings.defaults(),
    );
    expect(longBranchBytes, isNotEmpty);

    final output = File('/tmp/customer_application_visual_test.pdf');
    await output.writeAsBytes(bytes, flush: true);
    expect(await output.exists(), isTrue);
  });
}
