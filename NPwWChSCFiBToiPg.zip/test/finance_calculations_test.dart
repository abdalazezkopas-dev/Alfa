import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/finance/models/finance_calculations.dart';
import 'package:alfa_expense_app/features/finance/screens/finance_screens.dart';

void main() {
  test(
    'monthly installment divides the amount across the requested months',
    () {
      final calculation = AdvanceCalculation(
        amount: 12000,
        type: 'مساعدة',
        reason: '',
        startDate: DateTime(2026, 9, 1),
        months: 12,
        frequency: 'monthly',
      );

      expect(calculation.installment, 1000);
      expect(calculation.installmentCount, 12);
      expect(calculation.schedule, hasLength(12));
      expect(calculation.schedule.first.amount, 1000);
      expect(calculation.schedule.first.remaining, 11000);
      expect(calculation.schedule.last.amount, 1000);
      expect(calculation.schedule.last.remaining, 0);
      expect(calculation.schedule[1].date, DateTime(2026, 10, 1));
    },
  );

  test('permanent advance uses monthly deductions', () {
    final calculation = AdvanceCalculation(
      amount: 12000,
      type: 'سلفة دائمة',
      reason: '',
      startDate: DateTime(2026, 9, 1),
      months: 12,
      frequency: 'monthly',
    );

    expect(calculation.frequency, 'monthly');
    expect(calculation.installmentCount, 12);
    expect(calculation.installment, 1000);
  });

  testWidgets('screen displays the correct monthly installment and schedule', (
    tester,
  ) async {
    await tester.pumpWidget(const MaterialApp(home: AdvanceCalculatorScreen()));
    await tester.pumpAndSettle();

    final fields = find.byType(TextField);
    expect(fields, findsNWidgets(2));
    await tester.enterText(fields.at(0), '12000');
    await tester.enterText(fields.at(1), '12');
    await tester.tap(find.text('احتساب'));
    await tester.pumpAndSettle();

    expect(find.text('قسط الخصم: 1000.00 شهريًا'), findsOneWidget);
    expect(find.text('السلف المحفوظة'), findsNothing);
    expect(find.byType(DataTable), findsOneWidget);
  });
}
