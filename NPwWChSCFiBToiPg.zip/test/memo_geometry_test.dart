import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/core/memo_geometry.dart';

void main() {
  test('uses the real A4 portrait geometry', () {
    expect(MemoGeometry.a4Width, closeTo(595.28, 0.001));
    expect(MemoGeometry.a4Height, closeTo(841.89, 0.001));
  });

  test('allows fields at Y 600, 700, and 780 when they fit', () {
    for (final y in [600.0, 700.0, 780.0]) {
      expect(MemoGeometry.clampY(y, 40), closeTo(y, 0.001));
    }
  });

  test('clamps oversized fields inside the A4 page', () {
    expect(MemoGeometry.clampX(-20, 120), 0);
    expect(MemoGeometry.clampX(590, 120), closeTo(475.28, 0.001));
    expect(MemoGeometry.clampY(-20, 40), 0);
    expect(MemoGeometry.clampY(830, 40), closeTo(801.89, 0.001));
  });
}
