import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/reports/services/report_service.dart';
import 'package:alfa_expense_app/features/settings/models/app_settings.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  const oneForm = ExpenseRequest(
    date: '01/08/2026',
    receiver: 'مدير الحسابات',
    amountNumber: '١٬٢٥٠',
    amountWords: 'ألف ومائتان وخمسون ريال',
    reason: '',
    statement: 'شراء مواد مكتبية',
    branch: '',
    account: '',
    requesterName: 'أحمد محمد',
    requesterSignature: '',
    directManagerName: '',
    directManagerSignature: '',
    approvedAuthorityName: '',
    approvedAuthoritySignature: '',
    accountsManagerName: '',
    accountsManagerSignature: '',
  );
  const secondForm = ExpenseRequest(
    date: '05/08/2026',
    receiver: 'مدير المبيعات',
    amountNumber: '300',
    amountWords: 'ثلاثمائة ريال',
    reason: '',
    statement: 'شراء مواد غذائية',
    branch: '',
    account: '',
    requesterName: 'سعيد علي',
    requesterSignature: '',
    directManagerName: '',
    directManagerSignature: '',
    approvedAuthorityName: '',
    approvedAuthoritySignature: '',
    accountsManagerName: '',
    accountsManagerSignature: '',
  );
  const secondCopy = ExpenseRequest(
    date: '05/08/2026',
    receiver: 'مدير المبيعات',
    amountNumber: '200',
    amountWords: 'مائتا ريال',
    reason: '',
    statement: 'مواد غذائية للنموذج الثاني',
    branch: '',
    account: '',
    requesterName: 'سعيد علي',
    requesterSignature: '',
    directManagerName: '',
    directManagerSignature: '',
    approvedAuthorityName: '',
    approvedAuthoritySignature: '',
    accountsManagerName: '',
    accountsManagerSignature: '',
  );
  const laterForm = ExpenseRequest(
    date: '10/09/2026',
    receiver: 'مدير مجلس الإدارة',
    amountNumber: '50',
    amountWords: 'خمسون ريال',
    reason: '',
    statement: 'صيانة',
    branch: '',
    account: '',
    requesterName: 'خالد حسن',
    requesterSignature: '',
    directManagerName: '',
    directManagerSignature: '',
    approvedAuthorityName: '',
    approvedAuthoritySignature: '',
    accountsManagerName: '',
    accountsManagerSignature: '',
  );

  final requests = [
    oneForm,
    secondForm.copyWithForTest(secondRequest: secondCopy),
    laterForm,
  ];

  test('يفلتر الفترة والبيان ونوع النموذج', () {
    final result = ReportService.filterAndSort(
      requests,
      ReportFilter(
        from: DateTime(2026, 8, 1),
        to: DateTime(2026, 8, 31),
        statementKeyword: 'غذائية',
        formFilter: ReportFormFilter.two,
      ),
    );

    expect(result, hasLength(1));
    expect(result.single.requesterName, 'سعيد علي');
    expect(ReportService.totalAmount(result.single), 500);
  });

  test('ينشئ تقرير PDF عربياً من النتائج المفلترة', () async {
    final bytes = await ReportPdfService.buildReport(
      requests: requests,
      filter: const ReportFilter(),
      settings: AppSettings.defaults(),
    );

    expect(bytes, isNotEmpty);
    expect(bytes.sublist(0, 4), orderedEquals([37, 80, 68, 70]));
  });

  test('يرتب بالمبلغ تصاعدياً وتنازلياً ويقرأ الأرقام العربية', () {
    final ascending = ReportService.filterAndSort(
      requests,
      const ReportFilter(
        sortField: ReportSortField.amount,
        ascending: true,
        formFilter: ReportFormFilter.one,
      ),
    );
    final descending = ReportService.filterAndSort(
      requests,
      const ReportFilter(
        sortField: ReportSortField.amount,
        ascending: false,
        formFilter: ReportFormFilter.one,
      ),
    );

    expect(ascending.map(ReportService.totalAmount), [50, 1250]);
    expect(descending.map(ReportService.totalAmount), [1250, 50]);
  });
}

extension on ExpenseRequest {
  ExpenseRequest copyWithForTest({ExpenseRequest? secondRequest}) {
    return ExpenseRequest(
      date: date,
      receiver: receiver,
      amountNumber: amountNumber,
      amountWords: amountWords,
      reason: reason,
      statement: statement,
      branch: branch,
      account: account,
      requesterName: requesterName,
      requesterSignature: requesterSignature,
      directManagerName: directManagerName,
      directManagerSignature: directManagerSignature,
      approvedAuthorityName: approvedAuthorityName,
      approvedAuthoritySignature: approvedAuthoritySignature,
      accountsManagerName: accountsManagerName,
      accountsManagerSignature: accountsManagerSignature,
      formCount: secondRequest == null ? formCount : 2,
      secondRequest: secondRequest ?? this.secondRequest,
    );
  }
}
