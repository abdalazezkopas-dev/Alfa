import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

import 'package:alfa_expense_app/features/expense_request/models/expense_request.dart';
import 'package:alfa_expense_app/features/sample_request/screens/sample_request_single_page_screen.dart';
import 'package:alfa_expense_app/features/sample_request/screens/sample_request_three_page_screen.dart';
import 'package:alfa_expense_app/features/sample_request/services/sample_request_validator.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  test('sample request round-trips selected products and quantities', () {
    const request = ExpenseRequest(
      date: '01/10/2026',
      receiver: 'الجهة المستلمة',
      amountNumber: '',
      amountWords: '',
      reason: 'تسويقية',
      statement: 'ملاحظات الطلب',
      branch: '',
      account: '',
      requesterName: 'مقدم الطلب',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      documentType: ExpenseDocumentType.sampleRequest,
      customFields: {'sampleUsage': 'تسويقية'},
      sampleItems: [
        SampleItem(
          productId: 'p1',
          productName: 'صنف 1',
          pharmaceuticalForm: 'أقراص',
          quantityNumber: '2',
          quantityWords: 'اثنان',
          notes: 'ملاحظة',
        ),
      ],
    );
    final restored = ExpenseRequest.fromMap(request.toMap());
    expect(restored.documentType, ExpenseDocumentType.sampleRequest);
    expect(restored.sampleItems, hasLength(1));
    expect(restored.sampleItems.single.quantityNumber, '2');
    expect(restored.sampleItems.single.notes, 'ملاحظة');
  });

  test('sample request without items is rejected by screen contract', () {
    const request = ExpenseRequest(
      date: '01/10/2026',
      receiver: 'الجهة المستلمة',
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: '',
      branch: '',
      account: '',
      requesterName: 'مقدم الطلب',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      documentType: ExpenseDocumentType.sampleRequest,
    );
    expect(request.sampleItems, isEmpty);
  });

  test('validates positive Arabic and Persian integer quantities', () {
    expect(SampleRequestValidator.quantity('١٢').normalizedValue, '12');
    expect(SampleRequestValidator.quantity('۱۲').normalizedValue, '12');
    expect(SampleRequestValidator.quantity('0').isValid, isFalse);
    expect(SampleRequestValidator.quantity('-1').isValid, isFalse);
    expect(SampleRequestValidator.quantity('1.5').isValid, isFalse);
  });

  test('rejects impossible dates instead of DateTime normalization', () {
    expect(SampleRequestValidator.date('31/02/2026').isValid, isFalse);
    expect(SampleRequestValidator.date('01/10/2026').isValid, isTrue);
  });

  testWidgets('sample request screen renders its first step', (tester) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(
      const MaterialApp(home: SampleRequestThreePageScreen()),
    );
    await tester.pumpAndSettle();

    expect(find.text('البيانات العامة'), findsWidgets);
    expect(find.widgetWithText(TextFormField, 'التاريخ'), findsOneWidget);
    expect(find.byType(PdfPreview), findsNothing);

    await tester.pumpWidget(const SizedBox.shrink());
    await tester.pump();
  });

  testWidgets(
    'mobile sample request toolbar exposes direct actions beside menu',
    (tester) async {
      SharedPreferences.setMockInitialValues({});
      tester.view
        ..physicalSize = const Size(390, 844)
        ..devicePixelRatio = 1.0;
      addTearDown(() {
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
      });

      await tester.pumpWidget(
        const MaterialApp(home: SampleRequestThreePageScreen()),
      );
      await tester.pumpAndSettle();

      expect(find.byTooltip('إعدادات النموذج'), findsOneWidget);
      expect(find.byTooltip('معاينة PDF'), findsOneWidget);
      expect(find.byTooltip('تحرير وضبط مواضع الخانات'), findsOneWidget);
      expect(find.byTooltip('عمليات نموذج طلب العينات'), findsOneWidget);
    },
  );

  testWidgets(
    'required field is focused and highlighted after validation fails',
    (tester) async {
      SharedPreferences.setMockInitialValues({});
      await tester.pumpWidget(
        const MaterialApp(home: SampleRequestThreePageScreen()),
      );
      await tester.pumpAndSettle();

      await tester.tap(find.byTooltip('طباعة PDF'));
      await tester.pump();

      final receiver = find.byType(TextFormField).at(1);
      final receiverEditable = find.descendant(
        of: receiver,
        matching: find.byType(EditableText),
      );
      expect(
        tester.widget<EditableText>(receiverEditable).focusNode.hasFocus,
        isTrue,
      );
      final receiverDecorator = find.descendant(
        of: receiver,
        matching: find.byType(InputDecorator),
      );
      expect(
        tester.widget<InputDecorator>(receiverDecorator).decoration.fillColor,
        isNotNull,
      );
      expect(find.text('الجهة مطلوبة'), findsOneWidget);
    },
  );

  testWidgets('optional requester does not block the general sample step', (
    tester,
  ) async {
    const request = ExpenseRequest(
      date: '23/10/2026',
      receiver: 'الجهة المستلمة',
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: '',
      branch: '',
      account: '',
      requesterName: '',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      documentType: ExpenseDocumentType.sampleRequest,
    );
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(
      const MaterialApp(
        home: SampleRequestThreePageScreen(initialRequest: request),
      ),
    );
    await tester.pumpAndSettle();

    await tester.tap(find.text('التالي'));
    await tester.pumpAndSettle();

    expect(tester.widget<Stepper>(find.byType(Stepper)).currentStep, 1);
    expect(find.text('مقدم الطلب مطلوب'), findsNothing);
  });

  testWidgets('three-page screen has a fixed template with no type selector', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(
      const MaterialApp(home: SampleRequestThreePageScreen()),
    );
    await tester.pumpAndSettle();

    expect(find.byType(SampleRequestThreePageScreen), findsOneWidget);
    expect(find.text('نوع نموذج طلب العينات'), findsNothing);
    expect(find.text('البيانات العامة'), findsWidgets);
  });

  testWidgets(
    'automatic quantity fills selected items and leaves them editable',
    (tester) async {
      const request = ExpenseRequest(
        date: '01/10/2026',
        receiver: 'الجهة المستلمة',
        amountNumber: '',
        amountWords: '',
        reason: '',
        statement: '',
        branch: '',
        account: '',
        requesterName: 'مقدم الطلب',
        requesterSignature: '',
        directManagerName: '',
        directManagerSignature: '',
        approvedAuthorityName: '',
        approvedAuthoritySignature: '',
        accountsManagerName: '',
        accountsManagerSignature: '',
        documentType: ExpenseDocumentType.sampleRequest,
        sampleItems: [
          SampleItem(
            productId: 'p1',
            productName: 'صنف 1',
            pharmaceuticalForm: 'أقراص',
          ),
          SampleItem(
            productId: 'p2',
            productName: 'صنف 2',
            pharmaceuticalForm: 'شراب',
          ),
        ],
      );
      SharedPreferences.setMockInitialValues({});
      await tester.pumpWidget(
        const MaterialApp(
          home: SampleRequestThreePageScreen(initialRequest: request),
        ),
      );
      await tester.pumpAndSettle();

      await tester.tap(find.text('التالي'));
      await tester.pumpAndSettle();
      await tester.tap(find.byTooltip('اختيار الكمية التلقائية'));
      await tester.pumpAndSettle();
      await tester.tap(find.text('30').last);
      await tester.pump();

      final quantities = tester
          .widgetList<TextField>(find.byType(TextField))
          .where((field) => field.controller?.text == '30');
      expect(quantities, hasLength(2));
    },
  );

  testWidgets('single-page screen has a fixed template with no type selector', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(
      const MaterialApp(home: SampleRequestSinglePageScreen()),
    );
    await tester.pumpAndSettle();

    expect(find.byType(SampleRequestSinglePageScreen), findsOneWidget);
    expect(find.text('نوع نموذج طلب العينات'), findsNothing);
    expect(find.text('البيانات العامة'), findsWidgets);
  });

  testWidgets('sample request shows a visible loading scaffold immediately', (
    tester,
  ) async {
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(
      const MaterialApp(home: SampleRequestThreePageScreen()),
    );

    expect(find.byType(Scaffold), findsOneWidget);
    expect(find.text('جاري تجهيز نموذج طلب العينات...'), findsOneWidget);
    expect(tester.takeException(), isNull);
    await tester.pump(const Duration(seconds: 13));
  });

  testWidgets('invalid restored sample usage does not blank the screen', (
    tester,
  ) async {
    const request = ExpenseRequest(
      date: '01/10/2026',
      receiver: '',
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: '',
      branch: '',
      account: '',
      requesterName: '',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      documentType: ExpenseDocumentType.sampleRequest,
      customFields: {'sampleUsage': 'قيمة قديمة غير مدعومة'},
    );
    SharedPreferences.setMockInitialValues({});
    await tester.pumpWidget(
      const MaterialApp(
        home: SampleRequestThreePageScreen(initialRequest: request),
      ),
    );
    final dropdownFinder = find.byWidgetPredicate(
      (widget) => widget is DropdownButtonFormField<String>,
    );
    for (var i = 0; i < 70 && !tester.any(dropdownFinder); i++) {
      await tester.pump(const Duration(milliseconds: 100));
    }

    expect(tester.takeException(), isNull);
    expect(dropdownFinder, findsOneWidget);
    expect(find.text('تسويقية'), findsAtLeastNWidgets(1));
  });

  testWidgets(
    'sample request remains renderable on a narrow viewport with text scaling',
    (tester) async {
      SharedPreferences.setMockInitialValues({});
      tester.view
        ..physicalSize = const Size(320, 700)
        ..devicePixelRatio = 1.0;
      addTearDown(() {
        tester.view.resetPhysicalSize();
        tester.view.resetDevicePixelRatio();
      });

      await tester.pumpWidget(
        MediaQuery(
          data: const MediaQueryData(textScaler: TextScaler.linear(1.3)),
          child: const MaterialApp(home: SampleRequestThreePageScreen()),
        ),
      );
      await tester.pump(const Duration(seconds: 12));

      expect(tester.takeException(), isNull);
      expect(find.byType(Scaffold), findsOneWidget);
    },
  );
}
