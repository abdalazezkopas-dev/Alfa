import 'package:flutter_test/flutter_test.dart';

import 'package:alfa_expense_app/features/settings/models/app_settings.dart';
import 'package:alfa_expense_app/features/travel_allowance/models/travel_allowance_request.dart';
import 'package:alfa_expense_app/features/travel_allowance/services/travel_allowance_pdf_service.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  test('يحافظ نموذج بدل السفر على عشرة صفوف ويحسب الإجماليات', () {
    final request = TravelAllowanceRequest(
      rows: [
        const TravelAllowanceRow(date: '01/10/2026', dailyAmount: '25'),
        const TravelAllowanceRow(date: '02/10/2026', dailyAmount: '1,030'),
      ],
    );
    expect(request.totalDays, 2);
    expect(request.totalAmount, 1055);
    final restored = TravelAllowanceRequest.fromMap(request.toMap());
    expect(restored.rows.length, 2);
    expect(restored.totalAmount, 1055);
  });

  test('ينشئ PDF بدل السفر الأفقي', () async {
    final bytes = await TravelAllowancePdfService.build(
      const TravelAllowanceRequest(
        branch: 'الفرع',
        month: 'أكتوبر',
        year: '2026',
        rows: [
          TravelAllowanceRow(day: '1', date: '01/10/2026', dailyAmount: '25'),
        ],
      ),
    );
    expect(bytes, isNotEmpty);
    expect(bytes.take(4).toList(), <int>[37, 80, 68, 70]);
  });

  test('يقبل PDF إعدادات المواضع والألوان الخاصة ببدل السفر', () async {
    final defaults = AppSettings.defaultsForScope('travelAllowance');
    final fields = Map<String, FieldSetting>.from(defaults.fieldSettings);
    fields['branch'] = fields['branch']!.copyWith(
      x: 470,
      y: 64,
      width: 280,
      height: 24,
      colorValue: 0xFF0070C0,
      geometryConfigured: true,
    );
    final settings = defaults.copyWith(fieldSettings: fields);
    final bytes = await TravelAllowancePdfService.build(
      const TravelAllowanceRequest(
        branch: 'الجنوبية',
        month: 'مايو',
        year: '2026',
      ),
      settings: settings,
    );
    expect(bytes, isNotEmpty);
    expect(bytes.take(4).toList(), <int>[37, 80, 68, 70]);
  });
}
