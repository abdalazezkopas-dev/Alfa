import 'dart:io';

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('declares INTERNET permission in the main Android manifest', () async {
    final manifest = await File(
      'android/app/src/main/AndroidManifest.xml',
    ).readAsString();

    expect(
      manifest,
      contains('android.permission.INTERNET'),
      reason: 'The production manifest must allow the app network access.',
    );
  });

  test(
    'preserves Android application identity and disables platform backup',
    () async {
      final gradle = await File('android/app/build.gradle.kts').readAsString();
      final activity = await File(
        'android/app/src/main/kotlin/com/shibapharma/formsuite/MainActivity.kt',
      ).readAsString();
      final manifest = await File(
        'android/app/src/main/AndroidManifest.xml',
      ).readAsString();

      expect(gradle, contains('namespace = "com.shibapharma.formsuite"'));
      expect(gradle, contains('applicationId = "com.shibapharma.formsuite"'));
      expect(activity, contains('package com.shibapharma.formsuite'));
      expect(manifest, contains('android:allowBackup="false"'));
      expect(manifest, contains('android:fullBackupContent="false"'));
    },
  );
}
