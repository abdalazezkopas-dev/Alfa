# إعداد Google Drive OAuth للتطبيق

## بيانات المشروع الحالية

- معرّف Android (`applicationId`): `com.shibapharma.formsuite`
- نطاق Drive الذي يطلبه التطبيق فقط: `https://www.googleapis.com/auth/drive.appdata`
- مساحة التخزين: `appDataFolder` المخفية الخاصة بالتطبيق. النسخ لن تظهر في واجهة Drive المعتادة؛ فهي مخصصة لبيانات التطبيق، ويمكن للمستخدم حذف بيانات التطبيق أو مساحة التطبيق يدويًا من Drive. توضح Google أن `drive.appdata` نطاق غير حساس ومخصص لبيانات التطبيق.[1] [2]
- إصدار `google_sign_in`: 7.x.

## التسجيل المطلوب في Google Cloud

1. اختر مشروع Google Cloud الموجود الذي يملكه صاحب التطبيق، أو أنشئ مشروعًا جديدًا تحت الحساب المناسب. فعّل **Google Drive API** فيه.
2. أكمل إعداد **OAuth consent screen / Google Auth Platform**. اختر نوع الجمهور بحسب الاستخدام: داخلي فقط إذا كان جميع المستخدمين ضمن Google Workspace للمنظمة نفسها، أو خارجي إذا كان الحساب سيستخدمه أشخاص خارجها. أثناء الاختبار الخارجي، أضف حسابات المستخدمين التجريبية. لا تختَر نوع الجمهور قبل معرفة حسابات الشركة المستهدفة.
3. أنشئ **OAuth client ID من نوع Android** لكل شهادة توقيع ستُستخدم. أدخل اسم الحزمة أعلاه وبصمة SHA-1 الصحيحة. يختلف SHA-1 بحسب التوقيع: استخدم debug للتجربة المحلية، وrelease للبناء الموقّع يدويًا، أو بصمة **App signing key certificate** من Play Console إذا كان التطبيق موزعًا عبر Google Play.[3]
4. أنشئ **OAuth client ID من نوع Web application** في المشروع نفسه، ثم انسخ قيمة **Client ID** فقط. رغم أنه معرّف نوع Web، فهذا هو `serverClientId` الذي تتطلبه حزمة Android عند التسجيل المباشر دون `google-services.json`.[4]
5. أضف نطاق `drive.appdata` إلى نطاقات OAuth المسموح بها إذا طلبت شاشة الإعداد ذلك. لا يطلب التطبيق نطاق الوصول الكامل إلى Drive.

## استخراج بصمة SHA-1

من مجلد Android في بيئة تطوير التطبيق، شغّل:

```bash
./gradlew signingReport
```

انسخ بصمة SHA1 للـ variant الذي تختبره. ولتطبيق منشور مع Play App Signing، استخدم بصمة شهادة التوقيع المعروضة في Google Play Console، لا بصمة رفع الحزمة.[3]

لا توجد حاليًا في الحزمة المرفقة شهادة إصدار أو ملف debug keystore؛ لذلك لم أضع بصمة افتراضية. كما أن ملف `android/local.properties` خاص بمسارات الجهاز ويُستبعد من التسليم.

## تشغيل التطبيق بعد التسجيل

مرّر **Web client ID** إلى البناء. مثال بعد استبدال النص بمعرّفك:

```bash
flutter run --dart-define=GOOGLE_SERVER_CLIENT_ID=YOUR_WEB_CLIENT_ID.apps.googleusercontent.com
```

ولإنشاء APK:

```bash
flutter build apk --release --dart-define=GOOGLE_SERVER_CLIENT_ID=YOUR_WEB_CLIENT_ID.apps.googleusercontent.com
```

تأكد أن ملف توقيع Release معدّ في `key.properties` غير المضمّن في المستودع، وأن بصمة SHA-1 المسجلة في Google Cloud تطابق شهادة هذا التوقيع. معرّف Web Client ID ليس كلمة مرور، لكن لا ترفع أي **client secret** أو ملف مفاتيح خاصة إلى المستودع أو المحادثة؛ هذا التكامل لا يحتاج `client secret` في تطبيق Android.

## ما أحتاجه لإكمال الإعداد بدلًا عنك

لإنشاء إعداد مطابق، يلزم تحديد مشروع Google Cloud الذي سيملكه التطبيق، ونوع الجمهور (داخلي أو خارجي)، وبصمة SHA-1 الخاصة بالبناء التجريبي والإصدار النهائي. أنشئ/وفّر Web Client ID بعد تسجيله، ويمكن تمريره إلى البناء من دون إدخاله كنص ثابت في المستودع. لا ترسل كلمات مرور Google أو أسرار العميل أو ملف keystore الخاص.

لا أستطيع استخراج بصمة موثوقة من الملفات المتوفرة هنا: لا يحتوي المشروع على APK/AAB أو keystore، وFlutter/Android SDK المشار إليهما في إعدادات الجهاز غير موجودين في بيئة العمل الحالية. بعد توفير هذه البيانات، يجب تجربة تسجيل الدخول والرفع والتنزيل على جهاز Android فعلي.

## المراجع

[1]: https://developers.google.com/workspace/drive/api/guides/appdata "Google Drive API: Store application-specific data"  
[2]: https://developers.google.com/workspace/drive/api/guides/api-specific-auth "Google Drive API: Choose scopes"  
[3]: https://developers.google.com/android/guides/client-auth "Google: Authenticate to APIs from Android"  
[4]: https://pub.dev/packages/google_sign_in_android "google_sign_in_android: Android integration" 
