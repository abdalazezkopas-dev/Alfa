/// قفل بسيط يمنع تداخل عمليات القراءة والتعديل والحفظ لنفس مخزن SharedPreferences.
class StoreMutex {
  StoreMutex._();

  static final Map<String, Future<void>> _tails = {};

  static Future<T> run<T>(String key, Future<T> Function() action) {
    final previous = _tails[key] ?? Future<void>.value();
    final result = previous.then((_) => action());
    final tail = result.then<void>((_) {}, onError: (_, _) {});
    _tails[key] = tail;
    tail.then<void>(
      (_) {
        if (identical(_tails[key], tail)) _tails.remove(key);
      },
      onError: (_, _) {
        if (identical(_tails[key], tail)) _tails.remove(key);
      },
    );
    return result;
  }
}
