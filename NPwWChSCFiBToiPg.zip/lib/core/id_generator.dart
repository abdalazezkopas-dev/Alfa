import 'package:shared_preferences/shared_preferences.dart';

import 'store_mutex.dart';

/// مولد معرفات محلي متسلسل لا يعتمد على دقة الساعة فقط.
class IdGenerator {
  IdGenerator._();

  static const _key = 'alfa_expense_app.id_counter.v1';

  static Future<int> next(String namespace) =>
      StoreMutex.run('id:$namespace', () async {
        final preferences = await SharedPreferences.getInstance();
        final key = '$_key.$namespace';
        final current =
            preferences.getInt(key) ?? DateTime.now().microsecondsSinceEpoch;
        final next = current + 1;
        final saved = await preferences.setInt(key, next);
        if (!saved) throw StateError('فشل حفظ البيانات في التخزين المحلي');
        return next;
      });
}
