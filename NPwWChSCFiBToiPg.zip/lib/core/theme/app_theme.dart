import 'package:flutter/material.dart';

import '../../features/settings/models/app_settings.dart';

abstract final class AppTheme {
  static const Color primary = Color(0xFF16823B);
  static const Color secondary = Color(0xFFD4AF37);
  static const Color background = Color(0xFFF6F8FA);

  static ThemeData build(AppSettings settings) {
    final appPrimary = settings.primaryColor;
    final isDark = settings.darkMode;
    final brightness = isDark ? Brightness.dark : Brightness.light;
    final surface = isDark ? const Color(0xFF1A1D1E) : Colors.white;
    final textColor = isDark ? const Color(0xFFF3F6F7) : settings.textColor;
    final fieldFill = isDark
        ? const Color(0xFF252B2D)
        : Color(settings.fieldBackgroundColorValue);
    final borderColor = isDark
        ? const Color(0xFF6D7B80)
        : const Color(0xFFD7DEE2);
    final colorScheme =
        ColorScheme.fromSeed(
          seedColor: appPrimary,
          brightness: brightness,
        ).copyWith(
          primary: appPrimary,
          secondary: secondary,
          surface: surface,
          onSurface: textColor,
          onSurfaceVariant: isDark
              ? const Color(0xFFD4DEE1)
              : const Color(0xFF526067),
          outline: borderColor,
          outlineVariant: borderColor,
        );

    return ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: isDark
          ? const Color(0xFF101416)
          : Color(settings.backgroundColorValue),
      fontFamily: 'Cairo',
      textTheme: ThemeData(brightness: brightness).textTheme.apply(
        fontFamily: 'Cairo',
        bodyColor: textColor,
        displayColor: textColor,
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: appPrimary,
        foregroundColor: Colors.white,
        centerTitle: true,
        elevation: 0,
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: fieldFill,
        labelStyle: TextStyle(color: colorScheme.onSurfaceVariant),
        floatingLabelStyle: TextStyle(color: colorScheme.primary),
        hintStyle: TextStyle(color: colorScheme.onSurfaceVariant),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: borderColor),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: borderColor),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: appPrimary, width: 2),
        ),
        errorStyle: TextStyle(
          color: isDark ? const Color(0xFFFFB4AB) : const Color(0xFFB3261E),
        ),
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 1,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: borderColor.withValues(alpha: 0.7)),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: appPrimary,
          foregroundColor: Colors.white,
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }

  static ThemeData get light => build(AppSettings.defaults());
}
