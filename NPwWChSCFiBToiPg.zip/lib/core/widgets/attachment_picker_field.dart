import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../services/attachment_manager.dart';

class AttachmentPickerField extends StatefulWidget {
  const AttachmentPickerField({
    super.key,
    required this.paths,
    required this.onChanged,
    this.onRemove,
  });

  final List<String> paths;
  final ValueChanged<List<String>> onChanged;
  final Future<void> Function(String path)? onRemove;

  @override
  State<AttachmentPickerField> createState() => _AttachmentPickerFieldState();
}

class _AttachmentPickerFieldState extends State<AttachmentPickerField> {
  late List<String> _paths;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _paths = List<String>.from(widget.paths);
  }

  @override
  void didUpdateWidget(covariant AttachmentPickerField oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.paths != widget.paths) {
      _paths = List<String>.from(widget.paths);
    }
  }

  Future<void> _pickFiles() async {
    if (_busy) return;
    final result = await FilePicker.pickFiles(
      dialogTitle: 'اختيار المرفقات',
      allowMultiple: true,
      type: FileType.custom,
      allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png', 'webp'],
    );
    if (result == null || result.files.isEmpty) return;
    setState(() => _busy = true);
    final added = <String>[];
    try {
      for (final picked in result.files) {
        final path = picked.path;
        if (path == null || path.trim().isEmpty) continue;
        final stored = await AttachmentManager.saveAttachment(File(path));
        added.add(stored.path);
      }
      if (added.isNotEmpty && mounted) {
        setState(() => _paths = {..._paths, ...added}.toList());
        widget.onChanged(List<String>.from(_paths));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _takePhoto() async {
    if (_busy) return;
    final image = await ImagePicker().pickImage(
      source: ImageSource.camera,
      imageQuality: 88,
      maxWidth: 1800,
    );
    if (image == null) return;
    setState(() => _busy = true);
    try {
      final stored = await AttachmentManager.saveAttachment(File(image.path));
      if (!mounted) return;
      setState(() => _paths = [..._paths, stored.path]);
      widget.onChanged(List<String>.from(_paths));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _remove(String path) async {
    setState(() => _paths.remove(path));
    widget.onChanged(List<String>.from(_paths));
    await widget.onRemove?.call(path);
  }

  String _name(String path) => path.split(Platform.pathSeparator).last;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Icon(Icons.attach_file_outlined),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _paths.isEmpty
                        ? 'لا توجد مرفقات'
                        : 'المرفقات (${_paths.length})',
                    style: Theme.of(context).textTheme.titleSmall,
                  ),
                ),
                if (_busy)
                  const SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
              ],
            ),
            if (_paths.isNotEmpty) ...[
              const SizedBox(height: 8),
              ..._paths.map(
                (path) => ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  leading: Icon(
                    path.toLowerCase().endsWith('.pdf')
                        ? Icons.picture_as_pdf_outlined
                        : Icons.image_outlined,
                  ),
                  title: Text(
                    _name(path),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: IconButton(
                    tooltip: 'حذف المرفق',
                    onPressed: _busy ? null : () => _remove(path),
                    icon: const Icon(Icons.delete_outline),
                  ),
                ),
              ),
            ],
            const SizedBox(height: 4),
            Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                OutlinedButton.icon(
                  onPressed: _busy ? null : _pickFiles,
                  icon: const Icon(Icons.attach_file),
                  label: const Text('إضافة مرفقات'),
                ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: _busy ? null : _takePhoto,
                  icon: const Icon(Icons.camera_alt_outlined),
                  label: const Text('الكاميرا / التقاط صورة'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
