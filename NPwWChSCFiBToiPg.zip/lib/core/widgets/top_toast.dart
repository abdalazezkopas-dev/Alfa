import 'package:flutter/material.dart';

/// Lightweight top-positioned feedback notification shared by all screens.
class TopToast {
  const TopToast._();

  static const Duration duration = Duration(milliseconds: 1500);
  static const Color navy = Color(0xFF0F2942);
  static const Color errorRed = Color(0xFF7F1D1D);

  static void show(
    BuildContext context,
    String message, {
    bool isError = false,
  }) {
    final mediaQuery = MediaQuery.of(context);
    final messenger = ScaffoldMessenger.of(context);
    messenger
      ..clearSnackBars()
      ..showSnackBar(
        SnackBar(
          duration: duration,
          behavior: SnackBarBehavior.floating,
          margin: EdgeInsets.only(
            top: mediaQuery.padding.top + 10,
            bottom: mediaQuery.size.height - (mediaQuery.padding.top + 82),
            left: 16,
            right: 16,
          ),
          backgroundColor: isError ? errorRed : navy,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          content: Directionality(
            textDirection: TextDirection.rtl,
            child: Row(
              children: [
                Icon(
                  isError ? Icons.error_outline : Icons.check_circle_outline,
                  color: Colors.white,
                  size: 20,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    message,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontFamily: 'Noto Kufi Arabic',
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
  }

  static void success(BuildContext context, String message) {
    show(context, message);
  }

  static void error(BuildContext context, String message) {
    show(context, message, isError: true);
  }
}
