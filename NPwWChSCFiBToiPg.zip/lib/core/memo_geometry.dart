class MemoGeometry {
  const MemoGeometry._();

  static const double a4Width = 595.28;
  static const double a4Height = 841.89;

  static double clampX(double x, double width) =>
      x.clamp(0.0, (a4Width - width).clamp(0.0, a4Width)).toDouble();

  static double clampY(double y, double height) =>
      y.clamp(0.0, (a4Height - height).clamp(0.0, a4Height)).toDouble();

  static double clampWidth(double width) =>
      width.clamp(0.0, a4Width).toDouble();

  static double clampHeight(double height) =>
      height.clamp(0.0, a4Height).toDouble();
}
