import 'dart:convert';
import 'dart:io';
import 'dart:math';

import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:flutter/services.dart';

class KeyProtection {
  const KeyProtection._();

  static const _keyName = 'kabas_storage_key_v1';
  static const _storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static String? _testKey;

  static Future<String> getOrCreateStorageKey() async {
    try {
      final existing = await _storage.read(key: _keyName);
      if (existing != null && existing.isNotEmpty) {
        if (existing.length < 32) {
          throw StateError(
            'مفتاح التخزين المشفر غير صالح ولا يمكن استبداله تلقائيًا',
          );
        }
        return existing;
      }
      final encoded = _newKey();
      await _storage.write(key: _keyName, value: encoded);
      return encoded;
    } on MissingPluginException {
      if (Platform.environment['FLUTTER_TEST'] != 'true') rethrow;
      return _testKey ??= _newKey();
    }
  }

  static String _newKey() {
    final random = Random.secure();
    final bytes = List<int>.generate(32, (_) => random.nextInt(256));
    return base64UrlEncode(bytes);
  }
}
