import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../features/backup/services/encrypted_backup_codec.dart';
import 'key_protection.dart';

/// Encrypted-at-rest key/value storage used as a safe migration layer.
/// Legacy values remain untouched until the encrypted value is written and
/// read back successfully.
class SecureLocalStore {
  const SecureLocalStore._();

  static String _key(String key) => 'secure.v1.$key';

  static Future<String?> read(String key) async {
    final preferences = await SharedPreferences.getInstance();
    final raw = preferences.getString(_key(key));
    if (raw == null || raw.isEmpty) return null;
    final password = await KeyProtection.getOrCreateStorageKey();
    return EncryptedBackupCodec.decryptJson(raw, password: password);
  }

  static Future<void> write(String key, String value) async {
    final password = await KeyProtection.getOrCreateStorageKey();
    final encrypted = await EncryptedBackupCodec.encryptJson(
      value,
      password: password,
    );
    final preferences = await SharedPreferences.getInstance();
    final saved = await preferences.setString(_key(key), encrypted);
    if (!saved || preferences.getString(_key(key)) != encrypted) {
      throw StateError('تعذر التحقق من حفظ التخزين المشفر');
    }
    // Verify that the value is readable before the caller can remove a legacy copy.
    final verified = await read(key);
    if (verified != value) {
      throw StateError('تعذر التحقق من قراءة التخزين المشفر بعد حفظه');
    }
  }

  static Future<void> writeJson(String key, Object value) =>
      write(key, jsonEncode(value));

  static Future<Object?> readJson(String key) async {
    final value = await read(key);
    return value == null ? null : jsonDecode(value);
  }

  static Future<void> remove(String key) async {
    final preferences = await SharedPreferences.getInstance();
    if (!preferences.containsKey(_key(key))) return;
    final removed = await preferences.remove(_key(key));
    if (!removed || preferences.containsKey(_key(key))) {
      throw StateError('تعذر التحقق من حذف التخزين المشفر');
    }
  }
}
