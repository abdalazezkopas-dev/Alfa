/// Conservative limits applied at model boundaries.
///
/// These helpers intentionally preserve legacy records by falling back to a
/// safe value instead of throwing for a single malformed field. Collection
/// stores can therefore skip or retain healthy records independently.
class InputLimits {
  const InputLimits._();

  static const maxIdLength = 128;
  static const maxShortTextLength = 512;
  static const maxLongTextLength = 20000;
  static const maxCategoryLength = 128;
  static const maxTasks = 200;
  static const maxDebtEntries = 500;
  static const maxCustomFields = 200;
  static const maxCustomFieldKeyLength = 128;
  static const maxAttachmentPathLength = 2048;

  static String string(
    Object? value, {
    String fallback = '',
    int maxLength = maxShortTextLength,
  }) {
    if (value is! String) return fallback;
    if (value.length <= maxLength) return value;
    return value.substring(0, maxLength);
  }

  static String id(Object? value, {String fallback = ''}) =>
      string(value, fallback: fallback, maxLength: maxIdLength);

  static int integer(
    Object? value, {
    int fallback = 0,
    int min = 0,
    int max = 1 << 31,
  }) {
    final parsed = value is num
        ? value.toInt()
        : int.tryParse(value?.toString() ?? '');
    if (parsed == null || parsed < min || parsed > max) return fallback;
    return parsed;
  }

  static double finiteDouble(
    Object? value, {
    double fallback = 0,
    double min = 0,
    double max = 1e12,
  }) {
    final parsed = value is num
        ? value.toDouble()
        : double.tryParse(value?.toString() ?? '');
    if (parsed == null || !parsed.isFinite || parsed < min || parsed > max) {
      return fallback;
    }
    return parsed;
  }

  static bool color(Object? value, {int fallback = 0xFFFFFFFF}) {
    final parsed = integer(value, fallback: fallback, min: 0, max: 0xFFFFFFFF);
    return parsed >= 0 && parsed <= 0xFFFFFFFF;
  }

  static List<Object?> list(Object? value, {int maxLength = 500}) {
    if (value is! List) return const [];
    return value.take(maxLength).toList(growable: false);
  }

  /// Strict counterparts used for persisted/imported data. Unlike the UI
  /// helpers above, these never truncate or replace malformed values.
  static String strictString(
    Object? value, {
    required String field,
    int maxLength = maxShortTextLength,
  }) {
    if (value is! String) {
      throw FormatException('الحقل $field يجب أن يكون نصًا');
    }
    if (value.length > maxLength) {
      throw FormatException('الحقل $field يتجاوز الحد المسموح');
    }
    return value;
  }

  static int strictInteger(
    Object? value, {
    required String field,
    int min = 0,
    int max = 1 << 31,
  }) {
    if (value is! int || value < min || value > max) {
      throw FormatException('الحقل $field يجب أن يكون عددًا صحيحًا صالحًا');
    }
    return value;
  }

  static double strictFiniteDouble(
    Object? value, {
    required String field,
    double min = 0,
    double max = 1e12,
  }) {
    if (value is! num) {
      throw FormatException('الحقل $field يجب أن يكون رقمًا');
    }
    final parsed = value.toDouble();
    if (!parsed.isFinite || parsed < min || parsed > max) {
      throw FormatException('الحقل $field يحتوي رقمًا غير صالح');
    }
    return parsed;
  }

  static bool strictBool(Object? value, {required String field}) {
    if (value is! bool) {
      throw FormatException('الحقل $field يجب أن يكون منطقيًا');
    }
    return value;
  }

  static DateTime strictDateTime(Object? value, {required String field}) {
    final parsed = value is String ? DateTime.tryParse(value) : null;
    if (parsed == null) {
      throw FormatException('الحقل $field يجب أن يكون تاريخًا صالحًا');
    }
    return parsed;
  }

  static List<Object?> strictList(
    Object? value, {
    required String field,
    int maxLength = 500,
  }) {
    if (value is! List) {
      throw FormatException('القائمة $field غير صحيحة');
    }
    if (value.length > maxLength) {
      throw FormatException('القائمة $field تتجاوز الحد المسموح');
    }
    return List<Object?>.from(value);
  }

  static Map<String, Object?> strictMap(
    Object? value, {
    required String field,
  }) {
    if (value is! Map) {
      throw FormatException('الحقل $field يجب أن يكون كائنًا');
    }
    try {
      return Map<String, Object?>.from(value);
    } catch (_) {
      throw FormatException('الحقل $field يحتوي مفاتيح غير صالحة');
    }
  }
}
