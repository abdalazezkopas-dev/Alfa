/// Unified Gregorian date formatting for the Arabic UI and generated reports.
///
/// Display format is intentionally year-first with the marker first: `م2026/09/26`.
class DateFormatter {
  const DateFormatter._();

  static String two(int value) => value.toString().padLeft(2, '0');

  static String date(DateTime value) =>
      'م${value.year}/${two(value.month)}/${two(value.day)}';

  static String dateTime(DateTime value) =>
      '${date(value)} ${two(value.hour)}:${two(value.minute)}';

  /// Parses the current year-first format and the legacy day-first format.
  /// The legacy format remains readable so existing saved documents are not
  /// broken, while every newly displayed/selected value uses [date].
  static DateTime? parse(String raw) {
    final value = raw.trim().replaceAll('م', '').trim();
    final parts = value.split('/');
    if (parts.length != 3) return null;
    final first = int.tryParse(parts[0]);
    final second = int.tryParse(parts[1]);
    final third = int.tryParse(parts[2]);
    if (first == null || second == null || third == null) return null;

    final int year;
    final int month;
    final int day;
    if (first >= 1000) {
      year = first;
      month = second;
      day = third;
    } else {
      day = first;
      month = second;
      year = third;
    }
    if (year < 1 || month < 1 || month > 12 || day < 1 || day > 31) {
      return null;
    }
    final parsed = DateTime(year, month, day);
    return parsed.year == year && parsed.month == month && parsed.day == day
        ? parsed
        : null;
  }
}
