import 'package:flutter/services.dart';

class NumberNormalizer {
  const NumberNormalizer._();

  static String digits(String value) {
    const arabic = '٠١٢٣٤٥٦٧٨٩';
    const persian = '۰۱۲۳۴۵۶۷۸۹';
    final buffer = StringBuffer();
    for (final rune in value.runes) {
      final character = String.fromCharCode(rune);
      final arabicIndex = arabic.indexOf(character);
      if (arabicIndex >= 0) {
        buffer.write(arabicIndex);
        continue;
      }
      final persianIndex = persian.indexOf(character);
      buffer.write(persianIndex >= 0 ? persianIndex : character);
    }
    return buffer.toString();
  }

  static String decimal(String value) => digits(
    value,
  ).replaceAll('٫', '.').replaceAll('٬', ',').replaceAll('،', ',');

  static String formatGrouped(String value) {
    final normalized = decimal(value).replaceAll(',', '').trim();
    if (normalized.isEmpty) return '';
    final parts = normalized.split('.');
    if (parts.length > 2 || !RegExp(r'^\d+$').hasMatch(parts.first)) {
      return value;
    }
    if (parts.length == 2 && !RegExp(r'^\d*$').hasMatch(parts[1])) {
      return value;
    }
    final grouped = parts.first.replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (match) => ',',
    );
    return parts.length == 2 ? '$grouped.${parts[1]}' : grouped;
  }

  static double? parseDouble(String value) {
    final normalized = decimal(value).replaceAll(',', '').trim();
    return double.tryParse(normalized);
  }

  static int? parseMinorUnits(String value, {int decimals = 2}) {
    final parsed = parseDouble(value);
    if (parsed == null || !parsed.isFinite) return null;
    final factor = _pow10(decimals);
    final minor = (parsed * factor).round();
    return minor;
  }

  static int _pow10(int exponent) {
    var value = 1;
    for (var i = 0; i < exponent; i++) {
      value *= 10;
    }
    return value;
  }
}

int _digitCount(String value) => value.runes.where((rune) {
  final character = String.fromCharCode(rune);
  return RegExp(r'[0-9٠-٩۰-۹]').hasMatch(character);
}).length;

int _formattedOffset(String original, String formatted, int offset) {
  final safe = offset.clamp(0, original.length).toInt();
  final before = _digitCount(original.substring(0, safe));
  if (before == 0) return 0;
  var seen = 0;
  for (var index = 0; index < formatted.length; index++) {
    if (RegExp(r'[0-9]').hasMatch(formatted[index])) {
      seen++;
      if (seen == before) return index + 1;
    }
  }
  return formatted.length;
}

TextSelection _mapSelection(
  String original,
  String formatted,
  TextSelection selection,
) {
  return TextSelection(
    baseOffset: _formattedOffset(original, formatted, selection.baseOffset),
    extentOffset: _formattedOffset(original, formatted, selection.extentOffset),
    affinity: selection.affinity,
    isDirectional: selection.isDirectional,
  );
}

TextRange _mapComposing(
  String original,
  String formatted,
  TextRange composing,
) {
  if (!composing.isValid || composing.isCollapsed) return TextRange.empty;
  return TextRange(
    start: _formattedOffset(original, formatted, composing.start),
    end: _formattedOffset(original, formatted, composing.end),
  );
}

class ThousandsSeparatorInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    if (newValue.text.isNotEmpty &&
        !RegExp(r'^[0-9٠-٩۰-۹.,٫٬]*$').hasMatch(newValue.text)) {
      return oldValue;
    }
    final formatted = NumberNormalizer.formatGrouped(newValue.text);
    if (formatted == newValue.text) return newValue;
    return TextEditingValue(
      text: formatted,
      selection: _mapSelection(newValue.text, formatted, newValue.selection),
      composing: _mapComposing(newValue.text, formatted, newValue.composing),
    );
  }
}
