import 'dart:io';

import 'package:path_provider/path_provider.dart';

import '../../features/expense_request/models/expense_request.dart';

class AttachmentManager {
  const AttachmentManager._();

  static Future<File> saveAttachment(File source) async {
    final appDirectory = await getApplicationSupportDirectory();
    final attachmentDirectory = Directory('${appDirectory.path}/attachments');
    await attachmentDirectory.create(recursive: true);
    final extension = source.path.contains('.')
        ? source.path.substring(source.path.lastIndexOf('.'))
        : '.jpg';
    final target = File(
      '${attachmentDirectory.path}/attachment_${DateTime.now().microsecondsSinceEpoch}$extension',
    );
    return source.copy(target.path);
  }

  static Future<void> deleteAttachment(
    String? path, {
    Iterable<ExpenseRequest> activeRequests = const [],
  }) async {
    if (path == null || path.trim().isEmpty || !await isManagedPath(path)) {
      return;
    }
    if (_isReferenced(path, activeRequests)) return;
    final file = File(path);
    if (await file.exists()) await file.delete();
  }

  static Future<void> deleteAttachments(
    Iterable<String> paths, {
    Iterable<ExpenseRequest> activeRequests = const [],
  }) async {
    for (final path in paths.toSet()) {
      await deleteAttachment(path, activeRequests: activeRequests);
    }
  }

  /// Imported data must never control an arbitrary filesystem path.
  static Future<bool> isManagedPath(String path) async {
    final trimmed = path.trim();
    if (trimmed.isEmpty) return false;
    final appDirectory = await getApplicationSupportDirectory();
    final root = Directory('${appDirectory.path}/attachments').absolute.path;
    final candidate = File(trimmed).absolute.path;
    final prefix = root.endsWith(Platform.pathSeparator)
        ? root
        : '$root${Platform.pathSeparator}';
    return candidate.startsWith(prefix);
  }

  static Future<void> cleanupOrphaned({
    required Iterable<ExpenseRequest> activeRequests,
  }) async {
    final appDirectory = await getApplicationSupportDirectory();
    final directory = Directory('${appDirectory.path}/attachments');
    if (!await directory.exists()) return;
    final referenced = <String>{};
    for (final request in activeRequests) {
      _collectPaths(request, referenced);
    }
    await for (final entity in directory.list()) {
      if (entity is File && !referenced.contains(entity.path)) {
        await entity.delete();
      }
    }
  }

  static bool _isReferenced(String path, Iterable<ExpenseRequest> requests) {
    for (final request in requests) {
      final paths = <String>{};
      _collectPaths(request, paths);
      if (paths.contains(path)) return true;
    }
    return false;
  }

  static void _collectPaths(ExpenseRequest request, Set<String> paths) {
    paths.addAll(request.allAttachmentPaths);
    final second = request.secondRequest;
    if (second != null) _collectPaths(second, paths);
  }
}
