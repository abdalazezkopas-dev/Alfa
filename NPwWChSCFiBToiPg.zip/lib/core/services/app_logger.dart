import 'dart:developer' as developer;

class AppLogger {
  const AppLogger._();

  static void error(
    String message, {
    Object? error,
    StackTrace? stackTrace,
    String scope = 'app',
  }) {
    developer.log(
      message,
      name: 'com.shibapharma.formsuite.$scope',
      error: error,
      stackTrace: stackTrace,
      level: 1000,
    );
  }

  static void warning(String message, {String scope = 'app'}) {
    developer.log(
      message,
      name: 'com.shibapharma.formsuite.$scope',
      level: 900,
    );
  }

  static void info(String message, {String scope = 'app'}) {
    developer.log(
      message,
      name: 'com.shibapharma.formsuite.$scope',
      level: 800,
    );
  }
}
