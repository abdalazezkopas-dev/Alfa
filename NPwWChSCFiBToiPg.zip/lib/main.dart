import 'dart:async';
import 'dart:ui' show PlatformDispatcher;

import 'package:flutter/material.dart';

import 'app.dart';
import 'features/reminders/services/reminder_notification_service.dart';
import 'features/settings/services/settings_store.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  installFlutterErrorHandlers();
  // Load the initial theme/settings before mounting MaterialApp. Updating the
  // root inherited-widget tree during the welcome route's first transition
  // can leave dependents attached in Flutter debug builds.
  await SettingsStore.load();
  runApp(const AlfaExpenseApp());

  // Notification setup must never block the first Flutter frame. Some Android
  // devices take time to answer the notification-permission request; awaiting
  // it here leaves the app on the native black launch surface indefinitely.
  unawaited(_initializeNotificationsSafely());
}

void installFlutterErrorHandlers() {
  PlatformDispatcher.instance.onError = handleUncaughtPlatformError;
  FlutterError.onError = (details) {
    debugPrint('خطأ أثناء بناء واجهة التطبيق: ${details.exceptionAsString()}');
    if (details.stack != null) debugPrintStack(stackTrace: details.stack);
  };
  ErrorWidget.builder = (details) {
    debugPrint('تعذر بناء عنصر واجهة: ${details.exceptionAsString()}');
    if (details.stack != null) debugPrintStack(stackTrace: details.stack);
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Material(
        color: const Color(0xFFFFF3F3),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, size: 48, color: Colors.red),
                const SizedBox(height: 12),
                const Text(
                  'تعذر عرض هذه الشاشة بسبب خطأ غير متوقع.',
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 8),
                const Text(
                  'أعد المحاولة، وإذا استمر الخطأ فأغلق الشاشة وافتحها مجددًا.',
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  };
}

bool handleUncaughtPlatformError(Object error, StackTrace stackTrace) {
  // Keep logs free of exception payloads that may contain user-entered data.
  debugPrint(
    'حدث خطأ غير معالج من النوع ${error.runtimeType} خارج واجهة Flutter.',
  );
  debugPrintStack(stackTrace: stackTrace);
  // Return false so the platform's default uncaught-error handling is retained.
  return false;
}

Future<void> _initializeNotificationsSafely() async {
  try {
    await ReminderNotificationService.instance.initialize().timeout(
      const Duration(seconds: 10),
    );
    await ReminderNotificationService.instance.rescheduleSaved().timeout(
      const Duration(seconds: 10),
    );
  } catch (error, stackTrace) {
    // Notifications are an optional convenience; the main application must
    // remain usable if Android denies permission or a plugin is unavailable.
    debugPrint('Notification initialization skipped: $error');
    debugPrintStack(stackTrace: stackTrace);
  }
}
