import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/security/secure_local_store.dart';
import '../../../core/store_mutex.dart';
import '../engine/calculator_engine.dart';

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _expression = '';
  String _result = '0';
  List<String> _history = const [];
  double _memory = 0;
  bool _justEvaluated = false;

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    final history = await StoreMutex.run('calculator_history', () async {
      final preferences = await SharedPreferences.getInstance();
      try {
        final secure = await SecureLocalStore.readJson('calculator.history');
        if (secure is List) {
          await preferences.remove('alfa_calculator_history');
          return secure.whereType<String>().toList();
        }
      } catch (_) {}
      final legacy =
          preferences.getStringList('alfa_calculator_history') ??
          const <String>[];
      try {
        await SecureLocalStore.writeJson('calculator.history', legacy);
        await preferences.remove('alfa_calculator_history');
      } catch (_) {}
      return legacy;
    });
    if (!mounted) return;
    setState(() => _history = history);
  }

  Future<void> _saveHistory() => StoreMutex.run('calculator_history', () async {
    final preferences = await SharedPreferences.getInstance();
    await SecureLocalStore.writeJson('calculator.history', _history);
    await preferences.remove('alfa_calculator_history');
  });

  void _showHistory() {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: SizedBox(
          height: 420,
          child: _history.isEmpty
              ? const Center(child: Text('لا توجد عمليات محفوظة بعد'))
              : Column(
                  children: [
                    ListTile(
                      title: const Text('محفوظات العمليات'),
                      trailing: IconButton(
                        tooltip: 'مسح المحفوظات',
                        onPressed: () async {
                          setState(() => _history = const []);
                          await _saveHistory();
                          if (context.mounted) Navigator.pop(context);
                        },
                        icon: const Icon(Icons.delete_sweep_outlined),
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: _history.length,
                        itemBuilder: (_, index) => ListTile(
                          dense: true,
                          leading: const Icon(Icons.history),
                          title: Text(
                            _history[index],
                            textDirection: TextDirection.ltr,
                          ),
                          onTap: () {
                            final parts = _history[index].split(' = ');
                            setState(() {
                              _expression = parts.first;
                              _result = parts.length > 1 ? parts.last : '0';
                            });
                            Navigator.pop(context);
                          },
                        ),
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }

  void _press(String value) {
    HapticFeedback.selectionClick();
    setState(() {
      if (value == 'C') {
        _expression = '';
        _result = '0';
        _justEvaluated = false;
      } else if (value == '⌫') {
        _justEvaluated = false;
        if (_expression.isNotEmpty) {
          _expression = _expression.substring(0, _expression.length - 1);
        }
        _updateLiveResult();
      } else if (value == 'MC') {
        _memory = 0;
      } else if (value == 'MR') {
        if (_justEvaluated) _expression = '';
        _expression += CalculatorEngine.formatForExpression(_memory);
        _justEvaluated = false;
        _updateLiveResult();
      } else if (value == 'M+') {
        _memory += _parseDisplayNumber(_result);
      } else if (value == 'M-') {
        _memory -= _parseDisplayNumber(_result);
      } else if (value == '+/-') {
        _justEvaluated = false;
        if (_expression.trim().isEmpty) {
          _expression = '-';
        } else if (_expression.startsWith('-') &&
            !_expression.substring(1).contains(RegExp(r'[+\-×÷*/()]'))) {
          _expression = _expression.substring(1);
        } else {
          _expression = '-($_expression)';
        }
        _updateLiveResult();
      } else if (value == '=') {
        try {
          _result = _format(_evaluate(_expression));
          _justEvaluated = true;
          if (_expression.trim().isNotEmpty) {
            _history = [
              '$_expression = $_result',
              ..._history,
            ].take(50).toList();
            _saveHistory();
          }
        } on FormatException {
          _result = 'غير صالح';
          _justEvaluated = false;
        }
      } else if (value == '%') {
        if (_expression.isNotEmpty && _canAppendPercent) {
          _expression += '%';
          _justEvaluated = false;
        }
      } else if (value == '.') {
        _prepareForNewExpression(value);
        if (_canAppendDecimal) {
          _expression += _currentNumber.isEmpty ? '0.' : '.';
        }
      } else {
        _prepareForNewExpression(value);
        if (_isOperator(value)) {
          _appendOperator(value);
        } else if (_expression.length < 120) {
          _expression += value;
        }
      }
      if (value != '=' &&
          value != 'C' &&
          value != 'MC' &&
          value != 'MR' &&
          value != 'M+' &&
          value != 'M-') {
        _updateLiveResult();
      }
    });
  }

  void _updateLiveResult() {
    if (_expression.trim().isEmpty) {
      _result = '0';
      return;
    }
    try {
      _result = _format(_evaluate(_expression));
    } on FormatException {
      // Partial expressions such as "12 +" keep the last usable result.
    }
  }

  String _format(double value) {
    if (!value.isFinite) throw const FormatException();
    final raw = value == value.roundToDouble()
        ? value.toInt().toString()
        : value.toStringAsFixed(12).replaceFirst(RegExp(r'\.?0+$'), '');
    final parts = raw.split('.');
    final sign = parts.first.startsWith('-') ? '-' : '';
    final digits = sign.isEmpty ? parts.first : parts.first.substring(1);
    final grouped = digits.replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (_) => ',',
    );
    return '$sign$grouped${parts.length > 1 ? '.${parts[1]}' : ''}';
  }

  double _parseDisplayNumber(String value) =>
      double.tryParse(value.replaceAll(',', '')) ?? 0;

  String get _currentNumber {
    final match = RegExp(r'[-+]?\d*\.?\d*$').firstMatch(_expression);
    return match?.group(0) ?? '';
  }

  bool get _canAppendDecimal =>
      _currentNumber.isEmpty || !_currentNumber.contains('.');

  bool get _canAppendPercent =>
      RegExp(r'[\d)]$').hasMatch(_expression) && !_expression.endsWith('%');

  bool _isOperator(String value) => const ['+', '−', '×', '÷'].contains(value);

  void _prepareForNewExpression(String value) {
    if (!_justEvaluated) return;
    final continues = _isOperator(value) || value == '%';
    _expression = continues
        ? CalculatorEngine.formatForExpression(_evaluate(_expression))
        : '';
    _justEvaluated = false;
  }

  void _appendOperator(String value) {
    if (_expression.isEmpty) {
      if (value == '−') _expression = value;
      return;
    }
    if (RegExp(r'[+−×÷]$').hasMatch(_expression)) {
      _expression = '${_expression.substring(0, _expression.length - 1)}$value';
    } else if (_expression.length < 120) {
      _expression += value;
    }
  }

  double _evaluate(String input) => CalculatorEngine.evaluate(input);

  @override
  Widget build(BuildContext context) {
    const keys = [
      ['MC', 'MR', 'M+', 'M-', '⌫'],
      ['C', '(', ')', '%', '÷'],
      ['7', '8', '9', '+/-', '×'],
      ['4', '5', '6', '00', '−'],
      ['1', '2', '3', '000', '+'],
      ['0', '00', '000', '.', '='],
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('الحاسبة الاحترافية'),
        actions: [
          IconButton(
            tooltip: 'محفوظات العمليات',
            onPressed: _showHistory,
            icon: const Icon(Icons.history_outlined),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              flex: 2,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.fromLTRB(24, 30, 24, 20),
                color: Theme.of(context).colorScheme.surfaceContainerHighest,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text(
                      _expression.isEmpty ? '0' : _expression,
                      style: Theme.of(context).textTheme.headlineSmall,
                      textDirection: TextDirection.ltr,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _result,
                      style: Theme.of(context).textTheme.displaySmall?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                      textDirection: TextDirection.ltr,
                    ),
                  ],
                ),
              ),
            ),
            Expanded(
              flex: 5,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Column(
                    children: keys
                        .map(
                          (row) => Expanded(
                            child: Row(
                              children: row.map((key) {
                                final isOperator = [
                                  '÷',
                                  '×',
                                  '−',
                                  '+',
                                  '=',
                                  '+/-',
                                ].contains(key);
                                return Expanded(
                                  child: Padding(
                                    padding: const EdgeInsets.all(4),
                                    child: FilledButton(
                                      style: FilledButton.styleFrom(
                                        minimumSize: Size.zero,
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 5,
                                          vertical: 4,
                                        ),
                                        visualDensity: VisualDensity.standard,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(
                                            14,
                                          ),
                                        ),
                                        backgroundColor:
                                            [
                                              'MC',
                                              'MR',
                                              'M+',
                                              'M-',
                                            ].contains(key)
                                            ? Theme.of(
                                                context,
                                              ).colorScheme.secondaryContainer
                                            : isOperator
                                            ? Theme.of(
                                                context,
                                              ).colorScheme.primary
                                            : Theme.of(context)
                                                  .colorScheme
                                                  .surfaceContainerHighest,
                                        foregroundColor: isOperator
                                            ? Theme.of(
                                                context,
                                              ).colorScheme.onPrimary
                                            : Theme.of(
                                                context,
                                              ).colorScheme.onSurface,
                                      ),
                                      onPressed: () => _press(key),
                                      child: FittedBox(
                                        fit: BoxFit.scaleDown,
                                        child: Text(
                                          key,
                                          style: const TextStyle(
                                            fontSize: 24,
                                            fontWeight: FontWeight.w700,
                                            fontFamily: 'Roboto',
                                          ),
                                          textDirection: TextDirection.ltr,
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              }).toList(),
                            ),
                          ),
                        )
                        .toList(),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
