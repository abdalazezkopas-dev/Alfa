import '../../../core/utils/number_normalizer.dart';

class CalculatorEngine {
  const CalculatorEngine._();

  static double evaluate(String input) {
    final normalized = NumberNormalizer.decimal(input)
        .replaceAll('×', '*')
        .replaceAll('÷', '/')
        .replaceAll('−', '-')
        .replaceAll(',', '')
        .replaceAll(' ', '');
    if (normalized.isEmpty) throw const FormatException('empty expression');

    final parser = _Parser(_tokenize(normalized));
    final result = parser.parseExpression();
    if (!parser.isAtEnd) {
      throw const FormatException('invalid expression');
    }
    if (!result.isFinite) throw const FormatException('invalid result');
    return _round(result);
  }

  /// Produces a non-scientific value that can safely be inserted into an
  /// expression (for example by the MR button).
  static String formatForExpression(double value) {
    if (!value.isFinite) throw const FormatException('invalid result');
    if (value == value.roundToDouble()) return value.toInt().toString();
    return value.toStringAsFixed(12).replaceFirst(RegExp(r'\.?0+$'), '');
  }

  static List<String> _tokenize(String input) {
    final tokens = <String>[];
    var cursor = 0;
    final numberPattern = RegExp(
      r'^(?:(?:\d+(?:\.\d*)?)|(?:\.\d+))(?:[eE][+\-]?\d+)?',
    );
    const operators = {'+', '-', '*', '/', '(', ')', '%'};

    while (cursor < input.length) {
      final remainder = input.substring(cursor);
      final number = numberPattern.firstMatch(remainder);
      if (number != null) {
        tokens.add(number.group(0)!);
        cursor += number.end;
        continue;
      }
      final token = input[cursor];
      if (!operators.contains(token)) {
        throw const FormatException('invalid expression');
      }
      tokens.add(token);
      cursor++;
    }
    return tokens;
  }

  static double _round(double value) {
    if (!value.isFinite || value.abs() > 9000000000000) return value;
    return (value * 1000000000000).roundToDouble() / 1000000000000;
  }
}

class _Parser {
  _Parser(this.tokens);

  final List<String> tokens;
  var index = 0;

  bool get isAtEnd => index == tokens.length;

  String? get current => isAtEnd ? null : tokens[index];

  String take() {
    final token = current;
    if (token == null) throw const FormatException('missing operand');
    index++;
    return token;
  }

  double parseExpression() {
    final value = parseAddSub();
    if (value.isPercent) {
      return value.value;
    }
    return value.value;
  }

  _ParsedValue parseAddSub() {
    var left = parseMulDiv();
    while (current == '+' || current == '-') {
      final operator = take();
      final right = parseMulDiv();
      final rightValue = right.isPercent
          ? left.value * right.value
          : right.value;
      left = _ParsedValue(
        operator == '+' ? left.value + rightValue : left.value - rightValue,
      );
    }
    return left;
  }

  _ParsedValue parseMulDiv() {
    var left = parseUnary();
    while (current == '*' || current == '/') {
      final operator = take();
      final right = parseUnary();
      final rightValue = right.value;
      if (operator == '/' && rightValue == 0) {
        throw const FormatException('division by zero');
      }
      left = _ParsedValue(
        operator == '*' ? left.value * rightValue : left.value / rightValue,
      );
      if (!left.value.isFinite) throw const FormatException('invalid result');
    }
    return left;
  }

  _ParsedValue parseUnary() {
    if (current == '-') {
      final negative = take() == '-';
      final value = parseUnary();
      return _ParsedValue(negative ? -value.value : value.value);
    }

    if (current == '+') {
      throw const FormatException('missing operand');
    }

    final token = current;
    if (token == null) throw const FormatException('missing operand');
    final value = token == '(' ? parseParenthesized() : _parseNumber(take());
    if (current == '%') {
      take();
      return _ParsedValue(value.value / 100, isPercent: true);
    }
    return value;
  }

  _ParsedValue parseParenthesized() {
    take();
    final value = parseAddSub();
    if (takeIf(')') == false) {
      throw const FormatException('unbalanced parentheses');
    }
    return value;
  }

  bool takeIf(String expected) {
    if (current != expected) return false;
    index++;
    return true;
  }

  _ParsedValue _parseNumber(String token) {
    final value = double.tryParse(token);
    if (value == null || !value.isFinite) {
      throw const FormatException('invalid number');
    }
    return _ParsedValue(value);
  }
}

class _ParsedValue {
  const _ParsedValue(this.value, {this.isPercent = false});

  final double value;
  final bool isPercent;
}
