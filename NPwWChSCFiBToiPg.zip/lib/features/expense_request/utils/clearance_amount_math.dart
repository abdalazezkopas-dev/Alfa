import 'package:flutter/services.dart';

/// Decimal-safe amount handling scoped to clearance entries.
class ClearanceAmountMath {
  const ClearanceAmountMath._();

  static BigInt toMinorUnits(String value) {
    final normalized = _normalizeCharacters(value).replaceAll(',', '').trim();
    final match = RegExp(r'^(-?)(\d*)(?:\.(\d*))?$').firstMatch(normalized);
    if (match == null ||
        ((match[2] ?? '').isEmpty && (match[3] ?? '').isEmpty)) {
      throw FormatException('Invalid clearance amount', value);
    }

    final wholeText = (match[2] ?? '').isEmpty ? '0' : match[2]!;
    final fraction = match[3] ?? '';
    var minor = BigInt.parse(wholeText) * BigInt.from(100);
    final cents = '${fraction}00'.substring(0, 2);
    minor += BigInt.parse(cents);

    // Round each amount to two decimal places, with half values away from zero.
    if (fraction.length > 2 && int.parse(fraction[2]) >= 5) {
      minor += BigInt.one;
    }
    if (match[1] == '-' && minor != BigInt.zero) {
      minor = -minor;
    }
    return minor;
  }

  static String normalizeAmount(String value) =>
      amountFromMinorUnits(toMinorUnits(value));

  static BigInt sumMinorUnits(Iterable<String> values) {
    var total = BigInt.zero;
    for (final value in values) {
      total += toMinorUnits(value);
    }
    return total;
  }

  static String amountFromMinorUnits(BigInt minorUnits) {
    final negative = minorUnits.isNegative;
    final absolute = minorUnits.abs();
    final whole = absolute ~/ BigInt.from(100);
    final cents = (absolute % BigInt.from(100)).toString().padLeft(2, '0');
    return '${negative ? '-' : ''}$whole.$cents';
  }

  static String formatGroupedAmount(String value) {
    final normalized = normalizeAmount(value);
    final negative = normalized.startsWith('-');
    final unsigned = negative ? normalized.substring(1) : normalized;
    final parts = unsigned.split('.');
    final whole = parts.first.replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (_) => ',',
    );
    return '${negative ? '-' : ''}$whole.${parts[1]}';
  }

  /// Formats a partial input while preserving incomplete states such as `-`.
  /// Invalid legacy text is returned unchanged so loading a saved request does
  /// not silently erase it; output validation reports it before saving/printing.
  static String formatInput(String value) {
    final normalized = _normalizeCharacters(value).replaceAll(',', '').trim();
    if (!RegExp(r'^-?\d*(?:\.\d*)?$').hasMatch(normalized)) return value;
    if (normalized.isEmpty ||
        normalized == '-' ||
        normalized == '.' ||
        normalized == '-.') {
      return normalized;
    }
    final negative = normalized.startsWith('-');
    final unsigned = negative ? normalized.substring(1) : normalized;
    final parts = unsigned.split('.');
    final integer = parts.first.isEmpty ? '0' : parts.first;
    final grouped = integer.replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (_) => ',',
    );
    final fraction = parts.length == 2 ? '.${parts[1]}' : '';
    return '${negative ? '-' : ''}$grouped$fraction';
  }

  static String _normalizeCharacters(String value) {
    const arabic = '٠١٢٣٤٥٦٧٨٩';
    const persian = '۰۱۲۳۴۵۶۷۸۹';
    final output = StringBuffer();
    for (final rune in value.runes) {
      final character = String.fromCharCode(rune);
      final arabicIndex = arabic.indexOf(character);
      if (arabicIndex >= 0) {
        output.write(arabicIndex);
      } else {
        final persianIndex = persian.indexOf(character);
        output.write(switch (character) {
          '٫' => '.',
          '٬' || '،' => ',',
          _ => persianIndex >= 0 ? persianIndex : character,
        });
      }
    }
    return output.toString();
  }
}

int _clearanceDigitCount(String value) => value.runes.where((rune) {
  final character = String.fromCharCode(rune);
  return RegExp(r'[0-9٠-٩۰-۹]').hasMatch(character);
}).length;

int _clearanceFormattedOffset(String original, String formatted, int offset) {
  final safe = offset.clamp(0, original.length).toInt();
  final before = _clearanceDigitCount(original.substring(0, safe));
  if (before == 0) return 0;
  var seen = 0;
  for (var index = 0; index < formatted.length; index++) {
    if (RegExp(r'[0-9]').hasMatch(formatted[index])) {
      seen++;
      if (seen == before) return index + 1;
    }
  }
  return formatted.length;
}

TextSelection _clearanceSelection(
  String original,
  String formatted,
  TextSelection selection,
) => TextSelection(
  baseOffset: _clearanceFormattedOffset(
    original,
    formatted,
    selection.baseOffset,
  ),
  extentOffset: _clearanceFormattedOffset(
    original,
    formatted,
    selection.extentOffset,
  ),
  affinity: selection.affinity,
  isDirectional: selection.isDirectional,
);

TextRange _clearanceComposing(
  String original,
  String formatted,
  TextRange composing,
) {
  if (!composing.isValid || composing.isCollapsed) return TextRange.empty;
  return TextRange(
    start: _clearanceFormattedOffset(original, formatted, composing.start),
    end: _clearanceFormattedOffset(original, formatted, composing.end),
  );
}

class ClearanceAmountInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final normalized = ClearanceAmountMath._normalizeCharacters(
      newValue.text,
    ).replaceAll(',', '');
    if (!RegExp(r'^-?\d*(?:\.\d*)?$').hasMatch(normalized)) return oldValue;

    final formatted = ClearanceAmountMath.formatInput(normalized);
    if (formatted == newValue.text) return newValue;
    return TextEditingValue(
      text: formatted,
      selection: _clearanceSelection(
        newValue.text,
        formatted,
        newValue.selection,
      ),
      composing: _clearanceComposing(
        newValue.text,
        formatted,
        newValue.composing,
      ),
    );
  }
}
