import '../../../core/utils/number_normalizer.dart';
import '../../../core/utils/date_formatter.dart';

import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';
import 'package:printing/printing.dart';

import '../../settings/models/app_settings.dart';
import '../../settings/models/template_configuration.dart';
import '../../settings/screens/settings_screen.dart';
import '../../settings/screens/template_preview_screen.dart';
import '../../settings/services/settings_store.dart';
import '../../../core/services/attachment_manager.dart';
import '../../../core/widgets/attachment_picker_field.dart';
import '../models/expense_request.dart';
import '../services/amount_to_words.dart';
import '../utils/clearance_amount_math.dart';
import '../../calculator/engine/calculator_engine.dart';
import '../services/pdf_service.dart';
import '../services/quick_statement_store.dart';
import '../services/request_store.dart';
import '../services/share_service.dart';
import '../widgets/request_field.dart';

class ExpenseRequestScreen extends StatefulWidget {
  const ExpenseRequestScreen({
    super.key,
    this.initialRequest,
    this.editingIndex,
    this.isSecondary = false,
    this.documentType = ExpenseDocumentType.expenseRequest,
  });

  final ExpenseRequest? initialRequest;
  final int? editingIndex;
  final bool isSecondary;
  final ExpenseDocumentType documentType;

  @override
  State<ExpenseRequestScreen> createState() => _ExpenseRequestScreenState();
}

class _ExpenseRequestScreenState extends State<ExpenseRequestScreen> {
  final _formKey = GlobalKey<FormState>();
  final _formScrollController = ScrollController();

  final _dateController = TextEditingController();
  final _receiverController = TextEditingController();
  final _amountNumberController = TextEditingController();
  final _amountWordsController = TextEditingController();
  final _reasonController = TextEditingController();
  final _statementController = TextEditingController();
  final _doctorNamesController = TextEditingController();
  final _worksInController = TextEditingController();
  final _specialtyController = TextEditingController();
  final _branchController = TextEditingController();
  final _accountController = TextEditingController();
  final _requesterNameController = TextEditingController();
  final _requesterSignatureController = TextEditingController();
  final _directManagerNameController = TextEditingController();
  final _directManagerSignatureController = TextEditingController();
  final _approvedAuthorityNameController = TextEditingController();
  final _approvedAuthoritySignatureController = TextEditingController();
  final _accountsManagerNameController = TextEditingController();
  final _accountsManagerSignatureController = TextEditingController();
  final Map<String, TextEditingController> _customControllers = {};
  final List<TextEditingController> _clearanceAmounts = [];
  final List<TextEditingController> _clearanceDates = [];
  final List<TextEditingController> _clearanceStatements = [];
  final List<TextEditingController> _serviceNames = [];
  final List<TextEditingController> _serviceQuantities = [];
  final List<TextEditingController> _serviceNotes = [];
  final FocusNode _newServiceItemFocusNode = FocusNode();
  bool _isGeneratingPdf = false;
  int _formCount = 1;
  ExpenseRequest? _secondRequest;
  AppSettings _settings = AppSettings.defaults();
  bool _statementJustified = false;
  List<String> _attachmentPaths = [];
  Timer? _deleteRepeatTimer;

  @override
  void initState() {
    super.initState();
    final initialRequest = widget.initialRequest;
    if (initialRequest != null) {
      _formCount = initialRequest.formCount;
      _secondRequest = initialRequest.secondRequest;
    }
    _dateController.text = _formatDate(DateTime.now());
    _amountNumberController.addListener(_updateAmountInWords);
    _loadSettings();
    _restoreLostAttachment();
  }

  @override
  void dispose() {
    _formScrollController.dispose();
    _deleteRepeatTimer?.cancel();
    _amountNumberController.removeListener(_updateAmountInWords);
    for (final controller in [
      _dateController,
      _receiverController,
      _amountNumberController,
      _amountWordsController,
      _reasonController,
      _statementController,
      _doctorNamesController,
      _worksInController,
      _specialtyController,
      _branchController,
      _accountController,
      _requesterNameController,
      _requesterSignatureController,
      _directManagerNameController,
      _directManagerSignatureController,
      _approvedAuthorityNameController,
      _approvedAuthoritySignatureController,
      _accountsManagerNameController,
      _accountsManagerSignatureController,
    ]) {
      controller.dispose();
    }
    for (final controller in _customControllers.values) {
      controller.dispose();
    }
    for (final controller in [
      ..._clearanceAmounts,
      ..._clearanceDates,
      ..._clearanceStatements,
      ..._serviceNames,
      ..._serviceQuantities,
      ..._serviceNotes,
    ]) {
      controller.dispose();
    }
    _newServiceItemFocusNode.dispose();
    super.dispose();
  }

  bool get _isSinglePageDocument =>
      widget.documentType == ExpenseDocumentType.serviceRequest ||
      widget.documentType == ExpenseDocumentType.clearanceRequest;

  String _formatDate(DateTime date) => DateFormatter.date(date);

  Future<void> _loadSettings() async {
    // SettingsStore migrates the legacy global snapshot into this scope when
    // the scoped record does not exist. Do not overlay global values here:
    // doing so used to overwrite per-template fields after every launch.
    final settings = await SettingsStore.load(scope: _settingsScope);
    _syncCustomControllers(settings);
    _ensureStructuredControllers(settings);
    if (!mounted) return;
    final initialRequest = widget.initialRequest;
    setState(() {
      _settings = settings;
      if (initialRequest != null) {
        _formCount = initialRequest.formCount;
        _secondRequest = initialRequest.secondRequest;
      }
    });
    if (initialRequest != null) _fillRequest(initialRequest);
  }

  void _ensureStructuredControllers(AppSettings settings, {int count = 1}) {
    final maxRows = widget.documentType == ExpenseDocumentType.clearanceRequest
        ? ExpenseRequest.maxClearanceEntries
        : 6;
    final rowCount = count.clamp(1, maxRows).toInt();
    void ensure(List<TextEditingController> list) {
      while (list.length < rowCount) {
        list.add(TextEditingController());
      }
    }

    ensure(_clearanceAmounts);
    ensure(_clearanceDates);
    ensure(_clearanceStatements);
    ensure(_serviceNames);
    ensure(_serviceQuantities);
    ensure(_serviceNotes);
  }

  void _fillRequest(ExpenseRequest request) {
    var rowCount = 1;
    if (request.clearanceEntries.length > rowCount) {
      rowCount = request.clearanceEntries.length;
    }
    if (request.serviceItems.length > rowCount) {
      rowCount = request.serviceItems.length;
    }
    _ensureStructuredControllers(_settings, count: rowCount);
    _dateController.text = DateFormatter.parse(request.date) == null
        ? request.date
        : DateFormatter.date(DateFormatter.parse(request.date)!);
    _receiverController.text = request.receiver;
    _amountNumberController.text = AmountToWords.formatNumber(
      request.amountNumber,
    );
    _amountWordsController.text = request.amountWords;
    _reasonController.text = request.reason;
    _statementController.text = request.statement;
    _doctorNamesController.text = request.customFields['doctorNames'] ?? '';
    _worksInController.text = request.customFields['worksIn'] ?? '';
    _specialtyController.text = request.customFields['specialty'] ?? '';
    _attachmentPaths = request.allAttachmentPaths;
    _branchController.text = request.branch;
    _accountController.text = request.account;
    _requesterNameController.text = request.requesterName;
    _requesterSignatureController.text = request.requesterSignature;
    _directManagerNameController.text = request.directManagerName;
    _directManagerSignatureController.text = request.directManagerSignature;
    _approvedAuthorityNameController.text = request.approvedAuthorityName;
    _approvedAuthoritySignatureController.text =
        request.approvedAuthoritySignature;
    _accountsManagerNameController.text = request.accountsManagerName;
    _accountsManagerSignatureController.text = request.accountsManagerSignature;
    for (final entry in _customControllers.entries) {
      entry.value.text = request.customFields[entry.key] ?? '';
    }
    for (
      var i = 0;
      i < request.clearanceEntries.length && i < _clearanceAmounts.length;
      i++
    ) {
      final entry = request.clearanceEntries[i];
      _clearanceAmounts[i].text = ClearanceAmountMath.formatInput(entry.amount);
      _clearanceDates[i].text = DateFormatter.parse(entry.date) == null
          ? entry.date
          : DateFormatter.date(DateFormatter.parse(entry.date)!);
      _clearanceStatements[i].text = entry.statement;
    }
    for (
      var i = 0;
      i < request.serviceItems.length && i < _serviceNames.length;
      i++
    ) {
      final item = request.serviceItems[i];
      _serviceNames[i].text = item.name;
      _serviceQuantities[i].text = item.quantity;
      _serviceNotes[i].text = item.notes;
    }
  }

  Future<void> _restoreLostAttachment() async {
    final lost = await ImagePicker().retrieveLostData();
    if (lost.isEmpty) return;
    final image = lost.files != null && lost.files!.isNotEmpty
        ? lost.files!.first
        : null;
    if (image == null) return;
    final storedFile = await AttachmentManager.saveAttachment(File(image.path));
    if (!mounted) return;
    setState(
      () => _attachmentPaths = {..._attachmentPaths, storedFile.path}.toList(),
    );
  }

  Future<List<ExpenseRequest>> _otherActiveRequests() async {
    final requests = await RequestStore.load();
    final index = widget.editingIndex;
    if (index != null && index >= 0 && index < requests.length) {
      requests.removeAt(index);
    }
    return requests;
  }

  Future<void> _deleteAttachmentIfUnused(String path) async {
    await AttachmentManager.deleteAttachment(
      path,
      activeRequests: await _otherActiveRequests(),
    );
  }

  Widget _buildAttachmentField() {
    return AttachmentPickerField(
      paths: _attachmentPaths,
      onChanged: (paths) => setState(() => _attachmentPaths = paths),
      onRemove: (path) => _deleteAttachmentIfUnused(path),
    );
  }

  void _syncCustomControllers(AppSettings settings) {
    final customKeys = _formFields(
      settings,
    ).keys.where((key) => key.startsWith('custom_')).toSet();
    for (final key in customKeys) {
      _customControllers.putIfAbsent(key, TextEditingController.new);
    }
    final obsolete = _customControllers.keys
        .where((key) => !customKeys.contains(key))
        .toList();
    for (final key in obsolete) {
      _customControllers.remove(key)?.dispose();
    }
  }

  FieldSetting _field(String key) {
    return _formFields(_settings)[key] ??
        const FieldSetting(label: '', visible: false, required: false);
  }

  FieldSetting _clearanceField(String key, String baseKey) {
    final fields = _formFields(_settings);
    final configured = fields[key];
    if (configured != null) return configured;
    return (fields[baseKey] ??
            const FieldSetting(label: '', visible: true, required: false))
        .copyWith(visible: true, required: false, geometryConfigured: false);
  }

  Map<String, FieldSetting> _formFields(AppSettings settings) {
    return widget.documentType == ExpenseDocumentType.customerApplication
        ? settings.customerFieldSettings
        : settings.fieldSettings;
  }

  String get _settingsScope => switch (widget.documentType) {
    ExpenseDocumentType.clearanceRequest => 'clearanceRequest',
    ExpenseDocumentType.serviceRequest => 'serviceRequest',
    _ => 'expenseRequest',
  };

  String get _documentTitle => switch (widget.documentType) {
    ExpenseDocumentType.clearanceRequest => 'طلب إخلاء عهدة',
    ExpenseDocumentType.serviceRequest => 'طلب خدمة',
    ExpenseDocumentType.customerApplication => 'نموذج تقديم خاص بالعملاء',
    _ => 'طلب صرف',
  };

  String? _fieldValidator(String key, String? value) {
    return _field(key).required ? _requiredValidator(value) : null;
  }

  String? _requiredValidator(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'هذا الحقل مطلوب';
    }
    return null;
  }

  void _formatAmountNumber(String value) {
    final formatted = AmountToWords.formatNumber(value);
    if (formatted == value) return;
    _amountNumberController.value = TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }

  void _updateAmountInWords() {
    _formatAmountNumber(_amountNumberController.text);
    if (!_settings.autoSpelling) return;
    final amount = _amountNumberController.text.trim();
    final words = amount.isEmpty ? '' : AmountToWords.fromNumber(amount);
    if (_amountWordsController.text == words) return;

    _amountWordsController.value = _amountWordsController.value.copyWith(
      text: words,
      selection: TextSelection.collapsed(offset: words.length),
      composing: TextRange.empty,
    );
  }

  Future<void> _openAmountCalculator({TextEditingController? target}) async {
    final targetController = target ?? _amountNumberController;
    final controller = TextEditingController(text: targetController.text);
    String? errorText;
    bool justCalculated = false;

    void setExpression(String value, void Function(void Function()) setState) {
      controller.text = value;
      controller.selection = TextSelection.collapsed(offset: value.length);
      errorText = null;
      setState(() {});
    }

    String displayValue(double value) {
      return CalculatorEngine.formatForExpression(value);
    }

    final result = await showDialog<String>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            void calculate({bool close = false}) {
              try {
                final value = _evaluateAmountExpression(controller.text);
                final text = displayValue(value);
                if (close) {
                  Navigator.of(dialogContext).pop(text);
                } else {
                  setExpression(text, setDialogState);
                  justCalculated = true;
                }
              } catch (_) {
                setDialogState(
                  () => errorText = 'عملية غير صحيحة أو قسمة على صفر',
                );
              }
            }

            void press(String key) {
              if (key == '⌫') {
                if (controller.text.isNotEmpty) {
                  setExpression(
                    controller.text.substring(0, controller.text.length - 1),
                    setDialogState,
                  );
                }
                return;
              }
              if (key == 'C') {
                setExpression('', setDialogState);
                return;
              }
              if (key == '=') {
                calculate();
                return;
              }
              if (key == 'Rnd' || key == 'RndUp' || key == 'RndDn') {
                try {
                  final value = _evaluateAmountExpression(controller.text);
                  final rounded = switch (key) {
                    'RndUp' => value.ceilToDouble(),
                    'RndDn' => value.floorToDouble(),
                    _ => value.roundToDouble(),
                  };
                  setExpression(displayValue(rounded), setDialogState);
                  justCalculated = true;
                } catch (_) {
                  setDialogState(
                    () => errorText = 'أدخل رقماً قبل استخدام التقريب',
                  );
                }
                return;
              }
              final startsNew =
                  justCalculated && (RegExp(r'^[0-9.]$').hasMatch(key));
              justCalculated = false;
              setExpression(
                '${startsNew ? '' : controller.text}$key',
                setDialogState,
              );
            }

            Widget keyButton(String label, {bool accent = false}) {
              return Padding(
                padding: const EdgeInsets.all(4),
                child: FilledButton(
                  style: FilledButton.styleFrom(
                    backgroundColor: accent
                        ? Theme.of(context).colorScheme.primary
                        : Theme.of(context).colorScheme.surfaceContainerHighest,
                    foregroundColor: accent
                        ? Theme.of(context).colorScheme.onPrimary
                        : Theme.of(context).colorScheme.onSurface,
                    minimumSize: const Size(56, 52),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: () => press(label),
                  child: Text(
                    label,
                    textDirection: TextDirection.ltr,
                    style: TextStyle(
                      fontFamily: 'Arial',
                      fontSize: label.length > 2 ? 14 : 22,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              );
            }

            return AlertDialog(
              title: const Text('آلة حاسبة المبلغ'),
              content: SizedBox(
                width: 390,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextField(
                        controller: controller,
                        readOnly: true,
                        textDirection: TextDirection.ltr,
                        textAlign: TextAlign.right,
                        style: const TextStyle(fontFamily: 'Arial'),
                        decoration: InputDecoration(
                          labelText: 'العملية الحسابية',
                          hintText: '500 + 250 - 30 × 2',
                          errorText: errorText,
                          filled: true,
                        ),
                      ),
                      const SizedBox(height: 12),
                      GridView.count(
                        crossAxisCount: 5,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        childAspectRatio: 1.18,
                        children: [
                          for (final label in [
                            '1',
                            '2',
                            '3',
                            '+',
                            'Rnd',
                            '4',
                            '5',
                            '6',
                            '×',
                            'RndUp',
                            '7',
                            '8',
                            '9',
                            '÷',
                            'RndDn',
                            '0',
                            '.',
                            '−',
                            '⌫',
                            '=',
                            'C',
                          ])
                            keyButton(label, accent: label == '='),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: () =>
                                  Navigator.of(dialogContext).pop(),
                              child: const Text('إلغاء'),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: FilledButton.icon(
                              onPressed: () => calculate(close: true),
                              icon: const Icon(Icons.check),
                              label: const Text('تم'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
    controller.dispose();
    if (!mounted || result == null) return;
    targetController.text = result;
    targetController.selection = TextSelection.collapsed(offset: result.length);
  }

  double _evaluateAmountExpression(String expression) {
    return CalculatorEngine.evaluate(expression);
  }

  Future<void> _chooseOtherReceiver() async {
    final controller = TextEditingController(
      text: _receiverController.text == 'أخرى' ? '' : _receiverController.text,
    );
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('إدخال المرسل إليه'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'الاسم'),
          onSubmitted: (value) => Navigator.pop(context, value.trim()),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('اعتماد'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (!mounted || value == null || value.isEmpty) return;
    setState(() => _receiverController.text = value);
    await _rememberReceiver(value);
  }

  Future<void> _rememberBranch(String value) async {
    final clean = value.trim();
    if (clean.isEmpty || _settings.branchOptions.contains(clean)) return;
    final options = [..._settings.branchOptions, clean];
    final updated = _settings.copyWith(branchOptions: options);
    await SettingsStore.save(updated, scope: _settingsScope);
    if (mounted) {
      setState(() => _settings = _settings.copyWith(branchOptions: options));
    }
  }

  Future<void> _rememberReceiver(String value) async {
    final cleanValue = value.trim();
    if (cleanValue.isEmpty || _settings.receiverOptions.contains(cleanValue)) {
      return;
    }
    final options = [..._settings.receiverOptions, cleanValue];
    final updated = _settings.copyWith(receiverOptions: options);
    await SettingsStore.save(updated, scope: _settingsScope);
    if (mounted) {
      setState(() => _settings = _settings.copyWith(receiverOptions: options));
    }
  }

  Future<void> _addStakeholderSuggestion(
    String role,
    TextEditingController controller,
  ) async {
    final input = TextEditingController(text: controller.text.trim());
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('إضافة مقترح: $role'),
        content: TextField(
          controller: input,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'الاسم'),
          onSubmitted: (value) => Navigator.pop(context, value.trim()),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, input.text.trim()),
            child: const Text('حفظ'),
          ),
        ],
      ),
    );
    input.dispose();
    if (!mounted || value == null || value.trim().isEmpty) return;
    final clean = value.trim();
    final current = _settings.stakeholderOptions[role] ?? const <String>[];
    if (current.contains(clean)) {
      setState(() => controller.text = clean);
      return;
    }
    final updated = _settings.copyWith(
      stakeholderOptions: {
        ..._settings.stakeholderOptions,
        role: [...current, clean],
      },
    );
    await SettingsStore.save(updated, scope: _settingsScope);
    if (mounted) {
      setState(() {
        _settings = updated;
        controller.text = clean;
      });
    }
  }

  Future<void> _openSecondRequest() async {
    final result = await Navigator.of(context).push<ExpenseRequest>(
      MaterialPageRoute<ExpenseRequest>(
        builder: (_) => ExpenseRequestScreen(
          initialRequest: _secondRequest,
          isSecondary: true,
          documentType: widget.documentType,
        ),
      ),
    );
    if (!mounted || result == null) return;
    setState(() => _secondRequest = result);
  }

  void _focusFirstRequest() {
    _formScrollController.animateTo(
      0,
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOut,
    );
  }

  bool _normalizeClearanceAmounts() {
    for (var i = 0; i < _clearanceAmounts.length; i++) {
      final controller = _clearanceAmounts[i];
      if (controller.text.trim().isEmpty) continue;
      try {
        final normalized = ClearanceAmountMath.formatGroupedAmount(
          controller.text,
        );
        controller.value = TextEditingValue(
          text: normalized,
          selection: TextSelection.collapsed(offset: normalized.length),
        );
      } on FormatException {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('مبلغ البند ${i + 1} ليس رقمًا صالحًا')),
        );
        return false;
      }
    }
    return true;
  }

  Future<void> _completeSecondaryRequest() async {
    if (!_validateForOutput()) return;
    Navigator.of(context).pop(_collectRequest());
  }

  bool _validateForOutput() {
    if (!(_formKey.currentState?.validate() ?? false)) {
      _focusFirstRequest();
      return false;
    }
    final dateText = _dateController.text.trim();
    final parsedDate = _parseDate(dateText);
    if (_field('date').visible &&
        dateText.isNotEmpty &&
        (parsedDate == null || _formatDate(parsedDate) != dateText)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'أدخل تاريخاً صحيحاً بصيغة سنة/شهر/يوم مثل 2026/09/26م',
          ),
        ),
      );
      return false;
    }
    if (widget.documentType == ExpenseDocumentType.serviceRequest &&
        _field('reason').visible &&
        _field('reason').required &&
        _reasonController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اختر نوع طلب الخدمة أولاً')),
      );
      return false;
    }
    final amountText = _amountNumberController.text.trim();
    if (_field('amountNumber').visible && amountText.isNotEmpty) {
      try {
        final value = _evaluateAmountExpression(amountText);
        if (!value.isFinite || value < 0) throw const FormatException();
      } on FormatException {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('المبلغ يجب أن يكون رقماً صالحاً')),
        );
        return false;
      }
    }
    if (widget.documentType == ExpenseDocumentType.clearanceRequest &&
        !_normalizeClearanceAmounts()) {
      return false;
    }
    final activeControllers =
        widget.documentType == ExpenseDocumentType.clearanceRequest
        ? <TextEditingController>[
            ..._clearanceAmounts,
            ..._clearanceDates,
            ..._clearanceStatements,
          ]
        : widget.documentType == ExpenseDocumentType.serviceRequest
        ? <TextEditingController>[..._serviceNames]
        : const <TextEditingController>[];
    final structuredLength = activeControllers.fold<int>(
      0,
      (sum, controller) => sum + controller.text.trim().length,
    );
    final maxStructuredCharacters =
        widget.documentType == ExpenseDocumentType.clearanceRequest
        ? 10000
        : _settings.maxStructuredDataCharacters;
    if (structuredLength > maxStructuredCharacters) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'إجمالي بيانات الصفوف يتجاوز الحد المسموح ($maxStructuredCharacters حرفاً)',
          ),
        ),
      );
      return false;
    }
    if (widget.documentType == ExpenseDocumentType.clearanceRequest &&
        _clearanceAmounts.asMap().entries.any(
          (entry) =>
              entry.value.text.trim().isNotEmpty &&
              _clearanceDates[entry.key].text.trim().isEmpty,
        )) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('أدخل تاريخ كل مبلغ في نموذج إخلاء العهدة'),
        ),
      );
      return false;
    }
    if (_formCount == 2 && _secondRequest == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('أدخل بيانات النموذج الثاني أولاً'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return false;
    }
    return true;
  }

  Future<void> _rememberRequester(String name) async {
    final cleanName = name.trim();
    if (cleanName.isEmpty || _settings.requesterHistory.contains(cleanName)) {
      return;
    }
    final history = [
      cleanName,
      ..._settings.requesterHistory,
    ].take(30).toList();
    final updated = _settings.copyWith(requesterHistory: history);
    await SettingsStore.save(updated, scope: _settingsScope);
    if (mounted) setState(() => _settings = updated);
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: _parseDate(_dateController.text) ?? now,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      helpText: 'اختر تاريخ $_documentTitle',
      cancelText: 'إلغاء',
      confirmText: 'اختيار',
      locale: const Locale('ar'),
    );
    if (selected != null) {
      _dateController.text = _formatDate(selected);
    }
  }

  Future<void> _pickCustomDate(TextEditingController controller) async {
    final selected = await showDatePicker(
      context: context,
      initialDate: _parseDate(controller.text) ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      helpText: 'اختيار التاريخ',
      cancelText: 'إلغاء',
      confirmText: 'اختيار',
      locale: const Locale('ar'),
    );
    if (selected == null) return;
    final formatted = _formatDate(selected);
    controller.value = TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }

  DateTime? _parseDate(String value) => DateFormatter.parse(value);

  ExpenseRequest _collectRequest() {
    return ExpenseRequest(
      date: _dateController.text.trim(),
      receiver: _receiverController.text.trim(),
      amountNumber: _amountNumberController.text.trim(),
      amountWords: _amountWordsController.text.trim(),
      reason: _reasonController.text.trim(),
      statement: _statementController.text.trim(),
      branch: _branchController.text.trim(),
      account: _accountController.text.trim(),
      requesterName: _requesterNameController.text.trim(),
      requesterSignature: _requesterSignatureController.text.trim(),
      directManagerName: _directManagerNameController.text.trim(),
      directManagerSignature: _directManagerSignatureController.text.trim(),
      approvedAuthorityName: _approvedAuthorityNameController.text.trim(),
      approvedAuthoritySignature: _approvedAuthoritySignatureController.text
          .trim(),
      accountsManagerName: _accountsManagerNameController.text.trim(),
      accountsManagerSignature: _accountsManagerSignatureController.text.trim(),
      customFields: {
        for (final entry in _customControllers.entries)
          entry.key: entry.value.text.trim(),
        if (widget.documentType == ExpenseDocumentType.serviceRequest)
          'doctorNames': _doctorNamesController.text.trim(),
        if (widget.documentType == ExpenseDocumentType.serviceRequest)
          'worksIn': _worksInController.text.trim(),
        if (widget.documentType == ExpenseDocumentType.serviceRequest)
          'specialty': _specialtyController.text.trim(),
      },
      formCount: _formCount,
      secondRequest: _formCount == 2 ? _secondRequest : null,
      attachmentPath: _attachmentPaths.isEmpty ? null : _attachmentPaths.first,
      attachmentPaths: _attachmentPaths,
      settingsSnapshot: _settings.toMap(),
      documentType: widget.documentType,
      clearanceEntries: [
        for (var i = 0; i < _clearanceAmounts.length; i++)
          if (_clearanceAmounts[i].text.trim().isNotEmpty ||
              _clearanceDates[i].text.trim().isNotEmpty ||
              _clearanceStatements[i].text.trim().isNotEmpty)
            ClearanceEntry(
              amount: _clearanceAmounts[i].text.trim(),
              date: _clearanceDates[i].text.trim(),
              statement: _clearanceStatements[i].text.trim(),
            ),
      ],
      serviceItems: [
        for (var i = 0; i < _serviceNames.length; i++)
          if (_serviceNames[i].text.trim().isNotEmpty)
            ServiceItem(name: _serviceNames[i].text.trim()),
      ],
    );
  }

  Future<void> _saveDraft() async {
    if (!_validateForOutput()) return;
    final request = _collectRequest();
    await _rememberBranch(_branchController.text);
    await _rememberRequester(request.requesterName);
    final editingIndex = widget.editingIndex;
    bool saved;
    if (editingIndex == null) {
      saved = await RequestStore.add(request);
    } else {
      saved = await RequestStore.updateAt(editingIndex, request);
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          !saved
              ? 'لم يتم الحفظ: هذا النموذج مطابق لنموذج محفوظ سابقًا'
              : editingIndex == null
              ? 'تم حفظ الطلب كمسودة'
              : 'تم تحديث النموذج المحفوظ',
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  String _pdfFilename(ExpenseRequest request) {
    final prefix = switch (request.documentType) {
      ExpenseDocumentType.clearanceRequest => 'clearance_request',
      ExpenseDocumentType.serviceRequest => 'service_request',
      ExpenseDocumentType.fuelRequest => 'fuel_request',
      ExpenseDocumentType.customerApplication => 'customer_application',
      ExpenseDocumentType.internalMemo => 'internal_memo',
      ExpenseDocumentType.sampleRequest => 'sample_request',
      ExpenseDocumentType.expenseRequest => 'expense_request',
    };
    final parsedDate = DateFormatter.parse(request.date);
    final filenameDate = parsedDate == null
        ? request.date
        : DateFormatter.date(parsedDate);
    return '${prefix}_${filenameDate.replaceAll('/', '-')}.pdf';
  }

  Future<void> _createAndSharePdf() async {
    if (!_validateForOutput()) return;

    setState(() => _isGeneratingPdf = true);
    var stage = 'التحقق من البيانات';
    try {
      final request = _collectRequest();
      stage = 'إنشاء ملف PDF';
      final bytes = await PdfService.buildRequestPdf(
        request,
        settings: _settings,
      );
      stage = 'فتح نافذة المشاركة';
      await ShareService.sharePdf(
        bytes: bytes,
        filename: _pdfFilename(request),
      );
    } catch (error, stackTrace) {
      debugPrint('Open request share failed at "$stage": $error');
      debugPrintStack(stackTrace: stackTrace);
      _showOutputError(stage: stage, print: false);
    } finally {
      if (mounted) setState(() => _isGeneratingPdf = false);
    }
  }

  Future<void> _savePdfAs() async {
    if (!_validateForOutput()) return;

    setState(() => _isGeneratingPdf = true);
    var stage = 'التحقق من البيانات';
    try {
      final request = _collectRequest();
      stage = 'إنشاء ملف PDF';
      final bytes = await PdfService.buildRequestPdf(
        request,
        settings: _settings,
      );
      stage = 'فتح نافذة الحفظ';
      final uri = await FilePicker.saveFile(
        fileName: _pdfFilename(request),
        bytes: bytes,
        type: FileType.custom,
        allowedExtensions: ['pdf'],
        dialogTitle: 'حفظ $_documentTitle بصيغة PDF',
      );
      if (!mounted || uri == null) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('تم حفظ ملف PDF في: $uri'),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (error, stackTrace) {
      debugPrint('Save PDF as failed at "$stage": $error');
      debugPrintStack(stackTrace: stackTrace);
      _showOutputError(stage: stage, print: false);
    } finally {
      if (mounted) setState(() => _isGeneratingPdf = false);
    }
  }

  Future<void> _previewPdf() async {
    if (!_validateForOutput()) return;
    final request = _collectRequest();
    final settings = _settings;
    if (!mounted) return;
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => Scaffold(
          appBar: AppBar(
            title: Text('معاينة $_documentTitle'),
            actions: [
              IconButton(
                tooltip: 'مشاركة PDF',
                onPressed: _isGeneratingPdf ? null : _createAndSharePdf,
                icon: const Icon(Icons.share_outlined),
              ),
              IconButton(
                tooltip: 'طباعة PDF',
                onPressed: _isGeneratingPdf ? null : _printPdf,
                icon: const Icon(Icons.print_outlined),
              ),
              IconButton(
                tooltip: 'حفظ PDF باسم',
                onPressed: _isGeneratingPdf ? null : _savePdfAs,
                icon: const Icon(Icons.save_alt_outlined),
              ),
              IconButton(
                tooltip: 'ضبط مواضع الحقول',
                onPressed: _openPositionEditor,
                icon: const Icon(Icons.open_with_outlined),
              ),
              IconButton(
                tooltip: 'إعدادات النموذج',
                onPressed: _isGeneratingPdf ? null : _openSettings,
                icon: const Icon(Icons.settings_outlined),
              ),
            ],
          ),
          body: PdfPreview(
            canChangePageFormat: false,
            canChangeOrientation: false,
            build: (_) =>
                PdfService.buildRequestPdf(request, settings: settings),
          ),
        ),
      ),
    );
  }

  Future<void> _openSettings() async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => SettingsScreen(
          templateKind: switch (widget.documentType) {
            ExpenseDocumentType.clearanceRequest =>
              TemplateKind.clearanceRequest,
            ExpenseDocumentType.serviceRequest => TemplateKind.serviceRequest,
            _ => TemplateKind.expenseRequest,
          },
        ),
      ),
    );
    if (!mounted) return;
    final settings = await SettingsStore.load(scope: _settingsScope);
    _syncCustomControllers(settings);
    setState(() => _settings = settings);
  }

  Future<void> _openPositionEditor() async {
    final updated = await Navigator.of(context).push<AppSettings>(
      MaterialPageRoute<AppSettings>(
        builder: (_) => TemplatePreviewScreen(
          settings: _settings,
          templateScope: _settingsScope,
          fullPageForm:
              widget.documentType == ExpenseDocumentType.clearanceRequest ||
              widget.documentType == ExpenseDocumentType.serviceRequest ||
              widget.documentType == ExpenseDocumentType.fuelRequest,
          masterExpenseForm:
              widget.documentType == ExpenseDocumentType.expenseRequest,
          backgroundAsset:
              widget.documentType == ExpenseDocumentType.clearanceRequest
              ? 'assets/images/forms/clearance_request-1.png'
              : widget.documentType == ExpenseDocumentType.serviceRequest
              ? 'assets/images/forms/service_request-1.png'
              : widget.documentType == ExpenseDocumentType.fuelRequest
              ? 'assets/images/forms/fuel_request-1.png'
              : null,
          documentTitle: _documentTitle,
        ),
      ),
    );
    if (updated == null || !mounted) return;
    await SettingsStore.save(updated, scope: _settingsScope);
    setState(() => _settings = updated);
  }

  Future<void> _printPdf() async {
    if (!_validateForOutput()) return;

    setState(() => _isGeneratingPdf = true);
    var stage = 'التحقق من البيانات';
    try {
      final request = _collectRequest();
      stage = 'إنشاء ملف PDF';
      final bytes = await PdfService.buildRequestPdf(
        request,
        settings: _settings,
      );
      stage = 'فتح نافذة الطباعة';
      await ShareService.printPdf(bytes, filename: _pdfFilename(request));
    } catch (error, stackTrace) {
      debugPrint('Open request print failed at "$stage": $error');
      debugPrintStack(stackTrace: stackTrace);
      _showOutputError(stage: stage, print: true);
    } finally {
      if (mounted) setState(() => _isGeneratingPdf = false);
    }
  }

  void _showOutputError({required String stage, required bool print}) {
    if (!mounted) return;
    final message = switch (stage) {
      'إنشاء ملف PDF' =>
        'تعذر إنشاء ملف PDF بسبب إعدادات الحقول أو محتوى الطلب.',
      'فتح نافذة الطباعة' =>
        'تم إنشاء PDF، لكن تعذر فتح نافذة الطباعة. تحقق من خدمة الطباعة.',
      'فتح نافذة المشاركة' =>
        'تم إنشاء PDF، لكن تعذر فتح نافذة المشاركة. حاول مرة أخرى.',
      _ =>
        print
            ? 'تعذرت الطباعة أثناء: $stage. حاول مرة أخرى.'
            : 'تعذرت مشاركة PDF أثناء: $stage. حاول مرة أخرى.',
    };
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.isSecondary
              ? 'بيانات النموذج الثاني'
              : (widget.editingIndex == null
                    ? _documentTitle
                    : 'تعديل $_documentTitle'),
        ),
        actions: [
          IconButton(
            tooltip: 'حفظ الطلب',
            onPressed: _isGeneratingPdf ? null : _saveDraft,
            icon: const Icon(Icons.save_outlined),
          ),
          IconButton(
            tooltip: 'مشاركة PDF',
            onPressed: _isGeneratingPdf ? null : _createAndSharePdf,
            icon: const Icon(Icons.share_outlined),
          ),
          IconButton(
            tooltip: 'معاينة PDF',
            onPressed: _isGeneratingPdf ? null : _previewPdf,
            icon: const Icon(Icons.preview_outlined),
          ),
          IconButton(
            tooltip: 'طباعة PDF',
            onPressed: _isGeneratingPdf ? null : _printPdf,
            icon: const Icon(Icons.print_outlined),
          ),
          IconButton(
            tooltip: 'حفظ PDF باسم',
            onPressed: _isGeneratingPdf ? null : _savePdfAs,
            icon: const Icon(Icons.save_alt_outlined),
          ),
          IconButton(
            tooltip: 'الإعدادات',
            onPressed: _isGeneratingPdf ? null : _openSettings,
            icon: const Icon(Icons.settings_outlined),
          ),
          IconButton(
            tooltip: 'مسح النموذج',
            onPressed: _isGeneratingPdf
                ? null
                : () {
                    _clearForm();
                  },
            icon: const Icon(Icons.refresh_rounded),
          ),
          IconButton(
            tooltip: 'ضبط مواضع الحقول مباشرة',
            onPressed: _isGeneratingPdf ? null : _openPositionEditor,
            icon: const Icon(Icons.open_with_outlined),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1000),
            child: SingleChildScrollView(
              controller: _formScrollController,
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _DocumentHeader(settings: _settings, title: _documentTitle),
                  const SizedBox(height: 16),
                  _buildFormModeSelector(),
                  if (!widget.isSecondary) const SizedBox(height: 16),
                  _buildRequestDetails(),
                  if (!widget.isSecondary &&
                      widget.documentType != ExpenseDocumentType.serviceRequest)
                    _buildApprovals(),
                  if (!widget.isSecondary &&
                      _formCount == 2 &&
                      (!_isSinglePageDocument ||
                          widget.documentType ==
                              ExpenseDocumentType.serviceRequest))
                    _buildFormCopySelector(),
                  if (widget.isSecondary) ...[
                    const SizedBox(height: 16),
                    _buildApprovals(),
                  ],
                  const SizedBox(height: 20),
                  if (widget.isSecondary)
                    FilledButton.icon(
                      onPressed: _completeSecondaryRequest,
                      icon: const Icon(Icons.check_circle_outline),
                      label: const Text('اعتماد بيانات النموذج الثاني'),
                    )
                  else ...[
                    OutlinedButton.icon(
                      onPressed: _saveDraft,
                      icon: const Icon(Icons.save_outlined),
                      label: Text(
                        widget.editingIndex == null
                            ? 'حفظ كمسودة'
                            : 'حفظ تعديلات النموذج',
                      ),
                    ),
                    const SizedBox(height: 8),
                    FilledButton.icon(
                      onPressed: _isGeneratingPdf ? null : _createAndSharePdf,
                      icon: _isGeneratingPdf
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.picture_as_pdf_outlined),
                      label: Text(
                        _isGeneratingPdf
                            ? 'جارٍ إنشاء PDF...'
                            : 'إنشاء ومشاركة PDF',
                      ),
                    ),
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: _isGeneratingPdf ? null : _printPdf,
                      icon: const Icon(Icons.print_outlined),
                      label: const Text('إنشاء PDF وفتح الطباعة'),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      _isSinglePageDocument
                          ? 'سيظهر النموذج في صفحة A4 كاملة.'
                          : _formCount == 1
                          ? 'ستظهر صفحة A4 كاملة: النموذج الأول مع بقاء النصف الثاني فارغًا.'
                          : 'سيظهر نموذجان مستقلان في صفحة A4 واحدة.',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFormModeSelector() {
    if (widget.isSecondary ||
        (_isSinglePageDocument &&
            widget.documentType != ExpenseDocumentType.serviceRequest)) {
      return const SizedBox.shrink();
    }
    return _SectionCard(
      title: 'نوع نموذج PDF',
      icon: Icons.pages_outlined,
      children: [
        DropdownButtonFormField<int>(
          initialValue: _formCount,
          decoration: const InputDecoration(
            labelText: 'عدد النماذج في صفحة A4',
          ),
          isExpanded: true,
          items: const [
            DropdownMenuItem(
              value: 1,
              child: Text(
                'نموذج واحد - صفحة كاملة والنصف الثاني فارغ',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
            DropdownMenuItem(
              value: 2,
              child: Text(
                'نموذجان مستقلان - صفحة A4 كاملة',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
          onChanged: (value) {
            if (value == null) return;
            setState(() {
              _formCount = value;
              if (value == 1) _secondRequest = null;
            });
          },
        ),
        if (_formCount == 2)
          Text(
            _secondRequest == null
                ? 'بعد تعبئة النموذج الأول، استخدم زر النموذج الثاني أسفل البيان.'
                : 'تم اعتماد بيانات النموذج الثاني من زر النموذج السفلي.',
            style: Theme.of(context).textTheme.bodySmall,
          ),
      ],
    );
  }

  Widget _buildFormCopySelector() {
    final hasSecond = _secondRequest != null;
    return Padding(
      padding: const EdgeInsets.only(top: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            'تعبئة نماذج صفحة A4',
            style: Theme.of(
              context,
            ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold),
            textAlign: TextAlign.right,
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _focusFirstRequest,
                  icon: const Icon(Icons.vertical_align_top),
                  label: const Text('النموذج الأول'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _openSecondRequest,
                  icon: Icon(
                    hasSecond
                        ? Icons.edit_note_outlined
                        : Icons.add_box_outlined,
                  ),
                  label: Text(hasSecond ? 'النموذج الثاني' : 'إدخال الثاني'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            hasSecond
                ? 'بيانات النموذجين جاهزة للمعاينة والطباعة.'
                : 'أدخل بيانات النموذج الثاني بعد إكمال النموذج الأول.',
            style: Theme.of(context).textTheme.bodySmall,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  List<String> _receiverChoices() {
    final choices = <String>[
      ...(_settings.stakeholderOptions['المقدم إليه'] ??
          _settings.receiverOptions),
      'أخرى',
    ];
    final current = _receiverController.text.trim();
    if (current.isNotEmpty && !choices.contains(current)) {
      choices.insert(0, current);
    }
    return choices.toSet().toList();
  }

  Widget _buildReceiverField() {
    final current = _receiverController.text.trim();
    final choices = _receiverChoices();
    return DropdownButtonFormField<String>(
      initialValue: current.isEmpty ? null : current,
      isExpanded: true,
      decoration: InputDecoration(labelText: _field('receiver').label),
      hint: const Text('اختر المرسل إليه'),
      items: choices
          .map(
            (item) => DropdownMenuItem<String>(value: item, child: Text(item)),
          )
          .toList(),
      onChanged: (value) {
        if (value == null) return;
        if (value == 'أخرى') {
          _receiverController.clear();
          _chooseOtherReceiver();
        } else {
          setState(() => _receiverController.text = value);
        }
      },
      validator: (value) => _fieldValidator('receiver', value),
    );
  }

  Widget _buildServiceTypeSelector() {
    const options = ['ضيافة', 'دعم نقدي', 'هدية عينية'];
    final selected = _reasonController.text.trim();
    return InputDecorator(
      decoration: InputDecoration(
        labelText: _field('reason').label,
        errorText: _field('reason').required && selected.isEmpty
            ? 'هذا الحقل مطلوب'
            : null,
      ),
      child: Wrap(
        alignment: WrapAlignment.center,
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final option in options)
            ChoiceChip(
              selected: selected == option,
              showCheckmark: false,
              selectedColor: Theme.of(context).colorScheme.primary,
              label: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (selected == option) ...[
                    const Icon(Icons.check, size: 20, color: Colors.white),
                    const SizedBox(width: 4),
                  ],
                  Text(option),
                ],
              ),
              labelStyle: TextStyle(
                color: selected == option
                    ? Colors.white
                    : Theme.of(context).textTheme.bodyMedium?.color,
                fontWeight: selected == option
                    ? FontWeight.bold
                    : FontWeight.normal,
              ),
              onSelected: (_) =>
                  setState(() => _reasonController.text = option),
            ),
        ],
      ),
    );
  }

  List<Widget> _buildServiceExtraFields() {
    if (widget.documentType != ExpenseDocumentType.serviceRequest) {
      return const [];
    }
    Widget multiline(
      String key,
      TextEditingController controller,
      int minLines,
    ) {
      final field = _field(key);
      if (!field.visible) return const SizedBox.shrink();
      return RequestField(
        controller: controller,
        label: field.label,
        maxLength: field.maxLength,
        minLines: minLines,
        maxLines: minLines + 2,
        textInputAction: TextInputAction.next,
        validator: (value) => _fieldValidator(key, value),
      );
    }

    return [
      multiline('doctorNames', _doctorNamesController, 2),
      multiline('worksIn', _worksInController, 2),
      multiline('specialty', _specialtyController, 2),
    ];
  }

  Widget _buildBranchField() {
    final options = _settings.branchOptions;
    return Autocomplete<String>(
      initialValue: TextEditingValue(text: _branchController.text),
      optionsBuilder: (value) {
        final query = value.text.trim().toLowerCase();
        if (query.isEmpty) return options;
        return options.where((item) => item.toLowerCase().contains(query));
      },
      onSelected: (value) => _branchController.text = value,
      fieldViewBuilder: (context, fieldController, focusNode, onSubmitted) {
        if (fieldController.text != _branchController.text) {
          fieldController.text = _branchController.text;
        }
        return TextFormField(
          controller: fieldController,
          focusNode: focusNode,
          maxLength: _field('branch').maxLength,
          decoration: InputDecoration(
            labelText: _field('branch').label,
            suffixIcon: PopupMenuButton<String>(
              tooltip: 'فتح الفروع المحفوظة',
              icon: const Icon(Icons.arrow_drop_down),
              onSelected: (value) {
                fieldController.text = value;
                _branchController.text = value;
                setState(() {});
              },
              itemBuilder: (context) => options
                  .map(
                    (item) =>
                        PopupMenuItem<String>(value: item, child: Text(item)),
                  )
                  .toList(),
            ),
          ),
          textInputAction: TextInputAction.next,
          onChanged: (value) => _branchController.text = value,
          validator: (value) => _fieldValidator('branch', value),
          onFieldSubmitted: (_) => onSubmitted(),
        );
      },
    );
  }

  Widget _buildRequesterField() {
    return _buildStakeholderField(
      role: 'مقدم الطلب',
      controller: _requesterNameController,
      label: 'اسم مقدم الطلب',
      maxLength: _field('requesterName').maxLength,
      validator: (value) => _fieldValidator('requesterName', value),
    );
  }

  Widget _buildStakeholderField({
    required String role,
    required TextEditingController controller,
    required String label,
    required int maxLength,
    String? Function(String?)? validator,
  }) {
    final options = _settings.stakeholderOptions[role] ?? const <String>[];
    return Autocomplete<String>(
      initialValue: TextEditingValue(text: controller.text),
      optionsBuilder: (value) {
        final query = value.text.trim().toLowerCase();
        if (query.isEmpty) return options;
        return options.where((name) => name.toLowerCase().contains(query));
      },
      onSelected: (value) {
        controller.text = value;
        FocusManager.instance.primaryFocus?.unfocus();
      },
      fieldViewBuilder: (context, fieldController, focusNode, onSubmitted) {
        if (fieldController.text != controller.text) {
          fieldController.text = controller.text;
        }
        return TextFormField(
          controller: fieldController,
          focusNode: focusNode,
          maxLength: maxLength,
          decoration: InputDecoration(
            labelText: label,
            suffixIcon: PopupMenuButton<String>(
              tooltip: 'فتح المقترحات المحفوظة',
              icon: const Icon(Icons.arrow_drop_down),
              onSelected: (value) {
                if (value == '__add__') {
                  _addStakeholderSuggestion(role, controller);
                } else {
                  fieldController.text = value;
                  controller.text = value;
                  setState(() {});
                }
              },
              itemBuilder: (context) => [
                ...options.map(
                  (item) =>
                      PopupMenuItem<String>(value: item, child: Text(item)),
                ),
                if (options.isNotEmpty) const PopupMenuDivider(),
                const PopupMenuItem<String>(
                  value: '__add__',
                  child: Text('إضافة مقترح جديد'),
                ),
              ],
            ),
          ),
          textInputAction: TextInputAction.next,
          onChanged: (value) => controller.text = value,
          validator: validator,
          onFieldSubmitted: (_) {
            onSubmitted();
            focusNode.unfocus();
          },
          onTapOutside: (_) => focusNode.unfocus(),
        );
      },
    );
  }

  void _deleteStatement({TextEditingController? target}) {
    final controller = target ?? _statementController;
    final value = controller.value;
    final selection = value.selection;
    if (selection.isValid && !selection.isCollapsed) {
      final start = selection.start < selection.end
          ? selection.start
          : selection.end;
      final end = selection.start < selection.end
          ? selection.end
          : selection.start;
      controller.value = TextEditingValue(
        text: value.text.replaceRange(start, end, ''),
        selection: TextSelection.collapsed(offset: start),
      );
    } else {
      controller.clear();
    }
    setState(() {});
  }

  void _resetStatement({TextEditingController? target}) {
    final controller = target ?? _statementController;
    controller.value = const TextEditingValue(
      text: '',
      selection: TextSelection.collapsed(offset: 0),
      composing: TextRange.empty,
    );
    setState(() {});
  }

  void _deleteStatementBackward({TextEditingController? target}) {
    final controller = target ?? _statementController;
    final value = controller.value;
    final selection = value.selection;
    if (!selection.isValid) return;
    if (!selection.isCollapsed) {
      _deleteStatement(target: controller);
      return;
    }
    if (selection.start == 0) return;
    final start = selection.start - 1;
    controller.value = TextEditingValue(
      text: value.text.replaceRange(start, selection.start, ''),
      selection: TextSelection.collapsed(offset: start),
    );
    setState(() {});
  }

  void _deleteStatementForward({TextEditingController? target}) {
    final controller = target ?? _statementController;
    final value = controller.value;
    final selection = value.selection;
    if (!selection.isValid) return;
    if (!selection.isCollapsed) {
      _deleteStatement(target: controller);
      return;
    }
    if (selection.start >= value.text.length) return;
    controller.value = TextEditingValue(
      text: value.text.replaceRange(selection.start, selection.start + 1, ''),
      selection: selection,
    );
    setState(() {});
  }

  void _startDeleteRepeat(
    TextEditingController target, {
    required bool forward,
  }) {
    _deleteRepeatTimer?.cancel();
    (forward ? _deleteStatementForward : _deleteStatementBackward)(
      target: target,
    );
    Future<void>.delayed(const Duration(milliseconds: 280), () {
      if (!mounted) return;
      _deleteRepeatTimer = Timer.periodic(const Duration(milliseconds: 75), (
        _,
      ) {
        (forward ? _deleteStatementForward : _deleteStatementBackward)(
          target: target,
        );
      });
    });
  }

  void _stopDeleteRepeat() {
    _deleteRepeatTimer?.cancel();
    _deleteRepeatTimer = null;
  }

  Future<void> _insertStatementDate({TextEditingController? target}) async {
    final controller = target ?? _statementController;
    final selected = await showDatePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      initialDate: DateTime.now(),
    );
    if (selected == null || !mounted) return;
    final date = DateFormatter.date(selected);
    final value = controller.value;
    final selection = value.selection;
    final start = selection.isValid ? selection.start : value.text.length;
    final end = selection.isValid ? selection.end : value.text.length;
    final safeStart = start.clamp(0, value.text.length).toInt();
    final safeEnd = end.clamp(safeStart, value.text.length).toInt();
    controller.value = TextEditingValue(
      text: value.text.replaceRange(safeStart, safeEnd, date),
      selection: TextSelection.collapsed(offset: safeStart + date.length),
    );
    setState(() {});
  }

  Future<void> _copyStatement({TextEditingController? target}) async {
    final controller = target ?? _statementController;
    final text = controller.text;
    if (text.trim().isEmpty) {
      _showStatementMessage('لا يوجد بيان لنسخه');
      return;
    }
    await Clipboard.setData(ClipboardData(text: text));
    _showStatementMessage('تم نسخ البيان');
  }

  Future<void> _pasteStatement({TextEditingController? target}) async {
    final controller = target ?? _statementController;
    final data = await Clipboard.getData('text/plain');
    final pasted = data?.text ?? '';
    if (pasted.isEmpty) {
      _showStatementMessage('الحافظة لا تحتوي على نص');
      return;
    }
    final value = controller.value;
    final selection = value.selection;
    final start = selection.isValid ? selection.start : value.text.length;
    final end = selection.isValid ? selection.end : value.text.length;
    final safeStart = start.clamp(0, value.text.length).toInt();
    final safeEnd = end.clamp(safeStart, value.text.length).toInt();
    controller.value = TextEditingValue(
      text: value.text.replaceRange(safeStart, safeEnd, pasted),
      selection: TextSelection.collapsed(offset: safeStart + pasted.length),
    );
    setState(() {});
  }

  Future<void> _insertQuickStatement({TextEditingController? target}) async {
    final controller = target ?? _statementController;
    final selected = await showQuickStatementPicker(
      context,
      scope: _settingsScope,
      query: controller.text,
    );
    if (selected == null || !mounted) return;
    final current = controller.value;
    final selection = current.selection;
    final start = selection.isValid ? selection.start : current.text.length;
    final end = selection.isValid ? selection.end : current.text.length;
    final safeStart = start.clamp(0, current.text.length).toInt();
    final safeEnd = end.clamp(safeStart, current.text.length).toInt();
    controller.value = TextEditingValue(
      text: current.text.replaceRange(safeStart, safeEnd, selected),
      selection: TextSelection.collapsed(offset: safeStart + selected.length),
    );
    setState(() {});
  }

  void _showStatementMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), behavior: SnackBarBehavior.floating),
    );
  }

  Widget _buildStatementField({
    TextEditingController? controller,
    String fieldKey = 'statement',
    String? label,
  }) {
    final target = controller ?? _statementController;
    final field = fieldKey.startsWith('clearanceStatement')
        ? _clearanceField(fieldKey, 'clearanceStatement1')
        : _field(fieldKey);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Wrap(
          alignment: WrapAlignment.end,
          spacing: 2,
          runSpacing: 2,
          children: [
            IconButton(
              tooltip: 'عبارات سريعة',
              visualDensity: VisualDensity.compact,
              onPressed: () => _insertQuickStatement(target: target),
              icon: const Icon(Icons.bolt_outlined),
            ),
            IconButton(
              tooltip: 'إدراج تاريخ في موضع المؤشر',
              visualDensity: VisualDensity.compact,
              onPressed: () => _insertStatementDate(target: target),
              icon: const Icon(Icons.calendar_month_outlined),
            ),
            GestureDetector(
              onLongPressStart: (_) =>
                  _startDeleteRepeat(target, forward: false),
              onLongPressEnd: (_) => _stopDeleteRepeat(),
              onLongPressCancel: _stopDeleteRepeat,
              child: IconButton(
                tooltip: 'حذف للخلف',
                visualDensity: VisualDensity.compact,
                onPressed: () => _deleteStatementBackward(target: target),
                icon: const Icon(Icons.backspace_outlined),
              ),
            ),
            GestureDetector(
              onLongPressStart: (_) =>
                  _startDeleteRepeat(target, forward: true),
              onLongPressEnd: (_) => _stopDeleteRepeat(),
              onLongPressCancel: _stopDeleteRepeat,
              child: IconButton(
                tooltip: 'حذف للأمام',
                visualDensity: VisualDensity.compact,
                onPressed: () => _deleteStatementForward(target: target),
                icon: const Icon(Icons.delete_sweep_outlined),
              ),
            ),
            IconButton(
              tooltip: 'حذف البيان أو النص المحدد',
              visualDensity: VisualDensity.compact,
              onPressed: () => _deleteStatement(target: target),
              icon: const Icon(Icons.delete_outline),
            ),
            IconButton(
              tooltip: 'تصفير البيان',
              visualDensity: VisualDensity.compact,
              onPressed: () => _resetStatement(target: target),
              icon: const Icon(Icons.restart_alt),
            ),
            IconButton(
              tooltip: 'نسخ البيان',
              visualDensity: VisualDensity.compact,
              onPressed: () => _copyStatement(target: target),
              icon: const Icon(Icons.copy_outlined),
            ),
            IconButton(
              tooltip: 'لصق في البيان',
              visualDensity: VisualDensity.compact,
              onPressed: () => _pasteStatement(target: target),
              icon: const Icon(Icons.content_paste_outlined),
            ),
            IconButton(
              tooltip: _statementJustified
                  ? 'إلغاء تنظيم البيان'
                  : 'تنظيم البيان مثل Word',
              visualDensity: VisualDensity.compact,
              color: _statementJustified
                  ? Theme.of(context).colorScheme.primary
                  : null,
              onPressed: () =>
                  setState(() => _statementJustified = !_statementJustified),
              icon: const Icon(Icons.format_align_justify),
            ),
          ],
        ),
        RequestField(
          controller: target,
          label: label ?? field.label,
          maxLength: field.maxLength,
          minLines: 3,
          maxLines: 6,
          textInputAction: TextInputAction.newline,
          textAlign: _statementJustified ? TextAlign.justify : TextAlign.start,
          validator: (value) => _fieldValidator(fieldKey, value),
        ),
      ],
    );
  }

  void _addStructuredRow() {
    final maxRows = widget.documentType == ExpenseDocumentType.clearanceRequest
        ? ExpenseRequest.maxClearanceEntries
        : 6;
    if (_clearanceAmounts.length >= maxRows) return;
    final shouldFocusServiceItem =
        widget.documentType == ExpenseDocumentType.serviceRequest;
    setState(() {
      _clearanceAmounts.add(TextEditingController());
      _clearanceDates.add(TextEditingController());
      _clearanceStatements.add(TextEditingController());
      _serviceNames.add(TextEditingController());
      _serviceQuantities.add(TextEditingController());
      _serviceNotes.add(TextEditingController());
    });
    if (shouldFocusServiceItem) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) {
          FocusScope.of(context).requestFocus(_newServiceItemFocusNode);
        }
      });
    }
  }

  void _removeStructuredRow(int index) {
    if (index <= 0 || index >= _clearanceAmounts.length) return;
    setState(() {
      for (final list in [
        _clearanceAmounts,
        _clearanceDates,
        _clearanceStatements,
        _serviceNames,
        _serviceQuantities,
        _serviceNotes,
      ]) {
        list.removeAt(index).dispose();
      }
    });
  }

  Future<void> _pickStructuredDate(int index) async {
    final selected = await showDatePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      initialDate: DateTime.now(),
    );
    if (selected == null || !mounted) return;
    _clearanceDates[index].text = _formatDate(selected);
    setState(() {});
  }

  Widget _buildClearanceEntries() {
    return _SectionCard(
      title: 'تفاصيل العهدة',
      icon: Icons.table_rows_outlined,
      children: [
        for (var i = 0; i < _clearanceAmounts.length; i++)
          Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          'مجموعة العهدة ${i + 1}',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                      ),
                      if (i > 0)
                        IconButton(
                          tooltip: 'حذف المجموعة',
                          onPressed: () => _removeStructuredRow(i),
                          icon: const Icon(Icons.remove_circle_outline),
                        ),
                    ],
                  ),
                  if (_clearanceField(
                    'clearanceAmount${i + 1}',
                    'clearanceAmount1',
                  ).visible)
                    RequestField(
                      controller: _clearanceAmounts[i],
                      label: 'المبلغ ${i + 1}',
                      maxLength: _clearanceField(
                        'clearanceAmount${i + 1}',
                        'clearanceAmount1',
                      ).maxLength,
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      inputFormatters: [ClearanceAmountInputFormatter()],
                      suffixIcon: IconButton(
                        tooltip: 'آلة حاسبة المبلغ',
                        icon: const Icon(Icons.calculate_outlined),
                        onPressed: () =>
                            _openAmountCalculator(target: _clearanceAmounts[i]),
                      ),
                    ),
                  if (_clearanceField(
                    'clearanceDate${i + 1}',
                    'clearanceDate1',
                  ).visible)
                    RequestField(
                      controller: _clearanceDates[i],
                      label: 'التاريخ ${i + 1}',
                      maxLength: _clearanceField(
                        'clearanceDate${i + 1}',
                        'clearanceDate1',
                      ).maxLength,
                      readOnly: true,
                      hint: 'اضغط لاختيار التاريخ',
                      suffixIcon: const Icon(Icons.calendar_month_outlined),
                      onTap: () => _pickStructuredDate(i),
                    ),
                  if (_clearanceField(
                    'clearanceStatement${i + 1}',
                    'clearanceStatement1',
                  ).visible)
                    _buildStatementField(
                      controller: _clearanceStatements[i],
                      fieldKey: 'clearanceStatement${i + 1}',
                      label: 'البيان ${i + 1}',
                    ),
                ],
              ),
            ),
          ),
        if (_clearanceAmounts.length < ExpenseRequest.maxClearanceEntries)
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: FilledButton.icon(
              onPressed: _addStructuredRow,
              icon: const Icon(Icons.add),
              label: const Text('إضافة مجموعة أخرى'),
            ),
          ),
      ],
    );
  }

  Widget _buildServiceItems() {
    return _SectionCard(
      title: 'أصناف الخدمة',
      icon: Icons.inventory_2_outlined,
      children: [
        for (var i = 0; i < _serviceNames.length; i++)
          Row(
            children: [
              if (_field('serviceItemName${i + 1}').visible)
                Expanded(
                  child: RequestField(
                    controller: _serviceNames[i],
                    label: 'اسم الصنف ${i + 1}',
                    maxLength: _field('serviceItemName${i + 1}').maxLength,
                    focusNode: i == _serviceNames.length - 1
                        ? _newServiceItemFocusNode
                        : null,
                  ),
                ),
              if (i > 0)
                IconButton(
                  tooltip: 'حذف الصف',
                  onPressed: () => _removeStructuredRow(i),
                  icon: const Icon(Icons.remove_circle_outline),
                ),
            ],
          ),
        if (_serviceNames.length < 6)
          Align(
            alignment: AlignmentDirectional.centerStart,
            child: IconButton.filledTonal(
              tooltip: 'إضافة صنف جديد',
              onPressed: _addStructuredRow,
              icon: const Icon(Icons.add),
            ),
          ),
      ],
    );
  }

  Widget _buildServiceRequestDetails() {
    return _SectionCard(
      title: 'بيانات $_documentTitle',
      icon: Icons.description_outlined,
      children: [
        if (_field('date').visible)
          RequestField(
            controller: _dateController,
            label: _field('date').label,
            maxLength: _field('date').maxLength,
            hint: 'اضغط لاختيار التاريخ',
            readOnly: true,
            onTap: _pickDate,
            suffixIcon: const Icon(Icons.calendar_month_outlined),
            textInputAction: TextInputAction.next,
            validator: (value) => _fieldValidator('date', value),
          ),
        if (_field('receiver').visible) _buildReceiverField(),
        if (_field('reason').visible) _buildServiceTypeSelector(),
        ..._buildServiceExtraFields(),
        _buildServiceItems(),
        _buildAttachmentField(),
        if (_field('statement').visible) _buildStatementField(),
        if (_field('amountNumber').visible)
          RequestField(
            controller: _amountNumberController,
            label:
                '${_field('amountNumber').label} (${_settings.currencyName})',
            maxLength: _field('amountNumber').maxLength,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            inputFormatters: [ThousandsSeparatorInputFormatter()],
            suffixIcon: IconButton(
              tooltip: 'آلة حاسبة',
              icon: const Icon(Icons.calculate_outlined),
              onPressed: _openAmountCalculator,
            ),
            textInputAction: TextInputAction.next,
            validator: (value) => _fieldValidator('amountNumber', value),
          ),
        if (_field('amountWords').visible)
          RequestField(
            controller: _amountWordsController,
            label: _field('amountWords').label,
            maxLength: _field('amountWords').maxLength,
            textInputAction: TextInputAction.next,
            validator: (value) => _fieldValidator('amountWords', value),
          ),
        if (_field('branch').visible) _buildBranchField(),
        if (!widget.isSecondary) ...[
          if (_field('requesterName').visible) _buildRequesterField(),
          if (_field('directManagerName').visible)
            _buildStakeholderField(
              role: 'المدير المباشر',
              controller: _directManagerNameController,
              label: _field('directManagerName').label,
              maxLength: _field('directManagerName').maxLength,
              validator: _settings.requireApprovals ? _requiredValidator : null,
            ),
          if (_field('approvedAuthorityName').visible)
            _buildStakeholderField(
              role: 'الجهة المعنية بالاعتماد',
              controller: _approvedAuthorityNameController,
              label: _field('approvedAuthorityName').label,
              maxLength: _field('approvedAuthorityName').maxLength,
              validator: _settings.requireApprovals ? _requiredValidator : null,
            ),
        ],
        ..._buildCustomFields(),
      ],
    );
  }

  Widget _buildRequestDetails() {
    if (widget.documentType == ExpenseDocumentType.serviceRequest) {
      return _buildServiceRequestDetails();
    }
    return _SectionCard(
      title: 'بيانات $_documentTitle',
      icon: Icons.description_outlined,
      children: [
        if (_field('date').visible)
          RequestField(
            controller: _dateController,
            label: _field('date').label,
            maxLength: _field('date').maxLength,
            hint: 'اضغط لاختيار التاريخ',
            readOnly: true,
            onTap: _pickDate,
            suffixIcon: const Icon(Icons.calendar_month_outlined),
            textInputAction: TextInputAction.next,
            validator: (value) => _fieldValidator('date', value),
          ),
        if (_field('receiver').visible) _buildReceiverField(),
        if (_field('amountNumber').visible)
          RequestField(
            controller: _amountNumberController,
            label:
                '${_field('amountNumber').label} (${_settings.currencyName})',
            maxLength: _field('amountNumber').maxLength,
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            inputFormatters: [ThousandsSeparatorInputFormatter()],
            suffixIcon: IconButton(
              tooltip: 'آلة حاسبة',
              icon: const Icon(Icons.calculate_outlined),
              onPressed: _openAmountCalculator,
            ),
            textInputAction: TextInputAction.next,
            validator: (value) => _fieldValidator('amountNumber', value),
          ),
        if (_field('amountWords').visible)
          RequestField(
            controller: _amountWordsController,
            label: _field('amountWords').label,
            maxLength: _field('amountWords').maxLength,
            textInputAction: TextInputAction.next,
            validator: (value) => _fieldValidator('amountWords', value),
          ),
        if (widget.documentType == ExpenseDocumentType.clearanceRequest)
          _buildClearanceEntries(),
        if (widget.documentType == ExpenseDocumentType.serviceRequest)
          _buildServiceItems(),
        _buildAttachmentField(),
        if (_field('reason').visible)
          widget.documentType == ExpenseDocumentType.serviceRequest
              ? _buildServiceTypeSelector()
              : RequestField(
                  controller: _reasonController,
                  label: _field('reason').label,
                  maxLength: _field('reason').maxLength,
                  textInputAction: TextInputAction.next,
                  validator: (value) => _fieldValidator('reason', value),
                ),
        if (_field('statement').visible) _buildStatementField(),
        ..._buildServiceExtraFields(),
        if (_field('branch').visible) _buildBranchField(),
        if (_field('account').visible)
          RequestField(
            controller: _accountController,
            label: _field('account').label,
            maxLength: _field('account').maxLength,
            textInputAction: TextInputAction.next,
            validator: (value) => _fieldValidator('account', value),
          ),
        ..._buildCustomFields(),
      ],
    );
  }

  List<Widget> _buildCustomFields() {
    return _formFields(_settings).entries
        .where((entry) => entry.key.startsWith('custom_'))
        .where((entry) => entry.value.visible)
        .map((entry) {
          final controller = _customControllers[entry.key]!;
          final field = entry.value;
          if (field.inputType == FieldInputType.stakeholder) {
            return _buildStakeholderField(
              role: field.label,
              controller: controller,
              label: field.label,
              maxLength: field.maxLength,
              validator: (value) => _fieldValidator(entry.key, value),
            );
          }
          final isDate = field.inputType == FieldInputType.date;
          return RequestField(
            controller: controller,
            label: field.label,
            maxLength: field.maxLength,
            keyboardType: field.inputType == FieldInputType.amount
                ? const TextInputType.numberWithOptions(decimal: true)
                : null,
            readOnly: isDate,
            onTap: isDate ? () => _pickCustomDate(controller) : null,
            suffixIcon: isDate
                ? const Icon(Icons.calendar_month_outlined)
                : null,
            textInputAction: TextInputAction.next,
            validator: (value) => _fieldValidator(entry.key, value),
          );
        })
        .toList();
  }

  Widget _buildApprovals() {
    final requesterVisible = _field('requesterName').visible;
    final approvalsVisible = [
      'directManagerName',
      'approvedAuthorityName',
      'accountsManagerName',
    ].any((key) => _field(key).visible);
    if (!requesterVisible && !approvalsVisible) {
      return const SizedBox.shrink();
    }
    final approvalsRequired =
        _settings.requireApprovals || _field('signatures').required;

    return _SectionCard(
      title: 'بيانات مقدم الطلب والاعتماد',
      icon: Icons.fact_check_outlined,
      children: [
        if (requesterVisible) _buildRequesterField(),
        if (_field('directManagerName').visible)
          _buildStakeholderField(
            role: 'المدير المباشر',
            controller: _directManagerNameController,
            label: 'المدير المباشر',
            maxLength: _field('directManagerName').maxLength,
            validator: approvalsRequired ? _requiredValidator : null,
          ),
        if (_field('approvedAuthorityName').visible)
          _buildStakeholderField(
            role: 'الجهة المعتمدة',
            controller: _approvedAuthorityNameController,
            label: 'الجهة المعتمدة',
            maxLength: _field('approvedAuthorityName').maxLength,
            validator: approvalsRequired ? _requiredValidator : null,
          ),
        if (_field('accountsManagerName').visible)
          _buildStakeholderField(
            role: 'مدير الحسابات',
            controller: _accountsManagerNameController,
            label: 'مدير الحسابات',
            maxLength: _field('accountsManagerName').maxLength,
            validator: approvalsRequired ? _requiredValidator : null,
          ),
      ],
    );
  }

  Future<void> _clearForm() async {
    final previousAttachments = List<String>.from(_attachmentPaths);
    for (final controller in [
      _receiverController,
      _amountNumberController,
      _amountWordsController,
      _reasonController,
      _statementController,
      _doctorNamesController,
      _worksInController,
      _specialtyController,
      _branchController,
      _accountController,
      _requesterNameController,
      _requesterSignatureController,
      _directManagerNameController,
      _directManagerSignatureController,
      _approvedAuthorityNameController,
      _approvedAuthoritySignatureController,
      _accountsManagerNameController,
      _accountsManagerSignatureController,
    ]) {
      controller.clear();
    }
    for (final controller in _customControllers.values) {
      controller.clear();
    }
    for (final controller in [
      ..._clearanceAmounts,
      ..._clearanceDates,
      ..._clearanceStatements,
      ..._serviceNames,
      ..._serviceQuantities,
      ..._serviceNotes,
    ]) {
      controller.clear();
    }
    _dateController.text = _formatDate(DateTime.now());
    _formCount = 1;
    _secondRequest = null;
    _attachmentPaths = [];
    _formKey.currentState?.reset();
    setState(() {});
    for (final path in previousAttachments) {
      await _deleteAttachmentIfUnused(path);
    }
  }
}

class _DocumentHeader extends StatelessWidget {
  const _DocumentHeader({required this.settings, required this.title});

  final AppSettings settings;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              settings.companyName,
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              title,
              style: Theme.of(
                context,
              ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 8),
            Text(
              'رقم الوثيقة: ${settings.documentNumber}  |  الإصدار: ${settings.issueVersion}  |  تاريخ الإصدار: ${DateFormatter.date(DateFormatter.parse(settings.issueDate)!)}',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodySmall,
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({
    required this.title,
    required this.icon,
    required this.children,
  });

  final String title;
  final IconData icon;
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return Card(
      color: scheme.surface,
      surfaceTintColor: Colors.transparent,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Icon(icon, color: Theme.of(context).colorScheme.primary),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            ..._withSpacing(children),
          ],
        ),
      ),
    );
  }

  List<Widget> _withSpacing(List<Widget> items) {
    final spaced = <Widget>[];
    for (var index = 0; index < items.length; index++) {
      spaced.add(items[index]);
      if (index < items.length - 1) {
        spaced.add(const SizedBox(height: 12));
      }
    }
    return spaced;
  }
}
