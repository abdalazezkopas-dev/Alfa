import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class RequestField extends StatelessWidget {
  const RequestField({
    required this.controller,
    required this.label,
    this.hint,
    this.keyboardType,
    this.minLines,
    this.maxLines = 1,
    this.maxLength,
    this.textInputAction,
    this.validator,
    this.readOnly = false,
    this.textAlign = TextAlign.start,
    this.onTap,
    this.suffixIcon,
    this.inputFormatters,
    this.focusNode,
    super.key,
  });

  final TextEditingController controller;
  final String label;
  final String? hint;
  final TextInputType? keyboardType;
  final int? minLines;
  final int maxLines;
  final int? maxLength;
  final TextInputAction? textInputAction;
  final String? Function(String?)? validator;
  final bool readOnly;
  final TextAlign textAlign;
  final VoidCallback? onTap;
  final Widget? suffixIcon;
  final List<TextInputFormatter>? inputFormatters;
  final FocusNode? focusNode;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final isDark = scheme.brightness == Brightness.dark;
    final borderColor = isDark
        ? const Color(0xFF6D7B80)
        : const Color(0xFFD7DEE2);
    final fillColor =
        theme.inputDecorationTheme.fillColor ??
        (isDark ? const Color(0xFF252B2D) : Colors.white);

    return TextFormField(
      controller: controller,
      focusNode: focusNode,
      inputFormatters: inputFormatters,
      keyboardType: keyboardType,
      minLines: minLines,
      maxLines: maxLines,
      maxLength: maxLength,
      maxLengthEnforcement: maxLength == null
          ? null
          : MaxLengthEnforcement.enforced,
      buildCounter:
          (context, {required currentLength, maxLength, required isFocused}) =>
              maxLength == null
              ? null
              : Text(
                  '$currentLength/$maxLength',
                  style: const TextStyle(fontSize: 10),
                ),
      textInputAction: textInputAction,
      validator: validator,
      readOnly: readOnly,
      textAlign: textAlign,
      onTap: onTap,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        filled: true,
        fillColor: fillColor,
        labelStyle: TextStyle(color: scheme.onSurfaceVariant),
        floatingLabelStyle: TextStyle(color: scheme.primary),
        hintStyle: TextStyle(color: scheme.onSurfaceVariant),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: borderColor, width: 1),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: scheme.primary, width: 2),
        ),
        alignLabelWithHint: maxLines > 1,
        errorStyle: TextStyle(
          color: isDark ? const Color(0xFFFFB4AB) : const Color(0xFFB3261E),
        ),
        suffixIcon: suffixIcon,
      ),
    );
  }
}
