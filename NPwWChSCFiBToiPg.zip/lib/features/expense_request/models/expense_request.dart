import 'dart:convert';

import '../../../core/security/input_limits.dart';
import '../../settings/models/template_configuration.dart';

enum ExpenseDocumentType {
  expenseRequest,
  internalMemo,
  customerApplication,
  clearanceRequest,
  serviceRequest,
  fuelRequest,
  sampleRequest,
}

class ClearanceEntry {
  const ClearanceEntry({
    required this.amount,
    required this.date,
    required this.statement,
  });

  final String amount;
  final String date;
  final String statement;

  Map<String, Object?> toMap() => {
    'amount': amount,
    'date': date,
    'statement': statement,
  };

  factory ClearanceEntry.fromMap(Map<String, Object?> map) => ClearanceEntry(
    amount: InputLimits.string(map['amount']),
    date: InputLimits.string(map['date'], maxLength: 64),
    statement: InputLimits.string(
      map['statement'],
      maxLength: InputLimits.maxLongTextLength,
    ),
  );
}

class ServiceItem {
  const ServiceItem({required this.name, this.quantity = '', this.notes = ''});

  final String name;
  final String quantity;
  final String notes;

  Map<String, Object?> toMap() => {
    'name': name,
    'quantity': quantity,
    'notes': notes,
  };

  factory ServiceItem.fromMap(Map<String, Object?> map) => ServiceItem(
    name: InputLimits.string(map['name']),
    quantity: InputLimits.string(map['quantity'], maxLength: 64),
    notes: InputLimits.string(
      map['notes'],
      maxLength: InputLimits.maxLongTextLength,
    ),
  );
}

class FuelEntry {
  const FuelEntry({
    required this.date,
    required this.meter,
    required this.liters,
    required this.literPrice,
    required this.fuelAmount,
    required this.collection,
    this.sales = '',
    this.route = '',
  });

  final String date;
  final String meter;
  final String liters;
  final String literPrice;
  final String fuelAmount;
  final String collection;
  final String sales;
  final String route;

  Map<String, Object?> toMap() => {
    'date': date,
    'meter': meter,
    'liters': liters,
    'literPrice': literPrice,
    'fuelAmount': fuelAmount,
    'collection': collection,
    'sales': sales,
    'route': route,
  };

  factory FuelEntry.fromMap(Map<String, Object?> map) => FuelEntry(
    date: InputLimits.string(map['date'], maxLength: 10),
    meter: InputLimits.string(map['meter'], maxLength: 32),
    liters: InputLimits.string(map['liters'], maxLength: 32),
    literPrice: InputLimits.string(map['literPrice'], maxLength: 32),
    fuelAmount: InputLimits.string(map['fuelAmount'], maxLength: 32),
    collection: InputLimits.string(map['collection'], maxLength: 32),
    sales: InputLimits.string(map['sales'], maxLength: 32),
    route: InputLimits.string(map['route'], maxLength: 80),
  );
}

class SampleItem {
  const SampleItem({
    required this.productId,
    required this.productName,
    this.pharmaceuticalForm = '',
    this.quantityNumber = '',
    this.quantityWords = '',
    this.notes = '',
  });

  final String productId;
  final String productName;
  final String pharmaceuticalForm;
  final String quantityNumber;
  final String quantityWords;
  final String notes;

  Map<String, Object?> toMap() => {
    'productId': productId,
    'productName': productName,
    'pharmaceuticalForm': pharmaceuticalForm,
    'quantityNumber': quantityNumber,
    'quantityWords': quantityWords,
    'notes': notes,
  };

  factory SampleItem.fromMap(Map<String, Object?> map) => SampleItem(
    productId: InputLimits.string(map['productId'], maxLength: 128),
    productName: InputLimits.string(map['productName'], maxLength: 240),
    pharmaceuticalForm: InputLimits.string(
      map['pharmaceuticalForm'],
      maxLength: 120,
    ),
    quantityNumber: InputLimits.string(map['quantityNumber'], maxLength: 64),
    quantityWords: InputLimits.string(map['quantityWords'], maxLength: 120),
    notes: InputLimits.string(
      map['notes'],
      maxLength: InputLimits.maxLongTextLength,
    ),
  );
}

class ExpenseRequest {
  static const int maxClearanceEntries = 500;

  const ExpenseRequest({
    required this.date,
    required this.receiver,
    required this.amountNumber,
    required this.amountWords,
    required this.reason,
    required this.statement,
    required this.branch,
    required this.account,
    required this.requesterName,
    required this.requesterSignature,
    required this.directManagerName,
    required this.directManagerSignature,
    required this.approvedAuthorityName,
    required this.approvedAuthoritySignature,
    required this.accountsManagerName,
    required this.accountsManagerSignature,
    this.customFields = const {},
    this.formCount = 1,
    this.secondRequest,
    this.isFavorite = false,
    this.attachmentPath,
    this.attachmentPaths = const [],
    this.settingsSnapshot = const {},
    this.documentType = ExpenseDocumentType.expenseRequest,
    this.clearanceEntries = const [],
    this.serviceItems = const [],
    this.fuelEntries = const [],
    this.sampleItems = const [],
    this.memoLayout = InternalMemoLayout.fullA4,
  });

  final String date;
  final String receiver;
  final String amountNumber;
  final String amountWords;
  final String reason;
  final String statement;
  final String branch;
  final String account;
  final String requesterName;
  final String requesterSignature;
  final String directManagerName;
  final String directManagerSignature;
  final String approvedAuthorityName;
  final String approvedAuthoritySignature;
  final String accountsManagerName;
  final String accountsManagerSignature;
  final Map<String, String> customFields;
  final int formCount;
  final ExpenseRequest? secondRequest;
  final bool isFavorite;
  final String? attachmentPath;
  final List<String> attachmentPaths;
  final Map<String, Object?> settingsSnapshot;
  final ExpenseDocumentType documentType;
  final InternalMemoLayout memoLayout;
  final List<ClearanceEntry> clearanceEntries;
  final List<ServiceItem> serviceItems;
  final List<FuelEntry> fuelEntries;
  final List<SampleItem> sampleItems;

  bool get hasSecondRequest => formCount > 1 && secondRequest != null;

  /// Includes the legacy single attachment path for backward compatibility.
  List<String> get allAttachmentPaths => <String>{
    if (attachmentPath != null && attachmentPath!.trim().isNotEmpty)
      attachmentPath!,
    ...attachmentPaths.where((path) => path.trim().isNotEmpty),
  }.toList(growable: false);

  Map<String, Object?> toMap() {
    return {
      'date': date,
      'receiver': receiver,
      'amountNumber': amountNumber,
      'amountWords': amountWords,
      'reason': reason,
      'statement': statement,
      'branch': branch,
      'account': account,
      'requesterName': requesterName,
      'requesterSignature': requesterSignature,
      'directManagerName': directManagerName,
      'directManagerSignature': directManagerSignature,
      'approvedAuthorityName': approvedAuthorityName,
      'approvedAuthoritySignature': approvedAuthoritySignature,
      'accountsManagerName': accountsManagerName,
      'accountsManagerSignature': accountsManagerSignature,
      'customFields': jsonEncode(customFields),
      'formCount': formCount,
      'secondRequest': secondRequest?.toMap(),
      'isFavorite': isFavorite,
      'attachmentPath': attachmentPath,
      'attachmentPaths': attachmentPaths,
      'settingsSnapshot': settingsSnapshot,
      'documentType': documentType.name,
      'memoLayout': memoLayout.name,
      'clearanceEntries': clearanceEntries
          .map((entry) => entry.toMap())
          .toList(),
      'serviceItems': serviceItems.map((item) => item.toMap()).toList(),
      'fuelEntries': fuelEntries.map((item) => item.toMap()).toList(),
      'sampleItems': sampleItems.map((item) => item.toMap()).toList(),
    };
  }

  factory ExpenseRequest.fromMap(Map<String, Object?> map, {int depth = 0}) {
    String value(String key) => InputLimits.string(map[key]);

    final nested = map['secondRequest'];
    final second = nested is Map && depth < 1
        ? ExpenseRequest.fromMap(
            Map<String, Object?>.from(nested),
            depth: depth + 1,
          )
        : null;

    return ExpenseRequest(
      date: InputLimits.string(map['date'], maxLength: 64),
      receiver: value('receiver'),
      amountNumber: value('amountNumber'),
      amountWords: value('amountWords'),
      reason: value('reason'),
      statement: value('statement'),
      branch: value('branch'),
      account: value('account'),
      requesterName: value('requesterName'),
      requesterSignature: value('requesterSignature'),
      directManagerName: value('directManagerName'),
      directManagerSignature: value('directManagerSignature'),
      approvedAuthorityName: value('approvedAuthorityName'),
      approvedAuthoritySignature: value('approvedAuthoritySignature'),
      accountsManagerName: value('accountsManagerName'),
      accountsManagerSignature: value('accountsManagerSignature'),
      customFields: _customFieldsFromMap(map['customFields']),
      formCount:
          InputLimits.integer(map['formCount'], min: 1, max: 2) == 2 &&
              second != null
          ? 2
          : 1,
      secondRequest: second,
      isFavorite: map['isFavorite'] == true,
      attachmentPath:
          InputLimits.string(
            map['attachmentPath'],
            maxLength: InputLimits.maxAttachmentPathLength,
          ).trim().isEmpty
          ? null
          : InputLimits.string(
              map['attachmentPath'],
              maxLength: InputLimits.maxAttachmentPathLength,
            ),
      attachmentPaths: _attachmentPathsFromMap(map['attachmentPaths']),
      settingsSnapshot: map['settingsSnapshot'] is Map
          ? Map<String, Object?>.from(map['settingsSnapshot'] as Map)
          : const {},
      documentType: ExpenseDocumentType.values.firstWhere(
        (value) => value.name == map['documentType'],
        orElse: () => ExpenseDocumentType.expenseRequest,
      ),
      clearanceEntries: _clearanceEntriesFromMap(map['clearanceEntries']),
      serviceItems: _serviceItemsFromMap(map['serviceItems']),
      fuelEntries: _fuelEntriesFromMap(map['fuelEntries']),
      sampleItems: _sampleItemsFromMap(map['sampleItems']),
      memoLayout: InternalMemoLayout.values.firstWhere(
        (value) => value.name == map['memoLayout'],
        // Keep legacy enum support while using A4 as the safe current fallback.
        orElse: () => InternalMemoLayout.fullA4,
      ),
    );
  }

  /// Parses persisted/imported records without silently truncating fields or
  /// dropping malformed nested items. [fromMap] remains the compatibility
  /// parser used by existing UI paths.
  static ExpenseRequest fromMapStrict(
    Map<String, Object?> map, {
    int depth = 0,
  }) {
    void text(String key, {int maxLength = InputLimits.maxShortTextLength}) {
      if (map.containsKey(key)) {
        InputLimits.strictString(map[key], field: key, maxLength: maxLength);
      }
    }

    text('date', maxLength: 64);
    for (final key in const [
      'receiver',
      'amountNumber',
      'amountWords',
      'reason',
      'statement',
      'branch',
      'account',
      'requesterName',
      'requesterSignature',
      'directManagerName',
      'directManagerSignature',
      'approvedAuthorityName',
      'approvedAuthoritySignature',
      'accountsManagerName',
      'accountsManagerSignature',
    ]) {
      text(key);
    }
    if (map.containsKey('customFields'))
      _validateCustomFields(map['customFields']);
    if (map.containsKey('formCount')) {
      InputLimits.strictInteger(
        map['formCount'],
        field: 'formCount',
        min: 1,
        max: 2,
      );
    }
    for (final key in const ['isFavorite']) {
      if (map.containsKey(key)) InputLimits.strictBool(map[key], field: key);
    }
    if (map.containsKey('attachmentPath') && map['attachmentPath'] != null) {
      InputLimits.strictString(
        map['attachmentPath'],
        field: 'attachmentPath',
        maxLength: InputLimits.maxAttachmentPathLength,
      );
    }
    _validateStringList(
      map['attachmentPaths'],
      field: 'attachmentPaths',
      maxLength: InputLimits.maxAttachmentPathLength,
      limit: 500,
    );
    if (map.containsKey('settingsSnapshot') &&
        map['settingsSnapshot'] != null) {
      InputLimits.strictMap(map['settingsSnapshot'], field: 'settingsSnapshot');
    }
    if (map.containsKey('documentType')) {
      final value = InputLimits.strictString(
        map['documentType'],
        field: 'documentType',
        maxLength: 64,
      );
      if (!ExpenseDocumentType.values.any((item) => item.name == value)) {
        throw const FormatException('نوع مستند الطلب غير صالح');
      }
    }
    if (map.containsKey('memoLayout')) {
      final value = InputLimits.strictString(
        map['memoLayout'],
        field: 'memoLayout',
        maxLength: 64,
      );
      if (!InternalMemoLayout.values.any((item) => item.name == value)) {
        throw const FormatException('تخطيط المذكرة غير صالح');
      }
    }
    _validateMapList(
      map['clearanceEntries'],
      field: 'clearanceEntries',
      limit: maxClearanceEntries,
      validate: (item) {
        _validateText(item, 'amount', maxLength: 512);
        _validateText(item, 'date', maxLength: 64);
        _validateText(
          item,
          'statement',
          maxLength: InputLimits.maxLongTextLength,
        );
      },
    );
    _validateMapList(
      map['serviceItems'],
      field: 'serviceItems',
      limit: 100,
      validate: (item) {
        _validateText(item, 'name');
        _validateText(item, 'quantity', maxLength: 64);
        _validateText(item, 'notes', maxLength: InputLimits.maxLongTextLength);
      },
    );
    _validateMapList(
      map['fuelEntries'],
      field: 'fuelEntries',
      limit: 50,
      validate: (item) {
        for (final key in const [
          'date',
          'meter',
          'liters',
          'literPrice',
          'fuelAmount',
          'collection',
          'sales',
        ]) {
          _validateText(item, key, maxLength: key == 'date' ? 10 : 32);
        }
        _validateText(item, 'route', maxLength: 80);
      },
    );
    _validateMapList(
      map['sampleItems'],
      field: 'sampleItems',
      limit: 100,
      validate: (item) {
        _validateText(item, 'productId', maxLength: 128);
        _validateText(item, 'productName', maxLength: 240);
        _validateText(item, 'pharmaceuticalForm', maxLength: 120);
        _validateText(item, 'quantityNumber', maxLength: 64);
        _validateText(item, 'quantityWords', maxLength: 120);
        _validateText(item, 'notes', maxLength: InputLimits.maxLongTextLength);
      },
    );
    if (map.containsKey('secondRequest') && map['secondRequest'] != null) {
      if (depth >= 1 || map['secondRequest'] is! Map) {
        throw const FormatException('الطلب المتداخل غير صالح');
      }
      fromMapStrict(
        Map<String, Object?>.from(map['secondRequest'] as Map),
        depth: depth + 1,
      );
    }
    return ExpenseRequest.fromMap(map, depth: depth);
  }

  static void _validateText(
    Map<String, Object?> map,
    String key, {
    int maxLength = InputLimits.maxShortTextLength,
  }) {
    if (map.containsKey(key)) {
      InputLimits.strictString(map[key], field: key, maxLength: maxLength);
    }
  }

  static void _validateStringList(
    Object? value, {
    required String field,
    required int maxLength,
    required int limit,
  }) {
    if (value == null) return;
    for (final item in InputLimits.strictList(
      value,
      field: field,
      maxLength: limit,
    )) {
      InputLimits.strictString(item, field: field, maxLength: maxLength);
    }
  }

  static void _validateMapList(
    Object? value, {
    required String field,
    required int limit,
    required void Function(Map<String, Object?>) validate,
  }) {
    if (value == null) return;
    for (final item in InputLimits.strictList(
      value,
      field: field,
      maxLength: limit,
    )) {
      final map = InputLimits.strictMap(item, field: field);
      validate(map);
    }
  }

  static void _validateCustomFields(Object? value) {
    Object? decoded = value;
    if (value is String) {
      try {
        decoded = jsonDecode(value);
      } catch (_) {
        throw const FormatException('الحقول المخصصة غير صحيحة');
      }
    }
    final map = InputLimits.strictMap(decoded, field: 'customFields');
    if (map.length > InputLimits.maxCustomFields) {
      throw const FormatException('الحقول المخصصة تتجاوز الحد المسموح');
    }
    for (final entry in map.entries) {
      InputLimits.strictString(
        entry.key,
        field: 'customFields.key',
        maxLength: InputLimits.maxCustomFieldKeyLength,
      );
      InputLimits.strictString(entry.value, field: 'customFields.value');
    }
  }

  static List<String> _attachmentPathsFromMap(Object? value) {
    if (value is! List) return const [];
    return value
        .map(
          (item) => InputLimits.string(
            item,
            maxLength: InputLimits.maxAttachmentPathLength,
          ).trim(),
        )
        .where((path) => path.isNotEmpty)
        .toSet()
        .toList(growable: false);
  }

  static List<ClearanceEntry> _clearanceEntriesFromMap(Object? value) {
    return InputLimits.list(
          value,
          maxLength: ExpenseRequest.maxClearanceEntries,
        )
        .whereType<Map>()
        .map((item) => ClearanceEntry.fromMap(Map<String, Object?>.from(item)))
        .toList();
  }

  static List<ServiceItem> _serviceItemsFromMap(Object? value) {
    return InputLimits.list(value, maxLength: 100)
        .whereType<Map>()
        .map((item) => ServiceItem.fromMap(Map<String, Object?>.from(item)))
        .toList();
  }

  static List<FuelEntry> _fuelEntriesFromMap(Object? value) {
    return InputLimits.list(value, maxLength: 50)
        .whereType<Map>()
        .map((item) => FuelEntry.fromMap(Map<String, Object?>.from(item)))
        .toList();
  }

  static List<SampleItem> _sampleItemsFromMap(Object? value) {
    return InputLimits.list(value, maxLength: 100)
        .whereType<Map>()
        .map((item) => SampleItem.fromMap(Map<String, Object?>.from(item)))
        .where((item) => item.productName.trim().isNotEmpty)
        .toList();
  }

  static Map<String, String> _customFieldsFromMap(Object? value) {
    if (value is String) {
      try {
        final decoded = jsonDecode(value);
        if (decoded is Map) {
          return decoded.entries
              .take(InputLimits.maxCustomFields)
              .where((entry) => entry.key is String)
              .fold<Map<String, String>>({}, (result, entry) {
                final key = InputLimits.string(
                  entry.key,
                  maxLength: InputLimits.maxCustomFieldKeyLength,
                );
                if (key.isNotEmpty) {
                  result[key] = InputLimits.string(entry.value);
                }
                return result;
              });
        }
      } catch (_) {
        return {};
      }
    }
    if (value is Map) {
      return value.entries
          .take(InputLimits.maxCustomFields)
          .where((entry) => entry.key is String)
          .fold<Map<String, String>>({}, (result, entry) {
            final key = InputLimits.string(
              entry.key,
              maxLength: InputLimits.maxCustomFieldKeyLength,
            );
            if (key.isNotEmpty) result[key] = InputLimits.string(entry.value);
            return result;
          });
    }
    return {};
  }
}
