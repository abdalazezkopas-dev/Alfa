class AmountToWords {
  const AmountToWords._();

  static const _ones = <String>[
    'صفر',
    'واحد',
    'اثنان',
    'ثلاثة',
    'أربعة',
    'خمسة',
    'ستة',
    'سبعة',
    'ثمانية',
    'تسعة',
    'عشرة',
    'أحد عشر',
    'اثنا عشر',
    'ثلاثة عشر',
    'أربعة عشر',
    'خمسة عشر',
    'ستة عشر',
    'سبعة عشر',
    'ثمانية عشر',
    'تسعة عشر',
  ];

  static const _tens = <String>[
    '',
    '',
    'عشرون',
    'ثلاثون',
    'أربعون',
    'خمسون',
    'ستون',
    'سبعون',
    'ثمانون',
    'تسعون',
  ];

  static const _hundreds = <String>[
    '',
    'مائة',
    'مائتان',
    'ثلاثمائة',
    'أربعمائة',
    'خمسمائة',
    'ستمائة',
    'سبعمائة',
    'ثمانمائة',
    'تسعمائة',
  ];

  static const _scales = <_Scale>[
    _Scale('', '', '', ''),
    _Scale('ألف', 'ألفان', 'آلاف', 'ألف'),
    _Scale('مليون', 'مليونان', 'ملايين', 'مليون'),
    _Scale('مليار', 'ملياران', 'مليارات', 'مليار'),
    _Scale('تريليون', 'تريليونان', 'تريليونات', 'تريليون'),
  ];

  static String formatNumber(String input) {
    final normalized = _normalizeDigits(
      input,
    ).replaceAll(',', '').replaceAll('٬', '').replaceAll('٫', '.');
    if (normalized.isEmpty) return input;
    final parts = normalized.split('.');
    if (parts.length > 2 || !RegExp(r'^\d+$').hasMatch(parts.first)) {
      return input;
    }
    if (parts.length == 2 && !RegExp(r'^\d{0,2}$').hasMatch(parts[1])) {
      return input;
    }
    final grouped = parts.first.replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (match) => ',',
    );
    return parts.length == 2 ? '$grouped.${parts[1]}' : grouped;
  }

  static String fromNumber(String input) {
    final normalized = _normalizeDigits(
      input,
    ).replaceAll(',', '').replaceAll('٬', '').replaceAll('٫', '.');
    final parts = normalized.split('.');
    if (parts.length > 2 || normalized.trim().isEmpty) return '';

    final whole = int.tryParse(parts.first.trim());
    if (whole == null || whole < 0) return '';

    var fraction = 0;
    if (parts.length == 2) {
      final fractionText = parts[1].trim();
      if (fractionText.isNotEmpty &&
          !RegExp(r'^\d{1,2}$').hasMatch(fractionText)) {
        return '';
      }
      final padded = fractionText.padRight(2, '0');
      fraction = int.tryParse(padded) ?? 0;
    }

    if (whole == 0 && fraction == 0) {
      return 'صفر ريال';
    }

    final result = <String>[];
    if (whole > 0) {
      // Handle one and two directly so the currency is not repeated:
      // "ريال واحد" instead of the incorrect "واحد ريال واحد".
      result.add(_wholeAmountWords(whole));
    }
    if (fraction > 0) {
      result.add(_fractionWords(fraction));
    }
    return result.join(' و');
  }

  static String _normalizeDigits(String value) {
    const arabic = '٠١٢٣٤٥٦٧٨٩';
    const eastern = '۰۱۲۳۴۵۶۷۸۹';
    final output = StringBuffer();
    for (final character in value.trim().runes) {
      final symbol = String.fromCharCode(character);
      final arabicIndex = arabic.indexOf(symbol);
      final easternIndex = eastern.indexOf(symbol);
      if (arabicIndex >= 0) {
        output.write(arabicIndex);
      } else if (easternIndex >= 0) {
        output.write(easternIndex);
      } else {
        output.write(symbol);
      }
    }
    return output.toString();
  }

  static String _integerToWords(int number) {
    if (number == 0) return 'صفر';

    var remaining = number;
    var scaleIndex = 0;
    final groups = <String>[];
    while (remaining > 0) {
      final group = remaining % 1000;
      if (group > 0) {
        groups.insert(0, _groupToWords(group, scaleIndex));
      }
      remaining ~/= 1000;
      scaleIndex++;
    }
    return groups.join(' و');
  }

  static String _groupToWords(int group, int scaleIndex) {
    final words = _underThousand(group);
    if (scaleIndex == 0) return words;

    final scale = _scales[scaleIndex.clamp(0, _scales.length - 1)];
    if (group == 1) return scale.singular;
    if (group == 2) return scale.dual;
    if (group <= 10) return '$words ${scale.plural}';
    return '$words ${scale.accusative}';
  }

  static String _underThousand(int number) {
    if (number < 20) return _ones[number];

    final hundreds = number ~/ 100;
    final remainder = number % 100;
    final parts = <String>[];
    if (hundreds > 0) parts.add(_hundreds[hundreds]);
    if (remainder > 0) parts.add(_underHundred(remainder));
    return parts.join(' و');
  }

  static String _underHundred(int number) {
    if (number < 20) return _ones[number];
    final ones = number % 10;
    final tens = number ~/ 10;
    if (ones == 0) return _tens[tens];
    return '${_ones[ones]} و${_tens[tens]}';
  }

  static String _wholeAmountWords(int number) {
    if (number == 1) return 'ريال واحد';
    if (number == 2) return 'ريالان';
    return '${_integerToWords(number)} ${_riyalWords(number)}';
  }

  static String _riyalWords(int number) {
    if (number >= 3 && number <= 10) return 'ريالات';
    return 'ريال';
  }

  static String _fractionWords(int fraction) {
    final words = _underThousand(fraction);
    if (fraction == 1) return 'فلس واحد';
    if (fraction == 2) return 'فلسان';
    if (fraction >= 3 && fraction <= 10) return '$words فلوس';
    return '$words فلس';
  }
}

class _Scale {
  const _Scale(this.singular, this.dual, this.plural, this.accusative);

  final String singular;
  final String dual;
  final String plural;
  final String accusative;
}
