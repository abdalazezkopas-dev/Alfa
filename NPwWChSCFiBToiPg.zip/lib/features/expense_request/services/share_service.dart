import 'dart:typed_data';

import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';

class ShareService {
  const ShareService._();

  static Future<void> sharePdf({
    required Uint8List bytes,
    required String filename,
    String subject = 'طلب صرف',
    String body = 'مرفق ملف طلب الصرف بصيغة PDF',
  }) async {
    _ensurePdfBytes(bytes);
    await Printing.sharePdf(
      bytes: bytes,
      filename: _safeFilename(filename),
      subject: subject,
      body: body,
    );
  }

  static Future<void> printPdf(
    Uint8List bytes, {
    String filename = 'expense_request.pdf',
    PdfPageFormat format = PdfPageFormat.a4,
  }) async {
    _ensurePdfBytes(bytes);
    await Printing.layoutPdf(
      name: _safeFilename(filename),
      format: format,
      dynamicLayout: false,
      onLayout: (_) async => bytes,
    );
  }

  static void _ensurePdfBytes(Uint8List bytes) {
    if (bytes.isEmpty) {
      throw StateError('تعذر إنشاء ملف PDF فارغ');
    }
  }

  static String _safeFilename(String filename) {
    var safe = filename.replaceAll(RegExp(r'[\\/:*?"<>|\r\n]'), '_').trim();
    if (safe.isEmpty) safe = 'expense_request';
    if (!safe.toLowerCase().endsWith('.pdf')) safe = '$safe.pdf';
    return safe;
  }
}
