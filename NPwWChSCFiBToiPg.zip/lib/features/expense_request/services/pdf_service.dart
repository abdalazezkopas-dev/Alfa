import 'dart:io';

import '../../../core/utils/date_formatter.dart';
import '../../../core/utils/number_normalizer.dart';

import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../../settings/models/app_settings.dart';
import '../../settings/models/template_geometry.dart';
import '../models/expense_request.dart';
import '../utils/clearance_amount_math.dart';
import 'pdf_text_sanitizer.dart';

class _ClearancePdfFragment {
  const _ClearancePdfFragment({
    required this.startsEntry,
    required this.amount,
    required this.date,
    required this.amountMinor,
    required this.statement,
  });

  final bool startsEntry;
  final String amount;
  final String date;
  final BigInt amountMinor;
  final String statement;
}

class PdfService {
  const PdfService._();

  // The ISO artwork leaves an 11.3-point separator between the two copies.
  // Therefore the second copy starts at the first header position plus the
  // actual artwork height: 427.55 - 17.258 = 410.292 points.
  static const double expenseRequestTemplateOffset = 410.292;

  static const PdfColor deepNavy = PdfColor.fromInt(0xFF0F2942);
  static const PdfColor midnightBlue = PdfColor.fromInt(0xFF1E3A8A);
  static const PdfColor charcoalBlack = PdfColor.fromInt(0xFF1A1D20);
  static const PdfColor steelCyan = PdfColor.fromInt(0xFF0369A1);
  static const int sampleRequestMaxItems = 53;
  static const int sampleRequestSinglePageMaxItems = 25;

  static List<pw.Widget> _serviceTypeCheckmark(
    String reason,
    AppSettings settings,
  ) {
    const keys = <String, String>{
      'ضيافة': 'serviceTypeHospitality',
      'دعم نقدي': 'serviceTypeCashSupport',
      'هدية عينية': 'serviceTypeInKindGift',
    };
    final key = keys[reason.trim()];
    if (key == null) return const <pw.Widget>[];
    final field = settings.fieldSettings[key];
    if (field?.visible == false) return const <pw.Widget>[];
    final base = TemplateGeometry.forScope('serviceRequest')[key];
    if (base == null) return const <pw.Widget>[];
    final left = field?.geometryConfigured == true ? field!.x : base.x;
    final top = field?.geometryConfigured == true ? field!.y : base.y;
    return [
      pw.Positioned(
        left: left,
        top: top,
        child: pw.CustomPaint(
          size: const PdfPoint(18, 18),
          painter: (canvas, size) {
            canvas
              ..setStrokeColor(
                PdfColor.fromInt(field?.colorValue ?? 0xFF221BB9),
              )
              ..setLineWidth(2.2)
              ..moveTo(2, 9)
              ..lineTo(7, 4)
              ..lineTo(16, 15)
              ..strokePath();
          },
        ),
      ),
    ];
  }

  static pw.Widget _sampleUsageCheckmark(
    FieldSetting field,
    TemplateGeometry box,
    PdfColor color,
  ) {
    final width = (field.geometryConfigured ? field.width : box.width)
        .clamp(1.0, PdfPageFormat.letter.width)
        .toDouble();
    final height = (field.geometryConfigured ? field.height : box.height)
        .clamp(1.0, PdfPageFormat.letter.height)
        .toDouble();
    final left = (field.geometryConfigured ? field.x : box.x)
        .clamp(0.0, PdfPageFormat.letter.width - width)
        .toDouble();
    final top = (field.geometryConfigured ? field.y : box.y)
        .clamp(0.0, PdfPageFormat.letter.height - 1.0)
        .toDouble();
    final strokeWidth = (width < height ? width : height) * 0.10;
    return pw.Positioned(
      left: left,
      top: top,
      child: pw.CustomPaint(
        size: PdfPoint(width, height),
        painter: (canvas, _) {
          canvas
            ..setStrokeColor(color)
            ..setLineWidth(strokeWidth.clamp(1.5, 3.5).toDouble())
            ..moveTo(width * 0.16, height * 0.52)
            ..lineTo(width * 0.40, height * 0.76)
            ..lineTo(width * 0.86, height * 0.20)
            ..strokePath();
        },
      ),
    );
  }

  /// Builds sanitized RTL RichText with optional foreground and highlight maps.
  /// Matching is case-insensitive for Latin text and exact for Arabic terms.
  static pw.Widget buildHighlightedText({
    required String text,
    required pw.Font font,
    required pw.Font fontBold,
    Map<String, PdfColor>? keywordColors,
    Map<String, PdfColor>? keywordHighlights,
    double fontSize = 10,
    pw.TextDirection direction = pw.TextDirection.rtl,
  }) {
    final normalized = PdfTextSanitizer.normalize(text);
    final terms =
        <String>{
            ...?keywordColors?.keys,
            ...?keywordHighlights?.keys,
          }.where((term) => term.isNotEmpty).toList()
          ..sort((a, b) => b.length.compareTo(a.length));
    if (terms.isEmpty) {
      return pw.Text(
        normalized,
        textDirection: direction,
        style: pw.TextStyle(font: font, fontSize: fontSize),
      );
    }
    final pattern = RegExp(
      terms.map(RegExp.escape).join('|'),
      caseSensitive: false,
    );
    final spans = <pw.InlineSpan>[];
    var cursor = 0;
    for (final match in pattern.allMatches(normalized)) {
      if (match.start > cursor) {
        spans.add(pw.TextSpan(text: normalized.substring(cursor, match.start)));
      }
      final token = match.group(0)!;
      final matchedKey = terms.firstWhere(
        (term) => term.toLowerCase() == token.toLowerCase(),
        orElse: () => token,
      );
      spans.add(
        pw.TextSpan(
          text: token,
          style: pw.TextStyle(
            font: fontBold,
            fontSize: fontSize,
            color: keywordColors?[matchedKey] ?? charcoalBlack,
            background: keywordHighlights?[matchedKey] == null
                ? null
                : pw.BoxDecoration(color: keywordHighlights![matchedKey]),
          ),
        ),
      );
      cursor = match.end;
    }
    if (cursor < normalized.length) {
      spans.add(pw.TextSpan(text: normalized.substring(cursor)));
    }
    return pw.RichText(
      textDirection: direction,
      text: pw.TextSpan(
        style: pw.TextStyle(
          font: font,
          fontSize: fontSize,
          color: charcoalBlack,
        ),
        children: spans,
      ),
    );
  }

  static pw.Font? _latinFallbackFont;
  static Map<String, pw.Font> _configuredFonts = const {};
  static final Map<String, Future<pw.Font>> _fontCache = {};

  static Future<pw.Font> _loadFont(String path) {
    return _fontCache[path] ??= rootBundle
        .load(path)
        .then((data) => pw.Font.ttf(data));
  }

  static Future<Uint8List> buildRequestPdf(
    ExpenseRequest request, {
    AppSettings? settings,
  }) async {
    final configuration = settings ?? AppSettings.defaults();
    final sanitizedRequest = PdfTextSanitizer.normalizeRequest(request);
    final isSingleSample =
        sanitizedRequest.documentType == ExpenseDocumentType.sampleRequest &&
        sanitizedRequest.customFields['sampleTemplate'] == 'singlePage';
    final sampleMaxItems = isSingleSample
        ? sampleRequestSinglePageMaxItems
        : sampleRequestMaxItems;
    if (sanitizedRequest.documentType == ExpenseDocumentType.sampleRequest &&
        sanitizedRequest.sampleItems.length > sampleMaxItems) {
      throw StateError(
        'لا يمكن إنشاء نموذج طلب العينات بأكثر من $sampleMaxItems صنفًا',
      );
    }
    final regularFont = await _loadFont(
      'assets/fonts/NotoSansArabic-Regular.ttf',
    );
    final fallbackFont = await _loadFont('assets/fonts/DejaVuSans.ttf');
    _configuredFonts = {
      'Arial': await _loadFont('assets/fonts/Arial.ttf'),
      'Noto Kufi Arabic': await _loadFont(
        'assets/fonts/NotoKufiArabic-Regular.ttf',
      ),
      'Noto Sans Arabic': regularFont,
      'Noto Naskh Arabic': await _loadFont('assets/fonts/NotoNaskhArabic.ttf'),
      'Cairo': await _loadFont('assets/fonts/Cairo.ttf'),
      'Tajawal': await _loadFont('assets/fonts/Tajawal.ttf'),
      'Changa': await _loadFont('assets/fonts/Changa.ttf'),
      'El Messiri': await _loadFont('assets/fonts/ElMessiri.ttf'),
      'Reem Kufi': await _loadFont('assets/fonts/ReemKufi.ttf'),
      'Aref Ruqaa': await _loadFont('assets/fonts/ArefRuqaa.ttf'),
      'Lateef': await _loadFont('assets/fonts/Lateef.ttf'),
      'Katibeh': await _loadFont('assets/fonts/Katibeh.ttf'),
      'Lemonada': await _loadFont('assets/fonts/Lemonada.ttf'),
    };
    _latinFallbackFont = fallbackFont;

    final document = pw.Document(
      title: PdfTextSanitizer.normalize(
        '${configuration.formTitle} - ${_pdfDate(sanitizedRequest.date)}',
      ),
      author: PdfTextSanitizer.normalize(configuration.companyName),
    );

    if (sanitizedRequest.documentType ==
        ExpenseDocumentType.customerApplication) {
      await _addCustomerApplicationPage(
        document: document,
        request: sanitizedRequest,
        settings: configuration,
        regularFont: regularFont,
        fallbackFont: fallbackFont,
      );
    } else if (sanitizedRequest.documentType ==
        ExpenseDocumentType.sampleRequest) {
      if (isSingleSample) {
        await _addSinglePageSampleRequestPage(
          document: document,
          request: sanitizedRequest,
          settings: configuration,
          regularFont: regularFont,
          fallbackFont: fallbackFont,
        );
      } else {
        await _addSampleRequestPages(
          document: document,
          request: sanitizedRequest,
          settings: configuration,
          regularFont: regularFont,
          fallbackFont: fallbackFont,
        );
      }
    } else if (sanitizedRequest.documentType ==
        ExpenseDocumentType.fuelRequest) {
      await _addFuelPage(
        document: document,
        request: sanitizedRequest,
        settings: configuration,
        regularFont: regularFont,
        fallbackFont: fallbackFont,
      );
    } else if (sanitizedRequest.documentType ==
        ExpenseDocumentType.clearanceRequest) {
      await _addClearancePages(
        document: document,
        request: sanitizedRequest,
        settings: configuration,
        regularFont: regularFont,
        fallbackFont: fallbackFont,
      );
    } else if (sanitizedRequest.documentType ==
        ExpenseDocumentType.serviceRequest) {
      await _addOfficialRequestPage(
        document: document,
        request: sanitizedRequest,
        settings: configuration,
        regularFont: regularFont,
        fallbackFont: fallbackFont,
      );
      if (sanitizedRequest.formCount == 2 &&
          sanitizedRequest.secondRequest != null &&
          sanitizedRequest.documentType == ExpenseDocumentType.serviceRequest) {
        await _addOfficialRequestPage(
          document: document,
          request: sanitizedRequest.secondRequest!,
          settings: configuration,
          regularFont: regularFont,
          fallbackFont: fallbackFont,
        );
      }
    } else if (sanitizedRequest.documentType ==
        ExpenseDocumentType.internalMemo) {
      await LargeMemoPdfBuilder.addPage(
        document: document,
        request: sanitizedRequest,
        settings: configuration,
        regularFont: regularFont,
        fallbackFont: fallbackFont,
      );
    } else if (configuration.templateMode == TemplateMode.original) {
      await _addOriginalPage(
        document,
        sanitizedRequest,
        configuration,
        regularFont,
        fallbackFont,
      );
    } else {
      _addEditablePage(
        document,
        sanitizedRequest,
        configuration,
        regularFont,
        fallbackFont,
      );
    }

    await _appendAttachmentPages(
      document,
      sanitizedRequest.allAttachmentPaths,
      pageFormat: attachmentPageFormatFor(sanitizedRequest.documentType),
    );
    return document.save();
  }

  static PdfPageFormat attachmentPageFormatFor(ExpenseDocumentType type) =>
      switch (type) {
        ExpenseDocumentType.sampleRequest ||
        ExpenseDocumentType.customerApplication => PdfPageFormat.letter,
        ExpenseDocumentType.fuelRequest => PdfPageFormat.a4.landscape,
        _ => PdfPageFormat.a4,
      };

  static Future<void> _appendAttachmentPages(
    pw.Document document,
    Iterable<String> paths, {
    required PdfPageFormat pageFormat,
  }) async {
    for (final path in paths) {
      final file = File(path);
      if (!await file.exists()) continue;
      final bytes = await file.readAsBytes();
      if (_isPdfPath(path)) {
        await for (final raster in Printing.raster(bytes, dpi: 150)) {
          final png = await raster.toPng();
          document.addPage(
            _attachmentImagePage(pw.MemoryImage(png), pageFormat),
          );
        }
      } else if (_isImagePath(path)) {
        document.addPage(
          _attachmentImagePage(
            pw.MemoryImage(Uint8List.fromList(bytes)),
            pageFormat,
          ),
        );
      }
    }
  }

  static pw.Page _attachmentImagePage(
    pw.ImageProvider image,
    PdfPageFormat pageFormat,
  ) => pw.Page(
    pageFormat: pageFormat,
    margin: const pw.EdgeInsets.all(18),
    build: (_) => pw.Center(child: pw.Image(image, fit: pw.BoxFit.contain)),
  );

  static bool _isPdfPath(String path) => path.toLowerCase().endsWith('.pdf');

  static bool _isImagePath(String path) {
    final lower = path.toLowerCase();
    return lower.endsWith('.jpg') ||
        lower.endsWith('.jpeg') ||
        lower.endsWith('.png') ||
        lower.endsWith('.webp');
  }

  static double _structuredStatementHeight(
    String text, {
    required double maxHeight,
  }) {
    final length = text.trim().runes.length;
    if (length == 0) return 22;
    final lines = (length / 32).ceil().clamp(1, 4);
    return (lines * 12.0).clamp(22.0, maxHeight);
  }

  static Future<void> _addSinglePageSampleRequestPage({
    required pw.Document document,
    required ExpenseRequest request,
    required AppSettings settings,
    required pw.Font regularFont,
    required pw.Font fallbackFont,
  }) async {
    final background = pw.MemoryImage(
      (await rootBundle.load(
        'assets/templates/sample_request_single_page.png',
      )).buffer.asUint8List(),
    );
    final geometry = TemplateGeometry.forScope('sampleRequestSinglePage');
    final fields = settings.fieldSettings;
    pw.Widget cell(String key, String text) {
      if (text.trim().isEmpty || fields[key]?.visible == false) {
        return pw.SizedBox();
      }
      final field =
          fields[key] ??
          const FieldSetting(label: '', visible: true, required: false);
      final box = geometry[key];
      if (box == null) return pw.SizedBox();
      return _positionedValue(
        text,
        field,
        regularFont,
        fallbackFont,
        left: field.geometryConfigured ? field.x : box.x,
        top: field.geometryConfigured ? field.y : box.y,
        width: field.geometryConfigured ? field.width : box.width,
        height: field.geometryConfigured ? field.height : box.height,
        direction: pw.TextDirection.rtl,
        fontSize: field.fontSize > 0 ? field.fontSize : 8,
        textColorValue: settings.printedTextColorValue,
        key: key,
        pageWidth: PdfPageFormat.letter.width,
        pageHeight: PdfPageFormat.letter.height,
      );
    }

    final overlays = <pw.Widget>[
      cell('date', request.date),
      cell('receiver', request.receiver),
      cell('requesterName', request.requesterName),
      cell('reason', request.reason),
    ];
    final usage = request.customFields['sampleUsage'] ?? '';
    final usageKey = switch (usage) {
      'تسويقية' => 'sampleUsageMarketing',
      'استخدام أطباء' => 'sampleUsageDoctors',
      'استخدام موظفين' => 'sampleUsageEmployees',
      'أخرى' => 'sampleUsageOther',
      _ => null,
    };
    if (usageKey != null) {
      final field = fields[usageKey];
      final box = geometry[usageKey];
      if (field != null && box != null && field.visible) {
        overlays.add(
          _sampleUsageCheckmark(
            field,
            box,
            PdfColor.fromInt(settings.printedTextColorValue),
          ),
        );
      }
    }

    for (var i = 0; i < request.sampleItems.length; i++) {
      final item = request.sampleItems[i];
      final number = i + 1;
      overlays.addAll([
        cell('sampleItemName$number', item.productName),
        cell('sampleItemForm$number', item.pharmaceuticalForm),
        cell('sampleItemQuantity$number', item.quantityNumber),
        cell('sampleItemQuantityWords$number', item.quantityWords),
        cell('sampleItemNotes$number', item.notes),
      ]);
    }
    document.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.letter,
        margin: pw.EdgeInsets.zero,
        build: (_) => pw.Stack(
          fit: pw.StackFit.expand,
          children: [
            pw.Positioned.fill(
              child: pw.Image(background, fit: pw.BoxFit.fill),
            ),
            ...overlays,
          ],
        ),
      ),
    );
  }

  static Future<void> _addSampleRequestPages({
    required pw.Document document,
    required ExpenseRequest request,
    required AppSettings settings,
    required pw.Font regularFont,
    required pw.Font fallbackFont,
  }) async {
    final assets = [
      'assets/templates/sample_request_page_1.png',
      'assets/templates/sample_request_page_2.png',
      'assets/templates/sample_request_page_3.png',
    ];
    final pageRows = [11, 22, 20];
    var offset = 0;
    var pageIndex = 0;
    final rows = request.sampleItems;
    final geometry = TemplateGeometry.forScope('sampleRequest');
    final fields = settings.fieldSettings;
    while (offset < rows.length || pageIndex == 0) {
      final pageNumber = pageIndex.clamp(0, assets.length - 1).toInt();
      final background = pw.MemoryImage(
        (await rootBundle.load(assets[pageNumber])).buffer.asUint8List(),
      );
      final capacity = pageRows[pageNumber];
      final pageItems = rows.skip(offset).take(capacity).toList();
      final rowTop = switch (pageNumber) {
        0 => 360.0,
        1 => 62.0,
        _ => 67.0,
      };
      final rowHeight = switch (pageNumber) {
        0 => 21.4,
        1 => 22.8,
        _ => 21.5,
      };
      pw.Widget cell(
        String key,
        String text, {
        required double left,
        required double width,
        required double top,
        double? height,
        double fontSize = 7,
        double? fontSizeOverride,
      }) {
        if (text.trim().isEmpty || fields[key]?.visible == false) {
          return pw.SizedBox();
        }
        final field =
            fields[key] ??
            const FieldSetting(label: '', visible: true, required: false);
        final box =
            geometry[key] ??
            TemplateGeometry(
              x: left,
              y: top,
              width: width,
              height: height ?? rowHeight,
            );
        return _positionedValue(
          text,
          field,
          regularFont,
          fallbackFont,
          left: field.geometryConfigured ? field.x : box.x,
          top: field.geometryConfigured ? field.y : box.y,
          width: field.geometryConfigured ? field.width : box.width,
          height: field.geometryConfigured ? field.height : box.height,
          direction: pw.TextDirection.rtl,
          fontSize: field.fontSize > 0 ? field.fontSize : fontSize,
          fontSizeOverride: fontSizeOverride,
          key: key,
          textColorValue: settings.printedTextColorValue,
        );
      }

      final overlays = <pw.Widget>[];
      if (pageNumber == 0) {
        final usage = request.customFields['sampleUsage'] ?? '';
        final usageLeft = switch (usage) {
          'تسويقية' => 466.0,
          'استخدام أطباء' => 368.0,
          'استخدام موظفين' => 267.0,
          'أخرى' => 132.0,
          _ => null,
        };
        overlays.addAll([
          cell('date', request.date, left: 35, width: 160, top: 74),
          cell('receiver', request.receiver, left: 390, width: 160, top: 204),
          cell(
            'requesterName',
            request.requesterName,
            left: 380,
            width: 135,
            top: 682,
          ),
          cell('reason', request.reason, left: 145, width: 310, top: 678),
          cell(
            'statement',
            request.statement,
            left: 130,
            width: 330,
            top: 720,
            height: 28,
          ),
        ]);
        if (usageLeft != null) {
          final usageKey = switch (usage) {
            'تسويقية' => 'sampleUsageMarketing',
            'استخدام أطباء' => 'sampleUsageDoctors',
            'استخدام موظفين' => 'sampleUsageEmployees',
            _ => 'sampleUsageOther',
          };
          final field = fields[usageKey];
          final box = geometry[usageKey];
          if (field != null && box != null && field.visible) {
            overlays.add(
              _sampleUsageCheckmark(
                field,
                box,
                PdfColor.fromInt(settings.printedTextColorValue),
              ),
            );
          }
        }
      } else if (pageNumber == 2) {
        overlays.add(
          cell(
            'reasonPage3',
            request.reason,
            left: 45,
            width: 450,
            top: 449,
            height: 50,
          ),
        );
      }
      for (var i = 0; i < pageItems.length; i++) {
        final item = pageItems[i];
        final top = rowTop + (i * rowHeight);
        final itemNumber = offset + i + 1;
        overlays.addAll([
          cell(
            'sampleItemName$itemNumber',
            item.productName,
            left: 374,
            width: 151,
            top: top,
          ),
          cell(
            'sampleItemForm$itemNumber',
            item.pharmaceuticalForm,
            left: 301,
            width: 73,
            top: top,
          ),
          cell(
            'sampleItemQuantity$itemNumber',
            item.quantityNumber,
            left: 236,
            width: 65,
            top: top,
          ),
          cell(
            'sampleItemQuantityWords$itemNumber',
            item.quantityWords,
            left: 171,
            width: 65,
            top: top,
          ),
          cell(
            'sampleItemNotes$itemNumber',
            item.notes,
            left: 46,
            width: 125,
            top: top,
          ),
        ]);
      }
      document.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.letter,
          margin: pw.EdgeInsets.zero,
          build: (_) => pw.Stack(
            fit: pw.StackFit.expand,
            children: [
              pw.Positioned.fill(
                child: pw.Image(background, fit: pw.BoxFit.fill),
              ),
              ...overlays,
            ],
          ),
        ),
      );
      offset += pageItems.length;
      pageIndex++;
      if (pageIndex >= assets.length && offset < rows.length) {
        pageIndex = assets.length - 1;
      }
      if (rows.isEmpty) break;
    }
  }

  static Future<void> _addFuelPage({
    required pw.Document document,
    required ExpenseRequest request,
    required AppSettings settings,
    required pw.Font regularFont,
    required pw.Font fallbackFont,
  }) async {
    final background = pw.MemoryImage(
      (await rootBundle.load(
        'assets/images/forms/fuel_request-1.png',
      )).buffer.asUint8List(),
    );
    final geometry = TemplateGeometry.forScope('fuelRequest');
    final fields = settings.fieldSettings;
    final custom = request.customFields;
    final systemTimestamp = DateFormatter.dateTime(DateTime.now());
    final selectedFuelType = custom['fuelType'] ?? '';
    pw.Widget value(
      String key,
      String content, {
      pw.TextDirection direction = pw.TextDirection.rtl,
    }) {
      if (content.trim().isEmpty || fields[key]?.visible == false) {
        return pw.SizedBox();
      }
      final field =
          fields[key] ??
          const FieldSetting(label: '', visible: true, required: false);
      final box =
          geometry[key] ?? const TemplateGeometry(x: 0, y: 0, width: 80);
      return _positionedValue(
        content,
        field,
        regularFont,
        fallbackFont,
        left: box.x,
        top: box.y,
        width: box.width,
        height: box.height,
        direction: direction,
        fontSize: field.fontSize > 0 ? field.fontSize : 8.5,
        textColorValue: settings.printedTextColorValue,
        key: key,
        allowTruncation: true,
        pageWidth: 841.89,
        pageHeight: 595.28,
      );
    }

    pw.Widget fuelTypeMark(String key, String option) {
      if (fields[key]?.visible == false || selectedFuelType != option) {
        return pw.SizedBox();
      }
      final box = geometry[key]!;
      final field =
          fields[key] ??
          const FieldSetting(label: '', visible: true, required: false);
      // Use the same text mark as the customer form, at half its current
      // 32-point size. _positionedValue applies configured x/y/width/height
      // when the user edits this field in the template editor.
      return _positionedValue(
        '✔',
        field,
        regularFont,
        fallbackFont,
        left: box.x,
        top: box.y,
        width: box.width,
        height: box.height,
        direction: pw.TextDirection.ltr,
        fontSize: 16,
        fontSizeOverride: 16,
        alignmentOverride: 'center',
        fontWeightOverride: 900,
        textColorValue: settings.printedTextColorValue,
        key: key,
        allowTruncation: false,
        pageWidth: 841.89,
        pageHeight: 595.28,
      );
    }

    final rows = request.fuelEntries.take(7).toList();
    document.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: pw.EdgeInsets.zero,
        build: (_) => pw.Stack(
          fit: pw.StackFit.expand,
          children: [
            pw.Positioned.fill(
              child: pw.Image(background, fit: pw.BoxFit.fill),
            ),
            value('fuelBranch', custom['fuelBranch'] ?? request.branch),
            value('vehicleNumber', custom['vehicleNumber'] ?? ''),
            value('collector', custom['collector'] ?? request.receiver),
            fuelTypeMark('fuelTypePetrol', 'بترول'),
            fuelTypeMark('fuelTypeDiesel', 'ديزل'),
            fuelTypeMark('fuelTypeGas', 'غاز'),
            value(
              'periodFrom',
              custom['periodFrom'] ?? request.date,
              direction: pw.TextDirection.ltr,
            ),
            value(
              'periodTo',
              custom['periodTo'] ?? request.statement,
              direction: pw.TextDirection.ltr,
            ),
            value(
              'beneficiary',
              custom['beneficiary'] ?? request.requesterName,
            ),
            value(
              'branchAccountant',
              custom['branchAccountant'] ?? request.approvedAuthorityName,
            ),
            value(
              'branchManager',
              custom['branchManager'] ?? request.directManagerName,
            ),
            value(
              'administrationAccountant',
              custom['administrationAccountant'] ?? '',
            ),
            value(
              'accountsManager',
              custom['accountsManager'] ?? request.accountsManagerName,
            ),
            value(
              'systemTimestamp',
              systemTimestamp,
              direction: pw.TextDirection.ltr,
            ),
            for (var i = 0; i < rows.length; i++) ...[
              value(
                'fuelDate${i + 1}',
                rows[i].date,
                direction: pw.TextDirection.ltr,
              ),
              value(
                'fuelMeter${i + 1}',
                rows[i].meter,
                direction: pw.TextDirection.ltr,
              ),
              value(
                'fuelLiters${i + 1}',
                rows[i].liters,
                direction: pw.TextDirection.ltr,
              ),
              value(
                'fuelPrice${i + 1}',
                rows[i].literPrice,
                direction: pw.TextDirection.ltr,
              ),
              value(
                'fuelAmount${i + 1}',
                rows[i].fuelAmount,
                direction: pw.TextDirection.ltr,
              ),
              value(
                'fuelCollection${i + 1}',
                rows[i].collection,
                direction: pw.TextDirection.ltr,
              ),
              value(
                'fuelSales${i + 1}',
                rows[i].sales,
                direction: pw.TextDirection.ltr,
              ),
              value('fuelRoute${i + 1}', rows[i].route),
            ],
          ],
        ),
      ),
    );
  }

  static Future<void> _addClearancePages({
    required pw.Document document,
    required ExpenseRequest request,
    required AppSettings settings,
    required pw.Font regularFont,
    required pw.Font fallbackFont,
  }) async {
    if (request.clearanceEntries.isEmpty) {
      await _addOfficialRequestPage(
        document: document,
        request: request,
        settings: settings,
        regularFont: regularFont,
        fallbackFont: fallbackFont,
      );
      return;
    }
    if (request.clearanceEntries.length > ExpenseRequest.maxClearanceEntries) {
      throw StateError(
        'لا يمكن إنشاء نموذج إخلاء العهدة بأكثر من '
        '${ExpenseRequest.maxClearanceEntries} بندًا',
      );
    }
    final structuredLength = request.clearanceEntries.fold<int>(
      0,
      (sum, entry) =>
          sum +
          entry.amount.length +
          entry.date.length +
          entry.statement.length,
    );
    if (structuredLength > 10000) {
      throw StateError('إجمالي بيانات العهدة يتجاوز الحد المسموح (10000 حرف)');
    }

    final background = pw.MemoryImage(
      (await rootBundle.load(
        'assets/images/forms/clearance_request-1.png',
      )).buffer.asUint8List(),
    );
    final fields = settings.fieldSettings;
    final geometry = TemplateGeometry.forScope('clearanceRequest');

    FieldSetting clearanceField(String key, String baseKey) {
      final configured = fields[key];
      if (configured != null) return configured;
      return (fields[baseKey] ??
              const FieldSetting(label: '', visible: true, required: false))
          .copyWith(visible: true, required: false, geometryConfigured: false);
    }

    pw.Widget value(
      String key,
      String content, {
      required double left,
      required double top,
      required double width,
      required double height,
      double fontSize = 9,
      pw.TextDirection direction = pw.TextDirection.rtl,
    }) {
      final field = fields[key];
      if (content.trim().isEmpty || field == null || !field.visible) {
        return pw.SizedBox();
      }
      return _positionedValue(
        content,
        field,
        regularFont,
        fallbackFont,
        left: field.geometryConfigured ? field.x : (geometry[key]?.x ?? left),
        top: field.geometryConfigured ? field.y : (geometry[key]?.y ?? top),
        width: field.geometryConfigured
            ? field.width
            : (geometry[key]?.width ?? width),
        height: field.geometryConfigured
            ? field.height
            : (geometry[key]?.height ?? height),
        direction: direction,
        fontSize: field.fontSize > 0 ? field.fontSize : fontSize,
        textColorValue: settings.printedTextColorValue,
        key: key,
        allowTruncation: false,
      );
    }

    pw.Widget rowValue(
      String key,
      String baseKey,
      String content, {
      required double left,
      required double top,
      required double width,
      required double height,
      required pw.TextDirection direction,
    }) {
      final field = clearanceField(key, baseKey);
      if (content.trim().isEmpty || !field.visible) return pw.SizedBox();
      return _positionedValue(
        content,
        field,
        regularFont,
        fallbackFont,
        left: left,
        top: top,
        width: width,
        height: height,
        direction: direction,
        fontSize: field.fontSize > 0 ? field.fontSize : 9,
        textColorValue: settings.printedTextColorValue,
        key: key,
        allowTruncation: false,
        useFieldGeometry: false,
      );
    }

    document.addPage(
      pw.MultiPage(
        pageTheme: pw.PageTheme(
          pageFormat: PdfPageFormat.a4,
          margin: pw.EdgeInsets.zero,
        ),
        maxPages: 2000,
        build: (context) {
          const rowCountPerPage = 6;
          const statementLeft = 55.0;
          const statementWidth = 220.0;
          const statementHeight = 46.0;
          const rowTop = 132.0;
          const rowSpacing = 48.0;
          FieldSetting statementFieldForSlot(int slotIndex) {
            final key = 'clearanceStatement${slotIndex + 1}';
            return clearanceField(key, 'clearanceStatement1');
          }

          double statementFontSizeForSlot(int slotIndex) =>
              statementFieldForSlot(slotIndex).fontSize.clamp(7, 24).toDouble();

          int maxLinesForSlot(int slotIndex) {
            final field = statementFieldForSlot(slotIndex);
            final fontSize = statementFontSizeForSlot(slotIndex);
            final lineHeight = field.lineHeight.clamp(0.2, 4.0);
            return (statementHeight / (fontSize * lineHeight))
                .floor()
                .clamp(1, 12)
                .toInt();
          }

          int maxCharactersPerLineForSlot(int slotIndex) {
            final fontSize = statementFontSizeForSlot(slotIndex);
            return ((statementWidth - 8) / (fontSize * 0.62))
                .floor()
                .clamp(1, 240)
                .toInt();
          }

          bool fitsLine(String text, int slotIndex) {
            final field = statementFieldForSlot(slotIndex);
            final font = _configuredFonts[field.fontFamily] ?? regularFont;
            final width =
                font
                    .getFont(context)
                    .stringMetrics(PdfTextSanitizer.normalize(text))
                    .size
                    .x *
                statementFontSizeForSlot(slotIndex);
            return text.runes.length <=
                    maxCharactersPerLineForSlot(slotIndex) &&
                width <= statementWidth - 8;
          }

          final fragments = <_ClearancePdfFragment>[];
          for (
            var entryIndex = 0;
            entryIndex < request.clearanceEntries.length;
            entryIndex++
          ) {
            final entry = request.clearanceEntries[entryIndex];
            final rawAmount = entry.amount.trim();
            final amount = rawAmount.isEmpty
                ? ''
                : ClearanceAmountMath.formatGroupedAmount(rawAmount);
            final amountMinor = rawAmount.isEmpty
                ? BigInt.zero
                : ClearanceAmountMath.toMinorUnits(rawAmount);
            final words = entry.statement.trim().isEmpty
                ? <String>[]
                : entry.statement.trim().split(RegExp(r'\s+'));
            var wordIndex = 0;
            var fragmentIndex = 0;

            do {
              final slotIndex = fragments.length % rowCountPerPage;
              final maxLinesPerFragment = maxLinesForSlot(slotIndex);
              final startsEntry = fragmentIndex == 0;
              final prefix = startsEntry
                  ? '${entryIndex + 1}.'
                  : '${entryIndex + 1} تابع البيان:';
              final lines = <String>[];
              var currentLine = prefix;

              while (lines.length < maxLinesPerFragment) {
                if (wordIndex >= words.length) {
                  if (currentLine.isNotEmpty) lines.add(currentLine);
                  break;
                }

                final word = words[wordIndex];
                final candidate = currentLine.isEmpty
                    ? word
                    : '$currentLine $word';
                if (fitsLine(candidate, slotIndex)) {
                  currentLine = candidate;
                  wordIndex++;
                  continue;
                }

                if (currentLine.isNotEmpty) {
                  lines.add(currentLine);
                  currentLine = '';
                  continue;
                }

                final runes = word.runes.toList();
                final partBuffer = StringBuffer();
                for (final rune in runes) {
                  final candidatePart =
                      '${partBuffer.toString()}${String.fromCharCode(rune)}';
                  if (!fitsLine(candidatePart, slotIndex)) break;
                  partBuffer.write(String.fromCharCode(rune));
                }
                final part = partBuffer.isEmpty
                    ? String.fromCharCode(runes.first)
                    : partBuffer.toString();
                lines.add(part);
                final consumedRunes = part.runes.length;
                if (consumedRunes >= runes.length) {
                  wordIndex++;
                } else {
                  words[wordIndex] = String.fromCharCodes(
                    runes.skip(consumedRunes),
                  );
                }
              }

              if (lines.isEmpty) lines.add(prefix);
              fragments.add(
                _ClearancePdfFragment(
                  startsEntry: startsEntry,
                  amount: startsEntry ? amount : '',
                  date: startsEntry ? entry.date : '',
                  amountMinor: startsEntry ? amountMinor : BigInt.zero,
                  statement: lines.join('\n'),
                ),
              );
              fragmentIndex++;
            } while (wordIndex < words.length);
          }

          final pages = <List<_ClearancePdfFragment>>[];
          for (
            var start = 0;
            start < fragments.length;
            start += rowCountPerPage
          ) {
            final end = (start + rowCountPerPage)
                .clamp(0, fragments.length)
                .toInt();
            pages.add(fragments.sublist(start, end));
          }

          final pageNumberField = const FieldSetting(
            label: '',
            visible: true,
            required: false,
            fontSize: 7,
            alignment: 'center',
          );
          final totalField =
              settings.fieldSettings['clearanceAmount1'] ??
              const FieldSetting(
                label: '',
                visible: true,
                required: false,
                fontSize: 8,
                alignment: 'right',
              );
          final widgets = <pw.Widget>[];

          for (var pageIndex = 0; pageIndex < pages.length; pageIndex++) {
            if (pageIndex > 0) widgets.add(pw.NewPage());
            final rows = pages[pageIndex];
            final overlays = <pw.Widget>[
              pw.Positioned.fill(
                child: pw.Image(background, fit: pw.BoxFit.fill),
              ),
              value(
                'date',
                _pdfDate(request.date),
                left: 58,
                top: 57,
                width: 120,
                height: 20,
                direction: pw.TextDirection.ltr,
              ),
              value(
                'receiver',
                request.receiver,
                left: 390,
                top: 91,
                width: 170,
                height: 20,
              ),
            ];

            for (var rowIndex = 0; rowIndex < rows.length; rowIndex++) {
              final row = rows[rowIndex];
              final top = rowTop + rowIndex * rowSpacing;
              overlays.addAll([
                rowValue(
                  'clearanceAmount${rowIndex + 1}',
                  'clearanceAmount1',
                  row.amount,
                  left: 470,
                  top: top,
                  width: 90,
                  height: 22,
                  direction: pw.TextDirection.ltr,
                ),
                rowValue(
                  'clearanceDate${rowIndex + 1}',
                  'clearanceDate1',
                  row.date,
                  left: 285,
                  top: top,
                  width: 95,
                  height: 22,
                  direction: pw.TextDirection.ltr,
                ),
                rowValue(
                  'clearanceStatement${rowIndex + 1}',
                  'clearanceStatement1',
                  row.statement,
                  left: statementLeft,
                  top: top,
                  width: statementWidth,
                  height: statementHeight,
                  direction: pw.TextDirection.rtl,
                ),
              ]);
            }

            final pageTotalMinor = rows.fold<BigInt>(
              BigInt.zero,
              (sum, row) => row.startsEntry ? sum + row.amountMinor : sum,
            );
            final pageTotal = ClearanceAmountMath.formatGroupedAmount(
              ClearanceAmountMath.amountFromMinorUnits(pageTotalMinor),
            );
            overlays.addAll([
              pw.Positioned(
                left: statementLeft,
                top: rowTop + rowCountPerPage * rowSpacing + 1,
                child: pw.Container(
                  width: statementWidth,
                  height: 17,
                  color: PdfColors.white,
                ),
              ),
              _positionedValue(
                'إجمالي الصفحة',
                totalField,
                regularFont,
                fallbackFont,
                left: statementLeft,
                top: rowTop + rowCountPerPage * rowSpacing,
                width: statementWidth,
                height: 18,
                direction: pw.TextDirection.rtl,
                fontSize: 8,
                fontSizeOverride: 8,
                textColorValue: settings.printedTextColorValue,
                key: 'clearancePageTotalLabel',
                allowTruncation: false,
                useFieldGeometry: false,
              ),
              rowValue(
                'clearanceAmount1',
                'clearanceAmount1',
                pageTotal,
                left: 470,
                top: rowTop + rowCountPerPage * rowSpacing,
                width: 90,
                height: 18,
                direction: pw.TextDirection.ltr,
              ),
            ]);

            overlays.add(
              _positionedValue(
                'صفحة ${pageIndex + 1} من ${pages.length}',
                pageNumberField,
                regularFont,
                fallbackFont,
                left: 260,
                top: 814,
                width: 75,
                height: 16,
                direction: pw.TextDirection.rtl,
                fontSize: 7,
                fontSizeOverride: 7,
                textColorValue: settings.printedTextColorValue,
                key: 'clearancePageNumber',
                allowTruncation: false,
                useFieldGeometry: false,
              ),
            );

            if (pageIndex == pages.length - 1) {
              overlays.addAll([
                value(
                  'amountWords',
                  request.amountWords,
                  left: 175,
                  top: 596,
                  width: 280,
                  height: 20,
                  fontSize: 8,
                ),
                value(
                  'requesterName',
                  request.requesterName.trim(),
                  left: 420,
                  top: 575,
                  width: 140,
                  height: 22,
                ),
                value(
                  'requesterSignature',
                  request.requesterSignature,
                  left: 425,
                  top: 545,
                  width: 115,
                  height: 18,
                  fontSize: 8,
                ),
                value(
                  'directManagerName',
                  request.directManagerName,
                  left: 80,
                  top: 575,
                  width: 140,
                  height: 22,
                ),
                value(
                  'directManagerSignature',
                  request.directManagerSignature,
                  left: 285,
                  top: 545,
                  width: 115,
                  height: 18,
                  fontSize: 8,
                ),
                value(
                  'approvedAuthorityName',
                  request.approvedAuthorityName,
                  left: 420,
                  top: 660,
                  width: 140,
                  height: 22,
                ),
                value(
                  'approvedAuthoritySignature',
                  request.approvedAuthoritySignature,
                  left: 95,
                  top: 545,
                  width: 125,
                  height: 18,
                  fontSize: 8,
                ),
                value(
                  'accountsManagerName',
                  request.accountsManagerName,
                  left: 80,
                  top: 660,
                  width: 140,
                  height: 22,
                ),
                value(
                  'accountsManagerSignature',
                  request.accountsManagerSignature,
                  left: 80,
                  top: 675,
                  width: 160,
                  height: 18,
                  fontSize: 8,
                ),
              ]);
            }

            widgets.add(
              pw.Container(
                width: PdfPageFormat.a4.width,
                height: PdfPageFormat.a4.height,
                child: pw.Stack(fit: pw.StackFit.expand, children: overlays),
              ),
            );
          }
          return widgets;
        },
      ),
    );
  }

  static Future<void> _addOfficialRequestPage({
    required pw.Document document,
    required ExpenseRequest request,
    required AppSettings settings,
    required pw.Font regularFont,
    required pw.Font fallbackFont,
  }) async {
    final isClearance =
        request.documentType == ExpenseDocumentType.clearanceRequest;
    final asset = isClearance
        ? 'assets/images/forms/clearance_request-1.png'
        : 'assets/images/forms/service_request-1.png';
    final background = pw.MemoryImage(
      (await rootBundle.load(asset)).buffer.asUint8List(),
    );
    final fields = settings.fieldSettings;
    final geometry = TemplateGeometry.forScope(
      isClearance ? 'clearanceRequest' : 'serviceRequest',
    );
    pw.Widget value(
      String key,
      String content, {
      required double left,
      required double top,
      required double width,
      required double height,
      double fontSize = 9,
      pw.TextDirection direction = pw.TextDirection.rtl,
      String? alignmentOverride,
    }) {
      if (content.trim().isEmpty ||
          fields[key] == null ||
          fields[key]?.visible == false) {
        return pw.SizedBox();
      }
      final field = fields[key];
      return _positionedValue(
        content,
        field ?? const FieldSetting(label: '', visible: true, required: false),
        regularFont,
        fallbackFont,
        left: field?.geometryConfigured == true
            ? field!.x
            : (geometry[key]?.x ?? left),
        top: field?.geometryConfigured == true
            ? field!.y
            : (geometry[key]?.y ?? top),
        width: field?.geometryConfigured == true
            ? field!.width
            : (geometry[key]?.width ?? width),
        height: field?.geometryConfigured == true
            ? field!.height
            : (geometry[key]?.height ?? height),
        direction: direction,
        fontSize: field != null && field.fontSize > 0
            ? field.fontSize
            : fontSize,
        textColorValue: settings.printedTextColorValue,
        key: key,
        alignmentOverride: alignmentOverride,
        allowTruncation: false,
      );
    }

    final statement = request.statement.trim();
    final requester = request.requesterName.trim();
    final doctorNames = request.customFields['doctorNames']?.trim() ?? '';
    final worksIn = request.customFields['worksIn']?.trim() ?? '';
    final specialty = request.customFields['specialty']?.trim() ?? '';
    document.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: pw.EdgeInsets.zero,
        build: (_) => pw.Stack(
          fit: pw.StackFit.expand,
          children: [
            pw.Positioned.fill(
              child: pw.Image(background, fit: pw.BoxFit.fill),
            ),
            value(
              'date',
              _pdfDate(request.date),
              left: 58,
              top: 57,
              width: 120,
              height: 20,
              direction: pw.TextDirection.ltr,
            ),
            value(
              'receiver',
              request.receiver,
              left: 390,
              top: 91,
              width: 170,
              height: 20,
            ),
            if (isClearance) ...[
              for (
                var i = 0;
                i < request.clearanceEntries.length && i < 6;
                i++
              ) ...[
                value(
                  'clearanceAmount${i + 1}',
                  request.clearanceEntries[i].amount,
                  left: 470,
                  top: 132 + (i * 48),
                  width: 90,
                  height: 22,
                  direction: pw.TextDirection.ltr,
                ),
                value(
                  'clearanceDate${i + 1}',
                  request.clearanceEntries[i].date,
                  left: 285,
                  top: 132 + (i * 48),
                  width: 95,
                  height: 22,
                  direction: pw.TextDirection.ltr,
                ),
                value(
                  'clearanceStatement${i + 1}',
                  request.clearanceEntries[i].statement,
                  left: 55,
                  top: 132 + (i * 48),
                  width: 220,
                  height: _structuredStatementHeight(
                    request.clearanceEntries[i].statement,
                    maxHeight: 46,
                  ),
                ),
              ],
              if (request.clearanceEntries.isEmpty)
                value(
                  'statement',
                  statement,
                  left: 60,
                  top: 130,
                  width: 480,
                  height: 390,
                ),
              if (request.clearanceEntries.isEmpty)
                value(
                  'amountNumber',
                  request.amountNumber,
                  left: 470,
                  top: 540,
                  width: 90,
                  height: 20,
                  direction: pw.TextDirection.ltr,
                ),
              value(
                'requesterName',
                requester,
                left: 420,
                top: 575,
                width: 140,
                height: 22,
              ),
              value(
                'directManagerName',
                request.directManagerName,
                left: 80,
                top: 575,
                width: 140,
                height: 22,
              ),
              value(
                'approvedAuthorityName',
                request.approvedAuthorityName,
                left: 420,
                top: 660,
                width: 140,
                height: 22,
              ),
              value(
                'accountsManagerName',
                request.accountsManagerName,
                left: 80,
                top: 660,
                width: 140,
                height: 22,
              ),
            ] else ...[
              ..._serviceTypeCheckmark(request.reason, settings),
              value(
                'branch',
                request.branch,
                left: 20,
                top: 443,
                width: 166,
                height: 70,
              ),
              value(
                'doctorNames',
                doctorNames,
                left: 19,
                top: 173,
                width: 394,
                height: 44,
              ),
              value(
                'worksIn',
                worksIn,
                left: 288,
                top: 219,
                width: 266,
                height: 47,
              ),
              value(
                'specialty',
                specialty,
                left: 15,
                top: 212,
                width: 205,
                height: 60,
              ),
              for (
                var i = 0;
                i < request.serviceItems.length && i < 6;
                i++
              ) ...[
                value(
                  'serviceItemName${i + 1}',
                  request.serviceItems[i].name,
                  left: 364,
                  top: const <double>[296, 320, 345, 371, 398, 423][i],
                  width: 200,
                  height: 22,
                  alignmentOverride: 'center',
                ),
              ],
              value(
                'statement',
                statement,
                left: 19,
                top: 292,
                width: 305,
                height: 150,
              ),
              value(
                'amountNumber',
                request.amountNumber,
                left: 442,
                top: 452,
                width: 80,
                height: 22,
                direction: pw.TextDirection.ltr,
                alignmentOverride: 'center',
              ),
              value(
                'amountWords',
                request.amountWords,
                left: 207,
                top: 445,
                width: 200,
                height: 70,
                alignmentOverride: 'center',
              ),
              value(
                'requesterName',
                requester,
                left: 414,
                top: 553,
                width: 145,
                height: 22,
              ),
              value(
                'directManagerName',
                request.directManagerName,
                left: 200,
                top: 553,
                width: 145,
                height: 22,
              ),
              value(
                'approvedAuthorityName',
                request.approvedAuthorityName,
                left: 15,
                top: 553,
                width: 145,
                height: 22,
              ),
            ],
          ],
        ),
      ),
    );
  }

  static Future<void> _addCustomerApplicationPage({
    required pw.Document document,
    required ExpenseRequest request,
    required AppSettings settings,
    required pw.Font regularFont,
    required pw.Font fallbackFont,
  }) async {
    final background = pw.MemoryImage(
      (await rootBundle.load(
        'assets/images/customer_application_sales_modified.png',
      )).buffer.asUint8List(),
    );
    final fields = settings.customerFieldSettings;
    final geometry = TemplateGeometry.forScope('customerApplication');
    final custom = request.customFields;
    String text(String key, [String fallback = '']) =>
        custom[key]?.trim().isNotEmpty == true ? custom[key]!.trim() : fallback;

    pw.Widget value(
      String key,
      String valueText, {
      required double left,
      required double top,
      required double width,
      required double height,
      double fontSize = 9,
      pw.TextDirection direction = pw.TextDirection.rtl,
      bool allowEmpty = false,
      double? fontSizeOverride,
      String? alignmentOverride,
      int? fontWeightOverride,
    }) {
      final field = fields[key];
      if (field?.visible == false ||
          (!allowEmpty && valueText.trim().isEmpty)) {
        return pw.SizedBox();
      }
      final resolved =
          field ??
          const FieldSetting(label: '', visible: true, required: false);
      return _positionedValue(
        valueText,
        resolved,
        regularFont,
        fallbackFont,
        left: field != null && field.geometryConfigured
            ? field.x
            : (geometry[key]?.x ?? left),
        top: field != null && field.geometryConfigured
            ? field.y
            : (geometry[key]?.y ?? top),
        width: field != null && field.geometryConfigured
            ? field.width
            : (geometry[key]?.width ?? width),
        height: field != null && field.geometryConfigured
            ? field.height
            : (geometry[key]?.height ?? height),
        direction: direction,
        fontSize: field != null && field.fontSize > 0
            ? (fontSizeOverride ?? field.fontSize)
            : fontSize,
        fontSizeOverride: fontSizeOverride,
        alignmentOverride: alignmentOverride,
        fontWeightOverride: fontWeightOverride,
        textColorValue: settings.printedTextColorValue,
        key: key,
        allowTruncation: key == 'branch',
        pageWidth: 612,
        pageHeight: 792,
      );
    }

    final selectedType = text('exceptionType');
    final selectedCustomerType = text('customerType');
    document.addPage(
      pw.Page(
        pageFormat: const PdfPageFormat(612, 792),
        margin: pw.EdgeInsets.zero,
        build: (_) => pw.Stack(
          fit: pw.StackFit.expand,
          children: [
            pw.Positioned.fill(
              child: pw.Image(background, fit: pw.BoxFit.fill),
            ),
            value(
              'date',
              _pdfDate('‎${_pdfDate(text('date', _pdfDate(request.date)))}‎'),
              left: 34,
              top: 49,
              width: 120,
              height: 24,
              direction: pw.TextDirection.ltr,
            ),
            value(
              'bonusExtra',
              selectedType == 'بونص إضافي' ? '✔' : '',
              left: 500,
              top: 148,
              width: 72,
              height: 30,
              fontSize: 16,
              allowEmpty: true,
              fontSizeOverride: 32,
              alignmentOverride: 'center',
              fontWeightOverride: 900,
            ),
            value(
              'customerCompensation',
              selectedType == 'تعويض عميل' ? '✔' : '',
              left: 380,
              top: 148,
              width: 72,
              height: 30,
              fontSize: 16,
              allowEmpty: true,
              fontSizeOverride: 32,
              alignmentOverride: 'center',
              fontWeightOverride: 900,
            ),
            value(
              'settlementOffer',
              selectedType == 'عرض سداد' ? '✔' : '',
              left: 260,
              top: 148,
              width: 72,
              height: 30,
              fontSize: 16,
              allowEmpty: true,
              fontSizeOverride: 32,
              alignmentOverride: 'center',
              fontWeightOverride: 900,
            ),
            value(
              'cashDiscount',
              selectedType == 'خصم نقدي' ? '✔' : '',
              left: 140,
              top: 148,
              width: 72,
              height: 30,
              fontSize: 16,
              allowEmpty: true,
              fontSizeOverride: 32,
              alignmentOverride: 'center',
              fontWeightOverride: 900,
            ),
            value(
              'otherType',
              selectedType == 'أخرى' ? '✔' : '',
              left: 24,
              top: 148,
              width: 72,
              height: 30,
              fontSize: 16,
              allowEmpty: true,
              fontSizeOverride: 32,
              alignmentOverride: 'center',
              fontWeightOverride: 900,
            ),
            value(
              'otherDetails',
              selectedType == 'أخرى' ? text('otherDetails') : '',
              left: 24,
              top: 180,
              width: 564,
              height: 30,
              fontSize: 11.5,
              alignmentOverride: 'right',
            ),
            value(
              'branch',
              text('branch'),
              left: 245,
              top: 254,
              width: 90,
              height: 22,
            ),
            value(
              'customer',
              text('customer'),
              left: 285,
              top: 278,
              width: 285,
              height: 24,
            ),
            value(
              'customerTypeNew',
              selectedCustomerType == 'جديد' ? '✔' : '',
              left: 140,
              top: 245,
              width: 40,
              height: 24,
              allowEmpty: true,
              fontSizeOverride: 20,
              alignmentOverride: 'center',
              fontWeightOverride: 800,
            ),
            value(
              'customerTypePrevious',
              selectedCustomerType == 'سابق' ? '✔' : '',
              left: 100,
              top: 245,
              width: 40,
              height: 24,
              allowEmpty: true,
              fontSizeOverride: 20,
              alignmentOverride: 'center',
              fontWeightOverride: 800,
            ),
            value(
              'previousPurchases',
              text('previousPurchases'),
              left: 350,
              top: 303,
              width: 170,
              height: 22,
              direction: pw.TextDirection.ltr,
            ),
            value(
              'currentPurchases',
              text('currentPurchases'),
              left: 350,
              top: 333,
              width: 170,
              height: 22,
              direction: pw.TextDirection.ltr,
            ),
            value(
              'previousPayments',
              text('previousPayments'),
              left: 70,
              top: 303,
              width: 170,
              height: 22,
              direction: pw.TextDirection.ltr,
            ),
            value(
              'currentPayments',
              text('currentPayments'),
              left: 70,
              top: 333,
              width: 170,
              height: 22,
              direction: pw.TextDirection.ltr,
            ),
            value(
              'bonusPercent',
              text('bonusPercent'),
              left: 333,
              top: 319,
              width: 50,
              height: 22,
              direction: pw.TextDirection.ltr,
            ),
            value(
              'statementOne',
              text('statementOne'),
              left: 39,
              top: 360,
              width: 540,
              height: 125,
              fontSize: 9,
            ),
            value(
              'statementTwo',
              text('statementTwo'),
              left: 24,
              top: 504,
              width: 564,
              height: 94,
              fontSize: 9,
            ),
            value(
              'requesterName',
              text('requester'),
              left: 383,
              top: 614,
              width: 145,
              height: 22,
              fontSize: 8,
            ),
            value(
              'approvedAuthorityName',
              request.accountsManagerName,
              left: 167,
              top: 614,
              width: 145,
              height: 22,
              fontSize: 8,
            ),
            value(
              'directManagerName',
              request.directManagerName,
              left: 3,
              top: 614,
              width: 100,
              height: 22,
              fontSize: 8,
            ),
            value(
              'accountsManagerName',
              request.approvedAuthorityName,
              left: 59,
              top: 708,
              width: 175,
              height: 22,
              fontSize: 8,
            ),
          ],
        ),
      ),
    );
  }

  static Future<void> _addInternalMemoPage(
    pw.Document document,
    ExpenseRequest request,
    AppSettings settings,
    pw.Font regularFont,
    pw.Font fallbackFont,
  ) async {
    final template = pw.MemoryImage(
      (await rootBundle.load(
        'assets/images/memo/internal_memo_full.png',
      )).buffer.asUint8List(),
    );
    List<pw.Widget> fields(
      ExpenseRequest memo,
      double top,
      Map<String, FieldSetting> values,
    ) {
      pw.Widget value(
        String key,
        String text, {
        required double left,
        required double y,
        required double width,
        required double height,
        required double fontSize,
        pw.TextDirection? direction,
      }) {
        final field = values[key];
        if (field?.visible == false) return pw.SizedBox();
        return _positionedValue(
          text,
          field ??
              const FieldSetting(label: '', visible: true, required: false),
          regularFont,
          fallbackFont,
          left: field != null && field.geometryConfigured ? field.x : left,
          top: field != null && field.geometryConfigured
              ? top + field.y
              : top + y,
          width: field != null && field.geometryConfigured
              ? field.width
              : width,
          height: field != null && field.geometryConfigured
              ? field.height
              : height,
          fontSize: field != null && field.fontSize > 0
              ? field.fontSize
              : fontSize,
          direction: direction ?? pw.TextDirection.rtl,
          textColorValue: settings.printedTextColorValue,
          key: key,
          allowTruncation: key != 'statement',
          copyOffsetY: top,
        );
      }

      return [
        value(
          'receiver',
          memo.receiver.trim().isEmpty
              ? ''
              : '${memo.receiver.trim()}     المحترم',
          left: 100,
          y: 92,
          width: 380,
          height: 24,
          fontSize: 10,
        ),
        value(
          'date',
          memo.date,
          left: 100,
          y: 116,
          width: 180,
          height: 24,
          fontSize: 10,
          direction: pw.TextDirection.ltr,
        ),
        value(
          'statement',
          memo.statement,
          left: 70,
          y: 145,
          width: 430,
          height: 180,
          fontSize: 11,
        ),
        value(
          'requesterName',
          memo.requesterName,
          left: 100,
          y: 350,
          width: 300,
          height: 24,
          fontSize: 10,
        ),
      ];
    }

    document.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: pw.EdgeInsets.zero,
        build: (_) {
          final children = <pw.Widget>[
            pw.Positioned.fill(child: pw.Image(template, fit: pw.BoxFit.fill)),
            ...fields(request, 0, settings.memoFullA4FieldSettings),
          ];
          // Legacy secondRequest data remains stored for compatibility, but
          // the current internal-memo renderer is one A4 memo per page.
          return pw.Stack(fit: pw.StackFit.expand, children: children);
        },
      ),
    );
  }

  static Future<void> _addOriginalPage(
    pw.Document document,
    ExpenseRequest request,
    AppSettings settings,
    pw.Font regularFont,
    pw.Font fallbackFont,
  ) async {
    // Keep the body artwork fixed and position each header independently.
    // The lower header uses the ISO artwork offset shared by the data layer.
    final svg = await rootBundle.loadString(
      'assets/templates/expense_request_iso_2026_clean.svg',
    );
    final headerTop = pw.MemoryImage(
      (await rootBundle.load(
        'assets/templates/expense_request_header_top.jpg',
      )).buffer.asUint8List(),
    );
    final headerBottom = pw.MemoryImage(
      (await rootBundle.load(
        'assets/templates/expense_request_header_bottom.jpg',
      )).buffer.asUint8List(),
    );
    const templateOffset = expenseRequestTemplateOffset;
    settings = settings.withExpenseRequestMasterLayout();

    document.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: pw.EdgeInsets.zero,
        build: (context) {
          final overlays = <pw.Widget>[
            pw.Positioned.fill(
              child: pw.SvgImage(svg: svg, fit: pw.BoxFit.fill),
            ),
            pw.Positioned(
              left: 43.69,
              right: PdfPageFormat.a4.width - 43.69 - 522.4,
              top: 17.258,
              bottom: PdfPageFormat.a4.height - 17.258 - 37.57,
              child: pw.Image(headerTop, fit: pw.BoxFit.fill),
            ),
            pw.Positioned(
              left: 33.06,
              right: PdfPageFormat.a4.width - 33.06 - 532.99,
              top: 17.258 + templateOffset,
              bottom: PdfPageFormat.a4.height - 17.258 - templateOffset - 37.12,
              child: pw.Image(headerBottom, fit: pw.BoxFit.fill),
            ),
            ..._buildOriginalOverlay(
              request,
              settings,
              regularFont,
              fallbackFont,
              top: 0,
            ),
          ];
          if (request.hasSecondRequest) {
            overlays.addAll(
              _buildOriginalOverlay(
                request.secondRequest!,
                settings,
                regularFont,
                fallbackFont,
                top: templateOffset,
              ),
            );
          }
          return pw.Stack(fit: pw.StackFit.expand, children: overlays);
        },
      ),
    );
  }

  static List<pw.Widget> _buildOriginalOverlay(
    ExpenseRequest request,
    AppSettings settings,
    pw.Font regularFont,
    pw.Font fallbackFont, {
    required double top,
  }) {
    final geometry = TemplateGeometry.forScope('expenseRequest');
    TemplateGeometry g(
      String key,
      double fallbackX,
      double fallbackY,
      double fallbackWidth,
      double fallbackHeight,
    ) =>
        geometry[key] ??
        TemplateGeometry(
          x: fallbackX,
          y: fallbackY,
          width: fallbackWidth,
          height: fallbackHeight,
        );
    final date = g('date', 70, 56, 90, 22);
    final receiver = g('receiver', 105, 70, 350, 22);
    final amountNumber = g('amountNumber', 404, 100, 95, 22);
    final amountWords = g('amountWords', 118, 113, 350, 22);
    final statement = g('statement', 30, 133, 470, 80);
    final branch = g('branch', 5, 282, 150, 22);
    final requester = g('requesterName', 413, 225, 120, 22);
    final directManager = g('directManagerName', 222, 225, 120, 22);
    final approvedAuthority = g('approvedAuthorityName', 57, 225, 120, 22);
    final accountsManager = g('accountsManagerName', 30, 358, 200, 22);
    return [
      _originalValue(
        _pdfDate(request.date),
        settings,
        'date',
        regularFont,
        fallbackFont,
        left: date.x,
        top: top + date.y,
        width: date.width,
        direction: pw.TextDirection.ltr,
        copyOffsetY: top,
      ),
      _originalValue(
        request.receiver,
        settings,
        'receiver',
        regularFont,
        fallbackFont,
        left: receiver.x,
        top: top + receiver.y,
        width: receiver.width,
        copyOffsetY: top,
      ),
      _originalValue(
        request.amountNumber,
        settings,
        'amountNumber',
        regularFont,
        fallbackFont,
        left: amountNumber.x,
        top: top + amountNumber.y,
        width: amountNumber.width,
        direction: pw.TextDirection.ltr,
        copyOffsetY: top,
      ),
      _originalValue(
        request.amountWords,
        settings,
        'amountWords',
        regularFont,
        fallbackFont,
        left: amountWords.x,
        top: top + amountWords.y,
        width: amountWords.width,
        copyOffsetY: top,
      ),
      _originalValue(
        request.statement,
        settings,
        'statement',
        regularFont,
        fallbackFont,
        left: statement.x,
        top: top + statement.y,
        width: statement.width,
        fontSize: 8,
        copyOffsetY: top,
      ),
      _originalValue(
        request.reason,
        settings,
        'reason',
        regularFont,
        fallbackFont,
        left: 82,
        top: top + 145,
        width: 390,
        fontSize: 7,
        copyOffsetY: top,
      ),
      _originalValue(
        request.branch,
        settings,
        'branch',
        regularFont,
        fallbackFont,
        left: branch.x,
        top: top + branch.y,
        width: branch.width,
        fontSize: 7,
        copyOffsetY: top,
      ),
      _originalValue(
        request.account,
        settings,
        'account',
        regularFont,
        fallbackFont,
        left: 260,
        top: top + 330,
        width: 180,
        fontSize: 7,
        copyOffsetY: top,
      ),
      ..._customOriginalOverlay(
        request,
        settings,
        regularFont,
        fallbackFont,
        top: top,
      ),
      _originalValue(
        request.requesterName,
        settings,
        'requesterName',
        regularFont,
        fallbackFont,
        left: requester.x,
        top: top + requester.y,
        width: requester.width,
        fontSize: 7,
        copyOffsetY: top,
      ),
      _originalValue(
        request.directManagerName,
        settings,
        'directManagerName',
        regularFont,
        fallbackFont,
        left: directManager.x,
        top: top + directManager.y,
        width: directManager.width,
        fontSize: 7,
        copyOffsetY: top,
      ),
      _originalValue(
        request.approvedAuthorityName,
        settings,
        'approvedAuthorityName',
        regularFont,
        fallbackFont,
        left: approvedAuthority.x,
        top: top + approvedAuthority.y,
        width: approvedAuthority.width,
        fontSize: 7,
        copyOffsetY: top,
      ),
      _originalValue(
        request.accountsManagerName,
        settings,
        'accountsManagerName',
        regularFont,
        fallbackFont,
        left: accountsManager.x,
        top: top + accountsManager.y,
        width: accountsManager.width,
        fontSize: 8,
        copyOffsetY: top,
      ),
    ];
  }

  static List<pw.Widget> _customOriginalOverlay(
    ExpenseRequest request,
    AppSettings settings,
    pw.Font regularFont,
    pw.Font fallbackFont, {
    required double top,
  }) {
    final entries = settings.fieldSettings.entries
        .where((entry) => entry.key.startsWith('custom_'))
        .where((entry) => entry.value.visible)
        .where((entry) => (request.customFields[entry.key] ?? '').isNotEmpty)
        .take(2)
        .toList();
    return [
      for (var index = 0; index < entries.length; index++)
        _originalValue(
          '${entries[index].value.label}: ${request.customFields[entries[index].key] ?? ''}',
          settings,
          entries[index].key,
          regularFont,
          fallbackFont,
          left: index == 0 ? 85 : 300,
          top: top + 168 + (index * 18),
          width: index == 0 ? 210 : 180,
          fontSize: 7,
          copyOffsetY: top,
        ),
    ];
  }

  static String _pdfDate(String value) {
    final parsed = DateFormatter.parse(value);
    return parsed == null
        ? value.replaceAll(RegExp(r'[-_]'), '/')
        : DateFormatter.date(parsed);
  }

  static pw.Widget _originalValue(
    String value,
    AppSettings settings,
    String key,
    pw.Font regularFont,
    pw.Font fallbackFont, {
    required double left,
    required double top,
    required double width,
    pw.TextDirection direction = pw.TextDirection.rtl,
    double fontSize = 8.5,
    double copyOffsetY = 0,
    bool useFieldGeometry = true,
  }) {
    final field = _field(settings, key);
    if (!field.visible || value.trim().isEmpty) return pw.SizedBox();
    return _positionedValue(
      value,
      field,
      regularFont,
      fallbackFont,
      left: left,
      top: top,
      width: width,
      direction: direction,
      fontSize: fontSize,
      copyOffsetY: copyOffsetY,
      textColorValue: settings.printedTextColorValue,
      key: key,
      allowTruncation: key != 'statement' && key != 'date',
      useFieldGeometry: useFieldGeometry,
    );
  }

  static void _addEditablePage(
    pw.Document document,
    ExpenseRequest request,
    AppSettings settings,
    pw.Font regularFont,
    pw.Font fallbackFont,
  ) {
    final halfHeight = PdfPageFormat.a4.height / 2;
    const templateOffset = expenseRequestTemplateOffset;
    settings = settings.withExpenseRequestMasterLayout();
    document.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        margin: pw.EdgeInsets.zero,
        build: (context) {
          final copies = <pw.Widget>[
            _editableCopy(
              request,
              settings,
              regularFont,
              fallbackFont,
              top: 0,
              height: halfHeight,
            ),
          ];
          if (request.hasSecondRequest) {
            copies.add(
              _editableCopy(
                request.secondRequest!,
                settings,
                regularFont,
                fallbackFont,
                top: templateOffset,
                height: halfHeight,
              ),
            );
          }
          return pw.Stack(fit: pw.StackFit.expand, children: copies);
        },
      ),
    );
  }

  static pw.Widget _editableCopy(
    ExpenseRequest request,
    AppSettings settings,
    pw.Font regularFont,
    pw.Font fallbackFont, {
    required double top,
    required double height,
  }) {
    final primary = PdfColor.fromInt(settings.primaryColorValue);
    final border = PdfColor.fromInt(0xFF263238);
    return pw.Positioned(
      left: 18,
      right: 18,
      top: top + 8,
      bottom: PdfPageFormat.a4.height - top - height + 8,
      child: pw.Container(
        decoration: pw.BoxDecoration(
          border: pw.Border.all(color: border, width: 1),
        ),
        child: pw.Stack(
          fit: pw.StackFit.expand,
          children: [
            pw.Positioned(
              left: 0,
              right: 0,
              top: 0,
              bottom: height - 16 - 48,
              child: pw.Container(
                color: primary,
                padding: const pw.EdgeInsets.symmetric(horizontal: 12),
                child: pw.Row(
                  mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                  children: [
                    _pdfText(
                      settings.companyName,
                      regularFont,
                      fallbackFont,
                      fontSize: 10,
                      color: PdfColors.white,
                    ),
                    _pdfText(
                      settings.formTitle,
                      regularFont,
                      fallbackFont,
                      fontSize: 12,
                      color: PdfColors.white,
                      bold: true,
                    ),
                  ],
                ),
              ),
            ),
            _editableText(
              _pdfDate(request.date),
              settings,
              'date',
              regularFont,
              fallbackFont,
              left: 25,
              top: 60,
              width: 90,
              direction: pw.TextDirection.ltr,
            ),
            _editableLabel(
              settings,
              'date',
              left: 120,
              top: 60,
              width: 95,
              font: regularFont,
              fallback: fallbackFont,
            ),
            _editableText(
              request.receiver,
              settings,
              'receiver',
              regularFont,
              fallbackFont,
              left: 215,
              top: 60,
              width: 320,
            ),
            _editableLabel(
              settings,
              'receiver',
              left: 140,
              top: 60,
              width: 70,
              font: regularFont,
              fallback: fallbackFont,
            ),
            _editableText(
              request.amountNumber,
              settings,
              'amountNumber',
              regularFont,
              fallbackFont,
              left: 400,
              top: 88,
              width: 135,
              direction: pw.TextDirection.ltr,
            ),
            _editableLabel(
              settings,
              'amountNumber',
              left: 300,
              top: 88,
              width: 95,
              font: regularFont,
              fallback: fallbackFont,
            ),
            _editableText(
              request.amountWords,
              settings,
              'amountWords',
              regularFont,
              fallbackFont,
              left: 25,
              top: 88,
              width: 260,
            ),
            _editableLabel(
              settings,
              'amountWords',
              left: 15,
              top: 112,
              width: 110,
              font: regularFont,
              fallback: fallbackFont,
            ),
            _editableText(
              request.statement,
              settings,
              'statement',
              regularFont,
              fallbackFont,
              left: 140,
              top: 140,
              width: 395,
              fontSize: 7.5,
            ),
            _editableLabel(
              settings,
              'statement',
              left: 25,
              top: 140,
              width: 110,
              font: regularFont,
              fallback: fallbackFont,
            ),
            _editableText(
              request.reason,
              settings,
              'reason',
              regularFont,
              fallbackFont,
              left: 140,
              top: 122,
              width: 395,
              fontSize: 7.5,
            ),
            _editableLabel(
              settings,
              'reason',
              left: 25,
              top: 122,
              width: 110,
              font: regularFont,
              fallback: fallbackFont,
            ),
            _editableText(
              request.branch,
              settings,
              'branch',
              regularFont,
              fallbackFont,
              left: 140,
              top: 215,
              width: 180,
            ),
            _editableLabel(
              settings,
              'branch',
              left: 25,
              top: 215,
              width: 100,
              font: regularFont,
              fallback: fallbackFont,
            ),
            _editableText(
              request.account,
              settings,
              'account',
              regularFont,
              fallbackFont,
              left: 340,
              top: 215,
              width: 195,
            ),
            _editableLabel(
              settings,
              'account',
              left: 255,
              top: 215,
              width: 80,
              font: regularFont,
              fallback: fallbackFont,
            ),
            _editableText(
              request.amountNumber,
              settings,
              'amountNumber',
              regularFont,
              fallbackFont,
              left: 340,
              top: 270,
              width: 195,
              direction: pw.TextDirection.ltr,
            ),
            ..._customEditableFields(
              request,
              settings,
              regularFont,
              fallbackFont,
            ),
            _editableText(
              request.accountsManagerName,
              settings,
              'accountsManagerName',
              regularFont,
              fallbackFont,
              left: 300,
              top: 365,
              width: 235,
            ),
            _editableLabel(
              settings,
              'accountsManagerName',
              left: 25,
              top: 365,
              width: 265,
              font: regularFont,
              fallback: fallbackFont,
            ),
            pw.Positioned(
              left: 10,
              right: 10,
              bottom: 5,
              child: _pdfText(
                '${settings.documentNumber}  |  إصدار ${settings.issueVersion}  |  ${_pdfDate(settings.issueDate)}',
                regularFont,
                fallbackFont,
                fontSize: 6,
                color: PdfColors.grey700,
                align: pw.TextAlign.center,
              ),
            ),
          ],
        ),
      ),
    );
  }

  static List<pw.Widget> _customEditableFields(
    ExpenseRequest request,
    AppSettings settings,
    pw.Font regularFont,
    pw.Font fallbackFont,
  ) {
    final entries = settings.fieldSettings.entries
        .where((entry) => entry.key.startsWith('custom_'))
        .where((entry) => entry.value.visible)
        .where((entry) => (request.customFields[entry.key] ?? '').isNotEmpty)
        .take(2)
        .toList();
    final widgets = <pw.Widget>[];
    for (var index = 0; index < entries.length; index++) {
      final entry = entries[index];
      final left = index == 0 ? 25.0 : 300.0;
      final valueLeft = left + 105;
      final width = index == 0 ? 250.0 : 235.0;
      widgets.add(
        _editableLabel(
          settings,
          entry.key,
          left: left,
          top: 330,
          width: 100,
          font: regularFont,
          fallback: fallbackFont,
        ),
      );
      widgets.add(
        _editableText(
          request.customFields[entry.key] ?? '',
          settings,
          entry.key,
          regularFont,
          fallbackFont,
          left: valueLeft,
          top: 330,
          width: width,
          fontSize: 7.5,
        ),
      );
    }
    return widgets;
  }

  static pw.Widget _editableLabel(
    AppSettings settings,
    String key, {
    required double left,
    required double top,
    required double width,
    required pw.Font font,
    required pw.Font fallback,
  }) {
    final field = _field(settings, key);
    if (!field.visible) return pw.SizedBox();
    return pw.Positioned(
      left: left,
      right: 559.28 - left - width,
      top: top,
      child: _pdfText(
        '${field.label}:',
        font,
        fallback,
        fontSize: field.fontSize.clamp(7, 12),
        color: PdfColor.fromInt(settings.printedTextColorValue),
        bold: true,
      ),
    );
  }

  static pw.Widget _editableText(
    String value,
    AppSettings settings,
    String key,
    pw.Font regularFont,
    pw.Font fallbackFont, {
    required double left,
    required double top,
    required double width,
    pw.TextDirection direction = pw.TextDirection.rtl,
    double fontSize = 8.5,
  }) {
    final field = _field(settings, key);
    if (!field.visible || value.trim().isEmpty) return pw.SizedBox();
    return _positionedValue(
      value,
      field,
      regularFont,
      fallbackFont,
      left: left,
      top: top,
      width: width,
      direction: direction,
      fontSize: fontSize,
      textColorValue: settings.printedTextColorValue,
      key: key,
      allowTruncation: key != 'statement' && key != 'date',
    );
  }

  static int _maxTextCharacters({
    required double width,
    required double fontSize,
    required int maxLines,
  }) {
    final estimatedCharsPerLine = (width / (fontSize * 0.62)).floor().clamp(
      1,
      160,
    );
    return (estimatedCharsPerLine * maxLines).clamp(1, 320);
  }

  static String _fitTextToField(
    String value, {
    required double width,
    required double fontSize,
    required int maxLines,
    bool allowTruncation = true,
  }) {
    if (!allowTruncation) return value;
    final maxCharacters = _maxTextCharacters(
      width: width,
      fontSize: fontSize,
      maxLines: maxLines,
    );
    if (value.runes.length <= maxCharacters) return value;
    final runes = value.runes.toList();
    final kept = runes.take(maxCharacters - 1);
    // The bidi package used by package:pdf can throw RangeError for U+2026
    // when it is appended to a long RTL string. ASCII dots preserve the
    // visual truncation cue without entering that faulty normalization path.
    return '${String.fromCharCodes(kept)}...';
  }

  static pw.Widget _positionedValue(
    String value,
    FieldSetting field,
    pw.Font regularFont,
    pw.Font fallbackFont, {
    required double left,
    required double top,
    required double width,
    double? height,
    required pw.TextDirection direction,
    required double fontSize,
    required String key,
    bool allowTruncation = true,
    double copyOffsetY = 0,
    bool useFieldGeometry = true,
    int? textColorValue,
    double? fontSizeOverride,
    String? alignmentOverride,
    int? fontWeightOverride,
    double pageWidth = 595.28,
    double pageHeight = 841.89,
  }) {
    final isBottomCopy = copyOffsetY > 0;
    // User-editable geometry must never produce a negative right/bottom
    // constraint or a NaN/Infinity value for the PDF layout engine.
    final rawWidth =
        !useFieldGeometry || !field.geometryConfigured || field.width <= 1
        ? width
        : field.width;
    final safeWidth = _finiteOr(
      rawWidth,
      width,
    ).clamp(1.0, pageWidth).toDouble();
    final rawLeft = !useFieldGeometry || !field.geometryConfigured
        ? left
        : field.x;
    final configuredLeft = _finiteOr(
      rawLeft,
      left,
    ).clamp(0.0, pageWidth - safeWidth).toDouble();
    final localTop = !useFieldGeometry || !field.geometryConfigured
        ? top - copyOffsetY
        : field.y;
    final rawTop = isBottomCopy ? copyOffsetY + localTop : localTop;
    final safeTop = _finiteOr(
      rawTop,
      top,
    ).clamp(0.0, pageHeight - 1.0).toDouble();
    final selectedFont = _configuredFonts[field.fontFamily];
    // The field rectangle is geometry, not typography: changing font settings
    // must never move or resize the stored field box.
    // Never allow a stored legacy value to collapse Arabic glyphs and marks.
    final safeLineHeight = field.lineHeight.clamp(0.2, 4.0).toDouble();
    final defaultHeight = height ?? (key == 'statement' ? 220.0 : 22.0);
    final configuredFieldHeight = !field.geometryConfigured || field.height <= 1
        ? defaultHeight
        : field.height;
    final rawHeight = !useFieldGeometry ? defaultHeight : configuredFieldHeight;
    final configuredHeight = _finiteOr(
      rawHeight,
      fontSize * 2,
    ).clamp(1.0, pageHeight - safeTop).toDouble();
    final configuredFontSize = field.fontSize.clamp(7, 24).toDouble();
    // Keep the user's selected statement size. Long text gets more usable
    // vertical space and lines instead of being silently reduced to 7 pt.
    final effectiveFontSize = fontSizeOverride ?? configuredFontSize;
    // The form-wide printed color is selected from the model settings and
    // must apply consistently to every printed field in that model. Older
    // field-level colors remain stored for compatibility but do not override
    // an explicitly supplied form color.
    final effectiveTextColorValue = textColorValue ?? field.colorValue;
    final maxLines = key == 'date'
        ? 1
        : (configuredHeight / (effectiveFontSize * safeLineHeight))
              .floor()
              .clamp(1, 12)
              .toInt();
    final displayValue = _isMonetaryKey(key)
        ? NumberNormalizer.formatGrouped(value)
        : value;
    final normalizedValue = PdfTextSanitizer.normalize(displayValue);
    if (!allowTruncation &&
        normalizedValue.runes.length >
            _maxTextCharacters(
              width: safeWidth,
              fontSize: effectiveFontSize,
              maxLines: maxLines,
            )) {
      throw StateError(
        'النص طويل جدًا للحقل «$key»؛ اختصر النص ثم أعد إنشاء ملف PDF.',
      );
    }
    final safeValue = _fitTextToField(
      normalizedValue,
      width: safeWidth,
      fontSize: effectiveFontSize,
      maxLines: maxLines,
      allowTruncation: allowTruncation,
    );
    // Keep the leading edge of RTL item names away from the cell divider with
    // a real non-breaking space in the rendered value, without changing data.
    final renderedValue = key.startsWith('sampleItemName')
        ? '\u00A0$safeValue'
        : safeValue;

    return pw.Positioned(
      left: configuredLeft,
      right: pageWidth - configuredLeft - safeWidth,
      top: safeTop,
      child: pw.Container(
        height: configuredHeight,
        child: pw.Directionality(
          textDirection: direction,
          child: pw.Text(
            renderedValue,
            maxLines: maxLines,
            overflow: pw.TextOverflow.clip,
            softWrap: true,
            textAlign: _textAlign(
              alignmentOverride ?? field.alignment,
              direction,
            ),
            style: pw.TextStyle(
              // Use the selected family as primary; Noto Sans remains a safe
              // fallback for glyphs that the selected family does not contain.
              font: selectedFont ?? regularFont,
              fontFallback: [
                ?selectedFont,
                regularFont,
                fallbackFont,
                ?_latinFallbackFont,
              ],
              fontSize: effectiveFontSize,
              color: PdfColor.fromInt(effectiveTextColorValue),
              fontWeight: _fontWeight(fontWeightOverride ?? field.fontWeight),
              fontStyle: field.fontStyle == 'italic'
                  ? pw.FontStyle.italic
                  : pw.FontStyle.normal,
              height: safeLineHeight,
            ),
          ),
        ),
      ),
    );
  }

  static bool _isMonetaryKey(String key) =>
      key == 'amountNumber' ||
      key.startsWith('clearanceAmount') ||
      key.startsWith('previousPurchases') ||
      key.startsWith('previousPayments') ||
      key.startsWith('currentPurchases') ||
      key.startsWith('currentPayments');

  static double _finiteOr(double value, double fallback) {
    return value.isFinite ? value : fallback;
  }

  static pw.TextAlign _textAlign(String alignment, pw.TextDirection direction) {
    return switch (alignment) {
      'left' => pw.TextAlign.left,
      'center' => pw.TextAlign.center,
      _ =>
        direction == pw.TextDirection.rtl
            ? pw.TextAlign.right
            : pw.TextAlign.left,
    };
  }

  static pw.FontWeight _fontWeight(int weight) {
    return weight >= 700 ? pw.FontWeight.bold : pw.FontWeight.normal;
  }

  static pw.Widget _pdfText(
    String value,
    pw.Font font,
    pw.Font fallback, {
    required double fontSize,
    PdfColor color = PdfColors.black,
    bool bold = false,
    pw.TextAlign align = pw.TextAlign.right,
  }) {
    return pw.Directionality(
      textDirection: pw.TextDirection.rtl,
      child: pw.Text(
        PdfTextSanitizer.normalize(value),
        textAlign: align,
        style: pw.TextStyle(
          font: font,
          fontFallback: [font, fallback, ?_latinFallbackFont],
          fontSize: fontSize,
          color: color,
          fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal,
        ),
      ),
    );
  }

  static FieldSetting _field(AppSettings settings, String key) {
    return settings.fieldSettings[key] ??
        const FieldSetting(label: '', visible: true, required: false);
  }
}

/// Public facade for the full A4 internal-memo layout.
///
/// The implementation deliberately delegates to the already verified memo
/// renderer so the original scanned template, top/bottom field geometry, RTL
/// sanitization, and signature/footer areas remain consistent.
class LargeMemoPdfBuilder {
  const LargeMemoPdfBuilder._();

  static Future<void> addPage({
    required pw.Document document,
    required ExpenseRequest request,
    required AppSettings settings,
    required pw.Font regularFont,
    required pw.Font fallbackFont,
  }) {
    return PdfService._addInternalMemoPage(
      document,
      request,
      settings,
      regularFont,
      fallbackFont,
    );
  }

  static pw.Widget highlightedStatement({
    required String text,
    required pw.Font font,
    required pw.Font fontBold,
    Map<String, PdfColor>? keywordColors,
    Map<String, PdfColor>? keywordHighlights,
    double fontSize = 10,
  }) {
    return PdfService.buildHighlightedText(
      text: text,
      font: font,
      fontBold: fontBold,
      keywordColors: keywordColors,
      keywordHighlights: keywordHighlights,
      fontSize: fontSize,
    );
  }
}
