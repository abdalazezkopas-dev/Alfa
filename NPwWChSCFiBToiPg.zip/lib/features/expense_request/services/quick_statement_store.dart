import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/security/secure_local_store.dart';
import '../../../core/services/app_logger.dart';
import '../../../core/store_mutex.dart';

class QuickStatementStore {
  QuickStatementStore._();

  static const _prefix = 'alfa.quick_statements.';
  static const scopes = <String, String>{
    'expenseRequest': 'طلب الصرف',
    'customerApplication': 'نموذج العملاء',
    'clearanceRequest': 'طلب إخلاء العهدة',
    'serviceRequest': 'طلب الخدمة',
    'internalMemo': 'المذكرة الداخلية',
    'sampleRequest': 'طلب العينات',
    'sampleRequestSinglePage': 'طلب العينات — صفحة واحدة',
    'fuelRequest': 'طلب المحروقات',
    'travelAllowance': 'بدل السفر',
  };
  static const defaults = <String>[
    'مقابل سداد فاتورة',
    'مقابل شراء بضاعة',
    'مقابل مصاريف نقل',
    'مقابل مصاريف شحن',
    'مقابل عهدة',
    'مقابل تسوية حساب',
    'مقابل سداد مديونية',
  ];

  static Future<List<String>> load(String scope) =>
      StoreMutex.run('quick_statements:$scope', () => _loadUnlocked(scope));

  static Future<List<String>> _loadUnlocked(String scope) async {
    final prefs = await SharedPreferences.getInstance();
    String? raw;
    try {
      raw = await SecureLocalStore.read('quick_statements.$scope');
    } catch (error, stackTrace) {
      AppLogger.error(
        'Store operation failed; using the existing fallback',
        error: error,
        stackTrace: stackTrace,
        scope: 'quick_statements',
      );
    }
    final fromSecure = raw != null && raw.isNotEmpty;
    raw ??= prefs.getString(_prefix + scope);
    if (raw == null || raw.isEmpty) return List<String>.from(defaults);
    try {
      final decoded = jsonDecode(raw);
      if (decoded is List) {
        final values = decoded
            .whereType<String>()
            .map((e) => e.trim())
            .where((e) => e.isNotEmpty)
            .where((e) => e != 'بنظر أ/حميد المقحفي مقابل')
            .toList();
        // An explicitly saved empty list is valid. Falling back to defaults
        // here made a successful delete appear to undo itself on reload.
        final result = List<String>.from(values);
        if (!fromSecure) {
          try {
            await SecureLocalStore.writeJson('quick_statements.$scope', result);
            await prefs.remove(_prefix + scope);
          } catch (error, stackTrace) {
            AppLogger.error(
              'Store operation failed; using the existing fallback',
              error: error,
              stackTrace: stackTrace,
              scope: 'quick_statements',
            );
          }
        }
        return result;
      }
    } catch (error, stackTrace) {
      AppLogger.error(
        'Store operation failed; using the existing fallback',
        error: error,
        stackTrace: stackTrace,
        scope: 'quick_statements',
      );
    }
    return List<String>.from(defaults);
  }

  static Future<void> _saveUnlocked(String scope, List<String> values) async {
    final prefs = await SharedPreferences.getInstance();
    final bounded = <String>[];
    for (final value in values) {
      final clean = value.trim();
      if (clean.isEmpty || clean == 'بنظر أ/حميد المقحفي مقابل') continue;
      if (bounded.contains(clean)) continue;
      bounded.add(clean);
      if (bounded.length == 100) break;
    }
    await SecureLocalStore.writeJson('quick_statements.$scope', bounded);
    await prefs.remove(_prefix + scope);
  }

  static Future<void> save(String scope, List<String> values) => StoreMutex.run(
    'quick_statements:$scope',
    () => _saveUnlocked(scope, values),
  );

  static Future<void> add(String scope, String value) =>
      StoreMutex.run('quick_statements:$scope', () async {
        final values = await _loadUnlocked(scope);
        final clean = value.trim();
        if (clean.isEmpty) return;
        values.remove(clean);
        values.insert(0, clean);
        await _saveUnlocked(scope, values);
      });

  static Future<void> update(String scope, String oldValue, String newValue) =>
      StoreMutex.run('quick_statements:$scope', () async {
        final values = await _loadUnlocked(scope);
        final clean = newValue.trim();
        if (clean.isEmpty) return;
        final index = values.indexOf(oldValue.trim());
        if (index < 0) return;
        values.removeWhere((value) => value == clean && value != oldValue);
        values[index] = clean;
        await _saveUnlocked(scope, values);
      });

  static Future<void> delete(String scope, String value) =>
      StoreMutex.run('quick_statements:$scope', () async {
        final values = await _loadUnlocked(scope);
        values.removeWhere((item) => item == value.trim());
        await _saveUnlocked(scope, values);
      });
}

Future<String?> showQuickStatementPicker(
  BuildContext context, {
  required String scope,
  String query = '',
}) async {
  final values = await QuickStatementStore.load(scope);
  if (!context.mounted) return null;
  final search = TextEditingController(text: query);
  var filtered = values;
  final selected = await showDialog<String>(
    context: context,
    builder: (dialogContext) => StatefulBuilder(
      builder: (context, setState) => AlertDialog(
        title: const Text('عبارات سريعة للبيان'),
        content: SizedBox(
          width: 420,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: search,
                decoration: const InputDecoration(
                  prefixIcon: Icon(Icons.search),
                  labelText: 'بحث في العبارات',
                ),
                onChanged: (value) => setState(() {
                  final q = value.trim().toLowerCase();
                  filtered = values
                      .where((item) => item.toLowerCase().contains(q))
                      .toList();
                }),
              ),
              const SizedBox(height: 8),
              SizedBox(
                height: 260,
                child: ListView.builder(
                  itemCount: filtered.length,
                  itemBuilder: (_, index) {
                    final value = filtered[index];
                    return ListTile(
                      dense: true,
                      leading: const Icon(Icons.bolt_outlined),
                      title: Text(value),
                      onTap: () => Navigator.pop(dialogContext, value),
                      trailing: IconButton(
                        tooltip: 'حذف العبارة',
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          values.remove(value);
                          await QuickStatementStore.save(scope, values);
                          setState(() => filtered = values.toList());
                        },
                      ),
                    );
                  },
                ),
              ),
              TextButton.icon(
                onPressed: () async {
                  final controller = TextEditingController();
                  final value = await showDialog<String>(
                    context: dialogContext,
                    builder: (_) => AlertDialog(
                      title: const Text('إضافة عبارة سريعة'),
                      content: TextField(
                        controller: controller,
                        autofocus: true,
                        maxLines: 3,
                        decoration: const InputDecoration(labelText: 'العبارة'),
                      ),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('إلغاء'),
                        ),
                        FilledButton(
                          onPressed: () =>
                              Navigator.pop(context, controller.text),
                          child: const Text('حفظ'),
                        ),
                      ],
                    ),
                  );
                  controller.dispose();
                  if (value == null || value.trim().isEmpty) return;
                  await QuickStatementStore.add(scope, value);
                  if (dialogContext.mounted) {
                    Navigator.pop(dialogContext, value.trim());
                  }
                },
                icon: const Icon(Icons.add),
                label: const Text('إضافة عبارة جديدة'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إغلاق'),
          ),
        ],
      ),
    ),
  );
  search.dispose();
  return selected;
}
