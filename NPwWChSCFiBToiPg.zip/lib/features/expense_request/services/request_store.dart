import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/services/attachment_manager.dart';
import '../../../core/security/secure_local_store.dart';
import '../../../core/store_mutex.dart';
import '../models/expense_request.dart';

class RequestStore {
  const RequestStore._();

  /// Finds an equivalent business record, excluding the record being edited.
  static Future<int?> findDuplicateIndex(
    ExpenseRequest request, {
    int? ignoreIndex,
  }) async {
    final requests = await load();
    final fingerprint = _fingerprint(request);
    for (var i = 0; i < requests.length; i++) {
      if (i != ignoreIndex && _fingerprint(requests[i]) == fingerprint) {
        return i;
      }
    }
    return null;
  }

  static const _requestsKey = 'alfa_expense_app.requests.v1';
  static const _legacyRequestsKey = 'alfa_expense_app.requests';

  static Future<List<ExpenseRequest>> load() =>
      StoreMutex.run('requests', _loadUnlocked);

  static Future<List<String>> savedCustomerNames() async {
    final requests = await load();
    final names = <String>{};
    for (final request in requests) {
      if (request.documentType != ExpenseDocumentType.customerApplication) {
        continue;
      }
      final value = request.customFields['customer']?.trim() ?? '';
      if (value.isNotEmpty) names.add(value);
    }
    return names.toList()..sort();
  }

  static Future<List<ExpenseRequest>> _loadUnlocked() async {
    final preferences = await SharedPreferences.getInstance();
    final secure = await SecureLocalStore.read('requests');
    if (secure != null && secure.isNotEmpty) return _decode(secure);

    final versioned = preferences.getString(_requestsKey);
    final legacy = preferences.getString(_legacyRequestsKey);
    final raw = versioned != null && versioned.isNotEmpty ? versioned : legacy;
    if (raw == null || raw.isEmpty) return [];

    final decoded = _decode(raw);
    try {
      await SecureLocalStore.write(
        'requests',
        jsonEncode(decoded.map((request) => request.toMap()).toList()),
      );
      final verified = await SecureLocalStore.read('requests');
      if (verified !=
          jsonEncode(decoded.map((request) => request.toMap()).toList())) {
        throw StateError('تعذر التحقق من ترحيل الطلبات إلى التخزين المشفر');
      }
      if (versioned != null && versioned.isNotEmpty) {
        await preferences.remove(_requestsKey);
      }
      if (legacy != null && legacy.isNotEmpty) {
        await preferences.remove(_legacyRequestsKey);
      }
    } catch (_) {
      // Keep the readable plaintext fallback for a retry; never replace it with [].
    }
    return decoded;
  }

  static List<ExpenseRequest> _decode(String raw) {
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) {
        throw const FormatException('صيغة سجل الطلبات غير صحيحة');
      }
      final result = <ExpenseRequest>[];
      for (final item in decoded) {
        if (item is! Map) {
          throw const FormatException('يوجد سجل طلب تالف');
        }
        result.add(ExpenseRequest.fromMap(Map<String, Object?>.from(item)));
      }
      return result;
    } on FormatException {
      rethrow;
    } catch (error) {
      throw FormatException('تعذر قراءة سجل الطلبات بأمان: $error');
    }
  }

  static Future<void> saveAll(List<ExpenseRequest> requests) =>
      StoreMutex.run('requests', () => _saveUnlocked(requests));

  static Future<void> _saveUnlocked(List<ExpenseRequest> requests) async {
    final preferences = await SharedPreferences.getInstance();
    final value = jsonEncode(
      requests.map((request) => request.toMap()).toList(),
    );
    await SecureLocalStore.write('requests', value);
    await preferences.remove(_requestsKey);
    await preferences.remove(_legacyRequestsKey);
  }

  static Future<bool> add(ExpenseRequest request) => StoreMutex.run(
    'requests',
    () async {
      final requests = await _loadUnlocked();
      if (requests.any((item) => _fingerprint(item) == _fingerprint(request))) {
        return false;
      }
      requests.insert(0, request);
      await _saveUnlocked(requests);
      return true;
    },
  );

  static Future<bool> updateAt(int index, ExpenseRequest request) =>
      StoreMutex.run('requests', () async {
        final requests = await _loadUnlocked();
        if (index < 0 || index >= requests.length) return false;
        for (var i = 0; i < requests.length; i++) {
          if (i != index &&
              _fingerprint(requests[i]) == _fingerprint(request)) {
            return false;
          }
        }
        final previous = requests[index];
        requests[index] = request;
        await _saveUnlocked(requests);
        await AttachmentManager.deleteAttachments(
          previous.allAttachmentPaths.where(
            (path) => !request.allAttachmentPaths.contains(path),
          ),
          activeRequests: requests,
        );
        return true;
      });

  static Future<void> deleteAt(int index) =>
      StoreMutex.run('requests', () async {
        final requests = await _loadUnlocked();
        if (index < 0 || index >= requests.length) return;
        final removed = requests[index];
        requests.removeAt(index);
        await _saveUnlocked(requests);
        await AttachmentManager.deleteAttachments(
          removed.allAttachmentPaths,
          activeRequests: requests,
        );
      });

  static Future<void> clear() => StoreMutex.run('requests', () async {
    final preferences = await SharedPreferences.getInstance();
    await SecureLocalStore.remove('requests');
    await preferences.remove(_requestsKey);
    await preferences.remove(_legacyRequestsKey);
    await AttachmentManager.cleanupOrphaned(activeRequests: const []);
  });

  static String _fingerprint(ExpenseRequest request) {
    Object normalize(Object? value) {
      if (value is Map) {
        final entries = value.entries.toList()
          ..sort((a, b) => a.key.toString().compareTo(b.key.toString()));
        return <String, Object?>{
          for (final entry in entries)
            entry.key.toString(): normalize(entry.value),
        };
      }
      if (value is Iterable) {
        return value.map(normalize).toList(growable: false);
      }
      return value ?? '';
    }

    final map = request.toMap();
    map.remove('settingsSnapshot');
    map.remove('isFavorite');
    map.remove('attachmentPath');
    map.remove('attachmentPaths');
    return jsonEncode(normalize(map));
  }
}
