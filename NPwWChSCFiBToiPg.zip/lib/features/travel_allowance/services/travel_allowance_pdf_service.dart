import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../../settings/models/app_settings.dart';
import '../../settings/models/template_geometry.dart';
import '../models/travel_allowance_request.dart';

class TravelAllowancePdfService {
  const TravelAllowancePdfService._();

  static Future<Uint8List> build(
    TravelAllowanceRequest request, {
    AppSettings? settings,
  }) async {
    final effectiveSettings =
        settings ?? AppSettings.defaultsForScope('travelAllowance');
    final fields = effectiveSettings.fieldSettings;
    final geometry = TemplateGeometry.forScope('travelAllowance');
    final background = pw.MemoryImage(
      (await rootBundle.load(
        'assets/templates/travel_allowance_request.png',
      )).buffer.asUint8List(),
    );
    final regular = pw.Font.ttf(
      (await rootBundle.load('assets/fonts/NotoSansArabic-Regular.ttf')),
    );
    final fallback = pw.Font.ttf(
      (await rootBundle.load('assets/fonts/DejaVuSans.ttf')),
    );
    final document = pw.Document(title: 'كشف بدل السفر');

    pw.TextAlign textAlign(String value) => switch (value) {
      'left' => pw.TextAlign.left,
      'right' => pw.TextAlign.right,
      _ => pw.TextAlign.center,
    };

    pw.Widget text(
      String key,
      String value, {
      pw.TextDirection direction = pw.TextDirection.rtl,
      double? fontSize,
    }) {
      if (value.trim().isEmpty) return pw.SizedBox();
      final box = geometry[key];
      if (box == null) return pw.SizedBox();
      final field = fields[key];
      if (field?.visible == false) return pw.SizedBox();
      final left = field?.geometryConfigured == true ? field!.x : box.x;
      final top = field?.geometryConfigured == true ? field!.y : box.y;
      final width = field?.geometryConfigured == true
          ? field!.width
          : box.width;
      final height = field?.geometryConfigured == true
          ? field!.height
          : box.height;
      final size = fontSize ?? (field?.fontSize ?? 9).clamp(6, 18).toDouble();
      final color = PdfColor.fromInt(
        field?.colorValue ?? effectiveSettings.printedTextColorValue,
      );
      return pw.Positioned(
        left: left,
        top: top,
        child: pw.SizedBox(
          width: width,
          height: height,
          child: pw.Text(
            value,
            textDirection: direction,
            textAlign: textAlign(field?.alignment ?? 'center'),
            maxLines: height >= size * 2 ? 2 : 1,
            style: pw.TextStyle(
              font: regular,
              fontFallback: [fallback],
              fontSize: size,
              color: color,
              lineSpacing: 0,
            ),
          ),
        ),
      );
    }

    final overlays = <pw.Widget>[
      text('branch', request.branch),
      text('month', request.month),
      text('year', request.year, direction: pw.TextDirection.ltr),
    ];
    for (var index = 0; index < request.rows.length && index < 10; index++) {
      final row = request.rows[index];
      final number = index + 1;
      overlays.addAll([
        text('travelDay$number', row.day.isEmpty ? '$number' : row.day),
        text('travelDate$number', row.date, direction: pw.TextDirection.ltr),
        text(
          'travelDailyAmount$number',
          row.dailyAmount,
          direction: pw.TextDirection.ltr,
        ),
        text('travelRegion$number', row.region),
        text('travelStatement$number', row.statement),
      ]);
    }
    overlays.addAll([
      text(
        'totalAmount',
        request.totalAmount.toStringAsFixed(2),
        direction: pw.TextDirection.ltr,
      ),
      text('totalDays', '${request.totalDays}'),
      text('beneficiary', request.beneficiary),
      text('branchManager', request.branchManager),
      text('departmentManager', request.departmentManager),
      text('administrationAccountant', request.administrationAccountant),
      text('accountsManager', request.accountsManager),
    ]);

    document.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: pw.EdgeInsets.zero,
        build: (_) => pw.Stack(
          fit: pw.StackFit.expand,
          children: [
            pw.Positioned.fill(child: pw.Image(background)),
            ...overlays,
          ],
        ),
      ),
    );
    return document.save();
  }
}
