import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/security/secure_local_store.dart';
import '../../../core/store_mutex.dart';
import '../models/travel_allowance_request.dart';

class TravelAllowanceStore {
  const TravelAllowanceStore._();

  static const _secureKey = 'travel_allowance_requests';
  static const _preferenceKey = 'alfa_expense_app.travel_allowance.v1';

  static Future<List<TravelAllowanceRequest>> load() =>
      StoreMutex.run('travel_allowance', _loadUnlocked);

  static Future<List<TravelAllowanceRequest>> _loadUnlocked() async {
    final preferences = await SharedPreferences.getInstance();
    final secure = await SecureLocalStore.read(_secureKey);
    final raw = secure?.isNotEmpty == true
        ? secure!
        : preferences.getString(_preferenceKey);
    if (raw == null || raw.isEmpty) return [];
    final decoded = jsonDecode(raw);
    if (decoded is! List) return [];
    return decoded
        .whereType<Map>()
        .map(
          (item) =>
              TravelAllowanceRequest.fromMap(Map<String, Object?>.from(item)),
        )
        .toList();
  }

  static Future<void> _saveUnlocked(
    List<TravelAllowanceRequest> requests,
  ) async {
    final value = jsonEncode(
      requests.map((request) => request.toMap()).toList(),
    );
    await SecureLocalStore.write(_secureKey, value);
    final preferences = await SharedPreferences.getInstance();
    await preferences.remove(_preferenceKey);
  }

  static Future<bool> add(TravelAllowanceRequest request) =>
      StoreMutex.run('travel_allowance', () async {
        final requests = await _loadUnlocked();
        requests.insert(0, request);
        await _saveUnlocked(requests);
        return true;
      });

  static Future<bool> updateAt(int index, TravelAllowanceRequest request) =>
      StoreMutex.run('travel_allowance', () async {
        final requests = await _loadUnlocked();
        if (index < 0 || index >= requests.length) return false;
        requests[index] = request;
        await _saveUnlocked(requests);
        return true;
      });

  static Future<void> deleteAt(int index) =>
      StoreMutex.run('travel_allowance', () async {
        final requests = await _loadUnlocked();
        if (index < 0 || index >= requests.length) return;
        requests.removeAt(index);
        await _saveUnlocked(requests);
      });
}
