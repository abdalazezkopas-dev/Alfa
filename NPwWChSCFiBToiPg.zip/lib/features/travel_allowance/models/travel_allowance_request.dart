class TravelAllowanceRow {
  const TravelAllowanceRow({
    this.day = '',
    this.date = '',
    this.dailyAmount = '',
    this.region = '',
    this.statement = '',
  });

  final String day;
  final String date;
  final String dailyAmount;
  final String region;
  final String statement;

  TravelAllowanceRow copyWith({
    String? day,
    String? date,
    String? dailyAmount,
    String? region,
    String? statement,
  }) => TravelAllowanceRow(
    day: day ?? this.day,
    date: date ?? this.date,
    dailyAmount: dailyAmount ?? this.dailyAmount,
    region: region ?? this.region,
    statement: statement ?? this.statement,
  );

  Map<String, Object?> toMap() => {
    'day': day,
    'date': date,
    'dailyAmount': dailyAmount,
    'region': region,
    'statement': statement,
  };

  factory TravelAllowanceRow.fromMap(Map<String, Object?> map) =>
      TravelAllowanceRow(
        day: map['day']?.toString() ?? '',
        date: map['date']?.toString() ?? '',
        dailyAmount: map['dailyAmount']?.toString() ?? '',
        region: map['region']?.toString() ?? '',
        statement: map['statement']?.toString() ?? '',
      );
}

class TravelAllowanceRequest {
  const TravelAllowanceRequest({
    this.branch = '',
    this.month = '',
    this.year = '',
    this.rows = const [],
    this.beneficiary = '',
    this.branchManager = '',
    this.departmentManager = '',
    this.administrationAccountant = '',
    this.accountsManager = '',
  });

  final String branch;
  final String month;
  final String year;
  final List<TravelAllowanceRow> rows;
  final String beneficiary;
  final String branchManager;
  final String departmentManager;
  final String administrationAccountant;
  final String accountsManager;

  double get totalAmount => rows.fold<double>(
    0,
    (sum, row) =>
        sum +
        (double.tryParse(
              row.dailyAmount.replaceAll(',', '').replaceAll('٬', '').trim(),
            ) ??
            0),
  );

  int get totalDays => rows.where((row) => row.date.trim().isNotEmpty).length;

  Map<String, Object?> toMap() => {
    'branch': branch,
    'month': month,
    'year': year,
    'rows': rows.map((row) => row.toMap()).toList(),
    'beneficiary': beneficiary,
    'branchManager': branchManager,
    'departmentManager': departmentManager,
    'administrationAccountant': administrationAccountant,
    'accountsManager': accountsManager,
  };

  factory TravelAllowanceRequest.fromMap(Map<String, Object?> map) {
    final rawRows = map['rows'];
    final rows = rawRows is List
        ? rawRows
              .whereType<Map>()
              .map(
                (row) =>
                    TravelAllowanceRow.fromMap(Map<String, Object?>.from(row)),
              )
              .take(10)
              .toList()
        : <TravelAllowanceRow>[];
    return TravelAllowanceRequest(
      branch: map['branch']?.toString() ?? '',
      month: map['month']?.toString() ?? '',
      year: map['year']?.toString() ?? '',
      rows: rows,
      beneficiary: map['beneficiary']?.toString() ?? '',
      branchManager: map['branchManager']?.toString() ?? '',
      departmentManager: map['departmentManager']?.toString() ?? '',
      administrationAccountant:
          map['administrationAccountant']?.toString() ?? '',
      accountsManager: map['accountsManager']?.toString() ?? '',
    );
  }
}
