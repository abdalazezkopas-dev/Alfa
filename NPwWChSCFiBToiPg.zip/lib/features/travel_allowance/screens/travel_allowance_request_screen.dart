import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';

import '../../expense_request/services/share_service.dart';
import '../../settings/models/app_settings.dart';
import '../../settings/models/template_configuration.dart';
import '../../settings/screens/settings_screen.dart';
import '../../settings/screens/template_preview_screen.dart';
import '../../settings/services/settings_store.dart';
import '../models/travel_allowance_request.dart';
import '../services/travel_allowance_pdf_service.dart';
import '../services/travel_allowance_store.dart';

class TravelAllowanceRequestScreen extends StatefulWidget {
  const TravelAllowanceRequestScreen({
    this.initialRequest,
    this.editingIndex,
    super.key,
  });

  final TravelAllowanceRequest? initialRequest;
  final int? editingIndex;

  @override
  State<TravelAllowanceRequestScreen> createState() =>
      _TravelAllowanceRequestScreenState();
}

class _TravelAllowanceRequestScreenState
    extends State<TravelAllowanceRequestScreen> {
  static const _months = <String>[
    'يناير',
    'فبراير',
    'مارس',
    'أبريل',
    'مايو',
    'يونيو',
    'يوليو',
    'أغسطس',
    'سبتمبر',
    'أكتوبر',
    'نوفمبر',
    'ديسمبر',
  ];
  static const _defaultBranches = <String>[
    'الجنوبية',
    'الوسطى',
    'الغربية',
    'الشمالية',
    'كبار العملاء',
    'البريات',
  ];

  final _formKey = GlobalKey<FormState>();
  final _formScrollController = ScrollController();
  final _branch = TextEditingController();
  final _month = TextEditingController();
  final _year = TextEditingController(text: DateTime.now().year.toString());
  final _beneficiary = TextEditingController();
  final _branchManager = TextEditingController();
  final _departmentManager = TextEditingController();
  final _administrationAccountant = TextEditingController();
  final _accountsManager = TextEditingController();
  final List<_RowControllers> _rows = [];
  AppSettings _settings = AppSettings.defaultsForScope('travelAllowance');
  bool _busy = false;
  bool _settingsLoaded = false;

  @override
  void initState() {
    super.initState();
    final request = widget.initialRequest;
    if (request == null) {
      _addRow();
    } else {
      _branch.text = request.branch;
      _month.text = request.month;
      _year.text = request.year;
      _beneficiary.text = request.beneficiary;
      _branchManager.text = request.branchManager;
      _departmentManager.text = request.departmentManager;
      _administrationAccountant.text = request.administrationAccountant;
      _accountsManager.text = request.accountsManager;
      for (final row in request.rows) {
        _addRow(row);
      }
      if (_rows.isEmpty) _addRow();
    }
    _loadSettings();
  }

  @override
  void dispose() {
    for (final row in _rows) {
      row.dispose();
    }
    _formScrollController.dispose();
    for (final controller in [
      _branch,
      _month,
      _year,
      _beneficiary,
      _branchManager,
      _departmentManager,
      _administrationAccountant,
      _accountsManager,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _loadSettings() async {
    try {
      final settings = await SettingsStore.load(scope: 'travelAllowance');
      if (!mounted) return;
      setState(() {
        _settings = settings;
        _settingsLoaded = true;
      });
    } catch (_) {
      if (mounted) setState(() => _settingsLoaded = true);
    }
  }

  void _addRow([TravelAllowanceRow? value]) {
    if (_rows.length >= 10) return;
    setState(
      () => _rows.add(
        _RowControllers(
          value ?? TravelAllowanceRow(day: '${_rows.length + 1}'),
        ),
      ),
    );
  }

  TravelAllowanceRequest _collect() => TravelAllowanceRequest(
    branch: _branch.text.trim(),
    month: _month.text.trim(),
    year: _year.text.trim(),
    rows: _rows.map((row) => row.value).toList(),
    beneficiary: _beneficiary.text.trim(),
    branchManager: _branchManager.text.trim(),
    departmentManager: _departmentManager.text.trim(),
    administrationAccountant: _administrationAccountant.text.trim(),
    accountsManager: _accountsManager.text.trim(),
  );

  Future<Uint8List> _buildPdf() =>
      TravelAllowancePdfService.build(_collect(), settings: _settings);

  Future<void> _save() async {
    if (!_validateForOutput()) return;
    setState(() => _busy = true);
    final request = _collect();
    final saved = widget.editingIndex == null
        ? await TravelAllowanceStore.add(request)
        : await TravelAllowanceStore.updateAt(widget.editingIndex!, request);
    if (!mounted) return;
    setState(() => _busy = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          saved ? 'تم حفظ طلب بدل السفر' : 'تعذر حفظ طلب بدل السفر',
        ),
      ),
    );
  }

  bool _validateForOutput() {
    final valid = _formKey.currentState?.validate() ?? false;
    if (!valid) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || !_formScrollController.hasClients) return;
        _formScrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOut,
        );
      });
    }
    return valid;
  }

  Future<void> _preview() async {
    if (!_validateForOutput()) return;
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => PdfPreview(
          build: (_) => _buildPdf(),
          allowPrinting: true,
          allowSharing: true,
          pdfFileName: 'travel_allowance_${_year.text}.pdf',
          canChangePageFormat: false,
          canChangeOrientation: false,
        ),
      ),
    );
  }

  Future<void> _share() async {
    if (!_validateForOutput()) return;
    await ShareService.sharePdf(
      bytes: await _buildPdf(),
      filename: 'travel_allowance_${_year.text}.pdf',
      subject: 'كشف بدل السفر',
      body: 'مرفق كشف بدل السفر بصيغة PDF',
    );
  }

  Future<void> _print() async {
    if (!_validateForOutput()) return;
    await ShareService.printPdf(
      await _buildPdf(),
      filename: 'travel_allowance_${_year.text}.pdf',
      format: PdfPageFormat.a4.landscape,
    );
  }

  Future<void> _openSettings() async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) =>
            const SettingsScreen(templateKind: TemplateKind.travelAllowance),
      ),
    );
    await _loadSettings();
  }

  Future<void> _openPositionEditor() async {
    final settings = await SettingsStore.load(scope: 'travelAllowance');
    if (!mounted) return;
    final updated = await Navigator.of(context).push<AppSettings>(
      MaterialPageRoute<AppSettings>(
        builder: (_) => TemplatePreviewScreen(
          settings: settings,
          templateScope: 'travelAllowance',
          fullPageForm: true,
          documentTitle: 'تحرير مواضع طلب بدل السفر',
        ),
      ),
    );
    if (updated != null) {
      await SettingsStore.save(updated, scope: 'travelAllowance');
      if (mounted) setState(() => _settings = updated);
    }
  }

  List<String> _optionsFor(String role, {List<String> fallback = const []}) {
    final values = <String>{
      ...fallback,
      if (role == 'الفرع') ..._settings.branchOptions,
      ...?_settings.stakeholderOptions[role],
      if (role == 'الموظف المستفيد') ..._settings.receiverOptions,
    };
    return values.where((item) => item.trim().isNotEmpty).toList();
  }

  Future<void> _pickDate(TextEditingController controller) async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: _parseDate(controller.text) ?? now,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      helpText: 'اختر تاريخ السفر',
      cancelText: 'إلغاء',
      confirmText: 'اختيار',
      locale: const Locale('ar'),
    );
    if (selected == null) return;
    final value =
        '${selected.day.toString().padLeft(2, '0')}/${selected.month.toString().padLeft(2, '0')}/${selected.year}';
    controller.value = TextEditingValue(
      text: value,
      selection: TextSelection.collapsed(offset: value.length),
    );
    setState(() {});
  }

  DateTime? _parseDate(String value) {
    final match = RegExp(
      r'^(\d{1,2})/(\d{1,2})/(\d{4})$',
    ).firstMatch(value.trim());
    if (match == null) return null;
    return DateTime.tryParse(
      '${match.group(3)}-${match.group(2)}-${match.group(1)}',
    );
  }

  InputDecoration _decoration(String label, {IconData? icon, Widget? suffix}) =>
      InputDecoration(
        labelText: label,
        prefixIcon: icon == null ? null : Icon(icon),
        suffixIcon: suffix,
        filled: true,
        fillColor: Theme.of(context).colorScheme.surface,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
      );

  Widget _textField(
    TextEditingController controller,
    String label, {
    bool required = false,
    bool number = false,
    bool date = false,
    List<String> suggestions = const [],
    ValueChanged<String>? onChanged,
  }) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: TextFormField(
      controller: controller,
      textDirection: TextDirection.rtl,
      keyboardType: date
          ? TextInputType.datetime
          : number
          ? TextInputType.number
          : TextInputType.text,
      inputFormatters: number ? [_ThousandsSeparatorFormatter()] : null,
      onChanged: (value) {
        setState(() {});
        onChanged?.call(value);
      },
      validator: required
          ? (value) =>
                value == null || value.trim().isEmpty ? 'هذا الحقل مطلوب' : null
          : null,
      decoration: _decoration(
        label,
        icon: date
            ? Icons.calendar_month_outlined
            : number
            ? Icons.numbers_outlined
            : Icons.edit_outlined,
        suffix: date
            ? IconButton(
                tooltip: 'اختيار التاريخ من التقويم',
                onPressed: () => _pickDate(controller),
                icon: const Icon(Icons.event_outlined),
              )
            : suggestions.isEmpty
            ? null
            : PopupMenuButton<String>(
                tooltip: 'اقتراحات $label',
                icon: const Icon(Icons.arrow_drop_down_circle_outlined),
                onSelected: (value) {
                  controller.text = value;
                  setState(() {});
                },
                itemBuilder: (_) => suggestions
                    .map(
                      (value) => PopupMenuItem<String>(
                        value: value,
                        child: Text(value),
                      ),
                    )
                    .toList(),
              ),
      ),
    ),
  );

  Widget _section(String title, IconData icon, Widget child) => Card(
    elevation: 1,
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(icon, color: Theme.of(context).colorScheme.primary),
              const SizedBox(width: 8),
              Text(
                title,
                style: Theme.of(
                  context,
                ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
              ),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final request = _collect();
    final branches = _optionsFor('الفرع', fallback: _defaultBranches);
    final beneficiaryOptions = _optionsFor('الموظف المستفيد');
    final branchManagerOptions = _optionsFor('مدير الفرع');
    final departmentManagerOptions = _optionsFor('مدير الإدارة المعنية');
    final accountantOptions = _optionsFor('محاسب الإدارة');
    final accountsManagerOptions = _optionsFor('مدير الحسابات');
    return Scaffold(
      appBar: AppBar(
        title: const Text('طلب بدل السفر'),
        actions: [
          IconButton(
            onPressed: _openSettings,
            tooltip: 'إعدادات بدل السفر',
            icon: const Icon(Icons.settings_outlined),
          ),
          IconButton(
            onPressed: _openPositionEditor,
            tooltip: 'تحرير مواضع بدل السفر',
            icon: const Icon(Icons.open_with_outlined),
          ),
          IconButton(
            onPressed: _preview,
            tooltip: 'معاينة',
            icon: const Icon(Icons.preview_outlined),
          ),
          IconButton(
            onPressed: _share,
            tooltip: 'مشاركة',
            icon: const Icon(Icons.share_outlined),
          ),
          IconButton(
            onPressed: _print,
            tooltip: 'طباعة',
            icon: const Icon(Icons.print_outlined),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          controller: _formScrollController,
          padding: const EdgeInsets.all(16),
          children: [
            _section(
              'بيانات الطلب',
              Icons.assignment_outlined,
              Column(
                children: [
                  _textField(
                    _branch,
                    'الفرع',
                    required: true,
                    suggestions: branches,
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: DropdownButtonFormField<String>(
                          initialValue: _months.contains(_month.text)
                              ? _month.text
                              : null,
                          decoration: _decoration(
                            'الشهر',
                            icon: Icons.calendar_view_month_outlined,
                          ),
                          items: _months
                              .map(
                                (month) => DropdownMenuItem(
                                  value: month,
                                  child: Text(month),
                                ),
                              )
                              .toList(),
                          onChanged: (value) =>
                              setState(() => _month.text = value ?? ''),
                          validator: (value) => value == null || value.isEmpty
                              ? 'هذا الحقل مطلوب'
                              : null,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _textField(
                          _year,
                          'العام',
                          required: true,
                          number: true,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            _section(
              'بيانات الأيام والمبالغ',
              Icons.route_outlined,
              Column(
                children: [
                  for (var index = 0; index < _rows.length; index++)
                    _buildRow(index, _rows[index]),
                  if (_rows.length < 10)
                    OutlinedButton.icon(
                      onPressed: _addRow,
                      icon: const Icon(Icons.add_circle_outline),
                      label: Text('إضافة الصف ${_rows.length + 1}'),
                    ),
                  const SizedBox(height: 10),
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primaryContainer,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('إجمالي الأيام: ${request.totalDays}'),
                        Text('الإجمالي: ${_formatAmount(request.totalAmount)}'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            _section(
              'الاعتمادات والجهات المعنية',
              Icons.approval_outlined,
              Column(
                children: [
                  _textField(
                    _beneficiary,
                    'الموظف المستفيد',
                    required: true,
                    suggestions: beneficiaryOptions,
                  ),
                  _textField(
                    _branchManager,
                    'مدير الفرع',
                    suggestions: branchManagerOptions,
                  ),
                  _textField(
                    _departmentManager,
                    'مدير الإدارة المعنية',
                    suggestions: departmentManagerOptions,
                  ),
                  _textField(
                    _administrationAccountant,
                    'محاسب الإدارة',
                    suggestions: accountantOptions,
                  ),
                  _textField(
                    _accountsManager,
                    'مدير الحسابات',
                    suggestions: accountsManagerOptions,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: _busy ? null : _save,
              icon: const Icon(Icons.save_outlined),
              label: Text(_busy ? 'جارٍ الحفظ...' : 'حفظ طلب بدل السفر'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _preview,
              icon: const Icon(Icons.preview_outlined),
              label: const Text('معاينة PDF'),
            ),
            if (!_settingsLoaded)
              const Padding(
                padding: EdgeInsets.only(top: 12),
                child: LinearProgressIndicator(),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildRow(int index, _RowControllers row) => Card(
    margin: const EdgeInsets.only(bottom: 10),
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'الصف ${index + 1}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              if (_rows.length > 1)
                IconButton(
                  onPressed: () => setState(() {
                    row.dispose();
                    _rows.removeAt(index);
                  }),
                  icon: const Icon(Icons.delete_outline),
                  tooltip: 'حذف الصف',
                ),
            ],
          ),
          Row(
            children: [
              SizedBox(width: 85, child: _textField(row.day, 'اليوم')),
              const SizedBox(width: 8),
              Expanded(child: _textField(row.date, 'التاريخ', date: true)),
            ],
          ),
          Row(
            children: [
              Expanded(
                child: _textField(
                  row.dailyAmount,
                  'مبلغ السفر اليومي',
                  number: true,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(child: _textField(row.region, 'المنطقة')),
            ],
          ),
          _textField(row.statement, 'البيان'),
        ],
      ),
    ),
  );

  String _formatAmount(double amount) {
    final parts = amount.toStringAsFixed(2).split('.');
    final digits = parts.first;
    final formatted = digits.replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (match) => ',',
    );
    return '$formatted.${parts[1]}';
  }
}

class _RowControllers {
  _RowControllers(TravelAllowanceRow value)
    : day = TextEditingController(text: value.day),
      date = TextEditingController(text: value.date),
      dailyAmount = TextEditingController(
        text: _formatStoredAmount(value.dailyAmount),
      ),
      region = TextEditingController(text: value.region),
      statement = TextEditingController(text: value.statement);

  final TextEditingController day;
  final TextEditingController date;
  final TextEditingController dailyAmount;
  final TextEditingController region;
  final TextEditingController statement;

  TravelAllowanceRow get value => TravelAllowanceRow(
    day: day.text.trim(),
    date: date.text.trim(),
    dailyAmount: dailyAmount.text.trim(),
    region: region.text.trim(),
    statement: statement.text.trim(),
  );

  void dispose() {
    day.dispose();
    date.dispose();
    dailyAmount.dispose();
    region.dispose();
    statement.dispose();
  }
}

String _formatStoredAmount(String value) {
  final raw = value.replaceAll(',', '').replaceAll('٬', '').trim();
  final number = int.tryParse(raw);
  if (number == null) return value;
  return number.toString().replaceAllMapped(
    RegExp(r'\B(?=(\d{3})+(?!\d))'),
    (match) => ',',
  );
}

int _travelDigitCount(String value) => value.runes.where((rune) {
  return RegExp(r'[0-9٠-٩۰-۹]').hasMatch(String.fromCharCode(rune));
}).length;

int _travelFormattedOffset(String original, String formatted, int offset) {
  final safe = offset.clamp(0, original.length).toInt();
  final before = _travelDigitCount(original.substring(0, safe));
  if (before == 0) return 0;
  var seen = 0;
  for (var index = 0; index < formatted.length; index++) {
    if (RegExp(r'[0-9]').hasMatch(formatted[index])) {
      seen++;
      if (seen == before) return index + 1;
    }
  }
  return formatted.length;
}

TextSelection _travelSelection(
  String original,
  String formatted,
  TextSelection selection,
) => TextSelection(
  baseOffset: _travelFormattedOffset(original, formatted, selection.baseOffset),
  extentOffset: _travelFormattedOffset(
    original,
    formatted,
    selection.extentOffset,
  ),
  affinity: selection.affinity,
  isDirectional: selection.isDirectional,
);

TextRange _travelComposing(String original, String formatted, TextRange range) {
  if (!range.isValid || range.isCollapsed) return TextRange.empty;
  return TextRange(
    start: _travelFormattedOffset(original, formatted, range.start),
    end: _travelFormattedOffset(original, formatted, range.end),
  );
}

class _ThousandsSeparatorFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    final raw = newValue.text.replaceAll(',', '').replaceAll('٬', '');
    if (raw.isEmpty) return newValue;
    if (!RegExp(r'^\d+$').hasMatch(raw)) return oldValue;
    final formatted = raw.replaceAllMapped(
      RegExp(r'\B(?=(\d{3})+(?!\d))'),
      (match) => ',',
    );
    if (formatted == newValue.text) return newValue;
    return TextEditingValue(
      text: formatted,
      selection: _travelSelection(newValue.text, formatted, newValue.selection),
      composing: _travelComposing(newValue.text, formatted, newValue.composing),
    );
  }
}
