import 'package:flutter/material.dart';

class ColorPickerDropdown extends StatefulWidget {
  const ColorPickerDropdown({
    super.key,
    required this.label,
    required this.color,
    required this.onColorSelected,
    this.allowAutomatic = true,
  });

  final String label;
  final Color color;
  final ValueChanged<Color> onColorSelected;
  final bool allowAutomatic;

  @override
  State<ColorPickerDropdown> createState() => _ColorPickerDropdownState();
}

class _ColorPickerDropdownState extends State<ColorPickerDropdown> {
  bool _highContrastOnly = false;
  late Color _selectedColor;

  @override
  void initState() {
    super.initState();
    _selectedColor = widget.color;
  }

  @override
  void didUpdateWidget(covariant ColorPickerDropdown oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.color != widget.color) _selectedColor = widget.color;
  }

  static const _themeColumns = <List<Color>>[
    [
      Color(0xFF70AD47),
      Color(0xFFE2F0D9),
      Color(0xFFC6E0B4),
      Color(0xFFA9D18E),
      Color(0xFF548235),
      Color(0xFF375623),
    ],
    [
      Color(0xFF5B9BD5),
      Color(0xFFDDEBF7),
      Color(0xFFBDD7EE),
      Color(0xFF9DC3E6),
      Color(0xFF2F75B5),
      Color(0xFF1F4E78),
    ],
    [
      Color(0xFFFFC000),
      Color(0xFFFFF2CC),
      Color(0xFFFFE699),
      Color(0xFFFFD966),
      Color(0xFFBF9000),
      Color(0xFF7F6000),
    ],
    [
      Color(0xFFA5A5A5),
      Color(0xFFF2F2F2),
      Color(0xFFD9D9D9),
      Color(0xFFBFBFBF),
      Color(0xFF7F7F7F),
      Color(0xFF595959),
    ],
    [
      Color(0xFFED7D31),
      Color(0xFFFCE4D6),
      Color(0xFFF8CBAD),
      Color(0xFFF4B183),
      Color(0xFFC55A11),
      Color(0xFF843C0C),
    ],
    [
      Color(0xFF4472C4),
      Color(0xFFD9E2F3),
      Color(0xFFB4C7E7),
      Color(0xFF8EAADB),
      Color(0xFF2F5597),
      Color(0xFF203864),
    ],
    [
      Color(0xFF264478),
      Color(0xFFD6E4F0),
      Color(0xFF9DC3E6),
      Color(0xFF5B9BD5),
      Color(0xFF1F4E79),
      Color(0xFF17365D),
    ],
    [
      Color(0xFF7F7F7F),
      Color(0xFFF2F2F2),
      Color(0xFFE7E6E6),
      Color(0xFFD9E1F2),
      Color(0xFFA6A6A6),
      Color(0xFF595959),
    ],
    [
      Color(0xFF000000),
      Color(0xFF404040),
      Color(0xFF666666),
      Color(0xFF808080),
      Color(0xFFBFBFBF),
      Color(0xFFD9D9D9),
    ],
    [
      Color(0xFFFFFFFF),
      Color(0xFFF2F2F2),
      Color(0xFFE7E6E6),
      Color(0xFFD9D9D9),
      Color(0xFFBFBFBF),
      Color(0xFF7F7F7F),
    ],
  ];

  static const _standardColors = <Color>[
    Color(0xFF7030A0),
    Color(0xFF002060),
    Color(0xFF0070C0),
    Color(0xFF00B0F0),
    Color(0xFF00B050),
    Color(0xFF92D050),
    Color(0xFFFFFF00),
    Color(0xFFFFC000),
    Color(0xFFFF0000),
    Color(0xFFC00000),
  ];

  Future<void> _openMenu() async {
    final selected = await showDialog<Color>(
      context: context,
      builder: (context) => _ColorPickerMenu(
        initialColor: _selectedColor,
        highContrastOnly: _highContrastOnly,
        onHighContrastChanged: (value) =>
            setState(() => _highContrastOnly = value),
        themeColumns: _themeColumns,
        standardColors: _standardColors,
        allowAutomatic: widget.allowAutomatic,
      ),
    );
    if (selected != null) {
      widget.onColorSelected(selected);
      setState(() => _selectedColor = selected);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted ||
            widget.color == selected ||
            _selectedColor == widget.color) {
          return;
        }
        setState(() => _selectedColor = widget.color);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: _openMenu,
      child: InputDecorator(
        decoration: InputDecoration(labelText: widget.label),
        child: Row(
          children: [
            _ColorSwatch(color: _selectedColor, selected: true),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                '#${_selectedColor.toARGB32().toRadixString(16).substring(2).toUpperCase()}',
              ),
            ),
            const Icon(Icons.arrow_drop_down),
          ],
        ),
      ),
    );
  }
}

class _ColorPickerMenu extends StatefulWidget {
  const _ColorPickerMenu({
    required this.initialColor,
    required this.highContrastOnly,
    required this.onHighContrastChanged,
    required this.themeColumns,
    required this.standardColors,
    required this.allowAutomatic,
  });

  final Color initialColor;
  final bool highContrastOnly;
  final ValueChanged<bool> onHighContrastChanged;
  final List<List<Color>> themeColumns;
  final List<Color> standardColors;
  final bool allowAutomatic;

  @override
  State<_ColorPickerMenu> createState() => _ColorPickerMenuState();
}

class _ColorPickerMenuState extends State<_ColorPickerMenu> {
  late bool _highContrast;

  @override
  void initState() {
    super.initState();
    _highContrast = widget.highContrastOnly;
  }

  bool _visible(Color color) {
    if (!_highContrast) return true;
    final luminance = color.computeLuminance();
    return luminance < .22 || luminance > .72;
  }

  @override
  Widget build(BuildContext context) {
    return Dialog(
      insetPadding: const EdgeInsets.all(18),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Directionality(
        textDirection: TextDirection.rtl,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'اختيار اللون',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('التباين العالي فقط'),
                value: _highContrast,
                onChanged: (value) {
                  final next = value ?? false;
                  setState(() => _highContrast = next);
                  widget.onHighContrastChanged(next);
                },
              ),
              if (_highContrast)
                const Tooltip(
                  message: 'مخفية بسبب فلتر التباين العالي',
                  child: Padding(
                    padding: EdgeInsets.only(bottom: 8),
                    child: Text(
                      'مخفية بسبب فلتر التباين العالي',
                      style: TextStyle(fontSize: 12),
                    ),
                  ),
                ),
              if (widget.allowAutomatic)
                TextButton.icon(
                  onPressed: () => Navigator.pop(context, Colors.black),
                  icon: const Icon(Icons.auto_awesome),
                  label: const Text('تلقائي'),
                ),
              const _SectionLabel('ألوان النسَق'),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: widget.themeColumns
                    .map(
                      (column) => Expanded(
                        child: Column(
                          children: column
                              .map(
                                (color) => Padding(
                                  padding: const EdgeInsets.all(2),
                                  child: _ColorSwatch(
                                    color: color,
                                    selected:
                                        color.toARGB32() ==
                                        widget.initialColor.toARGB32(),
                                    enabled: _visible(color),
                                    onTap: () => Navigator.pop(context, color),
                                  ),
                                ),
                              )
                              .toList(),
                        ),
                      ),
                    )
                    .toList(),
              ),
              const SizedBox(height: 14),
              const _SectionLabel('ألوان قياسية'),
              Wrap(
                alignment: WrapAlignment.start,
                spacing: 7,
                runSpacing: 7,
                children: widget.standardColors
                    .map(
                      (color) => _ColorSwatch(
                        color: color,
                        selected:
                            color.toARGB32() == widget.initialColor.toARGB32(),
                        enabled: _visible(color),
                        onTap: () => Navigator.pop(context, color),
                      ),
                    )
                    .toList(),
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: () async {
                  final color = await showDialog<Color>(
                    context: context,
                    builder: (_) =>
                        ColorPickerDialog(initialColor: widget.initialColor),
                  );
                  if (color != null && context.mounted) {
                    Navigator.pop(context, color);
                  }
                },
                icon: const Icon(Icons.palette_outlined),
                label: const Text('ألوان إضافية...'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('إلغاء'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ColorPickerDialog extends StatefulWidget {
  const ColorPickerDialog({super.key, required this.initialColor});
  final Color initialColor;

  @override
  State<ColorPickerDialog> createState() => _ColorPickerDialogState();
}

class _ColorPickerDialogState extends State<ColorPickerDialog> {
  late HSVColor _hsv;
  late final TextEditingController _hexController;
  String? _hexError;

  @override
  void initState() {
    super.initState();
    _hsv = HSVColor.fromColor(
      widget.initialColor == Colors.transparent
          ? Colors.blue
          : widget.initialColor,
    );
    _hexController = TextEditingController(text: _hex(_hsv.toColor()));
  }

  String _hex(Color color) =>
      color.toARGB32().toRadixString(16).substring(2).toUpperCase();

  void _setColor(HSVColor color) {
    setState(() {
      _hsv = color;
      _hexController.text = _hex(color.toColor());
      _hexError = null;
    });
  }

  bool _applyHex(String value) {
    final normalized = value.trim().replaceFirst('#', '');
    if (normalized.length != 6 ||
        !RegExp(r'^[0-9a-fA-F]{6}$').hasMatch(normalized)) {
      setState(() => _hexError = 'اكتب 6 رموز HEX من 0-9 أو A-F، مثل #A1FD33');
      return false;
    }
    final parsed = int.parse(normalized, radix: 16);
    _setColor(HSVColor.fromColor(Color(0xFF000000 | parsed)));
    return true;
  }

  @override
  void dispose() {
    _hexController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('لون مخصص'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 55,
              decoration: BoxDecoration(
                color: _hsv.toColor(),
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            const SizedBox(height: 12),
            _HueSlider(
              value: _hsv.hue,
              onChanged: (value) => _setColor(_hsv.withHue(value)),
            ),
            Slider(
              value: _hsv.saturation,
              onChanged: (value) => _setColor(_hsv.withSaturation(value)),
              min: 0,
              max: 1,
              label: 'التشبع',
            ),
            Slider(
              value: _hsv.value,
              onChanged: (value) => _setColor(_hsv.withValue(value)),
              min: 0,
              max: 1,
              label: 'الإضاءة',
            ),
            TextField(
              controller: _hexController,
              textCapitalization: TextCapitalization.characters,
              maxLength: 7,
              decoration: InputDecoration(
                labelText: 'HEX',
                hintText: '#A1FD33',
                prefixText: '#',
                errorText: _hexError,
                helperText: 'مثال صحيح: #A1FD33 — الحرف S غير صالح في HEX',
                counterText: '',
              ),
              onChanged: (value) {
                final normalized = value.trim().replaceFirst('#', '');
                if (normalized.length == 6) _applyHex(value);
              },
              onSubmitted: _applyHex,
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('إلغاء'),
        ),
        FilledButton(
          onPressed: () {
            if (_applyHex(_hexController.text)) {
              Navigator.pop(context, _hsv.toColor());
            }
          },
          child: const Text('اختيار'),
        ),
      ],
    );
  }
}

class _HueSlider extends StatelessWidget {
  const _HueSlider({required this.value, required this.onChanged});
  final double value;
  final ValueChanged<double> onChanged;
  @override
  Widget build(BuildContext context) => Slider(
    value: value,
    min: 0,
    max: 360,
    onChanged: onChanged,
    label: 'الدرجة',
  );
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 6),
    child: Text(
      text,
      style: Theme.of(
        context,
      ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold),
    ),
  );
}

class _ColorSwatch extends StatelessWidget {
  const _ColorSwatch({
    required this.color,
    this.selected = false,
    this.enabled = true,
    this.onTap,
  });
  final Color color;
  final bool selected;
  final bool enabled;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) {
    final swatch = Container(
      width: 28,
      height: 28,
      decoration: BoxDecoration(
        color: color == Colors.transparent
            ? Theme.of(context).colorScheme.surface
            : color,
        border: Border.all(
          color: color.computeLuminance() > .85
              ? Colors.grey
              : Colors.transparent,
          width: 1,
        ),
        borderRadius: BorderRadius.circular(5),
      ),
      child: selected
          ? Icon(
              Icons.check,
              size: 18,
              color: color.computeLuminance() > .55
                  ? Colors.black
                  : Colors.white,
            )
          : null,
    );
    return Opacity(
      opacity: enabled ? 1 : .25,
      child: onTap == null
          ? swatch
          : InkWell(
              onTap: enabled ? onTap : null,
              borderRadius: BorderRadius.circular(5),
              child: swatch,
            ),
    );
  }
}
