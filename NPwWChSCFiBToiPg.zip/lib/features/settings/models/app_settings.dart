import 'package:flutter/material.dart';

import 'template_geometry.dart';

class AppSettings {
  static const fixedFormTitle = 'نموذج طلب صرف';
  static const fixedDocumentNumber = 'SHIBA-IMSF-35-02';
  static const fixedIssueDate = '2025/06/01م';
  static const fixedIssueVersion = '1';

  const AppSettings({
    required this.companyName,
    required this.formTitle,
    required this.documentNumber,
    required this.issueDate,
    required this.issueVersion,
    required this.currencyName,
    required this.fractionName,
    required this.autoSpelling,
    required this.showAccountField,
    required this.requireAccountField,
    required this.showSignatures,
    required this.requireApprovals,
    required this.fontSize,
    required this.primaryColorValue,
    required this.textColorValue,
    this.printedTextColorValue = 0xFF0070C0,
    required this.backgroundColorValue,
    required this.fieldBackgroundColorValue,
    required this.darkMode,
    required this.fieldSettings,
    this.bottomFieldSettings = const {},
    this.memoFieldSettings = const {},
    this.memoBottomFieldSettings = const {},
    this.memoFullA4FieldSettings = const {},
    this.customerFieldSettings = const {},
    required this.templateMode,
    required this.pageCopies,
    required this.receiverOptions,
    required this.requesterHistory,
    required this.branchOptions,
    required this.stakeholderOptions,
    this.maxStructuredDataCharacters = 1200,
    this.representativeReportMedRep = '',
    this.representativeReportCity = '',
    this.representativeReportDistrict = '',
    this.representativeReportSection = '',
  });

  factory AppSettings.defaults() {
    final base = const AppSettings(
      companyName: 'سبا فارما',
      formTitle: fixedFormTitle,
      documentNumber: fixedDocumentNumber,
      issueDate: fixedIssueDate,
      issueVersion: fixedIssueVersion,
      currencyName: 'ريال',
      fractionName: 'فلس',
      autoSpelling: true,
      showAccountField: false,
      requireAccountField: false,
      showSignatures: false,
      requireApprovals: false,
      fontSize: 14,
      primaryColorValue: 0xFF16823B,
      textColorValue: 0xFF1F2937,
      backgroundColorValue: 0xFFF6F8FA,
      fieldBackgroundColorValue: 0xFFFFFFFF,
      darkMode: false,
      customerFieldSettings: {
        'date': FieldSetting(
          label: 'التاريخ',
          visible: true,
          required: true,
          inputType: FieldInputType.date,
        ),
        'exceptionType': FieldSetting(
          label: 'نوع الطلب الاستثنائي',
          visible: true,
          required: true,
        ),
        'bonusExtra': FieldSetting(
          label: 'بونص إضافي',
          visible: true,
          required: false,
        ),
        'customerCompensation': FieldSetting(
          label: 'تعويض عميل',
          visible: true,
          required: false,
        ),
        'settlementOffer': FieldSetting(
          label: 'عرض سداد',
          visible: true,
          required: false,
        ),
        'cashDiscount': FieldSetting(
          label: 'خصم نقدي',
          visible: true,
          required: false,
        ),
        'otherType': FieldSetting(
          label: 'أخرى',
          visible: true,
          required: false,
        ),
        'otherDetails': FieldSetting(
          label: 'تفاصيل أخرى',
          visible: true,
          required: false,
        ),
        'customer': FieldSetting(
          label: 'اسم العميل',
          visible: true,
          required: true,
        ),
        'branch': FieldSetting(label: 'الفرع', visible: true, required: true),
        'requesterName': FieldSetting(
          label: 'اسم مقدم الطلب',
          visible: true,
          required: true,
        ),
        'directManagerName': FieldSetting(
          label: 'مدير المبيعات',
          visible: true,
          required: false,
        ),
        'approvedAuthorityName': FieldSetting(
          label: 'الفرع / المنطقة',
          visible: true,
          required: false,
        ),
        'accountsManagerName': FieldSetting(
          label: 'مدير المبيعات',
          visible: true,
          required: false,
        ),
        'statementOne': FieldSetting(
          label: 'البيان الأول',
          visible: true,
          required: true,
          lineHeight: 1.5,
          height: 135,
          maxLength: 500,
          fontSize: 11.5,
          fontWeight: 700,
        ),
        'statementTwo': FieldSetting(
          label: 'البيان الثاني',
          visible: true,
          required: false,
          lineHeight: 1.5,
          height: 100,
          maxLength: 350,
          fontSize: 11.5,
          fontWeight: 700,
        ),
        'customerType': FieldSetting(
          label: 'نوع العميل',
          visible: false,
          required: false,
        ),
        'customerTypeNew': FieldSetting(
          label: 'جديد',
          visible: true,
          required: false,
        ),
        'customerTypePrevious': FieldSetting(
          label: 'سابق',
          visible: true,
          required: false,
        ),
        'previousPurchases': FieldSetting(
          label: 'سحبيات العام السابق',
          visible: true,
          required: false,
          inputType: FieldInputType.amount,
        ),
        'previousPayments': FieldSetting(
          label: 'مدفوعات العام السابق',
          visible: true,
          required: false,
          inputType: FieldInputType.amount,
        ),
        'currentPurchases': FieldSetting(
          label: 'سحبيات العام الحالي',
          visible: true,
          required: false,
          inputType: FieldInputType.amount,
        ),
        'currentPayments': FieldSetting(
          label: 'مدفوعات العام الحالي',
          visible: true,
          required: false,
          inputType: FieldInputType.amount,
        ),
        'bonusPercent': FieldSetting(
          label: 'نسبة البونص المعتمدة',
          visible: true,
          required: false,
        ),
      },
      fieldSettings: {
        'date': FieldSetting(
          label: 'التاريخ',
          visible: true,
          required: true,
          maxLength: 10,
        ),
        // Display-only label for the original form header. It is intentionally
        // separate from the editable date input and is not shown in add form.
        'dateLabel': FieldSetting(
          label: 'التاريخ',
          visible: true,
          required: false,
          x: 125,
          y: 36,
          width: 100,
          height: 27,
          maxLength: 40,
          fontSize: 10,
          fontWeight: 700,
        ),
        'receiver': FieldSetting(
          label: 'الأخ / المقدم إليه',
          visible: true,
          required: true,
          maxLength: 100,
        ),
        'amountNumber': FieldSetting(
          label: 'المبلغ بالأرقام',
          visible: true,
          required: true,
          maxLength: 30,
          alignment: 'center',
        ),
        'amountWords': FieldSetting(
          label: 'المبلغ بالحروف',
          visible: true,
          required: true,
          maxLength: 250,
          height: 24,
        ),
        'reason': FieldSetting(
          label: 'سبب الصرف',
          visible: false,
          required: false,
          maxLength: 250,
        ),
        'statement': FieldSetting(
          label: 'البيان',
          visible: true,
          required: true,
          maxLength: 250,
          height: 130,
        ),
        'branch': FieldSetting(
          label: 'الفرع',
          visible: true,
          required: false,
          maxLength: 100,
        ),
        'account': FieldSetting(
          label: 'الحساب',
          visible: false,
          required: false,
          maxLength: 150,
        ),
        'signatures': FieldSetting(
          label: 'الاعتمادات والتوقيعات',
          visible: false,
          required: false,
        ),
        'requesterName': FieldSetting(
          label: 'اسم مقدم الطلب',
          visible: true,
          required: false,
        ),
        'requesterSignature': FieldSetting(
          label: 'توقيع مقدم الطلب',
          visible: true,
          required: false,
        ),
        'directManagerName': FieldSetting(
          label: 'اسم المدير المباشر',
          visible: true,
          required: false,
        ),
        'directManagerSignature': FieldSetting(
          label: 'توقيع المدير المباشر',
          visible: true,
          required: false,
        ),
        'approvedAuthorityName': FieldSetting(
          label: 'اسم الجهة المعتمدة',
          visible: true,
          required: false,
        ),
        'approvedAuthoritySignature': FieldSetting(
          label: 'توقيع الجهة المعتمدة',
          visible: true,
          required: false,
        ),
        'accountsManagerName': FieldSetting(
          label: 'اسم مدير الحسابات',
          visible: true,
          required: false,
        ),
        'accountsManagerSignature': FieldSetting(
          label: 'توقيع مدير الحسابات',
          visible: true,
          required: false,
        ),
      },
      memoFieldSettings: {
        'receiver': FieldSetting(
          label: 'المقدم إليه',
          visible: true,
          required: true,
          x: 100,
          y: 92,
          width: 380,
          height: 24,
          fontSize: 10,
        ),
        'date': FieldSetting(
          label: 'التاريخ',
          visible: true,
          required: true,
          x: 100,
          y: 116,
          width: 180,
          height: 24,
          fontSize: 10,
        ),
        'statement': FieldSetting(
          label: 'البيان',
          visible: true,
          required: true,
          x: 70,
          y: 145,
          width: 430,
          height: 180,
          fontSize: 11,
        ),
        'requesterName': FieldSetting(
          label: 'اسم مقدم الطلب',
          visible: true,
          required: true,
          x: 100,
          y: 350,
          width: 300,
          height: 24,
          fontSize: 10,
        ),
      },
      memoFullA4FieldSettings: {
        'receiver': FieldSetting(
          label: 'المقدم إليه',
          visible: true,
          required: true,
          x: 100,
          y: 92,
          width: 380,
          height: 24,
          fontSize: 10,
        ),
        'date': FieldSetting(
          label: 'التاريخ',
          visible: true,
          required: true,
          x: 100,
          y: 116,
          width: 180,
          height: 24,
          fontSize: 10,
        ),
        'statement': FieldSetting(
          label: 'البيان',
          visible: true,
          required: true,
          x: 70,
          y: 145,
          width: 430,
          height: 180,
          fontSize: 11,
        ),
        'requesterName': FieldSetting(
          label: 'اسم مقدم الطلب',
          visible: true,
          required: true,
          x: 100,
          y: 350,
          width: 300,
          height: 24,
          fontSize: 10,
        ),
      },
      templateMode: TemplateMode.original,
      pageCopies: 2,
      receiverOptions: [
        'رئيس مجلس الإدارة',
        'مدير المبيعات',
        'مدير الحسابات',
        'أ/حميد المقحفي',
      ],
      requesterHistory: [],
      branchOptions: [
        'كبار العملاء',
        'الجنوبية',
        'الغربية',
        'الشمالية',
        'الوسطى',
        'إب أرياف',
      ],
      stakeholderOptions: {
        'المقدم إليه': [
          'رئيس مجلس الإدارة',
          'مدير المبيعات',
          'مدير الحسابات',
          'أ/حميد المقحفي',
        ],
        'العملاء': [],
        'الفرع': [],
        'محاسب الفرع': ['عارف الهبل'],
        'مختص حسابات الفرع': ['عارف الهبل'],
        'مدير المبيعات': ['أ/حميد المقحفي'],
        'مقدم الطلب': ['عبدالعزيز كباس'],
        'محاسب الإدارة': ['عبدالعزيز كباس'],
        'المدير المباشر': ['مدير المبيعات'],
        'الجهة المعتمدة': ['المدير العام', 'مدير الحسابات'],
        'مدير الحسابات': ['أ/ توفيق القاضي'],
        'المراجع': ['مراجع حسابات الفرع'],
      },
    );
    return base.copyWith(
      fieldSettings: TemplateGeometry.apply(
        'expenseRequest',
        base.fieldSettings,
      ),
      memoFullA4FieldSettings: TemplateGeometry.apply(
        'internalMemo',
        base.memoFullA4FieldSettings,
      ),
      customerFieldSettings: TemplateGeometry.apply(
        'customerApplication',
        base.customerFieldSettings,
      ),
    );
  }

  final String companyName;
  final String formTitle;
  final String documentNumber;
  final String issueDate;
  final String issueVersion;
  final String currencyName;
  final String fractionName;
  final bool autoSpelling;
  final bool showAccountField;
  final bool requireAccountField;
  final bool showSignatures;
  final bool requireApprovals;
  final double fontSize;
  final int primaryColorValue;
  final int textColorValue;
  final int printedTextColorValue;
  final int backgroundColorValue;
  final int fieldBackgroundColorValue;
  final bool darkMode;
  final Map<String, FieldSetting> fieldSettings;
  final Map<String, FieldSetting> bottomFieldSettings;
  final Map<String, FieldSetting> memoFieldSettings;
  final Map<String, FieldSetting> memoBottomFieldSettings;
  final Map<String, FieldSetting> memoFullA4FieldSettings;
  final Map<String, FieldSetting> customerFieldSettings;
  final TemplateMode templateMode;
  final int pageCopies;
  final List<String> receiverOptions;
  final List<String> requesterHistory;
  final List<String> branchOptions;
  final Map<String, List<String>> stakeholderOptions;
  final int maxStructuredDataCharacters;

  /// Defaults used only when creating new representative reports.
  final String representativeReportMedRep;
  final String representativeReportCity;
  final String representativeReportDistrict;
  final String representativeReportSection;

  Color get primaryColor => Color(primaryColorValue);
  Color get textColor => Color(textColorValue);
  Color get backgroundColor => Color(backgroundColorValue);
  Color get fieldBackgroundColor => Color(fieldBackgroundColorValue);

  Map<String, FieldSetting> fieldsForCopy({required bool bottom}) {
    if (!bottom) return fieldSettings;
    if (bottomFieldSettings.isNotEmpty) return bottomFieldSettings;
    return Map<String, FieldSetting>.from(fieldSettings);
  }

  /// Returns the single authoritative Expense Request layout. The legacy
  /// bottom-copy map remains stored for backward compatibility, but it is not
  /// an execution-time layout source for preview or printing.
  AppSettings withExpenseRequestMasterLayout() => this;

  /// Defaults for forms that share the legacy request model but must not share
  /// the expense-request field schema.
  static AppSettings defaultsForScope(String scope) {
    final base = AppSettings.defaults();
    final fields = switch (scope) {
      'travelAllowance' => <String, FieldSetting>{
        'branch': FieldSetting(label: 'الفرع', visible: true, required: true),
        'month': FieldSetting(label: 'الشهر', visible: true, required: true),
        'year': FieldSetting(label: 'العام', visible: true, required: true),
        'beneficiary': FieldSetting(
          label: 'الموظف المستفيد',
          visible: true,
          required: true,
        ),
        'branchManager': FieldSetting(
          label: 'مدير الفرع',
          visible: true,
          required: false,
        ),
        'departmentManager': FieldSetting(
          label: 'مدير الإدارة المعنية',
          visible: true,
          required: false,
        ),
        'administrationAccountant': FieldSetting(
          label: 'محاسب الإدارة',
          visible: true,
          required: false,
        ),
        'accountsManager': FieldSetting(
          label: 'مدير الحسابات',
          visible: true,
          required: false,
        ),
        'totalAmount': FieldSetting(
          label: 'إجمالي المبلغ',
          visible: true,
          required: false,
          inputType: FieldInputType.amount,
        ),
        'totalDays': FieldSetting(
          label: 'إجمالي الأيام',
          visible: true,
          required: false,
        ),
        for (var i = 1; i <= 10; i++) ...{
          'travelDay$i': FieldSetting(
            label: 'اليوم $i',
            visible: true,
            required: false,
          ),
          'travelDate$i': FieldSetting(
            label: 'تاريخ السفر $i',
            visible: true,
            required: false,
          ),
          'travelDailyAmount$i': FieldSetting(
            label: 'مبلغ السفر اليومي $i',
            visible: true,
            required: false,
            inputType: FieldInputType.amount,
          ),
          'travelRegion$i': FieldSetting(
            label: 'المنطقة $i',
            visible: true,
            required: false,
          ),
          'travelStatement$i': FieldSetting(
            label: 'البيان $i',
            visible: true,
            required: false,
          ),
        },
      },
      'clearanceRequest' => <String, FieldSetting>{
        'date': FieldSetting(
          label: 'تاريخ الإخلاء',
          visible: true,
          required: true,
        ),
        'receiver': FieldSetting(
          label: 'اسم الموظف',
          visible: true,
          required: true,
        ),
        'requesterName': FieldSetting(
          label: 'مسؤول العهدة',
          visible: true,
          required: false,
        ),
        'approvedAuthorityName': FieldSetting(
          label: 'الجهة المعتمدة',
          visible: true,
          required: false,
        ),
      },
      'fuelRequest' => <String, FieldSetting>{
        'fuelBranch': FieldSetting(
          label: 'الفرع',
          visible: true,
          required: true,
        ),
        'collector': FieldSetting(
          label: 'اسم المحصل',
          visible: true,
          required: true,
        ),
        'vehicleNumber': FieldSetting(
          label: 'رقم السيارة',
          visible: true,
          required: true,
          maxLength: 32,
        ),
        'fuelType': FieldSetting(
          label: 'نوع الوقود',
          visible: true,
          required: true,
        ),
        'fuelTypePetrol': FieldSetting(
          label: 'بترول',
          visible: true,
          required: false,
        ),
        'fuelTypeDiesel': FieldSetting(
          label: 'ديزل',
          visible: true,
          required: false,
        ),
        'fuelTypeGas': FieldSetting(
          label: 'غاز',
          visible: true,
          required: false,
        ),
        'systemTimestamp': FieldSetting(
          label: 'تاريخ النظام',
          visible: true,
          required: false,
        ),
        'periodFrom': FieldSetting(
          label: 'الفترة من تاريخ',
          visible: true,
          required: true,
          maxLength: 10,
        ),
        'periodTo': FieldSetting(
          label: 'إلى تاريخ',
          visible: true,
          required: true,
          maxLength: 10,
        ),
        'beneficiary': FieldSetting(
          label: 'الموظف المستفيد',
          visible: true,
          required: true,
        ),
        'branchAccountant': FieldSetting(
          label: 'مختص حسابات الفرع',
          visible: true,
          required: false,
        ),
        'branchManager': FieldSetting(
          label: 'مدير الفرع',
          visible: true,
          required: false,
        ),
        'administrationAccountant': FieldSetting(
          label: 'محاسب الإدارة',
          visible: true,
          required: false,
        ),
        'accountsManager': FieldSetting(
          label: 'مدير الحسابات',
          visible: true,
          required: false,
        ),
        'previousMeter': FieldSetting(
          label: 'العداد السابق',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'currentMeter': FieldSetting(
          label: 'العداد الحالي',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'meterDifference': FieldSetting(
          label: 'فارق قراءة العداد',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'averagePerDrum': FieldSetting(
          label: 'معدل المشي بالدبة حسب الرفع',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'drumsCount': FieldSetting(
          label: 'عدد الدبات',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'issuedAmount': FieldSetting(
          label: 'ما يتم صرفه',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'driverLoad': FieldSetting(
          label: 'ما يتم التحميل للسائق',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'periodCollection': FieldSetting(
          label: 'إجمالي توريد الفترة',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'periodSales': FieldSetting(
          label: 'إجمالي مبيعات الفترة',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelDate1': FieldSetting(
          label: 'تاريخ تعبئة الوقود 1',
          visible: true,
          required: false,
          maxLength: 10,
        ),
        'fuelMeter1': FieldSetting(
          label: 'رقم العداد 1',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelLiters1': FieldSetting(
          label: 'عدد اللترات 1',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelPrice1': FieldSetting(
          label: 'سعر اللتر 1',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelAmount1': FieldSetting(
          label: 'مبلغ الوقود 1',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelCollection1': FieldSetting(
          label: 'التحصيل 1',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelSales1': FieldSetting(
          label: 'المبيعات 1',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelRoute1': FieldSetting(
          label: 'خط سير السيارة 1',
          visible: true,
          required: false,
          maxLength: 80,
        ),
        'fuelDate2': FieldSetting(
          label: 'تاريخ تعبئة الوقود 2',
          visible: true,
          required: false,
          maxLength: 10,
        ),
        'fuelMeter2': FieldSetting(
          label: 'رقم العداد 2',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelLiters2': FieldSetting(
          label: 'عدد اللترات 2',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelPrice2': FieldSetting(
          label: 'سعر اللتر 2',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelAmount2': FieldSetting(
          label: 'مبلغ الوقود 2',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelCollection2': FieldSetting(
          label: 'التحصيل 2',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelSales2': FieldSetting(
          label: 'المبيعات 2',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelRoute2': FieldSetting(
          label: 'خط سير السيارة 2',
          visible: true,
          required: false,
          maxLength: 80,
        ),
        'fuelDate3': FieldSetting(
          label: 'تاريخ تعبئة الوقود 3',
          visible: true,
          required: false,
          maxLength: 10,
        ),
        'fuelMeter3': FieldSetting(
          label: 'رقم العداد 3',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelLiters3': FieldSetting(
          label: 'عدد اللترات 3',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelPrice3': FieldSetting(
          label: 'سعر اللتر 3',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelAmount3': FieldSetting(
          label: 'مبلغ الوقود 3',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelCollection3': FieldSetting(
          label: 'التحصيل 3',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelSales3': FieldSetting(
          label: 'المبيعات 3',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelRoute3': FieldSetting(
          label: 'خط سير السيارة 3',
          visible: true,
          required: false,
          maxLength: 80,
        ),
        'fuelDate4': FieldSetting(
          label: 'تاريخ تعبئة الوقود 4',
          visible: true,
          required: false,
          maxLength: 10,
        ),
        'fuelMeter4': FieldSetting(
          label: 'رقم العداد 4',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelLiters4': FieldSetting(
          label: 'عدد اللترات 4',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelPrice4': FieldSetting(
          label: 'سعر اللتر 4',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelAmount4': FieldSetting(
          label: 'مبلغ الوقود 4',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelCollection4': FieldSetting(
          label: 'التحصيل 4',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelSales4': FieldSetting(
          label: 'المبيعات 4',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelRoute4': FieldSetting(
          label: 'خط سير السيارة 4',
          visible: true,
          required: false,
          maxLength: 80,
        ),
        'fuelDate5': FieldSetting(
          label: 'تاريخ تعبئة الوقود 5',
          visible: true,
          required: false,
          maxLength: 10,
        ),
        'fuelMeter5': FieldSetting(
          label: 'رقم العداد 5',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelLiters5': FieldSetting(
          label: 'عدد اللترات 5',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelPrice5': FieldSetting(
          label: 'سعر اللتر 5',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelAmount5': FieldSetting(
          label: 'مبلغ الوقود 5',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelCollection5': FieldSetting(
          label: 'التحصيل 5',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelSales5': FieldSetting(
          label: 'المبيعات 5',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelRoute5': FieldSetting(
          label: 'خط سير السيارة 5',
          visible: true,
          required: false,
          maxLength: 80,
        ),
        'fuelDate6': FieldSetting(
          label: 'تاريخ تعبئة الوقود 6',
          visible: true,
          required: false,
          maxLength: 10,
        ),
        'fuelMeter6': FieldSetting(
          label: 'رقم العداد 6',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelLiters6': FieldSetting(
          label: 'عدد اللترات 6',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelPrice6': FieldSetting(
          label: 'سعر اللتر 6',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelAmount6': FieldSetting(
          label: 'مبلغ الوقود 6',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelCollection6': FieldSetting(
          label: 'التحصيل 6',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelSales6': FieldSetting(
          label: 'المبيعات 6',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelRoute6': FieldSetting(
          label: 'خط سير السيارة 6',
          visible: true,
          required: false,
          maxLength: 80,
        ),
        'fuelDate7': FieldSetting(
          label: 'تاريخ تعبئة الوقود 7',
          visible: true,
          required: false,
          maxLength: 10,
        ),
        'fuelMeter7': FieldSetting(
          label: 'رقم العداد 7',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelLiters7': FieldSetting(
          label: 'عدد اللترات 7',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelPrice7': FieldSetting(
          label: 'سعر اللتر 7',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelAmount7': FieldSetting(
          label: 'مبلغ الوقود 7',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelCollection7': FieldSetting(
          label: 'التحصيل 7',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelSales7': FieldSetting(
          label: 'المبيعات 7',
          visible: true,
          required: false,
          maxLength: 32,
        ),
        'fuelRoute7': FieldSetting(
          label: 'خط سير السيارة 7',
          visible: true,
          required: false,
          maxLength: 80,
        ),
      },
      'serviceRequest' => <String, FieldSetting>{
        'date': FieldSetting(
          label: 'تاريخ الطلب',
          visible: true,
          required: true,
          maxLength: 30,
          height: 22,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'receiver': FieldSetting(
          label: 'الجهة / القسم',
          visible: true,
          required: true,
          maxLength: 250,
          height: 22,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'reason': FieldSetting(
          label: 'نوع طلب الخدمة',
          visible: true,
          required: true,
          maxLength: 35,
          height: 5,
          lineHeight: 0.8,
          colorValue: 0xFF0000FF,
        ),
        'serviceTypeHospitality': FieldSetting(
          label: 'ضيافة',
          visible: true,
          required: false,
          maxLength: 35,
          height: 10,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'serviceTypeCashSupport': FieldSetting(
          label: 'دعم نقدي',
          visible: true,
          required: false,
          maxLength: 35,
          height: 10,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'serviceTypeInKindGift': FieldSetting(
          label: 'هدية عينية',
          visible: true,
          required: false,
          maxLength: 35,
          height: 10,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'doctorNames': FieldSetting(
          label: 'أسماء الأطباء',
          visible: true,
          required: false,
          maxLength: 150,
          height: 44,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'worksIn': FieldSetting(
          label: 'يعمل في',
          visible: true,
          required: false,
          maxLength: 150,
          height: 47,
          lineHeight: 0.2,
          colorValue: 0xFF3333CC,
        ),
        'specialty': FieldSetting(
          label: 'التخصص',
          visible: true,
          required: false,
          maxLength: 100,
          height: 60,
          lineHeight: 0.2,
          colorValue: 0xFF5106D8,
        ),
        'statement': FieldSetting(
          label: 'تفاصيل الخدمة',
          visible: true,
          required: true,
          maxLength: 400,
          height: 150,
          lineHeight: 0.2,
          alignment: 'center',
          colorValue: 0xFF0000FF,
        ),
        'amountNumber': FieldSetting(
          label: 'المبلغ رقمًا',
          visible: true,
          required: false,
          maxLength: 30,
          height: 30,
          lineHeight: 0.2,
          alignment: 'center',
          colorValue: 0xFF0000FF,
        ),
        'amountWords': FieldSetting(
          label: 'المبلغ كتابة',
          visible: true,
          required: false,
          maxLength: 250,
          height: 70,
          lineHeight: 0.2,
          alignment: 'center',
          colorValue: 0xFF0000FF,
        ),
        'branch': FieldSetting(
          label: 'الفرع',
          visible: true,
          required: false,
          maxLength: 100,
          height: 70,
          lineHeight: 0.2,
          alignment: 'right',
          colorValue: 0xFF0000FF,
        ),
        'requesterName': FieldSetting(
          label: 'اسم مقدم الطلب',
          visible: true,
          required: true,
          maxLength: 100,
          height: 22,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'directManagerName': FieldSetting(
          label: 'المدير المباشر',
          visible: true,
          required: false,
          maxLength: 100,
          height: 22,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'approvedAuthorityName': FieldSetting(
          label: 'الجهة المعنية بالاعتماد',
          visible: true,
          required: false,
          maxLength: 100,
          height: 22,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
      },
      'sampleRequest' => <String, FieldSetting>{
        'date': FieldSetting(
          label: 'التاريخ',
          visible: true,
          required: true,
          maxLength: 10,
          fontSize: 11.5,
          height: 22,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'receiver': FieldSetting(
          label: 'الجهة / الأخ',
          visible: true,
          required: true,
          maxLength: 100,
          fontSize: 12,
          height: 22,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'requesterName': FieldSetting(
          label: 'مقدم الطلب',
          visible: true,
          required: false,
          maxLength: 100,
          fontSize: 12,
          height: 22,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'reason': FieldSetting(
          label: 'الغرض',
          visible: true,
          required: false,
          maxLength: 250,
          fontSize: 11,
          height: 28,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'reasonPage3': FieldSetting(
          label: 'الغرض — الصفحة الثالثة',
          visible: true,
          required: false,
          maxLength: 250,
          fontSize: 11.5,
          height: 50,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'sampleUsageMarketing': FieldSetting(
          label: 'تسويقية',
          visible: true,
          required: false,
          height: 36,
          width: 40,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'sampleUsageDoctors': FieldSetting(
          label: 'استخدام أطباء',
          visible: true,
          required: false,
          height: 36,
          width: 40,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'sampleUsageEmployees': FieldSetting(
          label: 'استخدام موظفين',
          visible: true,
          required: false,
          height: 36,
          width: 40,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
        'sampleUsageOther': FieldSetting(
          label: 'أخرى',
          visible: true,
          required: false,
          height: 36,
          width: 40,
          lineHeight: 0.2,
          colorValue: 0xFF0000FF,
        ),
      },
      _ => base.fieldSettings,
    };
    if (scope == 'clearanceRequest') {
      for (var i = 1; i <= 6; i++) {
        fields['clearanceAmount$i'] = FieldSetting(
          label: 'المبلغ $i',
          visible: true,
          required: false,
          maxLength: 30,
        );
        fields['clearanceDate$i'] = FieldSetting(
          label: 'التاريخ $i',
          visible: true,
          required: false,
          maxLength: 10,
        );
        fields['clearanceStatement$i'] = FieldSetting(
          label: 'البيان $i',
          visible: true,
          required: false,
          maxLength: 120,
        );
      }
    }
    if (scope == 'serviceRequest') {
      for (var i = 1; i <= 6; i++) {
        fields['serviceItemName$i'] = FieldSetting(
          label: 'اسم الصنف $i',
          visible: true,
          required: false,
          maxLength: 36,
          height: 22,
          lineHeight: 0.2,
          alignment: 'center',
          colorValue: 0xFF0000FF,
        );
      }
    }
    if (scope == 'sampleRequest' || scope == 'sampleRequestSinglePage') {
      if (scope == 'sampleRequestSinglePage') {
        fields
          ..clear()
          ..addAll(AppSettings.defaultsForScope('sampleRequest').fieldSettings)
          ..remove('reasonPage3');
        for (var i = 26; i <= 53; i++) {
          fields.remove('sampleItemName$i');
          fields.remove('sampleItemForm$i');
          fields.remove('sampleItemQuantity$i');
          fields.remove('sampleItemQuantityWords$i');
          fields.remove('sampleItemNotes$i');
        }
      }
      final maxSampleItems = scope == 'sampleRequestSinglePage' ? 25 : 53;
      for (var i = 1; i <= maxSampleItems; i++) {
        fields['sampleItemName$i'] = FieldSetting(
          label: 'اسم الصنف $i',
          visible: true,
          required: false,
          maxLength: 80,
          height: 22,
          fontSize: 11.5,
          lineHeight: 0.2,
          alignment: 'right',
          colorValue: 0xFF0000FF,
        );
        fields['sampleItemForm$i'] = FieldSetting(
          label: 'الشكل الصيدلاني $i',
          visible: true,
          required: false,
          maxLength: 40,
          height: 22,
          fontSize: 11.5,
          lineHeight: 0.2,
          alignment: 'center',
          colorValue: 0xFF0000FF,
        );
        fields['sampleItemQuantity$i'] = FieldSetting(
          label: 'الكمية رقمًا $i',
          visible: true,
          required: false,
          maxLength: 20,
          height: 22,
          fontSize: 11.5,
          lineHeight: 0.2,
          alignment: 'center',
          colorValue: 0xFF0000FF,
        );
        fields['sampleItemQuantityWords$i'] = FieldSetting(
          label: 'الكمية كتابة $i',
          visible: true,
          required: false,
          maxLength: 80,
          height: 22,
          fontSize: 9,
          lineHeight: 0.2,
          alignment: 'center',
          colorValue: 0xFF0000FF,
        );
        fields['sampleItemNotes$i'] = FieldSetting(
          label: 'ملاحظات الصنف $i',
          visible: true,
          required: false,
          maxLength: 100,
          height: 22,
          fontSize: 9,
          lineHeight: 0.2,
          alignment: 'right',
          colorValue: 0xFF0000FF,
        );
      }
    }
    final styledFields = scope == 'fuelRequest'
        ? _applyFuelFieldSpecification(fields)
        : fields;
    final geometryScope =
        scope == 'clearanceRequest' ||
            scope == 'serviceRequest' ||
            scope == 'sampleRequest' ||
            scope == 'sampleRequestSinglePage' ||
            scope == 'travelAllowance'
        ? scope
        : 'expenseRequest';
    if (scope == 'internalMemo') {
      return base.copyWith(
        memoFullA4FieldSettings: TemplateGeometry.apply(
          'internalMemo',
          base.memoFullA4FieldSettings,
        ),
      );
    }
    if (scope == 'customerApplication') {
      return base.copyWith(
        customerFieldSettings: TemplateGeometry.apply(
          'customerApplication',
          base.customerFieldSettings,
        ),
      );
    }
    final scopedFields = TemplateGeometry.apply(geometryScope, styledFields);
    if (scope == 'travelAllowance') {
      const branches = <String>[
        'الجنوبية',
        'الوسطى',
        'الغربية',
        'الشمالية',
        'كبار العملاء',
        'البريات',
      ];
      return base.copyWith(
        fieldSettings: scopedFields,
        branchOptions: branches,
        stakeholderOptions: {
          ...base.stakeholderOptions,
          'الموظف المستفيد': base.receiverOptions,
          'مدير الفرع': const ['مدير الفرع'],
          'مدير الإدارة المعنية': const ['مدير الإدارة'],
          'محاسب الإدارة': base.stakeholderOptions['محاسب الإدارة'] ?? const [],
          'مدير الحسابات': base.stakeholderOptions['مدير الحسابات'] ?? const [],
        },
      );
    }
    return base.copyWith(fieldSettings: scopedFields);
  }

  static Map<String, FieldSetting> _applyFuelFieldSpecification(
    Map<String, FieldSetting> source,
  ) {
    final fields = <String, FieldSetting>{...source};
    FieldSetting style(String key, double fontSize, double height, int color) {
      final current = fields[key];
      if (current == null) {
        return FieldSetting(
          label: key,
          visible: true,
          required: false,
          fontSize: fontSize,
          height: height,
          colorValue: color,
          lineHeight: 0.2,
          alignment: 'right',
        );
      }
      return current.copyWith(
        fontSize: fontSize,
        height: height,
        colorValue: color,
        lineHeight: 0.2,
        alignment: 'right',
      );
    }

    // Deep blue for printed form values; the bottom system timestamp stays black.
    const blue = 0xFF000066;
    fields['fuelBranch'] = style('fuelBranch', 10, 22, blue);
    fields['vehicleNumber'] = style('vehicleNumber', 10, 30, blue);
    fields['collector'] = style('collector', 10, 22, blue);
    fields['periodFrom'] = style('periodFrom', 11, 22, blue);
    fields['periodTo'] = style('periodTo', 11, 22, blue);
    fields['beneficiary'] = style('beneficiary', 10.5, 22, blue);
    fields['branchAccountant'] = style('branchAccountant', 10.5, 22, blue);
    fields['branchManager'] = style('branchManager', 10.5, 22, blue);
    fields['administrationAccountant'] = style(
      'administrationAccountant',
      10.5,
      22,
      blue,
    );
    fields['accountsManager'] = style('accountsManager', 10.5, 22, blue);
    fields['systemTimestamp'] = style('systemTimestamp', 10, 22, 0xFF000000);
    for (final key in ['fuelTypePetrol', 'fuelTypeDiesel', 'fuelTypeGas']) {
      fields[key] = style(key, 11, 30, blue);
    }
    for (var i = 1; i <= 7; i++) {
      fields['fuelDate$i'] = style('fuelDate$i', 12, 22, blue);
      fields['fuelMeter$i'] = style('fuelMeter$i', 12, 22, blue);
      fields['fuelLiters$i'] = style('fuelLiters$i', 12, 22, blue);
      fields['fuelPrice$i'] = style('fuelPrice$i', 12, 22, blue);
      fields['fuelAmount$i'] = style('fuelAmount$i', 12, 22, blue);
      fields['fuelCollection$i'] = style('fuelCollection$i', 12, 22, blue);
      fields['fuelSales$i'] = style('fuelSales$i', 12, 22, blue);
      fields['fuelRoute$i'] = style('fuelRoute$i', 8, 35, blue);
    }
    return fields;
  }

  AppSettings copyWith({
    String? companyName,
    String? formTitle,
    String? documentNumber,
    String? issueDate,
    String? issueVersion,
    String? currencyName,
    String? fractionName,
    bool? autoSpelling,
    bool? showAccountField,
    bool? requireAccountField,
    bool? showSignatures,
    bool? requireApprovals,
    double? fontSize,
    int? primaryColorValue,
    int? textColorValue,
    int? printedTextColorValue,
    int? backgroundColorValue,
    int? fieldBackgroundColorValue,
    bool? darkMode,
    Map<String, FieldSetting>? fieldSettings,
    Map<String, FieldSetting>? bottomFieldSettings,
    Map<String, FieldSetting>? memoFieldSettings,
    Map<String, FieldSetting>? memoBottomFieldSettings,
    Map<String, FieldSetting>? memoFullA4FieldSettings,
    Map<String, FieldSetting>? customerFieldSettings,
    TemplateMode? templateMode,
    int? pageCopies,
    List<String>? receiverOptions,
    List<String>? requesterHistory,
    List<String>? branchOptions,
    Map<String, List<String>>? stakeholderOptions,
    int? maxStructuredDataCharacters,
    String? representativeReportMedRep,
    String? representativeReportCity,
    String? representativeReportDistrict,
    String? representativeReportSection,
  }) {
    return AppSettings(
      companyName: companyName ?? this.companyName,
      formTitle: formTitle ?? this.formTitle,
      documentNumber: documentNumber ?? this.documentNumber,
      issueDate: issueDate ?? this.issueDate,
      issueVersion: issueVersion ?? this.issueVersion,
      currencyName: currencyName ?? this.currencyName,
      fractionName: fractionName ?? this.fractionName,
      autoSpelling: autoSpelling ?? this.autoSpelling,
      showAccountField: showAccountField ?? this.showAccountField,
      requireAccountField: requireAccountField ?? this.requireAccountField,
      showSignatures: showSignatures ?? this.showSignatures,
      requireApprovals: requireApprovals ?? this.requireApprovals,
      fontSize: fontSize ?? this.fontSize,
      primaryColorValue: primaryColorValue ?? this.primaryColorValue,
      textColorValue: textColorValue ?? this.textColorValue,
      printedTextColorValue:
          printedTextColorValue ?? this.printedTextColorValue,
      backgroundColorValue: backgroundColorValue ?? this.backgroundColorValue,
      fieldBackgroundColorValue:
          fieldBackgroundColorValue ?? this.fieldBackgroundColorValue,
      darkMode: darkMode ?? this.darkMode,
      fieldSettings: fieldSettings ?? this.fieldSettings,
      bottomFieldSettings: bottomFieldSettings ?? this.bottomFieldSettings,
      memoFieldSettings: memoFieldSettings ?? this.memoFieldSettings,
      memoBottomFieldSettings:
          memoBottomFieldSettings ?? this.memoBottomFieldSettings,
      memoFullA4FieldSettings:
          memoFullA4FieldSettings ?? this.memoFullA4FieldSettings,
      customerFieldSettings:
          customerFieldSettings ?? this.customerFieldSettings,
      templateMode: templateMode ?? this.templateMode,
      pageCopies: pageCopies ?? this.pageCopies,
      receiverOptions: receiverOptions ?? this.receiverOptions,
      requesterHistory: requesterHistory ?? this.requesterHistory,
      branchOptions: branchOptions ?? this.branchOptions,
      stakeholderOptions: stakeholderOptions ?? this.stakeholderOptions,
      maxStructuredDataCharacters:
          maxStructuredDataCharacters ?? this.maxStructuredDataCharacters,
      representativeReportMedRep:
          representativeReportMedRep ?? this.representativeReportMedRep,
      representativeReportCity:
          representativeReportCity ?? this.representativeReportCity,
      representativeReportDistrict:
          representativeReportDistrict ?? this.representativeReportDistrict,
      representativeReportSection:
          representativeReportSection ?? this.representativeReportSection,
    );
  }

  Map<String, Object> toMap() {
    return {
      'companyName': companyName,
      'formTitle': formTitle,
      'documentNumber': documentNumber,
      'issueDate': issueDate,
      'issueVersion': issueVersion,
      'currencyName': currencyName,
      'fractionName': fractionName,
      'autoSpelling': autoSpelling,
      'showAccountField': showAccountField,
      'requireAccountField': requireAccountField,
      'showSignatures': showSignatures,
      'requireApprovals': requireApprovals,
      'fontSize': fontSize,
      'primaryColorValue': primaryColorValue,
      'textColorValue': textColorValue,
      'printedTextColorValue': printedTextColorValue,
      'backgroundColorValue': backgroundColorValue,
      'fieldBackgroundColorValue': fieldBackgroundColorValue,
      'darkMode': darkMode,
      'fieldSettings': fieldSettings.map(
        (key, value) => MapEntry(key, value.toMap()),
      ),
      'bottomFieldSettings': bottomFieldSettings.map(
        (key, value) => MapEntry(key, value.toMap()),
      ),
      'memoFieldSettings': memoFieldSettings.map(
        (key, value) => MapEntry(key, value.toMap()),
      ),
      'memoBottomFieldSettings': memoBottomFieldSettings.map(
        (key, value) => MapEntry(key, value.toMap()),
      ),
      'memoFullA4FieldSettings': memoFullA4FieldSettings.map(
        (key, value) => MapEntry(key, value.toMap()),
      ),
      'customerFieldSettings': customerFieldSettings.map(
        (key, value) => MapEntry(key, value.toMap()),
      ),
      'templateMode': templateMode.name,
      'pageCopies': pageCopies,
      'receiverOptions': receiverOptions,
      'requesterHistory': requesterHistory,
      'branchOptions': branchOptions,
      'stakeholderOptions': stakeholderOptions,
      'maxStructuredDataCharacters': maxStructuredDataCharacters,
      'representativeReportMedRep': representativeReportMedRep,
      'representativeReportCity': representativeReportCity,
      'representativeReportDistrict': representativeReportDistrict,
      'representativeReportSection': representativeReportSection,
    };
  }

  factory AppSettings.fromMap(Map<String, Object?> map) {
    final defaults = AppSettings.defaults();
    return defaults.copyWith(
      companyName: map['companyName'] as String?,
      formTitle: fixedFormTitle,
      documentNumber: fixedDocumentNumber,
      issueDate: fixedIssueDate,
      issueVersion: fixedIssueVersion,
      currencyName: map['currencyName'] as String?,
      fractionName: map['fractionName'] as String?,
      autoSpelling: map['autoSpelling'] as bool?,
      showAccountField: map['showAccountField'] as bool?,
      requireAccountField: map['requireAccountField'] as bool?,
      showSignatures: map['showSignatures'] as bool?,
      requireApprovals: map['requireApprovals'] as bool?,
      fontSize: (map['fontSize'] as num?)?.toDouble(),
      primaryColorValue: map['primaryColorValue'] as int?,
      textColorValue: map['textColorValue'] as int?,
      printedTextColorValue: map['printedTextColorValue'] as int?,
      backgroundColorValue: map['backgroundColorValue'] as int?,
      fieldBackgroundColorValue: map['fieldBackgroundColorValue'] as int?,
      darkMode: map['darkMode'] as bool?,
      fieldSettings: _fieldSettingsFromMap(map['fieldSettings']),
      bottomFieldSettings:
          _fieldSettingsFromMap(map['bottomFieldSettings']) ??
          const <String, FieldSetting>{},
      memoFieldSettings: _memoFieldSettingsFromMap(
        map['memoFieldSettings'],
        defaults.memoFieldSettings,
      ),
      memoBottomFieldSettings: _memoFieldSettingsFromMap(
        map['memoBottomFieldSettings'],
        defaults.memoBottomFieldSettings,
      ),
      memoFullA4FieldSettings: _memoFieldSettingsFromMap(
        map['memoFullA4FieldSettings'],
        defaults.memoFullA4FieldSettings,
      ),
      customerFieldSettings: _memoFieldSettingsFromMap(
        map['customerFieldSettings'],
        defaults.customerFieldSettings,
      ),
      templateMode: TemplateMode.values.firstWhere(
        (value) => value.name == map['templateMode'],
        orElse: () => TemplateMode.original,
      ),
      pageCopies: map['pageCopies'] as int?,
      receiverOptions: _stringList(
        map['receiverOptions'],
        fallback: defaults.receiverOptions,
      ),
      requesterHistory: _stringList(
        map['requesterHistory'],
        fallback: defaults.requesterHistory,
      ),
      branchOptions: _withDefaults(
        _stringList(map['branchOptions'], fallback: defaults.branchOptions),
        defaults.branchOptions,
      ),
      maxStructuredDataCharacters: (map['maxStructuredDataCharacters'] as num?)
          ?.toInt(),
      representativeReportMedRep: map['representativeReportMedRep'] as String?,
      representativeReportCity: map['representativeReportCity'] as String?,
      representativeReportDistrict:
          map['representativeReportDistrict'] as String?,
      representativeReportSection:
          map['representativeReportSection'] as String?,
      stakeholderOptions: _stakeholderOptionsFromMap(
        map['stakeholderOptions'],
        defaults: defaults.stakeholderOptions,
        legacyReceiverOptions: _stringList(
          map.containsKey('receiverOptions')
              ? map['receiverOptions']
              : const [],
        ),
        legacyRequesterHistory: _stringList(
          map.containsKey('requesterHistory')
              ? map['requesterHistory']
              : const [],
        ),
      ),
    );
  }

  static List<String> _withDefaults(
    List<String> values,
    List<String> defaults,
  ) => <String>{...defaults, ...values}.toList();

  static List<String> _stringList(
    Object? value, {
    List<String> fallback = const [],
  }) {
    if (value is List) {
      final items = value
          .map((item) => item.toString().trim())
          .where((item) => item.isNotEmpty)
          .toSet()
          .toList();
      if (items.isNotEmpty) return items;
    }
    return List<String>.from(fallback);
  }

  static Map<String, FieldSetting> _memoFieldSettingsFromMap(
    Object? value,
    Map<String, FieldSetting> fallback,
  ) {
    if (value == null) return Map<String, FieldSetting>.from(fallback);
    if (value is! Map) return <String, FieldSetting>{};
    final fields = <String, FieldSetting>{};
    for (final entry in value.entries) {
      if (entry.value is Map) {
        fields[entry.key.toString()] = FieldSetting.fromMap(
          Map<String, dynamic>.from(entry.value as Map),
          key: entry.key.toString(),
        );
      }
    }
    return fields;
  }

  static Map<String, List<String>> _stakeholderOptionsFromMap(
    Object? value, {
    required Map<String, List<String>> defaults,
    required List<String> legacyReceiverOptions,
    required List<String> legacyRequesterHistory,
  }) {
    final result = <String, List<String>>{
      for (final entry in defaults.entries)
        entry.key: List<String>.from(entry.value),
    };
    if (value is Map) {
      for (final entry in value.entries) {
        if (entry.value is List) {
          result[entry.key.toString()] = _stringList(entry.value);
        }
      }
    }
    if (legacyReceiverOptions.isNotEmpty) {
      result['المقدم إليه'] = legacyReceiverOptions;
    }
    if (legacyRequesterHistory.isNotEmpty) {
      result['مقدم الطلب'] = legacyRequesterHistory;
    }
    List<String> mergeRoles(String first, String second) {
      final merged = <String>{
        ...?result[first],
        ...?result[second],
      }.where((item) => item.trim().isNotEmpty).toList();
      result[first] = List<String>.from(merged);
      result[second] = List<String>.from(merged);
      return merged;
    }

    mergeRoles('محاسب الفرع', 'مختص حسابات الفرع');
    final requester = result.putIfAbsent('مقدم الطلب', () => <String>[]);
    if (!requester.contains('عبدالعزيز كباس')) requester.add('عبدالعزيز كباس');
    final administrationAccountants = result.putIfAbsent(
      'محاسب الإدارة',
      () => <String>[],
    );
    if (!administrationAccountants.contains('عبدالعزيز كباس')) {
      administrationAccountants.add('عبدالعزيز كباس');
    }
    final accountsManagers = result.putIfAbsent(
      'مدير الحسابات',
      () => <String>[],
    );
    if (!accountsManagers.contains('أ/ توفيق القاضي')) {
      accountsManagers.add('أ/ توفيق القاضي');
    }
    final receivers = result.putIfAbsent('المقدم إليه', () => <String>[]);
    if (!receivers.contains('أ/حميد المقحفي')) {
      receivers.add('أ/حميد المقحفي');
    }
    if (!receivers.contains('أ/ توفيق القاضي')) {
      receivers.add('أ/ توفيق القاضي');
    }
    final salesManagers = result.putIfAbsent('مدير المبيعات', () => <String>[]);
    if (!salesManagers.contains('أ/حميد المقحفي')) {
      salesManagers.add('أ/حميد المقحفي');
    }
    result.putIfAbsent('العملاء', () => <String>[]);
    result.putIfAbsent('الفرع', () => <String>[]);
    return result;
  }

  static Map<String, FieldSetting>? _fieldSettingsFromMap(Object? value) {
    if (value == null) return null;
    if (value is! Map || value.isEmpty) return null;
    final fields = <String, FieldSetting>{};
    for (final entry in value.entries) {
      final item = entry.value;
      fields[entry.key.toString()] = item is Map
          ? FieldSetting.fromMap(
              Map<String, dynamic>.from(item),
              key: entry.key.toString(),
            )
          : const FieldSetting(label: '', visible: true, required: false);
    }
    return fields;
  }
}

enum TemplateMode { original, editable }

enum FieldInputType { text, amount, stakeholder, date }

FieldInputType fieldInputTypeForKey(String key) {
  if (key == 'date' || key.startsWith('clearanceDate')) {
    return FieldInputType.date;
  }
  if (key == 'amountNumber' ||
      key == 'bonusPercent' ||
      key.startsWith('previousPurchases') ||
      key.startsWith('previousPayments') ||
      key.startsWith('currentPurchases') ||
      key.startsWith('currentPayments') ||
      key.startsWith('clearanceAmount')) {
    return FieldInputType.amount;
  }
  if (key == 'receiver' ||
      key == 'requesterName' ||
      key == 'directManagerName' ||
      key == 'approvedAuthorityName' ||
      key == 'accountsManagerName') {
    return FieldInputType.stakeholder;
  }
  return FieldInputType.text;
}

class FieldSetting {
  const FieldSetting({
    required this.label,
    required this.visible,
    required this.required,
    this.fontSize = 11,
    this.colorValue = 0xFF0070C0,
    this.x = 0,
    this.y = 0,
    this.width = 1,
    this.height = 1,
    this.bottomX = 0,
    this.bottomY = 0,
    this.bottomWidth = 1,
    this.maxLength = 250,
    this.fontFamily = 'Noto Naskh Arabic',
    this.fontWeight = 400,
    this.fontStyle = 'normal',
    this.alignment = 'right',
    this.lineHeight = 1.5,
    this.geometryConfigured = false,
    this.inputType = FieldInputType.text,
  });

  final String label;
  final bool visible;
  final bool required;
  final double fontSize;
  final int colorValue;
  final double x;
  final double y;
  final double width;
  final double height;
  final double bottomX;
  final double bottomY;
  final double bottomWidth;
  final int maxLength;
  final String fontFamily;
  final int fontWeight;
  final String fontStyle;
  final String alignment;
  final double lineHeight;
  final bool geometryConfigured;
  final FieldInputType inputType;

  FieldSetting copyWith({
    String? label,
    bool? visible,
    bool? required,
    double? fontSize,
    int? colorValue,
    double? x,
    double? y,
    double? width,
    double? height,
    double? bottomX,
    double? bottomY,
    double? bottomWidth,
    int? maxLength,
    String? fontFamily,
    int? fontWeight,
    String? fontStyle,
    String? alignment,
    double? lineHeight,
    bool? geometryConfigured,
    FieldInputType? inputType,
  }) {
    return FieldSetting(
      label: label ?? this.label,
      visible: visible ?? this.visible,
      required: required ?? this.required,
      fontSize: fontSize ?? this.fontSize,
      colorValue: colorValue ?? this.colorValue,
      x: x ?? this.x,
      y: y ?? this.y,
      width: width ?? this.width,
      height: height ?? this.height,
      bottomX: bottomX ?? this.bottomX,
      bottomY: bottomY ?? this.bottomY,
      bottomWidth: bottomWidth ?? this.bottomWidth,
      maxLength: maxLength ?? this.maxLength,
      fontFamily: fontFamily ?? this.fontFamily,
      fontWeight: fontWeight ?? this.fontWeight,
      fontStyle: fontStyle ?? this.fontStyle,
      alignment: alignment ?? this.alignment,
      lineHeight: lineHeight ?? this.lineHeight,
      geometryConfigured: geometryConfigured ?? this.geometryConfigured,
      inputType: inputType ?? this.inputType,
    );
  }

  Map<String, Object> toMap() {
    return {
      'label': label,
      'visible': visible,
      'required': required,
      'fontSize': fontSize,
      'colorValue': colorValue,
      'x': x,
      'y': y,
      'width': width,
      'height': height,
      'bottomX': bottomX,
      'bottomY': bottomY,
      'bottomWidth': bottomWidth,
      'maxLength': maxLength,
      'fontFamily': fontFamily,
      'fontWeight': fontWeight,
      'fontStyle': fontStyle,
      'alignment': alignment,
      'lineHeight': lineHeight,
      'geometryConfigured': geometryConfigured,
      'inputType': inputType.name,
    };
  }

  factory FieldSetting.fromMap(Map<String, dynamic> map, {String? key}) {
    final storedLineHeight = (map['lineHeight'] as num?)?.toDouble() ?? 1.5;
    return FieldSetting(
      label: map['label'] as String? ?? '',
      visible: map['visible'] as bool? ?? true,
      required: map['required'] as bool? ?? false,
      fontSize: (map['fontSize'] as num?)?.toDouble() ?? 11,
      colorValue: map['colorValue'] as int? ?? 0xFF0070C0,
      x: (map['x'] as num?)?.toDouble() ?? 0,
      y: (map['y'] as num?)?.toDouble() ?? 0,
      width: (map['width'] as num?)?.toDouble() ?? 1,
      height: (map['height'] as num?)?.toDouble() ?? 1,
      bottomX: (map['bottomX'] as num?)?.toDouble() ?? 0,
      bottomY: (map['bottomY'] as num?)?.toDouble() ?? 0,
      bottomWidth: (map['bottomWidth'] as num?)?.toDouble() ?? 1,
      maxLength: map['maxLength'] as int? ?? 250,
      fontFamily: map['fontFamily'] as String? ?? 'Noto Naskh Arabic',
      fontWeight: map['fontWeight'] as int? ?? 400,
      fontStyle: map['fontStyle'] as String? ?? 'normal',
      alignment: map['alignment'] as String? ?? 'right',
      lineHeight: storedLineHeight.clamp(0.2, 4.0).toDouble(),
      geometryConfigured: map['geometryConfigured'] as bool? ?? false,
      inputType: FieldInputType.values.firstWhere(
        (value) => value.name == map['inputType'],
        orElse: () => fieldInputTypeForKey(key ?? ''),
      ),
    );
  }
}
