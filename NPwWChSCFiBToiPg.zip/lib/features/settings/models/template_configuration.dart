import 'app_settings.dart';

enum TemplateKind {
  customerApplication,
  expenseRequest,
  clearanceRequest,
  serviceRequest,
  fuelRequest,
  sampleRequest,
  sampleRequestSinglePage,
  travelAllowance,
  internalMemo,
}

extension TemplateKindDetails on TemplateKind {
  String get title => switch (this) {
    TemplateKind.customerApplication => 'نموذج العملاء',
    TemplateKind.expenseRequest => 'طلب الصرف',
    TemplateKind.clearanceRequest => 'طلب إخلاء عهدة',
    TemplateKind.serviceRequest => 'طلب خدمة',
    TemplateKind.fuelRequest => 'نموذج المحروقات',
    TemplateKind.sampleRequest => 'نموذج طلب عينات',
    TemplateKind.sampleRequestSinglePage => 'نموذج طلب عينات — صفحة واحدة',
    TemplateKind.travelAllowance => 'نموذج طلب بدل السفر',
    TemplateKind.internalMemo => 'المذكرة الداخلية',
  };

  String get description => switch (this) {
    TemplateKind.customerApplication =>
      'بيانات العملاء وحقول نموذج التقديم والطباعة.',
    TemplateKind.expenseRequest => 'طلب الصرف والمعنيون والحقول المالية.',
    TemplateKind.clearanceRequest =>
      'إخلاء عهدة مع المبالغ والبيانات والاعتمادات.',
    TemplateKind.serviceRequest => 'طلب خدمة مع الأصناف والجهة والموافقات.',
    TemplateKind.fuelRequest => 'محروقات مع البيانات العامة وصفوف التعبئة.',
    TemplateKind.sampleRequest =>
      'طلب عينات مع اختيار الأصناف والكميات والطباعة.',
    TemplateKind.sampleRequestSinglePage =>
      'إعدادات النموذج الجديد ذي الصفحة الواحدة و25 صنفًا.',
    TemplateKind.travelAllowance =>
      'كشف بدل السفر بعشرة صفوف مع الإجماليات والاعتمادات.',
    TemplateKind.internalMemo => 'مذكرة داخلية A4 كاملة، صفحة واحدة.',
  };
}

/// The supported document templates. Each id owns its own geometry and fields.
enum TemplateId {
  expenseRequestSingle,
  expenseRequestDouble,
  internalMemoHalf,
  internalMemoA4,
  customerApplication,
}

class TemplateConfiguration {
  const TemplateConfiguration({
    required this.id,
    required this.name,
    required this.paperWidth,
    required this.paperHeight,
    required this.fields,
    required this.assetPath,
    this.isFullPage = false,
  });

  final TemplateId id;
  final String name;
  final double paperWidth;
  final double paperHeight;
  final Map<String, FieldSetting> fields;
  final String assetPath;
  final bool isFullPage;

  bool get isA4 => paperWidth == 595.28 && paperHeight == 841.89;

  TemplateConfiguration copyWith({Map<String, FieldSetting>? fields}) {
    return TemplateConfiguration(
      id: id,
      name: name,
      paperWidth: paperWidth,
      paperHeight: paperHeight,
      fields: fields ?? this.fields,
      assetPath: assetPath,
      isFullPage: isFullPage,
    );
  }

  static TemplateConfiguration internalMemoA4(AppSettings settings) {
    return TemplateConfiguration(
      id: TemplateId.internalMemoA4,
      name: 'مذكرة داخلية — ورقة كاملة A4',
      paperWidth: 595.28,
      paperHeight: 841.89,
      fields: settings.memoFullA4FieldSettings,
      assetPath: 'assets/images/memo/internal_memo_full.png',
      isFullPage: true,
    );
  }

  static TemplateConfiguration internalMemoHalf(AppSettings settings) {
    return TemplateConfiguration(
      id: TemplateId.internalMemoHalf,
      name: 'مذكرة داخلية — نصف ورقة',
      paperWidth: 595.28,
      paperHeight: 420.945,
      fields: settings.memoFieldSettings,
      assetPath: 'assets/images/memo/internal_memo_full.png',
    );
  }

  static TemplateConfiguration customerApplication(AppSettings settings) {
    return TemplateConfiguration(
      id: TemplateId.customerApplication,
      name: 'نموذج تقديم خاص للمبيعات',
      paperWidth: 612,
      paperHeight: 792,
      fields: settings.customerFieldSettings,
      assetPath: 'assets/images/customer_application_sales_modified.png',
      isFullPage: true,
    );
  }
}

/// User-selectable memo output layout, persisted with each saved memo.
enum InternalMemoLayout { halfPage, fullA4 }

extension InternalMemoLayoutLabel on InternalMemoLayout {
  String get label => switch (this) {
    InternalMemoLayout.halfPage => 'مذكرة داخلية — نصف ورقة',
    InternalMemoLayout.fullA4 => 'مذكرة داخلية — ورقة كاملة A4',
  };
}
