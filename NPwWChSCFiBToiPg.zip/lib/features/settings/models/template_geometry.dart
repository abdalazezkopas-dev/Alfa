import 'app_settings.dart';

class TemplateGeometry {
  const TemplateGeometry({
    required this.x,
    required this.y,
    required this.width,
    this.height = 22,
  });

  final double x;
  final double y;
  final double width;
  final double height;

  static const Map<String, TemplateGeometry> expense = {
    'dateLabel': TemplateGeometry(x: 125, y: 36, width: 100, height: 27),
    'date': TemplateGeometry(x: 70, y: 56, width: 90, height: 22),
    'receiver': TemplateGeometry(x: 105, y: 70, width: 350, height: 22),
    'amountNumber': TemplateGeometry(x: 385, y: 102, width: 95, height: 22),
    'amountWords': TemplateGeometry(x: 118, y: 113, width: 350, height: 22),
    'reason': TemplateGeometry(x: 85, y: 145, width: 180),
    'statement': TemplateGeometry(x: 30, y: 137, width: 470, height: 80),
    'branch': TemplateGeometry(x: 5, y: 282, width: 150, height: 22),
    'account': TemplateGeometry(x: 260, y: 330, width: 180),
    'requesterName': TemplateGeometry(x: 413, y: 225, width: 120, height: 22),
    'directManagerName': TemplateGeometry(
      x: 222,
      y: 225,
      width: 120,
      height: 22,
    ),
    'approvedAuthorityName': TemplateGeometry(
      x: 57,
      y: 225,
      width: 120,
      height: 22,
    ),
    'accountsManagerName': TemplateGeometry(
      x: 30,
      y: 358,
      width: 200,
      height: 22,
    ),
  };

  static final Map<String, TemplateGeometry> sample = _sampleGeometry();
  static final Map<String, TemplateGeometry> sampleSinglePage =
      _sampleSinglePageGeometry();
  static final Map<String, TemplateGeometry> travelAllowance =
      _travelAllowanceGeometry();

  static Map<String, TemplateGeometry> _travelAllowanceGeometry() {
    final result = <String, TemplateGeometry>{
      'branch': const TemplateGeometry(x: 500, y: 66, width: 250),
      'month': const TemplateGeometry(x: 300, y: 66, width: 170),
      'year': const TemplateGeometry(x: 155, y: 66, width: 100),
      'totalAmount': const TemplateGeometry(x: 500, y: 354, width: 115),
      'totalDays': const TemplateGeometry(x: 625, y: 390, width: 130),
      'beneficiary': const TemplateGeometry(x: 730, y: 430, width: 100),
      'branchManager': const TemplateGeometry(x: 585, y: 430, width: 140),
      'departmentManager': const TemplateGeometry(x: 420, y: 430, width: 160),
      'administrationAccountant': const TemplateGeometry(
        x: 250,
        y: 430,
        width: 165,
      ),
      'accountsManager': const TemplateGeometry(x: 75, y: 430, width: 165),
    };
    for (var index = 0; index < 10; index++) {
      final top = 103 + (index * 25.0);
      result.addAll({
        'travelDay${index + 1}': TemplateGeometry(x: 765, y: top, width: 65),
        'travelDate${index + 1}': TemplateGeometry(x: 625, y: top, width: 125),
        'travelDailyAmount${index + 1}': TemplateGeometry(
          x: 500,
          y: top,
          width: 115,
        ),
        'travelRegion${index + 1}': TemplateGeometry(
          x: 285,
          y: top,
          width: 205,
        ),
        'travelStatement${index + 1}': TemplateGeometry(
          x: 12,
          y: top,
          width: 265,
        ),
      });
    }
    return result;
  }

  static Map<String, TemplateGeometry> _sampleSinglePageGeometry() {
    final result = <String, TemplateGeometry>{
      'date': const TemplateGeometry(x: 0, y: 70, width: 90, height: 22),
      'receiver': const TemplateGeometry(
        x: 352,
        y: 135,
        width: 150,
        height: 22,
      ),
      'requesterName': const TemplateGeometry(
        x: 391,
        y: 704,
        width: 145,
        height: 22,
      ),
      'reason': const TemplateGeometry(x: 3, y: 668, width: 500, height: 33),
      'sampleUsageMarketing': const TemplateGeometry(
        x: 485,
        y: 93,
        width: 32,
        height: 32,
      ),
      'sampleUsageDoctors': const TemplateGeometry(
        x: 370,
        y: 93,
        width: 32,
        height: 32,
      ),
      'sampleUsageEmployees': const TemplateGeometry(
        x: 255,
        y: 93,
        width: 32,
        height: 32,
      ),
      'sampleUsageOther': const TemplateGeometry(
        x: 140,
        y: 93,
        width: 32,
        height: 32,
      ),
    };
    for (var i = 1; i <= 25; i++) {
      final top = 205 + ((i - 1) * 18.2) + 10 - (i >= 7 ? 4 : 0);
      result['sampleItemName$i'] = TemplateGeometry(
        x: 405,
        y: top,
        width: 148,
        height: 17,
      );
      result['sampleItemForm$i'] = TemplateGeometry(
        x: 312,
        y: top,
        width: 90,
        height: 17,
      );
      result['sampleItemQuantity$i'] = TemplateGeometry(
        x: 236,
        y: top,
        width: 72,
        height: 17,
      );
      result['sampleItemQuantityWords$i'] = TemplateGeometry(
        x: 164,
        y: top,
        width: 68,
        height: 17,
      );
      result['sampleItemNotes$i'] = TemplateGeometry(
        x: 32,
        y: top,
        width: 128,
        height: 17,
      );
    }
    return result;
  }

  static Map<String, TemplateGeometry> _sampleGeometry() {
    final result = <String, TemplateGeometry>{
      'date': const TemplateGeometry(x: 0, y: 63, width: 90, height: 22),
      'receiver': const TemplateGeometry(
        x: 323,
        y: 200,
        width: 160,
        height: 22,
      ),
      'requesterName': const TemplateGeometry(
        x: 382,
        y: 640,
        width: 135,
        height: 22,
      ),
      'reason': const TemplateGeometry(x: 44, y: 585, width: 450, height: 30),
      'reasonPage3': const TemplateGeometry(
        x: 20,
        y: 496,
        width: 468,
        height: 56,
      ),
      'sampleUsageMarketing': const TemplateGeometry(
        x: 480,
        y: 146,
        width: 40,
        height: 36,
      ),
      'sampleUsageDoctors': const TemplateGeometry(
        x: 368,
        y: 146,
        width: 40,
        height: 36,
      ),
      'sampleUsageEmployees': const TemplateGeometry(
        x: 245,
        y: 146,
        width: 40,
        height: 36,
      ),
      'sampleUsageOther': const TemplateGeometry(
        x: 102,
        y: 146,
        width: 40,
        height: 36,
      ),
    };
    const pageOneRows = [
      331.0,
      351.0,
      370.0,
      391.0,
      411.0,
      426.0,
      446.0,
      466.0,
      490.0,
      511.0,
      533.0,
    ];
    const pageTwoRows = [
      55.0,
      79.0,
      96.0,
      115.0,
      134.0,
      151.0,
      173.0,
      195.0,
      215.0,
      237.0,
      257.0,
      280.0,
      306.0,
      330.0,
      350.0,
      374.0,
      395.0,
      418.0,
      440.0,
      464.0,
      484.0,
      506.0,
    ];
    for (var index = 1; index <= 53; index++) {
      final page = index <= 11
          ? 1
          : index <= 33
          ? 2
          : 3;
      final row = page == 1
          ? index - 1
          : page == 2
          ? index - 12
          : index - 34;
      const pageThreeRows = [
        38.0,
        60.0,
        78.0,
        98.0,
        117.0,
        137.0,
        155.0,
        177.0,
        199.0,
        221.0,
        243.0,
        264.0,
        286.0,
        308.0,
        332.0,
        355.0,
        378.0,
        397.0,
        419.0,
        443.0,
      ];
      final top = page == 1
          ? pageOneRows[row]
          : page == 2
          ? pageTwoRows[row]
          : pageThreeRows[row];
      result['sampleItemName$index'] = TemplateGeometry(
        x: 383,
        y: top,
        width: 166,
      );
      result['sampleItemForm$index'] = TemplateGeometry(
        x: 320,
        y: top,
        width: 73,
      );
      result['sampleItemQuantity$index'] = TemplateGeometry(
        x: 260,
        y: top,
        width: 65,
      );
      result['sampleItemQuantityWords$index'] = TemplateGeometry(
        x: 171,
        y: top,
        width: 78,
      );
      result['sampleItemNotes$index'] = TemplateGeometry(
        x: 45,
        y: top,
        width: 125,
      );
    }
    return result;
  }

  static const Map<String, TemplateGeometry> customer = {
    'date': TemplateGeometry(x: 34, y: 66, width: 80, height: 24),
    'bonusExtra': TemplateGeometry(x: 500, y: 148, width: 72, height: 35),
    'customerCompensation': TemplateGeometry(
      x: 380,
      y: 148,
      width: 72,
      height: 35,
    ),
    'settlementOffer': TemplateGeometry(x: 260, y: 148, width: 72, height: 35),
    'cashDiscount': TemplateGeometry(x: 140, y: 148, width: 72, height: 35),
    'otherType': TemplateGeometry(x: 24, y: 148, width: 72, height: 35),
    'otherDetails': TemplateGeometry(x: 1, y: 188, width: 158, height: 30),
    'receiver': TemplateGeometry(x: 300, y: 218, width: 250),
    'branch': TemplateGeometry(x: 219, y: 254, width: 80, height: 22),
    'customer': TemplateGeometry(x: 322, y: 254, width: 100, height: 24),
    'customerType': TemplateGeometry(x: 90, y: 278, width: 170, height: 24),
    'customerTypeNew': TemplateGeometry(x: 140, y: 245, width: 40, height: 24),
    'customerTypePrevious': TemplateGeometry(
      x: 100,
      y: 245,
      width: 40,
      height: 24,
    ),
    'previousPurchases': TemplateGeometry(
      x: 153,
      y: 273,
      width: 100,
      height: 22,
    ),
    'currentPurchases': TemplateGeometry(
      x: 150,
      y: 297,
      width: 100,
      height: 22,
    ),
    'previousPayments': TemplateGeometry(
      x: 370,
      y: 273,
      width: 100,
      height: 22,
    ),
    'currentPayments': TemplateGeometry(x: 370, y: 298, width: 100, height: 22),
    'bonusPercent': TemplateGeometry(x: 333, y: 319, width: 50, height: 22),
    'statementOne': TemplateGeometry(x: 17, y: 365, width: 577, height: 135),
    'statementTwo': TemplateGeometry(x: 17, y: 510, width: 577, height: 100),
    'requesterName': TemplateGeometry(x: 383, y: 614, width: 145, height: 22),
    'approvedAuthorityName': TemplateGeometry(
      x: 167,
      y: 614,
      width: 145,
      height: 22,
    ),
    'directManagerName': TemplateGeometry(x: 3, y: 614, width: 100, height: 22),
    'accountsManagerName': TemplateGeometry(
      x: 59,
      y: 708,
      width: 175,
      height: 22,
    ),
  };

  static const Map<String, TemplateGeometry> memo = {
    'receiver': TemplateGeometry(x: 100, y: 92, width: 380, height: 24),
    'date': TemplateGeometry(x: 100, y: 116, width: 180, height: 24),
    'statement': TemplateGeometry(x: 70, y: 145, width: 430, height: 180),
    'requesterName': TemplateGeometry(x: 100, y: 350, width: 300, height: 24),
  };

  static const Map<String, TemplateGeometry> clearance = {
    'date': TemplateGeometry(x: 58, y: 57, width: 120, height: 20),
    'receiver': TemplateGeometry(x: 390, y: 91, width: 170, height: 20),
    'amountNumber': TemplateGeometry(x: 470, y: 540, width: 90, height: 20),
    'requesterName': TemplateGeometry(x: 420, y: 575, width: 140),
    'directManagerName': TemplateGeometry(x: 80, y: 575, width: 140),
    'approvedAuthorityName': TemplateGeometry(x: 420, y: 660, width: 140),
    'accountsManagerName': TemplateGeometry(x: 80, y: 660, width: 140),
    'statement': TemplateGeometry(x: 60, y: 130, width: 480, height: 390),
  };

  static final Map<String, TemplateGeometry> fuel = {
    'fuelBranch': const TemplateGeometry(x: 591, y: 60, width: 70, height: 22),
    'vehicleNumber': const TemplateGeometry(
      x: 237,
      y: 60,
      width: 80,
      height: 30,
    ),
    'collector': const TemplateGeometry(x: 468, y: 58, width: 110, height: 22),
    'fuelTypePetrol': const TemplateGeometry(
      x: 734,
      y: 44,
      width: 40,
      height: 30,
    ),
    'fuelTypeDiesel': const TemplateGeometry(
      x: 713,
      y: 57,
      width: 40,
      height: 30,
    ),
    'fuelTypeGas': const TemplateGeometry(x: 685, y: 57, width: 40, height: 30),
    'periodFrom': const TemplateGeometry(x: 405, y: 60, width: 90, height: 22),
    'periodTo': const TemplateGeometry(x: 330, y: 60, width: 90, height: 22),
    'beneficiary': const TemplateGeometry(
      x: 694,
      y: 437,
      width: 120,
      height: 22,
    ),
    'branchAccountant': const TemplateGeometry(
      x: 586,
      y: 437,
      width: 120,
      height: 22,
    ),
    'branchManager': const TemplateGeometry(
      x: 459,
      y: 437,
      width: 120,
      height: 22,
    ),
    'administrationAccountant': const TemplateGeometry(
      x: 330,
      y: 437,
      width: 120,
      height: 22,
    ),
    'accountsManager': const TemplateGeometry(
      x: 189,
      y: 437,
      width: 120,
      height: 22,
    ),
    'systemTimestamp': const TemplateGeometry(
      x: 80,
      y: 502,
      width: 120,
      height: 22,
    ),
    'fuelDate1': const TemplateGeometry(x: 738, y: 126, width: 80, height: 22),
    'fuelMeter1': const TemplateGeometry(x: 675, y: 126, width: 65, height: 22),
    'fuelLiters1': const TemplateGeometry(
      x: 629,
      y: 126,
      width: 50,
      height: 22,
    ),
    'fuelPrice1': const TemplateGeometry(x: 580, y: 126, width: 50, height: 22),
    'fuelAmount1': const TemplateGeometry(
      x: 500,
      y: 126,
      width: 80,
      height: 22,
    ),
    'fuelCollection1': const TemplateGeometry(
      x: 410,
      y: 126,
      width: 80,
      height: 22,
    ),
    'fuelSales1': const TemplateGeometry(x: 320, y: 126, width: 80, height: 22),
    'fuelRoute1': const TemplateGeometry(x: 218, y: 126, width: 90, height: 35),
    'fuelDate2': const TemplateGeometry(x: 738, y: 164, width: 80, height: 22),
    'fuelMeter2': const TemplateGeometry(x: 675, y: 164, width: 65, height: 22),
    'fuelLiters2': const TemplateGeometry(
      x: 629,
      y: 164,
      width: 50,
      height: 22,
    ),
    'fuelPrice2': const TemplateGeometry(x: 580, y: 164, width: 50, height: 22),
    'fuelAmount2': const TemplateGeometry(
      x: 500,
      y: 164,
      width: 80,
      height: 22,
    ),
    'fuelCollection2': const TemplateGeometry(
      x: 410,
      y: 164,
      width: 80,
      height: 22,
    ),
    'fuelSales2': const TemplateGeometry(x: 320, y: 164, width: 80, height: 22),
    'fuelRoute2': const TemplateGeometry(x: 218, y: 164, width: 90, height: 35),
    'fuelDate3': const TemplateGeometry(x: 738, y: 199, width: 80, height: 22),
    'fuelMeter3': const TemplateGeometry(x: 675, y: 199, width: 65, height: 22),
    'fuelLiters3': const TemplateGeometry(
      x: 629,
      y: 199,
      width: 50,
      height: 22,
    ),
    'fuelPrice3': const TemplateGeometry(x: 580, y: 199, width: 50, height: 22),
    'fuelAmount3': const TemplateGeometry(
      x: 500,
      y: 199,
      width: 80,
      height: 22,
    ),
    'fuelCollection3': const TemplateGeometry(
      x: 410,
      y: 199,
      width: 80,
      height: 22,
    ),
    'fuelSales3': const TemplateGeometry(x: 320, y: 199, width: 80, height: 22),
    'fuelRoute3': const TemplateGeometry(x: 218, y: 199, width: 90, height: 35),
    'fuelDate4': const TemplateGeometry(x: 738, y: 235, width: 80, height: 22),
    'fuelMeter4': const TemplateGeometry(x: 675, y: 235, width: 65, height: 22),
    'fuelLiters4': const TemplateGeometry(
      x: 629,
      y: 235,
      width: 50,
      height: 22,
    ),
    'fuelPrice4': const TemplateGeometry(x: 580, y: 235, width: 50, height: 22),
    'fuelAmount4': const TemplateGeometry(
      x: 500,
      y: 235,
      width: 80,
      height: 22,
    ),
    'fuelCollection4': const TemplateGeometry(
      x: 410,
      y: 235,
      width: 80,
      height: 22,
    ),
    'fuelSales4': const TemplateGeometry(x: 320, y: 235, width: 80, height: 22),
    'fuelRoute4': const TemplateGeometry(x: 218, y: 235, width: 90, height: 35),
    'fuelDate5': const TemplateGeometry(x: 738, y: 270, width: 80, height: 22),
    'fuelMeter5': const TemplateGeometry(x: 675, y: 270, width: 65, height: 22),
    'fuelLiters5': const TemplateGeometry(
      x: 629,
      y: 270,
      width: 50,
      height: 22,
    ),
    'fuelPrice5': const TemplateGeometry(x: 580, y: 270, width: 50, height: 22),
    'fuelAmount5': const TemplateGeometry(
      x: 500,
      y: 270,
      width: 80,
      height: 22,
    ),
    'fuelCollection5': const TemplateGeometry(
      x: 410,
      y: 270,
      width: 80,
      height: 22,
    ),
    'fuelSales5': const TemplateGeometry(x: 320, y: 270, width: 80, height: 22),
    'fuelRoute5': const TemplateGeometry(x: 218, y: 270, width: 90, height: 35),
    'fuelDate6': const TemplateGeometry(x: 738, y: 306, width: 80, height: 22),
    'fuelMeter6': const TemplateGeometry(x: 675, y: 306, width: 65, height: 22),
    'fuelLiters6': const TemplateGeometry(
      x: 629,
      y: 306,
      width: 50,
      height: 22,
    ),
    'fuelPrice6': const TemplateGeometry(x: 580, y: 306, width: 50, height: 22),
    'fuelAmount6': const TemplateGeometry(
      x: 500,
      y: 306,
      width: 80,
      height: 22,
    ),
    'fuelCollection6': const TemplateGeometry(
      x: 410,
      y: 306,
      width: 80,
      height: 22,
    ),
    'fuelSales6': const TemplateGeometry(x: 320, y: 306, width: 80, height: 22),
    'fuelRoute6': const TemplateGeometry(x: 218, y: 306, width: 90, height: 35),
    'fuelDate7': const TemplateGeometry(x: 738, y: 341, width: 80, height: 22),
    'fuelMeter7': const TemplateGeometry(x: 675, y: 341, width: 65, height: 22),
    'fuelLiters7': const TemplateGeometry(
      x: 629,
      y: 341,
      width: 50,
      height: 22,
    ),
    'fuelPrice7': const TemplateGeometry(x: 580, y: 341, width: 50, height: 22),
    'fuelAmount7': const TemplateGeometry(
      x: 500,
      y: 341,
      width: 80,
      height: 22,
    ),
    'fuelCollection7': const TemplateGeometry(
      x: 410,
      y: 341,
      width: 80,
      height: 22,
    ),
    'fuelSales7': const TemplateGeometry(x: 320, y: 341, width: 80, height: 22),
    'fuelRoute7': const TemplateGeometry(x: 218, y: 341, width: 90, height: 35),
  };
  static const Map<String, TemplateGeometry> service = {
    'date': TemplateGeometry(x: 66, y: 52, width: 120, height: 22),
    'receiver': TemplateGeometry(x: 335, y: 74, width: 170, height: 22),
    'serviceTypeHospitality': TemplateGeometry(
      x: 434,
      y: 147,
      width: 50,
      height: 10,
    ),
    'serviceTypeCashSupport': TemplateGeometry(
      x: 222,
      y: 147,
      width: 50,
      height: 10,
    ),
    'serviceTypeInKindGift': TemplateGeometry(
      x: 46,
      y: 147,
      width: 50,
      height: 10,
    ),
    'doctorNames': TemplateGeometry(x: 19, y: 176, width: 394, height: 44),
    'worksIn': TemplateGeometry(x: 288, y: 219, width: 266, height: 47),
    'specialty': TemplateGeometry(x: 15, y: 212, width: 200, height: 60),
    'statement': TemplateGeometry(x: 19, y: 292, width: 305, height: 150),
    'amountNumber': TemplateGeometry(x: 442, y: 452, width: 80, height: 30),
    'amountWords': TemplateGeometry(x: 207, y: 445, width: 200, height: 70),
    'branch': TemplateGeometry(x: 20, y: 443, width: 166, height: 70),
    'requesterName': TemplateGeometry(x: 414, y: 553, width: 145, height: 22),
    'directManagerName': TemplateGeometry(
      x: 200,
      y: 553,
      width: 145,
      height: 22,
    ),
    'approvedAuthorityName': TemplateGeometry(
      x: 15,
      y: 553,
      width: 145,
      height: 22,
    ),
  };

  static Map<String, TemplateGeometry> _rows(
    Map<String, TemplateGeometry> base,
    String prefix,
    double x,
    double y,
    double width,
  ) {
    return {
      ...base,
      for (var i = 1; i <= 6; i++)
        '$prefix$i': TemplateGeometry(
          x: x,
          y: y + ((i - 1) * 48),
          width: width,
        ),
    };
  }

  static Map<String, TemplateGeometry> forScope(String scope) {
    if (scope == 'customerApplication') return customer;
    if (scope == 'internalMemo') return memo;
    if (scope == 'clearanceRequest') {
      return _rows(clearance, 'clearanceAmount', 470, 132, 90)
        ..addAll(_rows({}, 'clearanceDate', 285, 132, 95))
        ..addAll(_rows({}, 'clearanceStatement', 55, 132, 220));
    }
    if (scope == 'fuelRequest') return fuel;
    if (scope == 'sampleRequest') return sample;
    if (scope == 'sampleRequestSinglePage') return sampleSinglePage;
    if (scope == 'travelAllowance') return travelAllowance;
    if (scope == 'travelAllowance') return travelAllowance;
    if (scope == 'serviceRequest') {
      const itemRows = <int, double>{
        1: 296,
        2: 320,
        3: 345,
        4: 371,
        5: 398,
        6: 423,
      };
      return {
        ...service,
        for (final entry in itemRows.entries)
          'serviceItemName${entry.key}': TemplateGeometry(
            x: 364,
            y: entry.value,
            width: 200,
            height: 22,
          ),
      };
    }
    return expense;
  }

  static Map<String, FieldSetting> apply(
    String scope,
    Map<String, FieldSetting> fields,
  ) {
    final defaults = forScope(scope);
    return fields.map((key, field) {
      final geometry = defaults[key];
      if (geometry == null) return MapEntry(key, field);
      return MapEntry(
        key,
        field.copyWith(
          x: geometry.x,
          y: geometry.y,
          width: geometry.width,
          height: geometry.height,
          geometryConfigured: false,
        ),
      );
    });
  }
}
