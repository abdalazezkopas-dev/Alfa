import 'package:flutter/material.dart';

import '../../customer/screens/customer_application_screen.dart';
import '../../debts/screens/debt_settings_screen.dart';
import '../../expense_request/screens/expense_request_screen.dart';
import '../../fuel/screens/fuel_request_screen.dart';
import '../../sample_request/screens/sample_request_single_page_screen.dart';
import '../../sample_request/screens/sample_request_three_page_screen.dart';
import '../../travel_allowance/screens/travel_allowance_request_screen.dart';
import '../../expense_request/models/expense_request.dart';
import '../../memos/screens/internal_memo_screen.dart';
import '../models/app_settings.dart';
import '../models/template_configuration.dart';
import '../services/settings_store.dart';
import '../../product_catalog/screens/product_catalog_screen.dart';
import 'memo_preview_screen.dart';
import 'settings_screen.dart';
import 'template_preview_screen.dart';
import '../../representative_reports/screens/representative_reports_screen.dart';

extension TemplateKindIcon on TemplateKind {
  IconData get icon => switch (this) {
    TemplateKind.customerApplication => Icons.person_add_alt_1_outlined,
    TemplateKind.expenseRequest => Icons.request_quote_outlined,
    TemplateKind.clearanceRequest => Icons.assignment_return_outlined,
    TemplateKind.serviceRequest => Icons.miscellaneous_services_outlined,
    TemplateKind.fuelRequest => Icons.local_gas_station_outlined,
    TemplateKind.sampleRequest => Icons.inventory_2_outlined,
    TemplateKind.sampleRequestSinglePage => Icons.article_outlined,
    TemplateKind.travelAllowance => Icons.flight_takeoff_outlined,
    TemplateKind.internalMemo => Icons.article_outlined,
  };
}

class TemplateCatalogScreen extends StatelessWidget {
  const TemplateCatalogScreen({this.selectionMode = false, super.key});

  final bool selectionMode;

  Widget _newDocumentScreen(TemplateKind kind) {
    return switch (kind) {
      TemplateKind.customerApplication => const CustomerApplicationScreen(),
      TemplateKind.expenseRequest => const ExpenseRequestScreen(),
      TemplateKind.clearanceRequest => const ExpenseRequestScreen(
        documentType: ExpenseDocumentType.clearanceRequest,
      ),
      TemplateKind.serviceRequest => const ExpenseRequestScreen(
        documentType: ExpenseDocumentType.serviceRequest,
      ),
      TemplateKind.fuelRequest => const FuelRequestScreen(),
      TemplateKind.sampleRequest => const SampleRequestThreePageScreen(),
      TemplateKind.sampleRequestSinglePage =>
        const SampleRequestSinglePageScreen(),
      TemplateKind.travelAllowance => const TravelAllowanceRequestScreen(),
      TemplateKind.internalMemo => const InternalMemoScreen(
        initialLayout: InternalMemoLayout.fullA4,
      ),
    };
  }

  @override
  Widget build(BuildContext context) {
    final templates = TemplateKind.values
        .where(
          (kind) =>
              selectionMode || kind != TemplateKind.sampleRequestSinglePage,
        )
        .toList();
    return Scaffold(
      appBar: AppBar(
        title: Text(selectionMode ? 'اختار نموذجك وقدم' : 'القوالب والنماذج'),
        actions: [
          IconButton(
            tooltip: 'دليل الأصناف',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => const ProductCatalogScreen(),
              ),
            ),
            icon: const Icon(Icons.inventory_2_outlined),
          ),
        ],
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: templates.length + 1,
        separatorBuilder: (_, _) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          if (index == templates.length) {
            return Card(
              clipBehavior: Clip.antiAlias,
              child: InkWell(
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const RepresentativeReportsScreen(),
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(18),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 27,
                        backgroundColor: Theme.of(
                          context,
                        ).colorScheme.primaryContainer,
                        foregroundColor: Theme.of(
                          context,
                        ).colorScheme.onPrimaryContainer,
                        child: const Icon(Icons.assignment_outlined, size: 28),
                      ),
                      const SizedBox(width: 16),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            Text(
                              'تقارير المندوبين',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              'إنشاء تقارير الزيارات اليومية وحفظها وطباعتها.',
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.chevron_left_rounded, size: 30),
                    ],
                  ),
                ),
              ),
            );
          }
          final kind = templates[index];
          return _TemplateCard(
            kind: kind,
            title: selectionMode && kind == TemplateKind.sampleRequest
                ? 'طلب عينات — ثلاث صفحات'
                : selectionMode && kind == TemplateKind.sampleRequestSinglePage
                ? 'طلب عينات — صفحة واحدة'
                : null,
            description: selectionMode && kind == TemplateKind.sampleRequest
                ? 'قالب PDF السابق بثلاث صفحات ويدعم حتى 53 صنفًا.'
                : selectionMode && kind == TemplateKind.sampleRequestSinglePage
                ? 'قالب PDF بصفحة واحدة ويدعم حتى 25 صنفًا.'
                : null,
            onTap: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => selectionMode
                    ? _newDocumentScreen(kind)
                    : TemplateWorkspaceScreen(kind: kind),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _TemplateCard extends StatelessWidget {
  const _TemplateCard({
    required this.kind,
    required this.onTap,
    this.title,
    this.description,
  });

  final TemplateKind kind;
  final VoidCallback onTap;
  final String? title;
  final String? description;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              CircleAvatar(
                radius: 27,
                backgroundColor: scheme.primaryContainer,
                foregroundColor: scheme.onPrimaryContainer,
                child: Icon(kind.icon, size: 28),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      title ?? kind.title,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(description ?? kind.description),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left_rounded, size: 30),
            ],
          ),
        ),
      ),
    );
  }
}

class TemplateWorkspaceScreen extends StatelessWidget {
  const TemplateWorkspaceScreen({required this.kind, super.key});

  final TemplateKind kind;

  void _open(BuildContext context, Widget page) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
  }

  String get _settingsScope => switch (kind) {
    TemplateKind.customerApplication => 'customerApplication',
    TemplateKind.expenseRequest => 'expenseRequest',
    TemplateKind.clearanceRequest => 'clearanceRequest',
    TemplateKind.serviceRequest => 'serviceRequest',
    TemplateKind.fuelRequest => 'fuelRequest',
    TemplateKind.sampleRequest => 'sampleRequest',
    TemplateKind.sampleRequestSinglePage => 'sampleRequestSinglePage',
    TemplateKind.travelAllowance => 'travelAllowance',
    TemplateKind.internalMemo => 'internalMemo',
  };

  Future<void> _openEditor(BuildContext context) async {
    if (kind == TemplateKind.travelAllowance) {
      final settings = await SettingsStore.load(scope: _settingsScope);
      if (!context.mounted) return;
      final updated = await Navigator.of(context).push<AppSettings>(
        MaterialPageRoute<AppSettings>(
          builder: (_) => TemplatePreviewScreen(
            settings: settings,
            templateScope: _settingsScope,
            fullPageForm: true,
            backgroundAsset: 'assets/templates/travel_allowance_request.png',
            documentTitle: kind.title,
          ),
        ),
      );
      if (updated != null) {
        await SettingsStore.save(updated, scope: _settingsScope);
      }
      return;
    }
    if (kind == TemplateKind.sampleRequest ||
        kind == TemplateKind.sampleRequestSinglePage) {
      final settings = await SettingsStore.load(scope: _settingsScope);
      if (!context.mounted) return;
      final updated = await Navigator.of(context).push<AppSettings>(
        MaterialPageRoute<AppSettings>(
          builder: (_) => TemplatePreviewScreen(
            settings: settings,
            templateScope: _settingsScope,
            sampleRequest: true,
            documentTitle: kind.title,
          ),
        ),
      );
      if (updated != null) {
        await SettingsStore.save(updated, scope: _settingsScope);
      }
      return;
    }
    final settings = await SettingsStore.load(scope: _settingsScope);
    if (!context.mounted) return;
    final updated = await Navigator.of(context).push<AppSettings>(
      MaterialPageRoute<AppSettings>(
        builder: (_) => TemplatePreviewScreen(
          settings: settings,
          templateScope: _settingsScope,
          editMemoA4: kind == TemplateKind.internalMemo,
          editCustomer: kind == TemplateKind.customerApplication,
          fullPageForm:
              kind == TemplateKind.clearanceRequest ||
              kind == TemplateKind.serviceRequest ||
              kind == TemplateKind.fuelRequest,
          masterExpenseForm: kind == TemplateKind.expenseRequest,
          backgroundAsset: switch (kind) {
            TemplateKind.clearanceRequest =>
              'assets/images/forms/clearance_request-1.png',
            TemplateKind.serviceRequest =>
              'assets/images/forms/service_request-1.png',
            TemplateKind.fuelRequest =>
              'assets/images/forms/fuel_request-1.png',
            _ => null,
          },
          documentTitle: kind.title,
        ),
      ),
    );
    if (updated != null) {
      await SettingsStore.save(updated, scope: _settingsScope);
    }
  }

  Future<void> _openPreview(BuildContext context) async {
    if (kind == TemplateKind.travelAllowance) {
      _open(context, const TravelAllowanceRequestScreen());
      return;
    }
    if (kind == TemplateKind.sampleRequest ||
        kind == TemplateKind.sampleRequestSinglePage) {
      _open(
        context,
        kind == TemplateKind.sampleRequestSinglePage
            ? const SampleRequestSinglePageScreen()
            : const SampleRequestThreePageScreen(),
      );
      return;
    }
    final settings = await SettingsStore.load(scope: _settingsScope);
    if (!context.mounted) return;
    if (kind == TemplateKind.internalMemo) {
      _open(context, MemoPreviewScreen(settings: settings));
    } else {
      _open(
        context,
        TemplatePreviewScreen(
          settings: settings,
          templateScope: _settingsScope,
          editCustomer: kind == TemplateKind.customerApplication,
          fullPageForm:
              kind == TemplateKind.clearanceRequest ||
              kind == TemplateKind.serviceRequest ||
              kind == TemplateKind.fuelRequest,
          masterExpenseForm: kind == TemplateKind.expenseRequest,
          backgroundAsset: switch (kind) {
            TemplateKind.clearanceRequest =>
              'assets/images/forms/clearance_request-1.png',
            TemplateKind.serviceRequest =>
              'assets/images/forms/service_request-1.png',
            TemplateKind.fuelRequest =>
              'assets/images/forms/fuel_request-1.png',
            _ => null,
          },
          documentTitle: kind.title,
        ),
      );
    }
  }

  void _openPrinting(BuildContext context) {
    switch (kind) {
      case TemplateKind.customerApplication:
        _open(context, const CustomerApplicationScreen());
      case TemplateKind.expenseRequest:
        _open(context, const ExpenseRequestScreen());
      case TemplateKind.clearanceRequest:
        _open(
          context,
          const ExpenseRequestScreen(
            documentType: ExpenseDocumentType.clearanceRequest,
          ),
        );
      case TemplateKind.serviceRequest:
        _open(
          context,
          const ExpenseRequestScreen(
            documentType: ExpenseDocumentType.serviceRequest,
          ),
        );
      case TemplateKind.fuelRequest:
        _open(context, const FuelRequestScreen());
      case TemplateKind.sampleRequest:
        _open(context, const SampleRequestThreePageScreen());
      case TemplateKind.sampleRequestSinglePage:
        _open(context, const SampleRequestSinglePageScreen());
      case TemplateKind.travelAllowance:
        _open(context, const TravelAllowanceRequestScreen());
      case TemplateKind.internalMemo:
        _open(
          context,
          const InternalMemoScreen(initialLayout: InternalMemoLayout.fullA4),
        );
    }
  }

  String get _settingsDescription => switch (kind) {
    TemplateKind.customerApplication =>
      'حقول نموذج العملاء وظهورها وتنسيقها فقط.',
    TemplateKind.expenseRequest => 'حقول طلب الصرف والمواضع والإدخال فقط.',
    TemplateKind.clearanceRequest => 'حقول طلب إخلاء العهدة والاعتمادات.',
    TemplateKind.serviceRequest => 'حقول طلب الخدمة والأصناف والاعتمادات.',
    TemplateKind.fuelRequest =>
      'بيانات المحروقات وصفوف التعبئة والحسابات والاعتمادات.',
    TemplateKind.sampleRequest =>
      'اختيار أصناف العينات والكميات والبيانات العامة والطباعة.',
    TemplateKind.sampleRequestSinglePage =>
      'إعدادات مستقلة للنموذج الجديد ذي الصفحة الواحدة و25 صنفًا.',
    TemplateKind.travelAllowance =>
      'إدخال عشرة صفوف بدل سفر مع الإجماليات والاعتمادات والطباعة.',
    TemplateKind.internalMemo =>
      'حقول المذكرة الداخلية A4 وظهورها وتنسيقها فقط.',
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('إعدادات ${kind.title}'),
        actions: [
          IconButton(
            tooltip: 'رجوع للقوالب والنماذج',
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.dashboard_customize_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            color: Theme.of(context).colorScheme.primaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Row(
                children: [
                  Icon(kind.icon, size: 32),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      kind.title,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          _WorkspaceAction(
            icon: Icons.view_list_outlined,
            title: 'إدارة الحقول وإعدادات النموذج',
            subtitle: _settingsDescription,
            onTap: () => _open(context, SettingsScreen(templateKind: kind)),
          ),
          if (kind == TemplateKind.sampleRequest)
            _WorkspaceAction(
              icon: Icons.article_outlined,
              title: 'إعدادات نموذج طلب العينات — الصفحة الواحدة',
              subtitle: 'مواضع وحقول النموذج الجديد ذي 25 صنفًا.',
              onTap: () => _open(
                context,
                const SettingsScreen(
                  templateKind: TemplateKind.sampleRequestSinglePage,
                ),
              ),
            ),
          _WorkspaceAction(
            icon: Icons.open_with_outlined,
            title: 'ترتيب ومواضع الحقول — المحرر الفعلي',
            subtitle: 'سحب وتحريك وتعديل X وY والعرض والارتفاع على الصفحة.',
            onTap: () => _openEditor(context),
          ),
          _WorkspaceAction(
            icon: Icons.preview_outlined,
            title: 'المعاينة المباشرة',
            subtitle: 'معاينة مرتبطة بنفس إعدادات النموذج المحدد.',
            onTap: () => _openPreview(context),
          ),
          _WorkspaceAction(
            icon: Icons.print_outlined,
            title: 'الطباعة وA4',
            subtitle: 'فتح شاشة النموذج الخاصة بالطباعة والمشاركة.',
            onTap: () => _openPrinting(context),
          ),
          const SizedBox(height: 20),
          OutlinedButton.icon(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.arrow_back_rounded),
            label: const Text('رجوع للقوالب والنماذج'),
          ),
        ],
      ),
    );
  }
}

class _WorkspaceAction extends StatelessWidget {
  const _WorkspaceAction({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 6),
        leading: Icon(icon),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_left_rounded),
        onTap: onTap,
      ),
    );
  }
}

class GeneralSettingsScreen extends StatelessWidget {
  const GeneralSettingsScreen({super.key});

  void _open(BuildContext context, Widget page) {
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const _SettingsHubHeader(),
          const SizedBox(height: 12),
          _HubAction(
            icon: Icons.settings_suggest_outlined,
            title: 'الإعدادات العامة',
            subtitle: 'إعدادات النظام والنسخ والاستعادة والأنماط العامة.',
            onTap: () => _open(context, const SettingsScreen()),
          ),
          _HubAction(
            icon: Icons.dashboard_customize_outlined,
            title: 'إعدادات النماذج والمذكرة',
            subtitle:
                'طلب الصرف ونموذج العملاء والمذكرة، لكل نموذج إعداداته المستقلة.',
            onTap: () => _open(context, const TemplateCatalogScreen()),
          ),
          _HubAction(
            icon: Icons.account_balance_wallet_outlined,
            title: 'إعدادات الحسابات والديون',
            subtitle: 'العملة وعنوان تقارير الحسابات والمنازل العشرية.',
            onTap: () => _open(context, const DebtSettingsScreen()),
          ),
        ],
      ),
    );
  }
}

class _SettingsHubHeader extends StatelessWidget {
  const _SettingsHubHeader();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      color: scheme.primaryContainer,
      child: const Padding(
        padding: EdgeInsets.all(18),
        child: Row(
          children: [
            Icon(Icons.tune_rounded, size: 34),
            SizedBox(width: 12),
            Expanded(
              child: Text(
                'مركز الإعدادات\nاختر القسم المطلوب دون خلط إعدادات النماذج بالإعدادات العامة.',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HubAction extends StatelessWidget {
  const _HubAction({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
        leading: Icon(icon, size: 30),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_left_rounded),
        onTap: onTap,
      ),
    );
  }
}
