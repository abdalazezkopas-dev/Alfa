import 'dart:async';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../../core/memo_geometry.dart';
import '../models/app_settings.dart';
import '../models/template_geometry.dart';
import '../models/template_configuration.dart';

class TemplatePreviewScreen extends StatefulWidget {
  const TemplatePreviewScreen({
    required this.settings,
    this.editMemoA4 = false,
    this.editCustomer = false,
    this.backgroundAsset,
    this.fullPageForm = false,
    this.masterExpenseForm = false,
    this.sampleRequest = false,
    this.templateScope = 'expenseRequest',
    this.documentTitle,
    super.key,
  });

  final AppSettings settings;
  final bool editMemoA4;
  final bool editCustomer;
  final String? backgroundAsset;
  final bool fullPageForm;
  final bool masterExpenseForm;
  final bool sampleRequest;
  final String templateScope;
  final String? documentTitle;

  @override
  State<TemplatePreviewScreen> createState() => _TemplatePreviewScreenState();
}

class _TemplatePreviewScreenState extends State<TemplatePreviewScreen> {
  static const double _pdfWidth = MemoGeometry.a4Width;
  static const double _samplePageWidth = 612.0;
  static const double _samplePageHeight = 792.0;
  // Must match PdfService.expenseRequestTemplateOffset so the editable
  // bottom copy and the printed bottom copy use the same coordinate space.
  static const double _copyHeight = 410.292;
  static const double _landscapeA4Width = MemoGeometry.a4Height;
  static const double _landscapeA4Height = MemoGeometry.a4Width;

  late AppSettings _settings;
  String? _selectedField;
  bool _editingBottomCopy = false;
  int _samplePage = 0;
  final List<Map<String, FieldSetting>> _undoStack = [];
  final List<Map<String, FieldSetting>> _redoStack = [];

  bool get _singleSampleRequest =>
      widget.sampleRequest && widget.templateScope == 'sampleRequestSinglePage';

  @override
  void initState() {
    super.initState();
    _settings = widget.settings;
  }

  Map<String, FieldSetting> get _activeFields => widget.editMemoA4
      ? _settings.memoFullA4FieldSettings
      : widget.editCustomer
      ? _settings.customerFieldSettings
      : widget.masterExpenseForm || widget.fullPageForm || widget.sampleRequest
      ? _settings.fieldSettings
      : _settings.fieldsForCopy(bottom: _editingBottomCopy);

  TemplateConfiguration? get _configuredTemplate {
    if (widget.editCustomer) {
      return TemplateConfiguration.customerApplication(_settings);
    }
    if (widget.editMemoA4) {
      return TemplateConfiguration.internalMemoA4(_settings);
    }
    return null;
  }

  double get _pageHeight => widget.sampleRequest
      ? _samplePageHeight
      : _configuredTemplate?.paperHeight ??
            (widget.fullPageForm ? _landscapeA4Height : _copyHeight);
  double get _pageWidth => widget.sampleRequest
      ? _samplePageWidth
      : _configuredTemplate?.paperWidth ??
            (widget.fullPageForm ? _landscapeA4Width : _pdfWidth);

  bool _sampleFieldVisibleOnPage(String key) {
    if (!widget.sampleRequest) return true;
    if (_singleSampleRequest) {
      final match = RegExp(
        r'^sampleItem(?:Name|Form|Quantity|QuantityWords|Notes)(\d+)$',
      ).firstMatch(key);
      if (match != null) return int.parse(match.group(1)!) <= 25;
      return key != 'reasonPage3';
    }
    if (key == 'reason') return _samplePage == 0;
    if (key == 'reasonPage3') return _samplePage == 2;
    final match = RegExp(
      r'^sampleItem(?:Name|Form|Quantity|QuantityWords|Notes)(\d+)$',
    ).firstMatch(key);
    if (match != null) {
      final index = int.parse(match.group(1)!);
      final first = _samplePage == 0
          ? 1
          : _samplePage == 1
          ? 12
          : 34;
      final last = _samplePage == 0
          ? 11
          : _samplePage == 1
          ? 33
          : 53;
      return index >= first && index <= last;
    }
    return _samplePage == 0 ||
        (_samplePage == 2 && (key == 'requesterName' || key == 'statement'));
  }

  String get _sampleBackgroundAsset => _singleSampleRequest
      ? 'assets/templates/sample_request_single_page.png'
      : 'assets/templates/sample_request_page_${_samplePage + 1}.png';

  FieldSetting _field(String key) {
    return _activeFields[key] ??
        const FieldSetting(label: '', visible: true, required: false);
  }

  _PreviewPosition _position(String key) {
    final geometry = TemplateGeometry.forScope(widget.templateScope)[key];
    final base = geometry == null
        ? const _PreviewPosition(x: 40, y: 250, width: 250)
        : _PreviewPosition(
            x: geometry.x,
            y: geometry.y,
            width: geometry.width,
            height: geometry.height,
          );
    final field = _field(key);
    final width =
        (field.geometryConfigured && field.width > 1 ? field.width : base.width)
            .clamp(40.0, _pageWidth)
            .toDouble();
    final height =
        (field.geometryConfigured && field.height > 1
                ? field.height
                : base.height)
            .clamp(12.0, _pageHeight)
            .toDouble();
    return _PreviewPosition(
      x: (field.geometryConfigured ? field.x : base.x).clamp(
        0.0,
        _pageWidth - width,
      ),
      y: (field.geometryConfigured ? field.y : base.y).clamp(
        0.0,
        _pageHeight - height,
      ),
      width: width,
      height: height,
    );
  }

  AppSettings _settingsWithFields(Map<String, FieldSetting> fields) {
    if (widget.editMemoA4) {
      return _settings.copyWith(memoFullA4FieldSettings: fields);
    }
    if (widget.editCustomer) {
      return _settings.copyWith(customerFieldSettings: fields);
    }
    if (widget.masterExpenseForm ||
        widget.fullPageForm ||
        widget.sampleRequest) {
      return _settings.copyWith(fieldSettings: fields);
    }
    return _editingBottomCopy
        ? _settings.copyWith(bottomFieldSettings: fields)
        : _settings.copyWith(fieldSettings: fields);
  }

  void _moveField(String key, Offset delta, Size previewSize) {
    _recordHistory();
    final scaleX = previewSize.width / _pageWidth;
    final scaleY = previewSize.height / _pageHeight;
    final current = _position(key);
    final field = _field(key);
    final nextX = (current.x + delta.dx / scaleX).clamp(
      0.0,
      _pageWidth - current.width,
    );
    final nextY = (current.y + delta.dy / scaleY).clamp(
      0.0,
      _pageHeight - current.height,
    );
    final fields = Map<String, FieldSetting>.from(_activeFields);
    fields[key] = field.copyWith(
      x: nextX,
      y: nextY,
      width: current.width,
      height: current.height,
      geometryConfigured: true,
    );
    setState(() => _settings = _settingsWithFields(fields));
  }

  void _returnSettings() {
    Navigator.of(context).pop(_settings);
  }

  void _recordHistory() {
    _undoStack.add(Map<String, FieldSetting>.from(_activeFields));
    if (_undoStack.length > 80) _undoStack.removeAt(0);
    _redoStack.clear();
  }

  void _undo() {
    if (_undoStack.isEmpty) return;
    final current = Map<String, FieldSetting>.from(_activeFields);
    final previous = _undoStack.removeLast();
    _redoStack.add(current);
    setState(() => _settings = _settingsWithFields(previous));
  }

  void _redo() {
    if (_redoStack.isEmpty) return;
    final current = Map<String, FieldSetting>.from(_activeFields);
    final next = _redoStack.removeLast();
    _undoStack.add(current);
    setState(() => _settings = _settingsWithFields(next));
  }

  void _copyUpperPositionsToLower() {
    final fields = <String, FieldSetting>{
      for (final entry in _settings.fieldSettings.entries)
        entry.key: entry.value,
    };
    setState(() => _settings = _settings.copyWith(bottomFieldSettings: fields));
  }

  void _resetActivePositions() {
    final fields = Map<String, FieldSetting>.from(_activeFields);
    for (final entry in TemplateGeometry.forScope(
      widget.templateScope,
    ).entries) {
      final current = fields[entry.key];
      if (current == null) continue;
      fields[entry.key] = current.copyWith(
        x: entry.value.x,
        y: entry.value.y,
        width: entry.value.width,
        height: entry.value.height,
        geometryConfigured: false,
      );
    }
    setState(() => _settings = _settingsWithFields(fields));
  }

  void _updateSelectedPosition({
    double? x,
    double? y,
    double? width,
    double? height,
  }) {
    final key = _selectedField;
    if (key == null) return;
    _recordHistory();
    final current = _position(key);
    final field = _field(key);
    final nextWidth = (width ?? current.width).clamp(40.0, _pageWidth);
    final nextHeight = (height ?? current.height).clamp(12.0, _pageHeight);
    final nextX = (x ?? current.x).clamp(0.0, _pageWidth - nextWidth);
    final nextY = (y ?? current.y).clamp(0.0, _pageHeight - nextHeight);
    final fields = Map<String, FieldSetting>.from(_activeFields);
    fields[key] = field.copyWith(
      x: nextX,
      y: nextY,
      width: nextWidth,
      height: nextHeight,
      geometryConfigured: true,
    );
    setState(() => _settings = _settingsWithFields(fields));
  }

  @override
  Widget build(BuildContext context) {
    final visibleFields = _activeFields.entries
        .where(
          (entry) =>
              entry.value.visible && _sampleFieldVisibleOnPage(entry.key),
        )
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.editMemoA4
              ? 'محرر مذكرة A4'
              : widget.editCustomer
              ? 'محرر نموذج العملاء'
              : widget.documentTitle ?? 'معاينة النموذج الأصلي',
        ),
        actions: [
          IconButton(
            tooltip: 'تراجع',
            onPressed: _undoStack.isEmpty ? null : _undo,
            icon: const Icon(Icons.undo),
          ),
          IconButton(
            tooltip: 'تقدم',
            onPressed: _redoStack.isEmpty ? null : _redo,
            icon: const Icon(Icons.redo),
          ),
          IconButton(
            tooltip: 'اعتماد المواضع',
            onPressed: _returnSettings,
            icon: const Icon(Icons.check_rounded),
          ),
        ],
      ),
      body: Column(
        children: [
          Material(
            color: Theme.of(context).colorScheme.primaryContainer,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
              child: Row(
                children: [
                  if (!_editingBottomCopy ||
                      widget.editMemoA4 ||
                      widget.editCustomer ||
                      widget.fullPageForm ||
                      widget.masterExpenseForm)
                    const Spacer(),
                  if (_editingBottomCopy &&
                      !widget.editMemoA4 &&
                      !widget.editCustomer &&
                      !widget.fullPageForm &&
                      !widget.masterExpenseForm)
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _copyUpperPositionsToLower,
                        icon: const Icon(Icons.content_copy_outlined),
                        label: const Text('مطابقة العلوي'),
                      ),
                    ),
                  if (_editingBottomCopy &&
                      !widget.editMemoA4 &&
                      !widget.editCustomer &&
                      !widget.fullPageForm &&
                      !widget.masterExpenseForm)
                    const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _resetActivePositions,
                      icon: const Icon(Icons.restore),
                      label: const Text('إعادة الضبط'),
                    ),
                  ),
                  if (!_editingBottomCopy ||
                      widget.editMemoA4 ||
                      widget.editCustomer ||
                      widget.fullPageForm ||
                      widget.masterExpenseForm)
                    const Spacer(),
                ],
              ),
            ),
          ),
          if (widget.sampleRequest && !_singleSampleRequest)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 2),
              child: SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 0, label: Text('الصفحة 1')),
                  ButtonSegment(value: 1, label: Text('الصفحة 2')),
                  ButtonSegment(value: 2, label: Text('الصفحة 3')),
                ],
                selected: {_samplePage},
                onSelectionChanged: (selection) => setState(() {
                  _samplePage = selection.first;
                  _selectedField = null;
                }),
              ),
            ),
          if (!widget.sampleRequest &&
              !widget.editMemoA4 &&
              !widget.editCustomer &&
              !widget.fullPageForm &&
              !widget.masterExpenseForm)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 2),
              child: SegmentedButton<bool>(
                segments: const [
                  ButtonSegment<bool>(
                    value: false,
                    label: Text('النموذج العلوي'),
                    icon: Icon(Icons.vertical_align_top),
                  ),
                  ButtonSegment<bool>(
                    value: true,
                    label: Text('النموذج السفلي'),
                    icon: Icon(Icons.vertical_align_bottom),
                  ),
                ],
                selected: {_editingBottomCopy},
                onSelectionChanged: (selection) {
                  setState(() {
                    _editingBottomCopy = selection.first;
                    _selectedField = null;
                  });
                },
              ),
            ),
          Expanded(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final sidePanel = _selectedField == null
                    ? const SizedBox.shrink()
                    : _PositionEditor(
                        key: ValueKey(
                          '${_editingBottomCopy ? 'bottom' : 'top'}_$_selectedField',
                        ),
                        position: _position(_selectedField!),
                        maxPageWidth: _pageWidth,
                        maxPageHeight: _pageHeight,
                        onChanged:
                            ({
                              double? x,
                              double? y,
                              double? width,
                              double? height,
                            }) {
                              _updateSelectedPosition(
                                x: x,
                                y: y,
                                width: width,
                                height: height,
                              );
                            },
                      );
                final preview = LayoutBuilder(
                  builder: (context, previewConstraints) {
                    final availableWidth = previewConstraints.maxWidth - 24;
                    final width = availableWidth
                        .clamp(220.0, double.infinity)
                        .toDouble();
                    final height = width * _pageHeight / _pageWidth;
                    final previewSize = Size(width, height);
                    return SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Center(
                        child: SizedBox(
                          width: width,
                          height: height,
                          child: Stack(
                            fit: StackFit.expand,
                            children: [
                              Image.asset(
                                widget.sampleRequest
                                    ? _sampleBackgroundAsset
                                    : widget.backgroundAsset ??
                                          (widget.editMemoA4
                                              ? 'assets/images/memo/internal_memo_full.png'
                                              : widget.editCustomer
                                              ? 'assets/images/customer_application_sales_modified.png'
                                              : (_editingBottomCopy
                                                    ? 'assets/images/form_template_bottom.png'
                                                    : 'assets/images/form_template_top.png')),
                                fit: BoxFit.fill,
                              ),
                              for (final entry in visibleFields)
                                _draggableField(
                                  entry.key,
                                  entry.value,
                                  previewSize,
                                ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                );
                if (_selectedField == null || constraints.maxWidth < 620) {
                  return Column(
                    children: [
                      Expanded(child: preview),
                      sidePanel,
                    ],
                  );
                }
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Expanded(child: preview),
                    SizedBox(
                      width: 220,
                      child: SingleChildScrollView(child: sidePanel),
                    ),
                  ],
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _draggableField(String key, FieldSetting field, Size previewSize) {
    final position = _position(key);
    final scaleX = previewSize.width / _pageWidth;
    final scaleY = previewSize.height / _pageHeight;
    final height = position.height * scaleY;
    final isSelected = _selectedField == key;
    return Positioned(
      left: position.x * scaleX,
      top: position.y * scaleY,
      width: position.width * scaleX,
      height: height,
      child: GestureDetector(
        onTap: () => setState(() => _selectedField = key),
        onPanStart: (_) => setState(() => _selectedField = key),
        onPanUpdate: (details) => _moveField(key, details.delta, previewSize),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            if (isSelected)
              Positioned(
                left: 0,
                right: 0,
                top: -24,
                child: Text(
                  field.label.isEmpty ? key : field.label,
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.secondary,
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    backgroundColor: Theme.of(context).colorScheme.surface,
                  ),
                ),
              ),
            Positioned.fill(
              child: CustomPaint(
                painter: _FieldOutlinePainter(
                  color: isSelected
                      ? Theme.of(context).colorScheme.secondary
                      : field.color,
                  fillColor: field.color.withValues(alpha: 0.16),
                  selected: isSelected,
                  stepped:
                      key == 'statement' ||
                      key == 'statementOne' ||
                      key == 'statementTwo',
                ),
              ),
            ),
            Positioned.fill(
              child: Center(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 3),
                    child: Text(
                      field.label,
                      maxLines: 1,
                      style: TextStyle(
                        color: field.color,
                        fontSize: 10,
                        fontWeight: field.fontWeight >= 700
                            ? FontWeight.bold
                            : FontWeight.normal,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FieldOutlinePainter extends CustomPainter {
  const _FieldOutlinePainter({
    required this.color,
    required this.fillColor,
    required this.selected,
    required this.stepped,
  });

  final Color color;
  final Color fillColor;
  final bool selected;
  final bool stepped;

  @override
  void paint(ui.Canvas canvas, ui.Size size) {
    final borderWidth = selected ? 2.0 : 1.0;
    final border = ui.Paint()
      ..color = color
      ..style = ui.PaintingStyle.stroke
      ..strokeWidth = borderWidth;
    final fill = ui.Paint()
      ..color = fillColor
      ..style = ui.PaintingStyle.fill;
    final path = stepped ? _connectedStatementPath(size) : _roundedPath(size);
    if (stepped) {
      final fillPath = _roundedPath(size);
      canvas.drawPath(fillPath, fill);
    } else {
      canvas.drawPath(path, fill);
    }
    canvas.drawPath(path, border);
  }

  ui.Path _roundedPath(ui.Size size) {
    return ui.Path()..addRRect(
      ui.RRect.fromRectAndRadius(
        ui.Offset.zero & size,
        const ui.Radius.circular(3),
      ),
    );
  }

  ui.Path _connectedStatementPath(ui.Size size) {
    final width = size.width;
    final height = size.height;
    final radius = 6.0;
    final upperDrop = (height * 0.18).clamp(8.0, 18.0).toDouble();
    final turnY = upperDrop;
    final innerX = (width * 0.78).clamp(width * 0.62, width - 24).toDouble();
    final path = ui.Path()
      // يبدأ من النقطة الداخلية بجانب «مقابل».
      ..moveTo(innerX, 0)
      ..lineTo(innerX, turnY)
      // التفاف أفقي تحت «مقابل» حتى حافة الإطار العام.
      ..lineTo(width, turnY)
      // نزول طويل بمحاذاة حافة الإطار العام حتى نهاية البيان.
      ..lineTo(width, height - radius)
      ..quadraticBezierTo(width, height, width - radius, height)
      // التفاف سفلي وإغلاق بقية مساحة البيان.
      ..lineTo(radius, height)
      ..quadraticBezierTo(0, height, 0, height - radius)
      ..lineTo(0, radius)
      ..quadraticBezierTo(0, 0, radius, 0)
      ..lineTo(innerX, 0);
    return path;
  }

  @override
  bool shouldRepaint(covariant _FieldOutlinePainter oldDelegate) {
    return oldDelegate.color != color ||
        oldDelegate.fillColor != fillColor ||
        oldDelegate.selected != selected ||
        oldDelegate.stepped != stepped;
  }
}

class _PreviewPosition {
  const _PreviewPosition({
    required this.x,
    required this.y,
    required this.width,
    this.height = 22,
  });

  final double x;
  final double y;
  final double width;
  final double height;
}

class _PositionEditor extends StatelessWidget {
  const _PositionEditor({
    required this.position,
    required this.maxPageWidth,
    required this.maxPageHeight,
    required this.onChanged,
    super.key,
  });

  final _PreviewPosition position;
  final double maxPageWidth;
  final double maxPageHeight;
  final void Function({double? x, double? y, double? width, double? height})
  onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            children: [
              const Text(
                'تعديل الموضع والأبعاد بالأرقام أو بالأسهم',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                alignment: WrapAlignment.center,
                children: [
                  _PositionNumberField(
                    label: 'أفقي X',
                    value: position.x,
                    min: 0,
                    max: maxPageWidth - position.width,
                    onChanged: (value) => onChanged(x: value),
                  ),
                  _PositionNumberField(
                    label: 'رأسي Y',
                    value: position.y,
                    min: 0,
                    max: maxPageHeight - position.height,
                    onChanged: (value) => onChanged(y: value),
                  ),
                  _PositionNumberField(
                    label: 'العرض',
                    value: position.width,
                    min: 40,
                    max: maxPageWidth,
                    onChanged: (value) => onChanged(width: value),
                  ),
                  _PositionNumberField(
                    label: 'الارتفاع',
                    value: position.height,
                    min: 12,
                    max: maxPageHeight,
                    onChanged: (value) => onChanged(height: value),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PositionNumberField extends StatefulWidget {
  const _PositionNumberField({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.onChanged,
  });

  final String label;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;

  @override
  State<_PositionNumberField> createState() => _PositionNumberFieldState();
}

class _PositionNumberFieldState extends State<_PositionNumberField> {
  late final TextEditingController _controller;
  late final FocusNode _focusNode;
  Timer? _repeatTimer;
  Timer? _repeatStartTimer;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: _format(widget.value));
    _focusNode = FocusNode()..addListener(_handleFocusChange);
  }

  void _handleFocusChange() {
    if (!_focusNode.hasFocus) _commitText();
  }

  @override
  void didUpdateWidget(covariant _PositionNumberField oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value &&
        oldWidget.value.round() != widget.value.round()) {
      _controller.value = TextEditingValue(
        text: _format(widget.value),
        selection: TextSelection.collapsed(
          offset: _format(widget.value).length,
        ),
      );
    }
  }

  String _format(double value) => value.round().toString();

  void _setValue(double value) {
    final next = value.clamp(widget.min, widget.max).toDouble();
    _controller.text = _format(next);
    _controller.selection = TextSelection.collapsed(
      offset: _controller.text.length,
    );
    widget.onChanged(next);
  }

  void _commitText() {
    final normalized = _controller.text
        .trim()
        .replaceAll('،', '.')
        .replaceAll('٫', '.');
    final parsed = double.tryParse(normalized);
    if (parsed != null) {
      _setValue(parsed);
    } else {
      _setValue(widget.value);
    }
  }

  void _startRepeating(double delta) {
    _stopRepeating();
    _setValue(_currentValue() + delta);
    _repeatStartTimer = Timer(const Duration(milliseconds: 380), () {
      _repeatTimer = Timer.periodic(const Duration(milliseconds: 90), (_) {
        _setValue(_currentValue() + delta);
      });
    });
  }

  double _currentValue() => double.tryParse(_controller.text) ?? widget.value;

  void _stopRepeating() {
    _repeatStartTimer?.cancel();
    _repeatTimer?.cancel();
    _repeatStartTimer = null;
    _repeatTimer = null;
  }

  Widget _arrowButton({required double delta, required IconData icon}) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () => _setValue(_currentValue() + delta),
      onLongPressStart: (_) => _startRepeating(delta),
      onLongPressEnd: (_) => _stopRepeating(),
      onLongPressCancel: _stopRepeating,
      onLongPressUp: _stopRepeating,
      child: SizedBox(width: 44, height: 48, child: Icon(icon, size: 28)),
    );
  }

  @override
  void dispose() {
    _stopRepeating();
    _focusNode
      ..removeListener(_handleFocusChange)
      ..dispose();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 184,
      child: Row(
        children: [
          _arrowButton(delta: -1, icon: Icons.keyboard_arrow_down),
          Expanded(
            child: TextField(
              controller: _controller,
              focusNode: _focusNode,
              keyboardType: const TextInputType.numberWithOptions(
                decimal: true,
              ),
              textAlign: TextAlign.center,
              textDirection: TextDirection.ltr,
              decoration: InputDecoration(labelText: widget.label),
              onSubmitted: (_) {
                _commitText();
                _focusNode.unfocus();
              },
              onEditingComplete: () {
                _commitText();
                _focusNode.unfocus();
              },
            ),
          ),
          _arrowButton(delta: 1, icon: Icons.keyboard_arrow_up),
        ],
      ),
    );
  }
}

extension on FieldSetting {
  Color get color => Color(colorValue);
}
