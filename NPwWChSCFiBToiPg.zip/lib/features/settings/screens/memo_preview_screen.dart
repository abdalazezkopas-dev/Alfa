import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

import '../../expense_request/models/expense_request.dart';
import '../../expense_request/services/pdf_service.dart';
import '../models/app_settings.dart';
import '../models/template_configuration.dart';

class MemoPreviewScreen extends StatelessWidget {
  const MemoPreviewScreen({
    super.key,
    required this.settings,
    this.layout = InternalMemoLayout.fullA4,
  });

  final AppSettings settings;
  final InternalMemoLayout layout;

  ExpenseRequest _sampleMemo() {
    return ExpenseRequest(
      date: '05/09/2026',
      receiver: 'المقدم إليه — معاينة',
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: 'ملاحظة: هذه معاينة حية لقالب مذكرة داخلية. صرف واعتماد عاجل.',
      branch: '',
      account: '',
      requesterName: 'مقدم الطلب — معاينة',
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      documentType: ExpenseDocumentType.internalMemo,
      memoLayout: layout,
      formCount: 1,
    );
  }

  @override
  Widget build(BuildContext context) {
    final request = _sampleMemo();
    return Scaffold(
      appBar: AppBar(title: const Text('معاينة المذكرة الداخلية')),
      body: PdfPreview(
        canChangePageFormat: false,
        canChangeOrientation: false,
        build: (format) =>
            PdfService.buildRequestPdf(request, settings: settings),
      ),
    );
  }
}
