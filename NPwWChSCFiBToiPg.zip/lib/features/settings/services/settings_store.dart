import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/security/secure_local_store.dart';
import '../../../core/services/app_logger.dart';
import '../../../core/store_mutex.dart';
import '../models/app_settings.dart';
import '../models/template_geometry.dart';

class SettingsStore {
  const SettingsStore._();

  static const _settingsKey = 'alfa_expense_app.settings';
  static const _scopePrefix = 'alfa_expense_app.settings.';

  static String _key(String scope) =>
      scope == 'global' ? _settingsKey : '$_scopePrefix$scope';
  static final ValueNotifier<AppSettings> notifier = ValueNotifier<AppSettings>(
    AppSettings.defaults(),
  );
  static final Map<String, ValueNotifier<AppSettings>> _notifiersByScope = {
    'global': notifier,
    for (final scope in [
      'expenseRequest',
      'clearanceRequest',
      'serviceRequest',
      'fuelRequest',
      'customerApplication',
      'sampleRequest',
      'sampleRequestSinglePage',
      'travelAllowance',
      'internalMemo',
    ])
      scope: ValueNotifier<AppSettings>(AppSettings.defaultsForScope(scope)),
  };

  static ValueNotifier<AppSettings> notifierFor(String scope) =>
      _notifiersByScope[scope] ?? notifier;

  static void _notifyScope(String scope, AppSettings settings) {
    _notifiersByScope[scope]?.value = settings;
  }

  static List<String> _mergeOptions(List<String> global, List<String> scoped) {
    final result = <String>[];
    for (final value in [...global, ...scoped]) {
      final clean = value.trim();
      if (clean.isNotEmpty && !result.contains(clean)) result.add(clean);
    }
    return result;
  }

  static AppSettings _mergeGlobalSharedOptions(
    AppSettings scoped,
    AppSettings global,
  ) {
    final roles = <String>{
      ...global.stakeholderOptions.keys,
      ...scoped.stakeholderOptions.keys,
    };
    final stakeholders = <String, List<String>>{
      for (final role in roles)
        role: _mergeOptions(
          global.stakeholderOptions[role] ?? const [],
          scoped.stakeholderOptions[role] ?? const [],
        ),
    };
    return scoped.copyWith(
      branchOptions: _mergeOptions(global.branchOptions, scoped.branchOptions),
      receiverOptions: _mergeOptions(
        global.receiverOptions,
        scoped.receiverOptions,
      ),
      requesterHistory: _mergeOptions(
        global.requesterHistory,
        scoped.requesterHistory,
      ),
      stakeholderOptions: stakeholders,
    );
  }

  static AppSettings _inheritGlobalSharedSettings(
    AppSettings scopedDefaults,
    AppSettings global,
  ) => scopedDefaults.copyWith(
    companyName: global.companyName,
    formTitle: global.formTitle,
    documentNumber: global.documentNumber,
    issueDate: global.issueDate,
    issueVersion: global.issueVersion,
    currencyName: global.currencyName,
    fractionName: global.fractionName,
    autoSpelling: global.autoSpelling,
    showAccountField: global.showAccountField,
    requireAccountField: global.requireAccountField,
    showSignatures: global.showSignatures,
    requireApprovals: global.requireApprovals,
    fontSize: global.fontSize,
    primaryColorValue: global.primaryColorValue,
    textColorValue: global.textColorValue,
    printedTextColorValue: global.printedTextColorValue,
    backgroundColorValue: global.backgroundColorValue,
    fieldBackgroundColorValue: global.fieldBackgroundColorValue,
    darkMode: global.darkMode,
    templateMode: global.templateMode,
    pageCopies: global.pageCopies,
    receiverOptions: global.receiverOptions,
    requesterHistory: global.requesterHistory,
    branchOptions: global.branchOptions,
    stakeholderOptions: global.stakeholderOptions,
    maxStructuredDataCharacters: global.maxStructuredDataCharacters,
  );

  static Future<AppSettings> load({
    String scope = 'global',
    bool inheritGlobalIfMissing = false,
  }) => StoreMutex.run('settings:$scope', () async {
    final preferences = await SharedPreferences.getInstance();
    String? raw;
    try {
      raw = await SecureLocalStore.read('settings.$scope');
      if (raw != null && raw.isNotEmpty) {
        await preferences.remove(_key(scope));
      }
    } catch (_) {
      raw = null;
    }
    var migratedToSecure = raw != null && raw.isNotEmpty;
    raw ??= preferences.getString(_key(scope));
    final scopedDefaults = AppSettings.defaultsForScope(scope);
    if ((raw == null || raw.isEmpty) && scope == 'expenseRequest') {
      raw = preferences.getString(_settingsKey);
    }
    if (raw == null || raw.isEmpty) {
      final settings = inheritGlobalIfMissing && scope != 'global'
          ? _inheritGlobalSharedSettings(scopedDefaults, await load())
          : scopedDefaults;
      _notifyScope(scope, settings);
      return settings;
    }

    try {
      final decoded = jsonDecode(raw);
      if (decoded is Map<String, dynamic>) {
        final fuelGeometryRevisionKey =
            'alfa_expense_app.fuel_geometry_revision';
        final sampleGeometryRevisionKey =
            'alfa_expense_app.sample_geometry_revision';
        final shouldResetFuelGeometry =
            scope == 'fuelRequest' &&
            (preferences.getInt(fuelGeometryRevisionKey) ?? 0) < 3;
        final shouldResetSampleGeometry =
            scope == 'sampleRequest' &&
            (preferences.getInt(sampleGeometryRevisionKey) ?? 0) < 4;
        var settings = _migrateScopedSchema(
          _migrateLegacyDefaults(AppSettings.fromMap(decoded)),
          scope,
          resetFuelGeometry: shouldResetFuelGeometry,
        );
        if (scope == 'clearanceRequest') {
          final fields = Map<String, FieldSetting>.from(settings.fieldSettings)
            ..remove('branch')
            ..remove('statement');
          settings = settings.copyWith(fieldSettings: fields);
        }
        if (scope != 'global') {
          settings = _mergeGlobalSharedOptions(settings, await load());
        }
        final requiresPersistence =
            shouldResetFuelGeometry ||
            shouldResetSampleGeometry ||
            !migratedToSecure;
        if (requiresPersistence) {
          try {
            await SecureLocalStore.write(
              'settings.$scope',
              jsonEncode(settings.toMap()),
            );
            await preferences.remove(_key(scope));
            migratedToSecure = true;
            if (shouldResetFuelGeometry) {
              await preferences.setInt(fuelGeometryRevisionKey, 3);
            }
            if (shouldResetSampleGeometry) {
              await preferences.setInt(sampleGeometryRevisionKey, 4);
            }
          } catch (error, stackTrace) {
            AppLogger.error(
              'Secure settings migration failed; keeping legacy fallback',
              error: error,
              stackTrace: stackTrace,
              scope: 'settings',
            );
            // Keep the legacy value as the active fallback until a later retry.
          }
        }
        _notifyScope(scope, settings);
        return settings;
      }
    } catch (error, stackTrace) {
      AppLogger.error(
        'Store operation failed; using the existing fallback',
        error: error,
        stackTrace: stackTrace,
        scope: 'settings',
      );
    }
    final settings = scopedDefaults;
    _notifyScope(scope, settings);
    return settings;
  });

  static AppSettings _migrateScopedSchema(
    AppSettings settings,
    String scope, {
    bool resetFuelGeometry = false,
  }) {
    if (settings.fractionName.trim() == 'هللة') {
      settings = settings.copyWith(fractionName: 'فلس');
    }
    if (scope == 'expenseRequest') {
      final fields = Map<String, FieldSetting>.from(settings.fieldSettings);
      const legacy = <String, List<double>>{
        'date': [58, 43, 90, 22],
        'receiver': [105, 68, 350, 22],
        'amountNumber': [305, 94, 95, 22],
        'amountWords': [90, 119, 350, 22],
        'statement': [82, 162, 390, 180],
        'branch': [85, 330, 150, 22],
        'requesterName': [412, 214, 120, 22],
        'directManagerName': [222, 214, 120, 22],
        'approvedAuthorityName': [32, 214, 120, 22],
        'accountsManagerName': [225, 356, 235, 22],
      };
      const current = <String, List<double>>{
        'date': [70, 56, 90, 22],
        'receiver': [105, 70, 350, 22],
        'amountNumber': [404, 100, 95, 22],
        'amountWords': [118, 113, 350, 22],
        'statement': [30, 133, 470, 80],
        'branch': [5, 282, 150, 22],
        'requesterName': [413, 225, 120, 22],
        'directManagerName': [222, 225, 120, 22],
        'approvedAuthorityName': [57, 225, 120, 22],
        'accountsManagerName': [30, 358, 200, 22],
      };
      for (final entry in legacy.entries) {
        final field = fields[entry.key];
        final old = entry.value;
        if (field == null ||
            field.x != old[0] ||
            field.y != old[1] ||
            field.width != old[2] ||
            field.height != old[3]) {
          continue;
        }
        final next = current[entry.key]!;
        fields[entry.key] = field.copyWith(
          x: next[0],
          y: next[1],
          width: next[2],
          height: next[3],
          geometryConfigured: false,
        );
        if (entry.key == 'branch') {
          fields[entry.key] = fields[entry.key]!.copyWith(visible: true);
        }
      }
      // Older saved settings may already have been marked as configured by
      // the editor, so the legacy-map migration above does not catch them.
      // Recognize those known defaults and activate the current geometry on
      // load, without overwriting genuinely customized coordinates.
      final amountNumber = fields['amountNumber'];
      if (amountNumber != null &&
          amountNumber.y == 100 &&
          amountNumber.width == 95 &&
          amountNumber.height == 22 &&
          (amountNumber.x == 305 ||
              amountNumber.x == 384 ||
              amountNumber.x == 402)) {
        fields['amountNumber'] = amountNumber.copyWith(
          x: 404,
          geometryConfigured: false,
        );
      }
      return settings.copyWith(fieldSettings: fields);
    }
    if (scope == 'serviceRequest') {
      final fields = Map<String, FieldSetting>.from(settings.fieldSettings);
      final defaults = AppSettings.defaultsForScope(scope).fieldSettings;
      final geometry = TemplateGeometry.forScope(scope);
      for (final entry in defaults.entries) {
        final current = fields[entry.key];
        if (current == null) {
          fields[entry.key] = entry.value;
          continue;
        }
        // Apply the new report geometry only to fields that were never moved
        // manually. Explicit editor changes remain untouched.
        var next = current;
        if (!current.geometryConfigured && geometry[entry.key] != null) {
          final target = geometry[entry.key]!;
          next = next.copyWith(
            x: target.x,
            y: target.y,
            width: target.width,
            height: target.height,
            geometryConfigured: false,
          );
        }
        // Migrate only the known pre-report defaults. Values changed manually
        // in the editor are preserved.
        final legacyMaxLength = <String, int>{
          'date': 250,
          'specialty': 150,
          'amountNumber': 80,
        };
        if (entry.key.startsWith('serviceItemName') &&
            current.maxLength == 200) {
          next = next.copyWith(maxLength: entry.value.maxLength);
        } else if (legacyMaxLength[entry.key] == current.maxLength) {
          next = next.copyWith(maxLength: entry.value.maxLength);
        }
        if (current.lineHeight == 0.8) {
          next = next.copyWith(lineHeight: entry.value.lineHeight);
        }
        if (entry.key == 'doctorNames' && current.lineHeight == 0.2) {
          next = next.copyWith(lineHeight: entry.value.lineHeight);
        }
        if (entry.key.startsWith('serviceItemName') &&
            current.alignment == 'right' &&
            !current.geometryConfigured) {
          next = next.copyWith(alignment: entry.value.alignment);
        }
        if ((entry.key == 'amountNumber' || entry.key == 'amountWords') &&
            current.alignment == 'right' &&
            !current.geometryConfigured) {
          next = next.copyWith(alignment: entry.value.alignment);
        }
        if (current.alignment == 'center' &&
            (entry.key == 'statement' ||
                entry.key == 'amountWords' ||
                entry.key == 'branch')) {
          next = next.copyWith(alignment: entry.value.alignment);
        }
        if (const {
          0xFF221BB7,
          0xFF221BB8,
          0xFF221BB9,
          0xFF1D2DC1,
        }.contains(current.colorValue)) {
          next = next.copyWith(colorValue: entry.value.colorValue);
        }
        fields[entry.key] = next;
      }
      return settings.copyWith(fieldSettings: fields);
    }
    if (scope == 'sampleRequest' || scope == 'sampleRequestSinglePage') {
      final defaults = AppSettings.defaultsForScope(scope).fieldSettings;
      final saved = settings.fieldSettings;
      final fields = <String, FieldSetting>{};
      for (final entry in defaults.entries) {
        final current = saved[entry.key];
        // A geometry revision may refresh defaults, but must never overwrite
        // coordinates explicitly configured by the user.
        final base = current == null || !current.geometryConfigured
            ? entry.value
            : current;
        fields[entry.key] = base.copyWith(colorValue: 0xFF0000FF);
      }
      for (final entry in saved.entries) {
        if (entry.key.startsWith('custom_')) fields[entry.key] = entry.value;
      }
      return settings.copyWith(fieldSettings: fields);
    }
    if (scope == 'customerApplication') {
      const removedCustomerFields = {
        'receiver',
        'amountNumber',
        'amountWords',
        'reason',
        'statement',
      };
      final customerFields = Map<String, FieldSetting>.from(
        settings.customerFieldSettings,
      )..removeWhere((key, _) => removedCustomerFields.contains(key));
      final statementOne = customerFields['statementOne'];
      if (statementOne != null &&
          ((statementOne.x == 29 &&
                  statementOne.y == 368 &&
                  statementOne.width == 540 &&
                  statementOne.height == 70) ||
              (statementOne.x == 29 &&
                  statementOne.y == 365 &&
                  statementOne.width == 540 &&
                  statementOne.height == 123) ||
              (statementOne.x == 29 &&
                  statementOne.y == 330 &&
                  statementOne.width == 540 &&
                  statementOne.height == 125) ||
              (statementOne.x == 39 &&
                  statementOne.y == 360 &&
                  statementOne.width == 540 &&
                  statementOne.height == 125) ||
              (statementOne.x == 25 &&
                  statementOne.y == 360 &&
                  statementOne.width == 577 &&
                  statementOne.height == 135) ||
              (statementOne.x == 17 &&
                  statementOne.y == 360 &&
                  statementOne.width == 577 &&
                  statementOne.height == 135))) {
        customerFields['statementOne'] = statementOne.copyWith(
          x: 17,
          y: 365,
          width: 577,
          height: 135,
          maxLength: 500,
          lineHeight: 1.5,
          fontSize: 11.5,
          fontWeight: 700,
        );
      }
      final statementTwo = customerFields['statementTwo'];
      if (statementTwo != null &&
          ((statementTwo.x == 35 &&
                  statementTwo.y == 520 &&
                  statementTwo.width == 540 &&
                  statementTwo.height == 65) ||
              (statementTwo.x == 35 &&
                  statementTwo.y == 512 &&
                  statementTwo.width == 540 &&
                  statementTwo.height == 90) ||
              (statementTwo.x == 35 &&
                  statementTwo.y == 508 &&
                  statementTwo.width == 45 &&
                  statementTwo.height == 125) ||
              (statementTwo.x == 24 &&
                  statementTwo.y == 504 &&
                  statementTwo.width == 564 &&
                  statementTwo.height == 94) ||
              (statementTwo.x == 25 &&
                  statementTwo.y == 504 &&
                  statementTwo.width == 577 &&
                  statementTwo.height == 100) ||
              (statementTwo.x == 17 &&
                  statementTwo.y == 504 &&
                  statementTwo.width == 577 &&
                  statementTwo.height == 100))) {
        customerFields['statementTwo'] = statementTwo.copyWith(
          x: 17,
          y: 510,
          width: 577,
          height: 100,
          maxLength: 350,
          lineHeight: 1.5,
          fontSize: 11.5,
          fontWeight: 700,
        );
      }
      for (final key in const [
        'bonusExtra',
        'customerCompensation',
        'settlementOffer',
        'cashDiscount',
        'otherType',
      ]) {
        final field = customerFields[key];
        if (field != null && !field.geometryConfigured && field.height == 30) {
          customerFields[key] = field.copyWith(height: 35);
        }
      }
      final stakeholders = <String, List<String>>{
        for (final entry in settings.stakeholderOptions.entries)
          if (entry.key != 'المقدم إليه') entry.key: [...entry.value],
      };
      final branchAccountants = stakeholders.putIfAbsent(
        'محاسب الفرع',
        () => <String>[],
      );
      if (branchAccountants.isEmpty) branchAccountants.add('عارف الهبل');
      final customerTypeNew = customerFields['customerTypeNew'];
      if (customerTypeNew != null &&
          customerTypeNew.x == 40 &&
          customerTypeNew.y == 278 &&
          customerTypeNew.width == 95 &&
          customerTypeNew.height == 24) {
        customerFields['customerTypeNew'] = customerTypeNew.copyWith(
          x: 140,
          y: 245,
          width: 40,
          height: 24,
        );
      }
      final customerTypePrevious = customerFields['customerTypePrevious'];
      if (customerTypePrevious != null &&
          customerTypePrevious.x == 135 &&
          customerTypePrevious.y == 278 &&
          customerTypePrevious.width == 95 &&
          customerTypePrevious.height == 24) {
        customerFields['customerTypePrevious'] = customerTypePrevious.copyWith(
          x: 100,
          y: 245,
          width: 40,
          height: 24,
        );
      }
      return settings.copyWith(
        customerFieldSettings: customerFields,
        stakeholderOptions: stakeholders,
        receiverOptions: const [],
      );
    }
    if (scope == 'fuelRequest') {
      final defaults = AppSettings.defaultsForScope(scope).fieldSettings;
      if (resetFuelGeometry) {
        return settings.copyWith(fieldSettings: {...defaults});
      }
      final effective = <String, FieldSetting>{...settings.fieldSettings};
      for (final entry in defaults.entries) {
        effective.putIfAbsent(entry.key, () => entry.value);
      }
      const deepBlue = 0xFF000066;
      for (final key in effective.keys.toList()) {
        final field = effective[key];
        if (field == null) continue;
        effective[key] = field.copyWith(
          colorValue: key == 'systemTimestamp' ? 0xFF000000 : deepBlue,
        );
      }
      final administrationAccountant = effective['administrationAccountant'];
      if (administrationAccountant != null) {
        effective['administrationAccountant'] = administrationAccountant
            .copyWith(x: 330, geometryConfigured: true);
      }
      return settings.copyWith(fieldSettings: effective);
    }
    if (scope != 'clearanceRequest' && scope != 'serviceRequest') {
      return settings;
    }
    final fields = settings.fieldSettings;
    final isLegacyExpenseShape =
        fields.containsKey('amountNumber') && fields.containsKey('amountWords');
    final defaults = AppSettings.defaultsForScope(scope).fieldSettings;
    final effectiveFields = <String, FieldSetting>{...fields};
    for (final entry in defaults.entries) {
      final saved = effectiveFields[entry.key];
      if (saved != null && saved.geometryConfigured != true) {
        effectiveFields[entry.key] = entry.value;
      }
    }
    final custom = <String, FieldSetting>{
      for (final entry in fields.entries)
        if (entry.key.startsWith('custom_')) entry.key: entry.value,
    };
    if (!isLegacyExpenseShape) {
      final structured = <String, FieldSetting>{
        for (final entry in defaults.entries)
          if (entry.key.startsWith('clearance') ||
              entry.key.startsWith('serviceItem') ||
              const {
                'doctorNames',
                'worksIn',
                'specialty',
                'amountNumber',
                'amountWords',
                'branch',
              }.contains(entry.key))
            entry.key: entry.value,
      };
      return settings.copyWith(
        fieldSettings: {...structured, ...effectiveFields},
      );
    }
    return settings.copyWith(fieldSettings: {...defaults, ...custom});
  }

  static AppSettings _migrateLegacyDefaults(AppSettings settings) {
    final defaults = AppSettings.defaults();
    var migrated = settings;
    final isLegacyDefaults =
        settings.companyName == 'Shiba-Pharma' ||
        settings.primaryColorValue == 0xFF4A90E2 ||
        settings.backgroundColorValue == 0xFFD4AF37;

    if (settings.companyName == 'Shiba-Pharma') {
      migrated = migrated.copyWith(companyName: defaults.companyName);
    }
    if (settings.formTitle == 'نموذج طلب صرف') {
      migrated = migrated.copyWith(formTitle: defaults.formTitle);
    }
    if (settings.primaryColorValue == 0xFF4A90E2) {
      migrated = migrated.copyWith(
        primaryColorValue: defaults.primaryColorValue,
      );
    }
    if (settings.textColorValue == 0xFF263238) {
      migrated = migrated.copyWith(textColorValue: defaults.textColorValue);
    }
    if (settings.backgroundColorValue == 0xFFD4AF37) {
      migrated = migrated.copyWith(
        backgroundColorValue: defaults.backgroundColorValue,
      );
    }

    final amountWords = settings.fieldSettings['amountWords'];
    final shouldMigrateAmountWords =
        amountWords != null && amountWords.height <= 1;
    if (isLegacyDefaults || shouldMigrateAmountWords) {
      final fields = Map<String, FieldSetting>.from(settings.fieldSettings);
      for (final key in ['reason', 'branch', 'account', 'signatures']) {
        final field = fields[key];
        if (field != null && field.visible) {
          fields[key] = field.copyWith(visible: false, required: false);
        }
      }
      if (shouldMigrateAmountWords) {
        final field = fields['amountWords'];
        if (field != null) fields['amountWords'] = field.copyWith(height: 24);
      }
      migrated = migrated.copyWith(
        showAccountField: isLegacyDefaults ? false : null,
        showSignatures: isLegacyDefaults ? false : null,
        fieldSettings: fields,
      );
    }
    return migrated;
  }

  static Future<void> save(AppSettings settings, {String scope = 'global'}) =>
      StoreMutex.run('settings:$scope', () async {
        final preferences = await SharedPreferences.getInstance();
        final encoded = jsonEncode(settings.toMap());
        await SecureLocalStore.write('settings.$scope', encoded);
        await preferences.remove(_key(scope));
        _notifyScope(scope, settings);
      });

  static Future<void> reset({String scope = 'global'}) =>
      StoreMutex.run('settings:$scope', () async {
        final preferences = await SharedPreferences.getInstance();
        await SecureLocalStore.remove('settings.$scope');
        await preferences.remove(_key(scope));
        _notifyScope(scope, AppSettings.defaultsForScope(scope));
      });
}
