import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/security/secure_local_store.dart';
import '../../../core/security/input_limits.dart';
import '../../../core/store_mutex.dart';
import '../models/app_settings.dart';
import '../../backup/services/encrypted_backup_codec.dart';

class SavedPattern {
  const SavedPattern({
    required this.name,
    required this.settings,
    this.scope = 'expenseRequest',
  });

  final String name;
  final AppSettings settings;
  final String scope;

  Map<String, Object?> toMap() => {
    'name': name,
    'scope': scope,
    'settings': settings.toMap(),
  };

  factory SavedPattern.fromMap(Map<String, Object?> map) {
    final rawSettings = map['settings'];
    return SavedPattern(
      name: map['name']?.toString() ?? 'نمط بدون اسم',
      scope: map['scope']?.toString().trim().isNotEmpty == true
          ? map['scope']!.toString()
          : 'expenseRequest',
      settings: rawSettings is Map
          ? AppSettings.fromMap(Map<String, Object?>.from(rawSettings))
          : AppSettings.defaults(),
    );
  }

  static SavedPattern fromMapStrict(Map<String, Object?> map) {
    final name = InputLimits.strictString(
      map['name'],
      field: 'name',
      maxLength: InputLimits.maxShortTextLength,
    );
    if (name.trim().isEmpty) throw const FormatException('اسم النمط فارغ');
    final scope = map['scope'] == null
        ? 'expenseRequest'
        : InputLimits.strictString(
            map['scope'],
            field: 'scope',
            maxLength: InputLimits.maxIdLength,
          );
    if (scope.trim().isEmpty) throw const FormatException('نطاق النمط فارغ');
    final settings = InputLimits.strictMap(map['settings'], field: 'settings');
    return SavedPattern(
      name: name,
      scope: scope,
      settings: AppSettings.fromMap(settings),
    );
  }
}

class PatternStore {
  PatternStore._();

  static const _key = 'saved_patterns_v1';
  // All scopes share one encrypted collection, so every operation must use
  // the same mutex key. A scope-specific lock can race with another scope
  // and cause one writer to overwrite the other writer's patterns.
  static const _mutexKey = 'patterns';
  static const masterName = 'النمط الرئيسي';

  static Future<List<SavedPattern>> load({String? scope}) => StoreMutex.run(
    _mutexKey,
    () async {
      final preferences = await SharedPreferences.getInstance();
      final secure = await SecureLocalStore.readJson('patterns');
      var patterns = secure == null
          ? <SavedPattern>[]
          : _decodeSecureList(secure);
      if (patterns.isEmpty) {
        final raw = preferences.getStringList(_key) ?? const <String>[];
        patterns = _decodeList(raw);
        if (patterns.isNotEmpty) {
          try {
            await SecureLocalStore.writeJson(
              'patterns',
              patterns.map((pattern) => pattern.toMap()).toList(),
            );
            await preferences.remove(_key);
          } catch (_) {}
        }
      }
      if (scope != null) {
        patterns = patterns.where((pattern) => pattern.scope == scope).toList();
      }
      return patterns;
    },
  );

  static Future<void> saveAll(
    List<SavedPattern> patterns, {
    String scope = 'expenseRequest',
  }) => StoreMutex.run(_mutexKey, () async {
    _validatePatterns(patterns);
    final preferences = await SharedPreferences.getInstance();
    await SecureLocalStore.writeJson(
      'patterns',
      patterns.map((pattern) => pattern.toMap()).toList(),
    );
    await preferences.remove(_key);
  });

  static Future<void> upsert(SavedPattern pattern) =>
      StoreMutex.run(_mutexKey, () async {
        final patterns = await _loadUnlocked();
        final index = patterns.indexWhere(
          (item) => item.name == pattern.name && item.scope == pattern.scope,
        );
        if (index >= 0) {
          patterns[index] = pattern;
        } else {
          patterns.add(pattern);
        }
        await _saveUnlocked(patterns);
      });

  static Future<void> delete(String name, {String? scope}) =>
      StoreMutex.run(_mutexKey, () async {
        final patterns = await _loadUnlocked();
        patterns.removeWhere(
          (pattern) =>
              pattern.name == name && (scope == null || pattern.scope == scope),
        );
        await _saveUnlocked(patterns);
      });

  static Future<List<SavedPattern>> _loadUnlocked() async {
    final preferences = await SharedPreferences.getInstance();
    final secure = await SecureLocalStore.readJson('patterns');
    if (secure != null) return _decodeSecureList(secure);
    final raw = preferences.getStringList(_key) ?? const <String>[];
    final patterns = _decodeList(raw);
    if (patterns.isNotEmpty) {
      try {
        await SecureLocalStore.writeJson(
          'patterns',
          patterns.map((pattern) => pattern.toMap()).toList(),
        );
        await preferences.remove(_key);
      } catch (_) {}
    }
    return patterns;
  }

  static List<SavedPattern> _decodeList(List<String> raw) {
    _validatePatternCount(raw.length);
    final patterns = <SavedPattern>[];
    for (final value in raw) {
      patterns.add(
        SavedPattern.fromMapStrict(
          InputLimits.strictMap(jsonDecode(value), field: 'patterns'),
        ),
      );
    }
    return patterns;
  }

  static List<SavedPattern> _decodeSecureList(Object value) {
    if (value is! List) {
      throw const FormatException('تخزين الأنماط المشفر غير صحيح');
    }
    _validatePatternCount(value.length);
    return value
        .map(
          (item) => SavedPattern.fromMapStrict(
            InputLimits.strictMap(item, field: 'patterns'),
          ),
        )
        .toList();
  }

  static void _validatePatternCount(int count) {
    if (count > 5000) {
      throw const FormatException('عدد الأنماط يتجاوز الحد المسموح');
    }
  }

  static void _validatePatterns(List<SavedPattern> patterns) {
    _validatePatternCount(patterns.length);
    for (final pattern in patterns) {
      SavedPattern.fromMapStrict(pattern.toMap());
    }
  }

  static Future<void> mergeAll(List<SavedPattern> imported) =>
      StoreMutex.run(_mutexKey, () async {
        _validatePatterns(imported);
        final patterns = await _loadUnlocked();
        for (final pattern in imported) {
          final index = patterns.indexWhere(
            (item) => item.name == pattern.name && item.scope == pattern.scope,
          );
          if (index >= 0) {
            patterns[index] = pattern;
          } else {
            patterns.add(pattern);
          }
        }
        await _saveUnlocked(patterns);
      });

  static Future<void> _saveUnlocked(List<SavedPattern> patterns) async {
    _validatePatterns(patterns);
    final preferences = await SharedPreferences.getInstance();
    await SecureLocalStore.writeJson(
      'patterns',
      patterns.map((pattern) => pattern.toMap()).toList(),
    );
    await preferences.remove(_key);
  }

  static String _masterKey(String scope) => '${_key}_master_$scope';

  static Future<void> saveMaster(
    AppSettings settings, {
    String scope = 'global',
  }) async {
    await StoreMutex.run(_mutexKey, () async {
      final preferences = await SharedPreferences.getInstance();
      final master = SavedPattern(
        name: masterName,
        scope: scope,
        settings: settings,
      );
      SavedPattern.fromMapStrict(master.toMap());
      final encoded = jsonEncode(master.toMap());
      await SecureLocalStore.write('patterns.master.$scope', encoded);
      await preferences.remove(_masterKey(scope));
    });
  }

  static Future<SavedPattern?> loadMaster({String scope = 'global'}) async {
    return StoreMutex.run(_mutexKey, () async {
      final preferences = await SharedPreferences.getInstance();
      var raw = await SecureLocalStore.read('patterns.master.$scope');
      raw ??= preferences.getString(_masterKey(scope));
      if (raw == null || raw.isEmpty) return null;
      try {
        final pattern = SavedPattern.fromMapStrict(
          InputLimits.strictMap(jsonDecode(raw), field: 'master pattern'),
        );
        if (preferences.getString(_masterKey(scope)) == raw) {
          await SecureLocalStore.write('patterns.master.$scope', raw);
          await preferences.remove(_masterKey(scope));
        }
        return pattern;
      } catch (error) {
        if (error is FormatException) rethrow;
        rethrow;
      }
    });
  }

  static Future<void> deleteMaster({String scope = 'global'}) =>
      StoreMutex.run(_mutexKey, () async {
        final preferences = await SharedPreferences.getInstance();
        await SecureLocalStore.remove('patterns.master.$scope');
        await preferences.remove(_masterKey(scope));
      });
}

class PatternExport {
  PatternExport._();

  static Map<String, Object?> toPortableMap(List<SavedPattern> patterns) => {
    'format': 'spapharma-patterns-v1',
    'patterns': patterns.map((pattern) => pattern.toMap()).toList(),
  };

  static Future<String?> exportPatterns() async {
    final patterns = await PatternStore.load();
    final bytes = Uint8List.fromList(
      utf8.encode(jsonEncode(toPortableMap(patterns))),
    );
    return FilePicker.saveFile(
      dialogTitle: 'تصدير الأنماط والمواضع',
      fileName: 'spapharma_patterns.json',
      type: FileType.custom,
      allowedExtensions: ['json'],
      bytes: bytes,
    );
  }

  static Future<int?> importPatterns() async {
    final result = await FilePicker.pickFiles(
      dialogTitle: 'استيراد الأنماط والمواضع',
      type: FileType.custom,
      allowedExtensions: ['json'],
      withData: true,
    );
    final file = result?.files.single;
    final bytes = await _readPickedFileBytes(file);
    if (bytes == null) return null;
    final decoded = jsonDecode(utf8.decode(bytes));
    if (decoded is! Map || decoded['format'] != 'spapharma-patterns-v1') {
      throw const FormatException('Invalid patterns format');
    }
    final values = decoded['patterns'];
    if (values is! List) throw const FormatException('Missing patterns');
    if (values.length > 5000) {
      throw const FormatException('عدد الأنماط يتجاوز الحد المسموح');
    }
    final imported = values
        .map(
          (value) => SavedPattern.fromMapStrict(
            InputLimits.strictMap(value, field: 'patterns'),
          ),
        )
        .toList();
    await PatternStore.mergeAll(imported);
    return imported.length;
  }

  static Future<String?> exportEncryptedPatterns({
    required String password,
  }) async {
    final patterns = await PatternStore.load();
    final payload = jsonEncode(toPortableMap(patterns));
    final encrypted = await EncryptedBackupCodec.encryptJson(
      payload,
      password: password,
    );
    return FilePicker.saveFile(
      dialogTitle: 'تصدير الأنماط والمواضع المشفرة',
      fileName: 'spapharma_patterns.kpatterns',
      type: FileType.custom,
      allowedExtensions: ['kpatterns'],
      bytes: Uint8List.fromList(utf8.encode(encrypted)),
    );
  }

  static Future<int?> importEncryptedPatterns({
    required String password,
  }) async {
    final result = await FilePicker.pickFiles(
      dialogTitle: 'استيراد الأنماط والمواضع المشفرة',
      type: FileType.custom,
      allowedExtensions: ['kpatterns'],
      withData: true,
    );
    final file = result?.files.single;
    final bytes = await _readPickedFileBytes(file);
    if (bytes == null) return null;
    final plain = await EncryptedBackupCodec.decryptJson(
      utf8.decode(bytes),
      password: password,
    );
    final decoded = jsonDecode(plain);
    if (decoded is! Map || decoded['format'] != 'spapharma-patterns-v1') {
      throw const FormatException('Invalid encrypted patterns format');
    }
    final values = decoded['patterns'];
    if (values is! List) throw const FormatException('Missing patterns');
    if (values.length > 5000) {
      throw const FormatException('عدد الأنماط يتجاوز الحد المسموح');
    }
    final imported = values
        .map(
          (value) => SavedPattern.fromMapStrict(
            InputLimits.strictMap(value, field: 'patterns'),
          ),
        )
        .toList();
    await PatternStore.mergeAll(imported);
    return imported.length;
  }

  static Future<Uint8List?> _readPickedFileBytes(PlatformFile? file) async {
    if (file == null) return null;
    if (file.bytes != null) return file.bytes;
    final path = file.path;
    if (path == null || path.trim().isEmpty) return null;
    final picked = File(path);
    if (!await picked.exists()) return null;
    return picked.readAsBytes();
  }
}
