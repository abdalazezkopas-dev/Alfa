import '../../../core/security/input_limits.dart';
import '../../../core/utils/number_normalizer.dart';

enum DebtEntryType { owedToMe, iOwe }

class DebtEntry {
  DebtEntry({
    required this.id,
    required double amount,
    required this.type,
    required this.date,
    required this.note,
    this.category = 'عام',
    this.dueDate,
    this.settled = false,
    this.archived = false,
    this.archivedAt,
    this.transferId,
    this.attachmentPath,
  }) : amountMinor = (amount * 100).round();

  DebtEntry.fromMinorUnits({
    required this.id,
    required this.amountMinor,
    required this.type,
    required this.date,
    required this.note,
    this.category = 'عام',
    this.dueDate,
    this.settled = false,
    this.archived = false,
    this.archivedAt,
    this.transferId,
    this.attachmentPath,
  });

  final int id;
  final int amountMinor;
  final DebtEntryType type;
  final DateTime date;
  final String note;
  final String category;
  final DateTime? dueDate;
  final bool settled;
  final bool archived;
  final DateTime? archivedAt;
  final String? transferId;
  final String? attachmentPath;
  double get amount => amountMinor / 100;
  bool get active => !archived && !settled;

  DebtEntry copyWith({
    int? amountMinor,
    DebtEntryType? type,
    DateTime? date,
    String? note,
    String? category,
    DateTime? dueDate,
    bool? settled,
    bool? archived,
    DateTime? archivedAt,
    String? transferId,
    String? attachmentPath,
  }) => DebtEntry.fromMinorUnits(
    id: id,
    amountMinor: amountMinor ?? this.amountMinor,
    type: type ?? this.type,
    date: date ?? this.date,
    note: note ?? this.note,
    category: category ?? this.category,
    dueDate: dueDate ?? this.dueDate,
    settled: settled ?? this.settled,
    archived: archived ?? this.archived,
    archivedAt: archivedAt ?? this.archivedAt,
    transferId: transferId ?? this.transferId,
    attachmentPath: attachmentPath ?? this.attachmentPath,
  );

  Map<String, Object?> toMap() => {
    'id': id,
    'amountMinor': amountMinor,
    'amount': amount,
    'type': type.name,
    'date': date.toIso8601String(),
    'note': note,
    'category': category,
    'dueDate': dueDate?.toIso8601String(),
    'settled': settled,
    'archived': archived,
    'archivedAt': archivedAt?.toIso8601String(),
    'transferId': transferId,
    'attachmentPath': attachmentPath,
  };

  factory DebtEntry.fromMap(Map<String, Object?> map) {
    final rawMinor = map['amountMinor'];
    final minor = rawMinor is num
        ? rawMinor.round()
        : NumberNormalizer.parseMinorUnits(map['amount']?.toString() ?? '') ??
              0;
    return DebtEntry.fromMinorUnits(
      id: InputLimits.integer(
        map['id'],
        fallback: DateTime.now().microsecondsSinceEpoch,
        max: 1 << 62,
      ),
      amountMinor: minor.clamp(0, 100000000000000),
      type: DebtEntryType.values.firstWhere(
        (item) => item.name == map['type'],
        orElse: () => DebtEntryType.owedToMe,
      ),
      date:
          DateTime.tryParse(
            map['date'] is String ? map['date'] as String : '',
          ) ??
          DateTime.now(),
      note: InputLimits.string(
        map['note'],
        maxLength: InputLimits.maxLongTextLength,
      ),
      category: InputLimits.string(
        map['category'],
        fallback: 'عام',
        maxLength: InputLimits.maxCategoryLength,
      ),
      dueDate: DateTime.tryParse(
        map['dueDate'] is String ? map['dueDate'] as String : '',
      ),
      settled: map['settled'] == true,
      archived: map['archived'] == true,
      archivedAt: DateTime.tryParse(
        map['archivedAt'] is String ? map['archivedAt'] as String : '',
      ),
      transferId: map['transferId'] is String
          ? InputLimits.string(map['transferId'], maxLength: 128)
          : null,
      attachmentPath: map['attachmentPath'] is String
          ? InputLimits.string(map['attachmentPath'], maxLength: 1024)
          : null,
    );
  }

  static DebtEntry fromMapStrict(Map<String, Object?> map) {
    if (map.containsKey('id')) {
      InputLimits.strictInteger(map['id'], field: 'id', min: 0, max: 1 << 62);
    }
    if (map.containsKey('amountMinor')) {
      InputLimits.strictInteger(
        map['amountMinor'],
        field: 'amountMinor',
        min: 0,
        max: 100000000000000,
      );
    }
    if (map.containsKey('amount')) {
      InputLimits.strictFiniteDouble(
        map['amount'],
        field: 'amount',
        min: 0,
        max: 1000000000000,
      );
    }
    _enum(map, 'type', DebtEntryType.values.map((item) => item.name).toSet());
    _date(map, 'date');
    _text(map, 'note', maxLength: InputLimits.maxLongTextLength);
    _text(map, 'category', maxLength: InputLimits.maxCategoryLength);
    _date(map, 'dueDate', optional: true);
    _date(map, 'archivedAt', optional: true);
    _text(map, 'transferId', maxLength: 128);
    _text(
      map,
      'attachmentPath',
      maxLength: InputLimits.maxAttachmentPathLength,
    );
    _bool(map, 'settled');
    _bool(map, 'archived');
    return DebtEntry.fromMap(map);
  }

  static void _text(
    Map<String, Object?> map,
    String key, {
    int maxLength = InputLimits.maxShortTextLength,
  }) {
    if (map.containsKey(key) && map[key] != null) {
      InputLimits.strictString(map[key], field: key, maxLength: maxLength);
    }
  }

  static void _date(
    Map<String, Object?> map,
    String key, {
    bool optional = false,
  }) {
    if (map.containsKey(key) && map[key] != null) {
      InputLimits.strictDateTime(map[key], field: key);
    } else if (!optional && map.containsKey(key)) {
      throw FormatException('الحقل $key يجب أن يكون تاريخًا صالحًا');
    }
  }

  static void _bool(Map<String, Object?> map, String key) {
    if (map.containsKey(key)) InputLimits.strictBool(map[key], field: key);
  }

  static void _enum(Map<String, Object?> map, String key, Set<String> values) {
    if (!map.containsKey(key)) return;
    final value = InputLimits.strictString(map[key], field: key, maxLength: 64);
    if (!values.contains(value)) throw FormatException('قيمة $key غير صالحة');
  }
}

class DebtAccount {
  const DebtAccount({
    required this.id,
    required this.name,
    required this.kind,
    required this.phone,
    required this.notes,
    required this.entries,
  });
  final int id;
  final String name;
  final String kind;
  final String phone;
  final String notes;
  final List<DebtEntry> entries;
  Iterable<DebtEntry> get activeEntries =>
      entries.where((e) => !e.archived && !e.settled);
  double get owedToMe =>
      activeEntries
          .where((e) => e.type == DebtEntryType.owedToMe)
          .fold<int>(0, (sum, e) => sum + e.amountMinor) /
      100;
  double get iOwe =>
      activeEntries
          .where((e) => e.type == DebtEntryType.iOwe)
          .fold<int>(0, (sum, e) => sum + e.amountMinor) /
      100;
  double get balance => owedToMe - iOwe;
  int get overdueCount => activeEntries
      .where((e) => e.dueDate != null && e.dueDate!.isBefore(DateTime.now()))
      .length;
  DebtAccount copyWith({
    String? name,
    String? kind,
    String? phone,
    String? notes,
    List<DebtEntry>? entries,
  }) => DebtAccount(
    id: id,
    name: name ?? this.name,
    kind: kind ?? this.kind,
    phone: phone ?? this.phone,
    notes: notes ?? this.notes,
    entries: entries ?? this.entries,
  );
  Map<String, Object?> toMap() => {
    'id': id,
    'name': name,
    'kind': kind,
    'phone': phone,
    'notes': notes,
    'entries': entries.map((e) => e.toMap()).toList(),
  };
  factory DebtAccount.fromMap(Map<String, Object?> map) {
    final rawEntries = map['entries'];
    return DebtAccount(
      id: InputLimits.integer(
        map['id'],
        fallback: DateTime.now().microsecondsSinceEpoch,
        max: 1 << 62,
      ),
      name: InputLimits.string(map['name']),
      kind: InputLimits.string(map['kind'], fallback: 'شخص', maxLength: 64),
      phone: InputLimits.string(map['phone'], maxLength: 64),
      notes: InputLimits.string(
        map['notes'],
        maxLength: InputLimits.maxLongTextLength,
      ),
      entries: rawEntries is List
          ? InputLimits.list(rawEntries, maxLength: InputLimits.maxDebtEntries)
                .whereType<Map>()
                .map(
                  (item) => DebtEntry.fromMap(Map<String, Object?>.from(item)),
                )
                .toList()
          : const [],
    );
  }

  static DebtAccount fromMapStrict(Map<String, Object?> map) {
    if (map.containsKey('id')) {
      InputLimits.strictInteger(map['id'], field: 'id', min: 0, max: 1 << 62);
    }
    _text(map, 'name');
    _text(map, 'kind', maxLength: 64);
    _text(map, 'phone', maxLength: 64);
    _text(map, 'notes', maxLength: InputLimits.maxLongTextLength);
    if (map.containsKey('entries')) {
      for (final item in InputLimits.strictList(
        map['entries'],
        field: 'entries',
        maxLength: InputLimits.maxDebtEntries,
      )) {
        DebtEntry.fromMapStrict(InputLimits.strictMap(item, field: 'entries'));
      }
    }
    return DebtAccount.fromMap(map);
  }

  static void _text(
    Map<String, Object?> map,
    String key, {
    int maxLength = InputLimits.maxShortTextLength,
  }) {
    if (map.containsKey(key) && map[key] != null) {
      InputLimits.strictString(map[key], field: key, maxLength: maxLength);
    }
  }
}
