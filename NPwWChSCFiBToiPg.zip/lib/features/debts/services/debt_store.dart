import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/security/secure_local_store.dart';
import '../../../core/services/app_logger.dart';
import '../../../core/store_mutex.dart';
import '../../../core/id_generator.dart';
import '../models/debt.dart';

class DebtStore {
  const DebtStore._();
  static const _key = 'alfa_expense_app.debt_accounts.v1';
  static const _maxItems = 5000;
  static Future<List<DebtAccount>> load() =>
      StoreMutex.run('debts', _loadUnlocked);
  static Future<List<DebtAccount>> _loadUnlocked() async {
    final preferences = await SharedPreferences.getInstance();
    String? raw;
    try {
      raw = await SecureLocalStore.read('debts');
    } catch (error, stackTrace) {
      AppLogger.error(
        'تعذر قراءة التخزين الآمن للديون',
        error: error,
        stackTrace: stackTrace,
        scope: 'debts',
      );
      rethrow;
    }
    final fromSecure = raw != null && raw.isNotEmpty;
    raw ??= preferences.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    final accounts = _decode(raw);
    if (!fromSecure) {
      await SecureLocalStore.writeJson(
        'debts',
        accounts.map((item) => item.toMap()).toList(),
      );
      await preferences.remove(_key);
    }
    return accounts;
  }

  static List<DebtAccount> _decode(String raw) {
    final decoded = jsonDecode(raw);
    if (decoded is! List || decoded.length > _maxItems)
      throw const FormatException('تخزين الديون غير صحيح');
    return decoded.map((item) {
      if (item is! Map) throw const FormatException('سجل دين تالف');
      return DebtAccount.fromMapStrict(Map<String, Object?>.from(item));
    }).toList();
  }

  static Future<void> saveAll(List<DebtAccount> accounts) =>
      StoreMutex.run('debts', () => _saveUnlocked(accounts));
  static Future<void> _saveUnlocked(List<DebtAccount> accounts) async {
    if (accounts.length > _maxItems)
      throw const FormatException('عدد الحسابات يتجاوز الحد المسموح');
    for (final account in accounts) DebtAccount.fromMapStrict(account.toMap());
    final encoded = jsonEncode(accounts.map((a) => a.toMap()).toList());
    _decode(encoded);
    final preferences = await SharedPreferences.getInstance();
    await SecureLocalStore.write('debts', encoded);
    await preferences.remove(_key);
  }

  static Future<void> upsert(DebtAccount account) =>
      StoreMutex.run('debts', () async {
        final accounts = await _loadUnlocked();
        final index = accounts.indexWhere((item) => item.id == account.id);
        if (index == -1)
          accounts.add(account);
        else
          accounts[index] = account;
        await _saveUnlocked(accounts);
      });
  static Future<void> delete(int id) => StoreMutex.run('debts', () async {
    final accounts = await _loadUnlocked();
    accounts.removeWhere((account) => account.id == id);
    await _saveUnlocked(accounts);
  });
  static Future<DebtAccount?> updateEntry({
    required int accountId,
    required DebtEntry entry,
  }) => StoreMutex.run('debts', () async {
    final accounts = await _loadUnlocked();
    final accountIndex = accounts.indexWhere(
      (account) => account.id == accountId,
    );
    if (accountIndex < 0) return null;
    final account = accounts[accountIndex];
    final entryIndex = account.entries.indexWhere(
      (item) => item.id == entry.id,
    );
    if (entryIndex < 0) return null;
    final entries = [...account.entries]..[entryIndex] = entry;
    final updated = account.copyWith(entries: entries);
    accounts[accountIndex] = updated;
    await _saveUnlocked(accounts);
    return updated;
  });
  static Future<DebtAccount?> deleteEntry({
    required int accountId,
    required int entryId,
  }) => StoreMutex.run('debts', () async {
    final accounts = await _loadUnlocked();
    final accountIndex = accounts.indexWhere(
      (account) => account.id == accountId,
    );
    if (accountIndex < 0) return null;
    final account = accounts[accountIndex];
    final entries = account.entries
        .where((entry) => entry.id != entryId)
        .toList();
    if (entries.length == account.entries.length) return null;
    final updated = account.copyWith(entries: entries);
    accounts[accountIndex] = updated;
    await _saveUnlocked(accounts);
    return updated;
  });
  static Future<DebtAccount?> closeAccount(
    int accountId,
  ) => StoreMutex.run('debts', () async {
    final accounts = await _loadUnlocked();
    final index = accounts.indexWhere((a) => a.id == accountId);
    if (index < 0) return null;
    final account = accounts[index];
    final active = account.activeEntries.toList();
    if (active.isEmpty) return account;
    final now = DateTime.now();
    final archived = account.entries
        .map(
          (e) => e.archived || e.settled
              ? e
              : e.copyWith(archived: true, archivedAt: now),
        )
        .toList();
    final balanceMinor = active.fold<int>(
      0,
      (sum, e) =>
          sum +
          (e.type == DebtEntryType.owedToMe ? e.amountMinor : -e.amountMinor),
    );
    if (balanceMinor != 0)
      archived.add(
        DebtEntry.fromMinorUnits(
          id: await IdGenerator.next('debt_entries'),
          amountMinor: balanceMinor.abs(),
          type: balanceMinor > 0 ? DebtEntryType.owedToMe : DebtEntryType.iOwe,
          date: now,
          note: 'رصيد نهائي بعد إغلاق الحساب',
          category: 'إغلاق حساب',
        ),
      );
    final updated = account.copyWith(entries: archived);
    accounts[index] = updated;
    await _saveUnlocked(accounts);
    return updated;
  });
  static Future<bool> transfer({
    required int fromAccountId,
    required int toAccountId,
    required double amount,
    String note = '',
  }) => StoreMutex.run('debts', () async {
    if (fromAccountId == toAccountId || amount <= 0) return false;
    final accounts = await _loadUnlocked();
    final fromIndex = accounts.indexWhere((a) => a.id == fromAccountId);
    final toIndex = accounts.indexWhere((a) => a.id == toAccountId);
    if (fromIndex < 0 || toIndex < 0) return false;
    final transferId = 'TR-${DateTime.now().microsecondsSinceEpoch}';
    final now = DateTime.now();
    final amountMinor = (amount * 100).round();
    final fromEntry = DebtEntry.fromMinorUnits(
      id: await IdGenerator.next('debt_entries'),
      amountMinor: amountMinor,
      type: DebtEntryType.iOwe,
      date: now,
      note: note.isEmpty ? 'تحويل إلى ${accounts[toIndex].name}' : note,
      category: 'تحويل',
      transferId: transferId,
    );
    final toEntry = DebtEntry.fromMinorUnits(
      id: await IdGenerator.next('debt_entries'),
      amountMinor: amountMinor,
      type: DebtEntryType.owedToMe,
      date: now,
      note: note.isEmpty ? 'تحويل من ${accounts[fromIndex].name}' : note,
      category: 'تحويل',
      transferId: transferId,
    );
    accounts[fromIndex] = accounts[fromIndex].copyWith(
      entries: [...accounts[fromIndex].entries, fromEntry],
    );
    accounts[toIndex] = accounts[toIndex].copyWith(
      entries: [...accounts[toIndex].entries, toEntry],
    );
    await _saveUnlocked(accounts);
    return true;
  });
}
