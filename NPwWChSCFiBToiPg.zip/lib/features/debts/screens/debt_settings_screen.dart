import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../../core/store_mutex.dart';

class DebtSettingsScreen extends StatefulWidget {
  const DebtSettingsScreen({super.key});
  @override
  State<DebtSettingsScreen> createState() => _DebtSettingsScreenState();
}

class _DebtSettingsScreenState extends State<DebtSettingsScreen> {
  final currency = TextEditingController(text: 'ريال'),
      title = TextEditingController(text: 'تقرير الحسابات والديون'),
      categories = TextEditingController(
        text: 'عام، سحبيات، مبيعات، سلفة، مصروفات',
      );
  int decimals = 2, defaultDueDays = 0, alertDays = 3;
  String defaultType = 'owedToMe', sortMode = 'name';
  bool hideZero = false;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final v = await StoreMutex.run('debt_settings', () async {
      final p = await SharedPreferences.getInstance();
      return (
        currency: p.getString('alfa_debt_currency') ?? 'ريال',
        title:
            p.getString('alfa_debt_report_title') ?? 'تقرير الحسابات والديون',
        decimals: p.getInt('alfa_debt_decimals') ?? 2,
        categories:
            p.getString('alfa_debt_categories') ??
            'عام، سحبيات، مبيعات، سلفة، مصروفات',
        due: p.getInt('alfa_debt_default_due_days') ?? 0,
        alert: p.getInt('alfa_debt_alert_days') ?? 3,
        type: p.getString('alfa_debt_default_type') ?? 'owedToMe',
        sort: p.getString('alfa_debt_sort_mode') ?? 'name',
        hide: p.getBool('alfa_debt_hide_zero') ?? false,
      );
    });
    if (!mounted) return;
    setState(() {
      currency.text = v.currency;
      title.text = v.title;
      decimals = v.decimals;
      categories.text = v.categories;
      defaultDueDays = v.due;
      alertDays = v.alert;
      defaultType = v.type;
      sortMode = v.sort;
      hideZero = v.hide;
    });
  }

  Future<void> _save() => StoreMutex.run('debt_settings', () async {
    final p = await SharedPreferences.getInstance();
    final results = await Future.wait([
      p.setString(
        'alfa_debt_currency',
        currency.text.trim().isEmpty ? 'ريال' : currency.text.trim(),
      ),
      p.setString(
        'alfa_debt_report_title',
        title.text.trim().isEmpty
            ? 'تقرير الحسابات والديون'
            : title.text.trim(),
      ),
      p.setInt('alfa_debt_decimals', decimals),
      p.setString('alfa_debt_categories', categories.text.trim()),
      p.setInt('alfa_debt_default_due_days', defaultDueDays),
      p.setInt('alfa_debt_alert_days', alertDays),
      p.setString('alfa_debt_default_type', defaultType),
      p.setString('alfa_debt_sort_mode', sortMode),
      p.setBool('alfa_debt_hide_zero', hideZero),
    ]);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            results.every((x) => x)
                ? 'تم حفظ إعدادات الحسابات والديون'
                : 'فشل حفظ الإعدادات',
          ),
        ),
      );
    }
  });
  @override
  void dispose() {
    currency.dispose();
    title.dispose();
    categories.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('إعدادات الحسابات والديون'),
      actions: [
        IconButton(onPressed: _save, icon: const Icon(Icons.save_outlined)),
      ],
    ),
    body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text('إعدادات مستقلة لوحدة الحسابات والديون.'),
        const SizedBox(height: 16),
        TextField(
          controller: currency,
          decoration: const InputDecoration(labelText: 'اسم العملة'),
        ),
        TextField(
          controller: title,
          decoration: const InputDecoration(labelText: 'عنوان التقرير'),
        ),
        TextField(
          controller: categories,
          maxLines: 2,
          decoration: const InputDecoration(
            labelText: 'التصنيفات الافتراضية',
            hintText: 'افصل بينها بفاصلة',
          ),
        ),
        const SizedBox(height: 12),
        DropdownButtonFormField<int>(
          initialValue: decimals,
          decoration: const InputDecoration(labelText: 'المنازل العشرية'),
          items: const [
            DropdownMenuItem(value: 0, child: Text('بدون كسور')),
            DropdownMenuItem(value: 2, child: Text('منزلتان')),
            DropdownMenuItem(value: 3, child: Text('ثلاث منازل')),
          ],
          onChanged: (v) => setState(() => decimals = v ?? 2),
        ),
        DropdownButtonFormField<String>(
          initialValue: defaultType,
          decoration: const InputDecoration(labelText: 'نوع العملية الافتراضي'),
          items: const [
            DropdownMenuItem(value: 'owedToMe', child: Text('له عندي')),
            DropdownMenuItem(value: 'iOwe', child: Text('عليه عندي')),
          ],
          onChanged: (v) => setState(() => defaultType = v ?? 'owedToMe'),
        ),
        DropdownButtonFormField<int>(
          initialValue: defaultDueDays,
          decoration: const InputDecoration(
            labelText: 'مدة الاستحقاق الافتراضية',
          ),
          items: const [
            DropdownMenuItem(value: 0, child: Text('بدون تاريخ تلقائي')),
            DropdownMenuItem(value: 7, child: Text('بعد 7 أيام')),
            DropdownMenuItem(value: 14, child: Text('بعد 14 يومًا')),
            DropdownMenuItem(value: 30, child: Text('بعد 30 يومًا')),
          ],
          onChanged: (v) => setState(() => defaultDueDays = v ?? 0),
        ),
        DropdownButtonFormField<int>(
          initialValue: alertDays,
          decoration: const InputDecoration(labelText: 'التنبيه قبل الاستحقاق'),
          items: const [
            DropdownMenuItem(value: 0, child: Text('بدون تنبيه')),
            DropdownMenuItem(value: 1, child: Text('قبل يوم')),
            DropdownMenuItem(value: 3, child: Text('قبل 3 أيام')),
            DropdownMenuItem(value: 7, child: Text('قبل أسبوع')),
          ],
          onChanged: (v) => setState(() => alertDays = v ?? 3),
        ),
        DropdownButtonFormField<String>(
          initialValue: sortMode,
          decoration: const InputDecoration(labelText: 'الترتيب الافتراضي'),
          items: const [
            DropdownMenuItem(value: 'name', child: Text('حسب الاسم')),
            DropdownMenuItem(value: 'balance', child: Text('حسب الرصيد')),
            DropdownMenuItem(value: 'overdue', child: Text('المتأخرة أولًا')),
          ],
          onChanged: (v) => setState(() => sortMode = v ?? 'name'),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('إخفاء الحسابات ذات الرصيد الصفري'),
          value: hideZero,
          onChanged: (v) => setState(() => hideZero = v),
        ),
        const SizedBox(height: 20),
        FilledButton.icon(
          onPressed: _save,
          icon: const Icon(Icons.save_outlined),
          label: const Text('حفظ الإعدادات'),
        ),
      ],
    ),
  );
}
