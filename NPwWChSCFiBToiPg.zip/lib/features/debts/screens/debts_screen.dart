import '../../../core/utils/date_formatter.dart';
import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../expense_request/services/share_service.dart';
import '../../expense_request/services/amount_to_words.dart';
import '../../../core/id_generator.dart';
import '../../../core/utils/number_normalizer.dart';
import '../models/debt.dart';
import '../services/debt_store.dart';
import '../../reminders/models/reminder.dart';
import '../../reminders/services/reminder_notification_service.dart';
import '../../reminders/services/reminder_store.dart';
import '../../../core/services/attachment_manager.dart';

class DebtsScreen extends StatefulWidget {
  const DebtsScreen({super.key});
  @override
  State<DebtsScreen> createState() => _DebtsScreenState();
}

class _DebtsScreenState extends State<DebtsScreen> {
  List<DebtAccount> _accounts = [];
  bool _loading = true, _hideZero = false, _advanced = false;
  String _keyword = '', _category = 'الكل', _sortColumn = 'name';
  bool _ascending = true;
  double? _minAmount, _maxAmount;
  DateTime? _from, _to;
  String _currency = 'ريال', _reportTitle = 'تقرير الحسابات والديون';
  int _decimals = 2;
  final _keywordController = TextEditingController(),
      _minController = TextEditingController(),
      _maxController = TextEditingController();
  @override
  void initState() {
    super.initState();
    _loadPreferences();
    _load();
  }

  @override
  void dispose() {
    _keywordController.dispose();
    _minController.dispose();
    _maxController.dispose();
    super.dispose();
  }

  Future<void> _loadPreferences() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _currency = p.getString('alfa_debt_currency') ?? 'ريال';
      _reportTitle =
          p.getString('alfa_debt_report_title') ?? 'تقرير الحسابات والديون';
      _decimals = p.getInt('alfa_debt_decimals') ?? 2;
      _hideZero = p.getBool('alfa_debt_hide_zero') ?? false;
    });
  }

  Future<void> _load() async {
    final accounts = await DebtStore.load();
    if (!mounted) return;
    setState(() {
      _accounts = accounts;
      _loading = false;
    });
  }

  String _money(double value) =>
      '${value.toStringAsFixed(_decimals)} $_currency';
  void _setMinAmount(String value) {
    setState(() => _minAmount = NumberNormalizer.parseDouble(value));
  }

  void _setMaxAmount(String value) {
    setState(() => _maxAmount = NumberNormalizer.parseDouble(value));
  }

  void _setCategory(String? value) {
    setState(() => _category = value ?? 'الكل');
  }

  Future<void> _setHideZero(bool value) async {
    setState(() => _hideZero = value);
    final preferences = await SharedPreferences.getInstance();
    await preferences.setBool('alfa_debt_hide_zero', value);
  }

  List<String> get _categories => {
    'الكل',
    for (final a in _accounts)
      for (final e in a.entries)
        if (e.category.trim().isNotEmpty) e.category,
  }.toList();
  List<DebtAccount> get _filtered {
    final key = _keyword.toLowerCase().trim();
    final result = _accounts.where((a) {
      if (_hideZero && a.balance == 0) return false;
      final matchingEntries = a.entries.where((e) {
        final text =
            '${a.name} ${a.kind} ${a.phone} ${a.notes} ${e.note} ${e.category}'
                .toLowerCase();
        final amount = e.amount;
        final date = e.date;
        return (key.isEmpty || text.contains(key)) &&
            (_category == 'الكل' || e.category == _category) &&
            (_minAmount == null || amount >= _minAmount!) &&
            (_maxAmount == null || amount <= _maxAmount!) &&
            (_from == null || !date.isBefore(_from!)) &&
            (_to == null ||
                !date.isAfter(
                  DateTime(_to!.year, _to!.month, _to!.day, 23, 59, 59),
                ));
      });
      return matchingEntries.isNotEmpty ||
          (key.isEmpty &&
              _category == 'الكل' &&
              _minAmount == null &&
              _maxAmount == null &&
              _from == null &&
              _to == null);
    }).toList();
    int compare(DebtAccount a, DebtAccount b) {
      final value = switch (_sortColumn) {
        'balance' => a.balance.compareTo(b.balance),
        'owed' => a.owedToMe.compareTo(b.owedToMe),
        'iowe' => a.iOwe.compareTo(b.iOwe),
        'overdue' => a.overdueCount.compareTo(b.overdueCount),
        _ => a.name.toLowerCase().compareTo(b.name.toLowerCase()),
      };
      return _ascending ? value : -value;
    }

    result.sort(compare);
    return result;
  }

  double get _receivable => _accounts.fold(0, (s, a) => s + a.owedToMe);
  double get _payable => _accounts.fold(0, (s, a) => s + a.iOwe);
  void _sort(String column) => setState(() {
    if (_sortColumn == column) {
      _ascending = !_ascending;
    } else {
      _sortColumn = column;
      _ascending = true;
    }
  });
  Future<void> _pick(bool start) async {
    final picked = await showDatePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      initialDate: (start ? _from : _to) ?? DateTime.now(),
    );
    if (picked != null) {
      setState(() {
        if (start) {
          _from = picked;
        } else {
          _to = picked;
        }
      });
    }
  }

  Future<void> _addAccount() async {
    final account = await showDialog<DebtAccount>(
      context: context,
      builder: (_) => const _AccountEditor(),
    );
    if (account != null) {
      await DebtStore.upsert(account);
      await _load();
    }
  }

  Future<void> _openAccount(DebtAccount account) async {
    final updated = await Navigator.push<DebtAccount>(
      context,
      MaterialPageRoute(builder: (_) => _DebtAccountScreen(account: account)),
    );
    if (updated != null) {
      await DebtStore.upsert(updated);
      await _load();
    }
  }

  Future<void> _close(DebtAccount account) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('إغلاق الحساب؟'),
        content: const Text(
          'سيتم دمج العمليات النشطة في قيد رصيد نهائي مع أرشفة السجلات القديمة داخل JSON.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('إغلاق'),
          ),
        ],
      ),
    );
    if (ok == true) {
      await DebtStore.closeAccount(account.id);
      await _load();
    }
  }

  Future<void> _transfer() async {
    if (_accounts.length < 2) return;
    final result = await showDialog<_TransferData>(
      context: context,
      builder: (_) => _TransferDialog(accounts: _accounts, currency: _currency),
    );
    if (result != null) {
      final ok = await DebtStore.transfer(
        fromAccountId: result.from,
        toAccountId: result.to,
        amount: result.amount,
        note: result.note,
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              ok ? 'تم التحويل ذريًا وسُجلت العمليتان' : 'تعذر تنفيذ التحويل',
            ),
          ),
        );
      }
      await _load();
    }
  }

  String _csvCell(String value) => '"${value.replaceAll('"', '""')}"';
  Future<void> _exportCsv([DebtAccount? only]) async {
    final accounts = only == null ? _accounts : [only];
    final rows = <List<String>>[
      [
        'الحساب',
        'النوع',
        'المبلغ',
        'التاريخ',
        'الاستحقاق',
        'البيان',
        'التصنيف',
        'مسودة/مؤرشفة',
        'معرف التحويل',
      ],
      for (final a in accounts)
        for (final e in a.entries)
          [
            a.name,
            e.type == DebtEntryType.owedToMe ? 'له عندي' : 'عليه لي',
            e.amount.toStringAsFixed(2),
            DateFormatter.date(e.date),
            e.dueDate == null ? '' : DateFormatter.date(e.dueDate!),
            e.note,
            e.category,
            e.archived ? 'مؤرشفة' : (e.settled ? 'مسددة' : 'نشطة'),
            e.transferId ?? '',
          ],
    ];
    final csv = rows.map((r) => r.map(_csvCell).join(',')).join('\r\n');
    await FilePicker.saveFile(
      dialogTitle: 'تصدير CSV',
      fileName: only == null ? 'debt_report.csv' : '${only.name}.csv',
      type: FileType.custom,
      allowedExtensions: ['csv'],
      bytes: Uint8List.fromList([0xEF, 0xBB, 0xBF, ...utf8.encode(csv)]),
    );
  }

  Future<void> _report({required bool print}) async {
    final document = pw.Document(title: _reportTitle);
    final font = pw.Font.ttf(
      await rootBundle.load('assets/fonts/NotoSansArabic-Regular.ttf'),
    );
    document.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        textDirection: pw.TextDirection.rtl,
        theme: pw.ThemeData.withFont(base: font),
        build: (_) => [
          pw.Header(level: 0, child: pw.Text(_reportTitle)),
          pw.Text(
            'إجمالي لي: ${_money(_receivable)}    |    إجمالي عليّ: ${_money(_payable)}',
          ),
          pw.SizedBox(height: 12),
          pw.TableHelper.fromTextArray(
            headers: const ['الحساب', 'النوع', 'لي', 'عليّ', 'الرصيد'],
            data: _accounts
                .map(
                  (a) => [
                    a.name,
                    a.kind,
                    _money(a.owedToMe),
                    _money(a.iOwe),
                    _money(a.balance),
                  ],
                )
                .toList(),
          ),
        ],
      ),
    );
    final bytes = await document.save();
    if (print) {
      await ShareService.printPdf(bytes, filename: 'debt_report.pdf');
    } else {
      await ShareService.sharePdf(bytes: bytes, filename: 'debt_report.pdf');
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('الحسابات والديون'),
      actions: [
        IconButton(
          tooltip: 'تحويل بين حسابين',
          onPressed: _transfer,
          icon: const Icon(Icons.swap_horiz),
        ),
        PopupMenuButton<String>(
          onSelected: (v) {
            if (v == 'csv') {
              _exportCsv();
            } else {
              _report(print: v == 'print');
            }
          },
          itemBuilder: (_) => const [
            PopupMenuItem(value: 'print', child: Text('طباعة التقرير')),
            PopupMenuItem(value: 'share', child: Text('مشاركة التقرير')),
            PopupMenuItem(value: 'csv', child: Text('تصدير CSV UTF-8')),
          ],
        ),
      ],
    ),
    floatingActionButton: FloatingActionButton.extended(
      onPressed: _addAccount,
      icon: const Icon(Icons.add),
      label: const Text('حساب جديد'),
    ),
    body: _loading
        ? const Center(child: CircularProgressIndicator())
        : RefreshIndicator(
            onRefresh: _load,
            child: ListView(
              padding: EdgeInsets.fromLTRB(
                16,
                16,
                16,
                100 + MediaQuery.of(context).padding.bottom,
              ),
              children: [
                Row(
                  children: [
                    Expanded(
                      child: _SummaryCard(
                        title: 'لي',
                        value: _money(_receivable),
                        color: Colors.green,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _SummaryCard(
                        title: 'عليّ',
                        value: _money(_payable),
                        color: Colors.red,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _keywordController,
                  onChanged: (v) => setState(() => _keyword = v),
                  decoration: InputDecoration(
                    labelText: 'بحث بالكلمة في الحساب والبيان',
                    prefixIcon: const Icon(Icons.search),
                    suffixIcon: IconButton(
                      onPressed: () => setState(() => _advanced = !_advanced),
                      icon: Icon(_advanced ? Icons.expand_less : Icons.tune),
                    ),
                  ),
                ),
                if (_advanced) _AdvancedFilters(state: this),
                const SizedBox(height: 10),
                _SortHeader(
                  onSort: _sort,
                  active: _sortColumn,
                  ascending: _ascending,
                ),
                if (_filtered.isEmpty)
                  const Padding(
                    padding: EdgeInsets.all(32),
                    child: Center(child: Text('لا توجد نتائج مطابقة')),
                  )
                else
                  ..._filtered.map(
                    (a) => Card(
                      child: ListTile(
                        onTap: () => _openAccount(a),
                        leading: CircleAvatar(
                          child: Icon(
                            a.kind == 'محل'
                                ? Icons.storefront_outlined
                                : Icons.person_outline,
                          ),
                        ),
                        title: Text(
                          a.name,
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          '${a.kind} • الرصيد: ${_money(a.balance)}${a.overdueCount > 0 ? ' • متأخر: ${a.overdueCount}' : ''}',
                        ),
                        trailing: PopupMenuButton<String>(
                          onSelected: (v) {
                            if (v == 'close') _close(a);
                            if (v == 'csv') _exportCsv(a);
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(
                              value: 'close',
                              child: Text('إغلاق الحساب'),
                            ),
                            PopupMenuItem(
                              value: 'csv',
                              child: Text('CSV لهذا الحساب'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
  );
}

class _AdvancedFilters extends StatelessWidget {
  const _AdvancedFilters({required this.state});
  final _DebtsScreenState state;
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(10),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: state._minController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'مبلغ من'),
                  onChanged: state._setMinAmount,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: state._maxController,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'مبلغ إلى'),
                  onChanged: state._setMaxAmount,
                ),
              ),
            ],
          ),
          DropdownButtonFormField<String>(
            initialValue: state._categories.contains(state._category)
                ? state._category
                : 'الكل',
            decoration: const InputDecoration(labelText: 'التصنيف'),
            items: state._categories
                .map((c) => DropdownMenuItem(value: c, child: Text(c)))
                .toList(),
            onChanged: state._setCategory,
          ),
          Row(
            children: [
              Expanded(
                child: TextButton.icon(
                  onPressed: () => state._pick(true),
                  icon: const Icon(Icons.date_range),
                  label: Text(
                    state._from == null
                        ? 'من تاريخ'
                        : DateFormatter.date(state._from!),
                  ),
                ),
              ),
              Expanded(
                child: TextButton.icon(
                  onPressed: () => state._pick(false),
                  icon: const Icon(Icons.event),
                  label: Text(
                    state._to == null
                        ? 'إلى تاريخ'
                        : DateFormatter.date(state._to!),
                  ),
                ),
              ),
            ],
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('إخفاء الحسابات ذات الرصيد الصفري'),
            value: state._hideZero,
            onChanged: state._setHideZero,
          ),
        ],
      ),
    ),
  );
}

class _SortHeader extends StatelessWidget {
  const _SortHeader({
    required this.onSort,
    required this.active,
    required this.ascending,
  });
  final void Function(String) onSort;
  final String active;
  final bool ascending;
  @override
  Widget build(BuildContext context) => SingleChildScrollView(
    scrollDirection: Axis.horizontal,
    child: Row(
      children:
          [
                ('name', 'الحساب'),
                ('owed', 'لي'),
                ('iowe', 'عليّ'),
                ('balance', 'الرصيد'),
                ('overdue', 'المتأخر'),
              ]
              .map(
                (e) => TextButton(
                  onPressed: () => onSort(e.$1),
                  child: Row(
                    children: [
                      Text(e.$2),
                      if (active == e.$1)
                        Icon(
                          ascending ? Icons.arrow_upward : Icons.arrow_downward,
                          size: 15,
                        ),
                    ],
                  ),
                ),
              )
              .toList(),
    ),
  );
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.title,
    required this.value,
    required this.color,
  });
  final String title, value;
  final Color color;
  @override
  Widget build(BuildContext context) => Card(
    color: color.withValues(alpha: .1),
    child: Padding(
      padding: const EdgeInsets.all(14),
      child: Column(
        children: [
          Text(title),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: color,
              fontSize: 20,
            ),
          ),
        ],
      ),
    ),
  );
}

class _AccountEditor extends StatefulWidget {
  const _AccountEditor();
  @override
  State<_AccountEditor> createState() => _AccountEditorState();
}

class _AccountEditorState extends State<_AccountEditor> {
  final name = TextEditingController(),
      phone = TextEditingController(),
      notes = TextEditingController();
  String kind = 'شخص';
  @override
  void dispose() {
    name.dispose();
    phone.dispose();
    notes.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    if (name.text.trim().isEmpty) return;
    final id = await IdGenerator.next('debts');
    if (!mounted) return;
    Navigator.pop(
      context,
      DebtAccount(
        id: id,
        name: name.text.trim(),
        kind: kind,
        phone: phone.text.trim(),
        notes: notes.text.trim(),
        entries: const [],
      ),
    );
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('حساب جديد'),
    content: SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: name,
            autofocus: true,
            decoration: const InputDecoration(labelText: 'اسم الشخص أو المحل'),
          ),
          DropdownButtonFormField<String>(
            initialValue: kind,
            items: const [
              DropdownMenuItem(value: 'شخص', child: Text('شخص')),
              DropdownMenuItem(value: 'محل', child: Text('محل')),
            ],
            onChanged: (v) => setState(() => kind = v ?? 'شخص'),
          ),
          TextField(
            controller: phone,
            decoration: const InputDecoration(labelText: 'رقم التواصل'),
          ),
          TextField(
            controller: notes,
            maxLines: 2,
            decoration: const InputDecoration(labelText: 'ملاحظات'),
          ),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('إلغاء'),
      ),
      FilledButton(onPressed: submit, child: const Text('حفظ')),
    ],
  );
}

class _DebtAccountScreen extends StatefulWidget {
  const _DebtAccountScreen({required this.account});
  final DebtAccount account;
  @override
  State<_DebtAccountScreen> createState() => _DebtAccountScreenState();
}

class _DebtAccountScreenState extends State<_DebtAccountScreen> {
  late DebtAccount account;
  String currency = 'ريال';
  int decimals = 2;
  @override
  void initState() {
    super.initState();
    account = widget.account;
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (mounted) {
      setState(() {
        currency = p.getString('alfa_debt_currency') ?? 'ريال';
        decimals = p.getInt('alfa_debt_decimals') ?? 2;
      });
    }
  }

  String money(double x) => '${x.toStringAsFixed(decimals)} $currency';
  Future<void> _editEntry([DebtEntry? existing]) async {
    final entry = await showDialog<DebtEntry>(
      context: context,
      builder: (_) => _EntryEditor(initial: existing),
    );
    if (entry == null) return;
    final updated = existing == null
        ? account.copyWith(entries: [...account.entries, entry])
        : account.copyWith(
            entries: account.entries
                .map((item) => item.id == entry.id ? entry : item)
                .toList(),
          );
    await DebtStore.upsert(updated);
    if (existing?.attachmentPath != null &&
        existing!.attachmentPath != entry.attachmentPath) {
      await AttachmentManager.deleteAttachment(existing.attachmentPath);
    }
    if (!mounted) return;
    setState(() => account = updated);
    if (entry.dueDate != null && !entry.settled) await _schedule(entry);
  }

  Future<void> add() => _editEntry();

  Future<void> _deleteEntry(DebtEntry entry) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف العملية؟'),
        content: const Text('سيتم حذف هذه العملية نهائيًا من الحساب.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final updated = await DebtStore.deleteEntry(
      accountId: account.id,
      entryId: entry.id,
    );
    if (!mounted || updated == null) return;
    await AttachmentManager.deleteAttachment(entry.attachmentPath);
    setState(() => account = updated);
  }

  Future<void> _schedule(DebtEntry entry) async {
    final p = await SharedPreferences.getInstance();
    final days = p.getInt('alfa_debt_alert_days') ?? 3;
    final scheduled = entry.dueDate!.subtract(Duration(days: days));
    if (!scheduled.isAfter(DateTime.now())) return;
    final reminder = Reminder(
      id: await IdGenerator.next('reminders'),
      title: 'استحقاق حساب ${account.name}',
      notes:
          '${entry.note.isEmpty ? 'عملية دين' : entry.note} - المبلغ ${money(entry.amount)}',
      scheduledAt: scheduled,
    );
    await ReminderStore.upsert(reminder);
    await ReminderNotificationService.instance.schedule(reminder);
  }

  @override
  Widget build(BuildContext context) => PopScope<DebtAccount>(
    canPop: false,
    onPopInvokedWithResult: (didPop, _) {
      if (!didPop) Navigator.pop(context, account);
    },
    child: Scaffold(
      appBar: AppBar(
        title: Text(account.name),
        actions: [
          IconButton(onPressed: add, icon: const Icon(Icons.add_card_outlined)),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: add,
        icon: const Icon(Icons.add),
        label: const Text('عملية جديدة'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _SummaryCard(
            title: 'الرصيد',
            value: money(account.balance),
            color: account.balance >= 0 ? Colors.green : Colors.red,
          ),
          if (account.overdueCount > 0)
            Card(
              color: Colors.orange.withValues(alpha: .12),
              child: ListTile(
                leading: const Icon(Icons.warning_amber, color: Colors.orange),
                title: Text('عمليات متأخرة: ${account.overdueCount}'),
              ),
            ),
          ...account.entries.reversed.map(
            (e) => Card(
              child: ListTile(
                leading: Icon(
                  e.archived
                      ? Icons.archive_outlined
                      : (e.type == DebtEntryType.owedToMe
                            ? Icons.arrow_downward
                            : Icons.arrow_upward),
                  color: e.archived
                      ? Colors.grey
                      : (e.type == DebtEntryType.owedToMe
                            ? Colors.green
                            : Colors.red),
                ),
                title: Text(
                  '${e.type == DebtEntryType.owedToMe ? 'له عندي' : 'عليه لي'}: ${money(e.amount)}',
                ),
                subtitle: Text(
                  '${e.category} • ${DateFormatter.dateTime(e.date)} • ${e.note}${e.attachmentPath == null ? '' : ' • مرفق'}${e.archived ? ' • مؤرشفة' : ''}${e.settled ? ' • تمت التسوية' : ''}',
                ),
                trailing: PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'edit') _editEntry(e);
                    if (value == 'delete') _deleteEntry(e);
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'edit', child: Text('تعديل')),
                    PopupMenuItem(value: 'delete', child: Text('حذف')),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    ),
  );
}

class _EntryEditor extends StatefulWidget {
  const _EntryEditor({this.initial});
  final DebtEntry? initial;
  @override
  State<_EntryEditor> createState() => _EntryEditorState();
}

class _EntryEditorState extends State<_EntryEditor> {
  final amount = TextEditingController(),
      note = TextEditingController(),
      category = TextEditingController(text: 'عام');
  DebtEntryType type = DebtEntryType.owedToMe;
  DateTime? due;
  bool settled = false;
  String? attachmentPath;
  List<String> options = ['عام'];
  String words = '';
  @override
  void initState() {
    super.initState();
    final initial = widget.initial;
    if (initial != null) {
      amount.text = NumberNormalizer.formatGrouped(
        initial.amount.toStringAsFixed(2),
      );
      note.text = initial.note;
      category.text = initial.category;
      type = initial.type;
      due = initial.dueDate;
      settled = initial.settled;
      attachmentPath = initial.attachmentPath;
    }
    _defaults();
    amount.addListener(
      () => setState(() => words = AmountToWords.fromNumber(amount.text)),
    );
  }

  Future<void> _defaults() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString('alfa_debt_categories') ?? 'عام';
    final values = raw
        .split(RegExp(r'[,،]'))
        .map((v) => v.trim())
        .where((v) => v.isNotEmpty)
        .toSet()
        .toList();
    if (mounted) {
      setState(() {
        options = values.isEmpty ? ['عام'] : values;
        if (widget.initial == null) {
          category.text = options.first;
          type = p.getString('alfa_debt_default_type') == 'iOwe'
              ? DebtEntryType.iOwe
              : DebtEntryType.owedToMe;
          final d = p.getInt('alfa_debt_default_due_days') ?? 0;
          if (d > 0) due = DateTime.now().add(Duration(days: d));
        }
      });
    }
  }

  @override
  void dispose() {
    amount.dispose();
    note.dispose();
    category.dispose();
    super.dispose();
  }

  Future<void> pickDate() async {
    final d = await showDatePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 3650)),
      initialDate: due ?? DateTime.now(),
    );
    if (d != null) setState(() => due = d);
  }

  Future<void> pickAttachment() async {
    final result = await FilePicker.pickFiles(withData: false);
    final pickedPath = result?.files.single.path;
    if (pickedPath == null || pickedPath.trim().isEmpty) return;
    final saved = await AttachmentManager.saveAttachment(File(pickedPath));
    if (!mounted) return;
    setState(() => attachmentPath = saved.path);
  }

  Future<void> submit() async {
    final value = NumberNormalizer.parseDouble(amount.text);
    if (value == null || value <= 0) return;
    final id = widget.initial?.id ?? await IdGenerator.next('debt_entries');
    if (!mounted) return;
    Navigator.pop(
      context,
      DebtEntry(
        id: id,
        amount: value,
        type: type,
        date: widget.initial?.date ?? DateTime.now(),
        note: note.text.trim(),
        category: category.text.trim().isEmpty ? 'عام' : category.text.trim(),
        dueDate: due,
        settled: settled,
        attachmentPath: attachmentPath,
      ),
    );
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.initial == null ? 'إضافة عملية' : 'تعديل العملية'),
    content: SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: amount,
            inputFormatters: [ThousandsSeparatorInputFormatter()],
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(labelText: 'المبلغ'),
          ),
          if (words.isNotEmpty)
            Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                'كتابةً: $words',
                style: const TextStyle(fontStyle: FontStyle.italic),
              ),
            ),
          SegmentedButton<DebtEntryType>(
            segments: const [
              ButtonSegment(
                value: DebtEntryType.owedToMe,
                label: Text('له عندي'),
              ),
              ButtonSegment(value: DebtEntryType.iOwe, label: Text('عليه لي')),
            ],
            selected: {type},
            onSelectionChanged: (v) => setState(() => type = v.first),
          ),
          TextField(
            controller: note,
            decoration: const InputDecoration(labelText: 'البيان'),
          ),
          DropdownButtonFormField<String>(
            initialValue: options.contains(category.text)
                ? category.text
                : null,
            decoration: const InputDecoration(labelText: 'التصنيف'),
            items: options
                .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                .toList(),
            onChanged: (v) {
              if (v != null) category.text = v;
            },
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.event),
            title: const Text('تاريخ الاستحقاق'),
            subtitle: Text(due == null ? 'اختياري' : DateFormatter.date(due!)),
            onTap: pickDate,
          ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.attach_file_outlined),
            title: Text(attachmentPath == null ? 'إضافة مرفق' : 'تغيير المرفق'),
            subtitle: Text(
              attachmentPath == null
                  ? 'اختياري'
                  : attachmentPath!.split(Platform.pathSeparator).last,
            ),
            onTap: pickAttachment,
            trailing: attachmentPath == null
                ? null
                : IconButton(
                    tooltip: 'إزالة المرفق',
                    onPressed: () => setState(() => attachmentPath = null),
                    icon: const Icon(Icons.close),
                  ),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('تمت التسوية'),
            value: settled,
            onChanged: (v) => setState(() => settled = v),
          ),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('إلغاء'),
      ),
      FilledButton(onPressed: submit, child: const Text('حفظ')),
    ],
  );
}

class _TransferData {
  const _TransferData(this.from, this.to, this.amount, this.note);
  final int from, to;
  final double amount;
  final String note;
}

class _TransferDialog extends StatefulWidget {
  const _TransferDialog({required this.accounts, required this.currency});
  final List<DebtAccount> accounts;
  final String currency;
  @override
  State<_TransferDialog> createState() => _TransferDialogState();
}

class _TransferDialogState extends State<_TransferDialog> {
  late int from, to;
  final amount = TextEditingController(), note = TextEditingController();
  @override
  void initState() {
    super.initState();
    from = widget.accounts.first.id;
    to = widget.accounts[1].id;
  }

  @override
  void dispose() {
    amount.dispose();
    note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('تحويل بين حسابين'),
    content: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        DropdownButtonFormField<int>(
          initialValue: from,
          decoration: const InputDecoration(labelText: 'من حساب'),
          items: widget.accounts
              .map((a) => DropdownMenuItem(value: a.id, child: Text(a.name)))
              .toList(),
          onChanged: (v) => setState(() => from = v!),
        ),
        DropdownButtonFormField<int>(
          initialValue: to,
          decoration: const InputDecoration(labelText: 'إلى حساب'),
          items: widget.accounts
              .map((a) => DropdownMenuItem(value: a.id, child: Text(a.name)))
              .toList(),
          onChanged: (v) => setState(() => to = v!),
        ),
        TextField(
          controller: amount,
          inputFormatters: [ThousandsSeparatorInputFormatter()],
          keyboardType: TextInputType.number,
          decoration: InputDecoration(labelText: 'المبلغ (${widget.currency})'),
        ),
        TextField(
          controller: note,
          decoration: const InputDecoration(labelText: 'ملاحظة'),
        ),
      ],
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('إلغاء'),
      ),
      FilledButton(
        onPressed: () {
          final v = NumberNormalizer.parseDouble(amount.text);
          if (v != null && v > 0 && from != to) {
            Navigator.pop(
              context,
              _TransferData(from, to, v, note.text.trim()),
            );
          }
        },
        child: const Text('تحويل'),
      ),
    ],
  );
}
