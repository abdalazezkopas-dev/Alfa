import '../../../core/utils/date_formatter.dart';

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:printing/printing.dart';

import '../../../core/services/attachment_manager.dart';
import '../../../core/widgets/attachment_picker_field.dart';
import '../../expense_request/models/expense_request.dart';
import '../../expense_request/services/pdf_service.dart';
import '../../expense_request/services/request_store.dart';
import '../../expense_request/services/quick_statement_store.dart';
import '../../expense_request/services/share_service.dart';
import '../../settings/services/settings_store.dart';
import '../../settings/models/template_configuration.dart';
import '../../settings/models/app_settings.dart';
import '../../settings/screens/settings_screen.dart';
import '../../settings/screens/template_preview_screen.dart';

class InternalMemoScreen extends StatefulWidget {
  const InternalMemoScreen({
    super.key,
    this.initialRequest,
    this.initialLayout = InternalMemoLayout.fullA4,
    this.editingIndex,
  });

  final ExpenseRequest? initialRequest;
  // Kept for source compatibility with old navigation callers. New memos
  // always use the full A4 layout.
  final InternalMemoLayout initialLayout;
  final int? editingIndex;

  @override
  State<InternalMemoScreen> createState() => _InternalMemoScreenState();
}

class _InternalMemoScreenState extends State<InternalMemoScreen> {
  final _formKey = GlobalKey<FormState>();
  final _receiver = TextEditingController();
  final _date = TextEditingController();
  final _statement = TextEditingController();
  final _requester = TextEditingController();
  bool _busy = false;
  bool _requesterFieldInitialized = false;
  List<String> _attachmentPaths = [];
  AppSettings _settings = AppSettings.defaults();
  Timer? _deleteRepeatTimer;

  @override
  void initState() {
    super.initState();
    final request = widget.initialRequest;
    _date.text = request == null
        ? _formatDate(DateTime.now())
        : (DateFormatter.parse(request.date) == null
              ? request.date
              : DateFormatter.date(DateFormatter.parse(request.date)!));
    _receiver.text = request?.receiver ?? '';
    _statement.text = request?.statement ?? '';
    _requester.text = request?.requesterName ?? '';
    _attachmentPaths = request?.allAttachmentPaths ?? const [];
    SettingsStore.load(scope: 'internalMemo').then((settings) {
      final snapshot = widget.initialRequest?.settingsSnapshot;
      final effective = snapshot == null || snapshot.isEmpty
          ? settings
          : AppSettings.fromMap(snapshot);
      if (mounted) setState(() => _settings = effective);
    });
  }

  Future<void> _openSettings() async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) =>
            const SettingsScreen(templateKind: TemplateKind.internalMemo),
      ),
    );
    if (!mounted) return;
    final settings = await SettingsStore.load(scope: 'internalMemo');
    setState(() => _settings = settings);
  }

  @override
  void dispose() {
    _deleteRepeatTimer?.cancel();
    _receiver.dispose();
    _date.dispose();
    _statement.dispose();
    _requester.dispose();
    super.dispose();
  }

  String _formatDate(DateTime value) => DateFormatter.date(value);

  ExpenseRequest _collect() {
    final previous = widget.initialRequest;
    return ExpenseRequest(
      date: _date.text.trim(),
      receiver: _receiver.text.trim(),
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: _statement.text.trim(),
      branch: '',
      account: '',
      requesterName: _requester.text.trim(),
      requesterSignature: '',
      directManagerName: '',
      directManagerSignature: '',
      approvedAuthorityName: '',
      approvedAuthoritySignature: '',
      accountsManagerName: '',
      accountsManagerSignature: '',
      // Preserve legacy metadata when editing an old record. New memos are
      // always one A4 page and never expose a second copy in the new UX.
      customFields: previous?.customFields ?? const {},
      formCount: previous?.formCount ?? 1,
      secondRequest: previous?.secondRequest,
      isFavorite: previous?.isFavorite ?? false,
      attachmentPath: previous?.attachmentPath,
      attachmentPaths: _attachmentPaths,
      documentType: ExpenseDocumentType.internalMemo,
      memoLayout: InternalMemoLayout.fullA4,
      settingsSnapshot: _settings.toMap(),
    );
  }

  Future<void> _removeAttachment(String path) async {
    await AttachmentManager.deleteAttachment(
      path,
      activeRequests: await RequestStore.load(),
    );
  }

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final request = _collect();
    bool saved;
    if (widget.editingIndex == null) {
      saved = await RequestStore.add(request);
    } else {
      saved = await RequestStore.updateAt(widget.editingIndex!, request);
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          !saved
              ? 'لم يتم الحفظ: هذه المذكرة مطابقة لمذكرة محفوظة سابقًا'
              : widget.editingIndex == null
              ? 'تم حفظ المذكرة الداخلية A4'
              : 'تم تحديث المذكرة الداخلية A4',
        ),
      ),
    );
  }

  Future<void> _copyStatement() async {
    await Clipboard.setData(ClipboardData(text: _statement.text));
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('تم نسخ البيان')));
    }
  }

  Future<void> _pasteStatement() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text == null) return;
    _statement.text = data!.text!;
    if (mounted) setState(() {});
  }

  Future<void> _insertQuickStatement() async {
    final selected = await showQuickStatementPicker(
      context,
      scope: 'internalMemo',
      query: _statement.text,
    );
    if (selected == null || !mounted) return;
    final value = _statement.value;
    final selection = value.selection;
    final start = selection.isValid ? selection.start : value.text.length;
    final end = selection.isValid ? selection.end : value.text.length;
    final safeStart = start.clamp(0, value.text.length).toInt();
    final safeEnd = end.clamp(safeStart, value.text.length).toInt();
    _statement.value = value.copyWith(
      text: value.text.replaceRange(safeStart, safeEnd, selected),
      selection: TextSelection.collapsed(offset: safeStart + selected.length),
    );
    setState(() {});
  }

  void _clearStatement() {
    _statement.clear();
    if (mounted) setState(() {});
  }

  void _deleteStatementBackward() {
    final value = _statement.value;
    final selection = value.selection;
    if (!selection.isValid) return;
    if (!selection.isCollapsed) {
      _statement.value = value.copyWith(
        text: value.text.replaceRange(selection.start, selection.end, ''),
        selection: TextSelection.collapsed(offset: selection.start),
      );
    } else if (selection.start > 0) {
      final start = selection.start - 1;
      _statement.value = value.copyWith(
        text: value.text.replaceRange(start, selection.start, ''),
        selection: TextSelection.collapsed(offset: start),
      );
    }
    if (mounted) setState(() {});
  }

  void _deleteStatementForward() {
    final value = _statement.value;
    final selection = value.selection;
    if (!selection.isValid) return;
    if (!selection.isCollapsed) {
      _statement.value = value.copyWith(
        text: value.text.replaceRange(selection.start, selection.end, ''),
        selection: TextSelection.collapsed(offset: selection.start),
      );
    } else if (selection.start < value.text.length) {
      _statement.value = value.copyWith(
        text: value.text.replaceRange(selection.start, selection.start + 1, ''),
        selection: selection,
      );
    }
    if (mounted) setState(() {});
  }

  void _startDeleteRepeat({required bool forward}) {
    _deleteRepeatTimer?.cancel();
    (forward ? _deleteStatementForward : _deleteStatementBackward)();
    Future<void>.delayed(const Duration(milliseconds: 280), () {
      if (!mounted) return;
      _deleteRepeatTimer = Timer.periodic(const Duration(milliseconds: 75), (
        _,
      ) {
        (forward ? _deleteStatementForward : _deleteStatementBackward)();
      });
    });
  }

  void _stopDeleteRepeat() {
    _deleteRepeatTimer?.cancel();
    _deleteRepeatTimer = null;
  }

  Future<void> _insertStatementDate() async {
    final selected = await showDatePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      initialDate: DateTime.now(),
    );
    if (selected == null || !mounted) return;
    final date = DateFormatter.date(selected);
    final value = _statement.value;
    final selection = value.selection;
    final start = selection.isValid ? selection.start : value.text.length;
    final end = selection.isValid ? selection.end : value.text.length;
    final safeStart = start.clamp(0, value.text.length).toInt();
    final safeEnd = end.clamp(safeStart, value.text.length).toInt();
    _statement.value = value.copyWith(
      text: value.text.replaceRange(safeStart, safeEnd, date),
      selection: TextSelection.collapsed(offset: safeStart + date.length),
    );
    setState(() {});
  }

  Future<void> _chooseOtherReceiver() async {
    final controller = TextEditingController(
      text: _receiver.text == 'أخرى' ? '' : _receiver.text,
    );
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('إدخال المقدم إليه'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'الاسم'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text.trim()),
            child: const Text('اعتماد'),
          ),
        ],
      ),
    );
    controller.dispose();
    if (value != null && value.isNotEmpty && mounted) {
      setState(() => _receiver.text = value);
    }
  }

  Future<void> _rememberRequester(String value) async {
    final clean = value.trim();
    if (clean.isEmpty || _settings.requesterHistory.contains(clean)) return;
    final updated = _settings.copyWith(
      requesterHistory: [
        clean,
        ..._settings.requesterHistory,
      ].take(30).toList(),
    );
    await SettingsStore.save(updated, scope: 'internalMemo');
    if (mounted) setState(() => _settings = updated);
  }

  Widget _receiverField() {
    final options = <String>{..._settings.receiverOptions, 'أخرى'};
    final current = options.contains(_receiver.text) ? _receiver.text : null;
    return DropdownButtonFormField<String>(
      initialValue: current,
      decoration: _decoration('المقدم إليه'),
      items: options
          .map((item) => DropdownMenuItem(value: item, child: Text(item)))
          .toList(),
      onChanged: (value) {
        if (value == 'أخرى') {
          _chooseOtherReceiver();
        } else if (value != null) {
          setState(() => _receiver.text = value);
        }
      },
      validator: (_) =>
          _receiver.text.trim().isEmpty ? 'أدخل المقدم إليه' : null,
    );
  }

  Widget _requesterField() {
    return Autocomplete<String>(
      optionsBuilder: (value) {
        final query = value.text.trim();
        return _settings.requesterHistory.where(
          (name) => query.isEmpty || name.contains(query),
        );
      },
      onSelected: (value) => setState(() => _requester.text = value),
      fieldViewBuilder: (context, controller, focusNode, onSubmitted) {
        if (!_requesterFieldInitialized || controller.text != _requester.text) {
          controller.value = TextEditingValue(
            text: _requester.text,
            selection: TextSelection.collapsed(offset: _requester.text.length),
          );
          _requesterFieldInitialized = true;
        }
        return TextFormField(
          controller: controller,
          focusNode: focusNode,
          decoration: _decoration('اسم مقدم الطلب'),
          onChanged: (value) => _requester.text = value,
          validator: (_) =>
              _requester.text.trim().isEmpty ? 'أدخل اسم مقدم الطلب' : null,
          onFieldSubmitted: (_) => _rememberRequester(controller.text),
        );
      },
    );
  }

  Future<void> _savePdfAs() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() => _busy = true);
    try {
      final bytes = await PdfService.buildRequestPdf(
        _collect(),
        settings: _settings,
      );
      final path = await FilePicker.saveFile(
        dialogTitle: 'حفظ مذكرة PDF',
        fileName: 'internal_memo_a4.pdf',
        type: FileType.custom,
        allowedExtensions: ['pdf'],
        bytes: bytes,
      );
      if (mounted && path != null) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('تم حفظ ملف المذكرة A4')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _clearForm() {
    _receiver.clear();
    _date.clear();
    _statement.clear();
    _requester.clear();
    setState(() {});
  }

  Future<void> _openPositionEditor() async {
    final updated = await Navigator.of(context).push<AppSettings>(
      MaterialPageRoute<AppSettings>(
        builder: (_) => TemplatePreviewScreen(
          settings: _settings,
          templateScope: 'internalMemo',
          editMemoA4: true,
          documentTitle: 'مذكرة داخلية A4',
        ),
      ),
    );
    if (updated == null || !mounted) return;
    await SettingsStore.save(updated, scope: 'internalMemo');
    setState(() => _settings = updated);
  }

  Future<void> _preview() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final request = _collect();
    if (!mounted) return;
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(
            title: const Text('معاينة مذكرة A4'),
            actions: [
              IconButton(
                tooltip: 'ضبط مواضع الحقول',
                onPressed: _openPositionEditor,
                icon: const Icon(Icons.open_with_outlined),
              ),
            ],
          ),
          body: PdfPreview(
            canChangePageFormat: false,
            canChangeOrientation: false,
            build: (format) =>
                PdfService.buildRequestPdf(request, settings: _settings),
          ),
        ),
      ),
    );
  }

  Future<void> _output({required bool print}) async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() => _busy = true);
    try {
      final bytes = await PdfService.buildRequestPdf(
        _collect(),
        settings: _settings,
      );
      if (print) {
        await ShareService.printPdf(bytes, filename: 'internal_memo_a4.pdf');
      } else {
        await ShareService.sharePdf(
          bytes: bytes,
          filename: 'internal_memo_a4.pdf',
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  InputDecoration _decoration(String label) =>
      InputDecoration(labelText: label);

  Widget _statementTools() {
    return Wrap(
      spacing: 6,
      children: [
        IconButton(
          tooltip: 'عبارات سريعة',
          visualDensity: VisualDensity.compact,
          onPressed: _insertQuickStatement,
          icon: const Icon(Icons.bolt_outlined),
        ),
        IconButton(
          tooltip: 'إدراج تاريخ في موضع المؤشر',
          visualDensity: VisualDensity.compact,
          onPressed: _insertStatementDate,
          icon: const Icon(Icons.calendar_month_outlined),
        ),
        GestureDetector(
          onLongPressStart: (_) => _startDeleteRepeat(forward: false),
          onLongPressEnd: (_) => _stopDeleteRepeat(),
          onLongPressCancel: _stopDeleteRepeat,
          child: IconButton(
            tooltip: 'حذف للخلف',
            visualDensity: VisualDensity.compact,
            onPressed: _deleteStatementBackward,
            icon: const Icon(Icons.backspace_outlined),
          ),
        ),
        GestureDetector(
          onLongPressStart: (_) => _startDeleteRepeat(forward: true),
          onLongPressEnd: (_) => _stopDeleteRepeat(),
          onLongPressCancel: _stopDeleteRepeat,
          child: IconButton(
            tooltip: 'حذف للأمام',
            visualDensity: VisualDensity.compact,
            onPressed: _deleteStatementForward,
            icon: const Icon(Icons.delete_sweep_outlined),
          ),
        ),
        IconButton(
          tooltip: 'تصفير البيان',
          onPressed: _clearStatement,
          icon: const Icon(Icons.clear_all),
        ),
        IconButton(
          tooltip: 'نسخ البيان',
          onPressed: _copyStatement,
          icon: const Icon(Icons.copy_outlined),
        ),
        IconButton(
          tooltip: 'لصق البيان',
          onPressed: _pasteStatement,
          icon: const Icon(Icons.content_paste_outlined),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('مذكرة داخلية A4'),
        actions: [
          IconButton(
            tooltip: 'إعدادات المذكرة الداخلية',
            onPressed: _busy ? null : _openSettings,
            icon: const Icon(Icons.settings_outlined),
          ),
          IconButton(
            tooltip: 'معاينة المذكرة',
            onPressed: _busy ? null : _preview,
            icon: const Icon(Icons.preview_outlined),
          ),
          IconButton(
            tooltip: 'ضبط مواضع الحقول',
            onPressed: _busy ? null : _openPositionEditor,
            icon: const Icon(Icons.open_with_outlined),
          ),
          IconButton(
            tooltip: 'تفريغ المذكرة',
            onPressed: _busy ? null : _clearForm,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Card(
              child: ListTile(
                leading: Icon(Icons.description_outlined),
                title: Text('مذكرة داخلية — A4 كاملة'),
                subtitle: Text(
                  'A4 Portrait • صفحة واحدة • 595.28 × 841.89 نقطة',
                ),
              ),
            ),
            const SizedBox(height: 12),
            _receiverField(),
            const SizedBox(height: 12),
            TextFormField(
              controller: _date,
              decoration: _decoration('التاريخ'),
              validator: (value) =>
                  value == null || value.trim().isEmpty ? 'أدخل التاريخ' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _statement,
              minLines: 5,
              maxLines: 12,
              decoration: _decoration('البيان'),
              buildCounter:
                  (
                    context, {
                    required currentLength,
                    maxLength,
                    required isFocused,
                  }) => Text(
                    '$currentLength حرفًا • ${RegExp(r' ').allMatches(_statement.text).length} مسافة',
                  ),
              validator: (value) =>
                  value == null || value.trim().isEmpty ? 'أدخل البيان' : null,
            ),
            _statementTools(),
            const SizedBox(height: 12),
            _requesterField(),
            AttachmentPickerField(
              paths: _attachmentPaths,
              onChanged: (paths) => setState(() => _attachmentPaths = paths),
              onRemove: _removeAttachment,
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: _busy ? null : _save,
              icon: const Icon(Icons.save_outlined),
              label: const Text('حفظ المذكرة'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _busy ? null : _savePdfAs,
              icon: const Icon(Icons.picture_as_pdf_outlined),
              label: const Text('حفظ PDF باسم'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _busy ? null : () => _output(print: false),
              icon: const Icon(Icons.share_outlined),
              label: const Text('مشاركة PDF'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _busy ? null : () => _output(print: true),
              icon: const Icon(Icons.print_outlined),
              label: const Text('طباعة PDF'),
            ),
          ],
        ),
      ),
    );
  }
}
