import 'package:flutter/material.dart';

import '../../../core/utils/date_formatter.dart';
import '../../../core/utils/number_normalizer.dart';
import '../models/finance_calculations.dart';
import '../services/finance_store.dart';

String _money(double value) => value.toStringAsFixed(2);
double _number(String value) => NumberNormalizer.parseDouble(value) ?? 0;

class SalaryCalculatorScreen extends StatefulWidget {
  const SalaryCalculatorScreen({super.key});
  @override
  State<SalaryCalculatorScreen> createState() => _SalaryCalculatorScreenState();
}

class _SalaryCalculatorScreenState extends State<SalaryCalculatorScreen> {
  final _basic = TextEditingController();
  final _allowances = TextEditingController();
  final _otherIncome = TextEditingController();
  final _insuranceBase = TextEditingController();
  final _insuranceRate = TextEditingController(text: '9');
  final _tax = TextEditingController();
  final _otherDeductions = TextEditingController();
  SalaryCalculation? _result;

  @override
  void dispose() {
    for (final item in [
      _basic,
      _allowances,
      _otherIncome,
      _insuranceBase,
      _insuranceRate,
      _tax,
      _otherDeductions,
    ]) {
      item.dispose();
    }
    super.dispose();
  }

  void _calculate() {
    final basic = _number(_basic.text);
    final base = _insuranceBase.text.trim().isEmpty
        ? basic
        : _number(_insuranceBase.text);
    setState(
      () => _result = SalaryCalculation(
        basic: basic,
        allowances: _number(_allowances.text),
        otherIncome: _number(_otherIncome.text),
        insuranceBase: base,
        insuranceRate: _number(_insuranceRate.text),
        tax: _number(_tax.text),
        otherDeductions: _number(_otherDeductions.text),
      ),
    );
  }

  Widget _field(
    String label,
    TextEditingController controller, {
    String? hint,
  }) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: TextField(
      controller: controller,
      inputFormatters: [ThousandsSeparatorInputFormatter()],
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: const Icon(Icons.payments_outlined),
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final result = _result;
    return Scaffold(
      appBar: AppBar(title: const Text('حاسبة صافي الراتب والبدلات')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'أدخل القيم الفعلية؛ النسب والضريبة قابلة للتعديل حسب نظام جهة العمل.',
            style: TextStyle(color: Colors.grey),
          ),
          const SizedBox(height: 12),
          _field('الراتب الأساسي', _basic),
          _field('البدلات', _allowances),
          _field('دخل إضافي', _otherIncome),
          _field(
            'وعاء التأمينات',
            _insuranceBase,
            hint: 'اتركه فارغًا لاستخدام الأساسي',
          ),
          _field('نسبة التأمينات %', _insuranceRate),
          _field('الضريبة', _tax),
          _field('خصومات أخرى', _otherDeductions),
          FilledButton.icon(
            onPressed: _calculate,
            icon: const Icon(Icons.calculate),
            label: const Text('احتساب صافي الراتب'),
          ),
          if (result != null) ...[
            const SizedBox(height: 18),
            Card(
              color: Theme.of(context).colorScheme.primaryContainer,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      'صافي الراتب: ${_money(result.net)}',
                      style: Theme.of(context).textTheme.headlineSmall
                          ?.copyWith(fontWeight: FontWeight.bold),
                    ),
                    const Divider(),
                    Text('إجمالي الراتب: ${_money(result.gross)}'),
                    Text('التأمينات: ${_money(result.insurance)}'),
                    Text('الضريبة: ${_money(result.tax)}'),
                    Text('إجمالي الخصومات: ${_money(result.totalDeductions)}'),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class AdvanceCalculatorScreen extends StatefulWidget {
  const AdvanceCalculatorScreen({super.key});
  @override
  State<AdvanceCalculatorScreen> createState() =>
      _AdvanceCalculatorScreenState();
}

class _AdvanceCalculatorScreenState extends State<AdvanceCalculatorScreen> {
  final _amount = TextEditingController();
  final _reason = TextEditingController();
  final _months = TextEditingController(text: '1');
  String _type = 'مساعدة';
  String _frequency = 'monthly';
  DateTime _startDate = DateTime.now();
  AdvanceCalculation? _result;
  List<AdvanceCalculation> _saved = const [];

  static const _types = [
    'مساعدة',
    'سلفة سيارة',
    'تأمين سيارة',
    'سلفة زواج',
    'سلفة هاتف',
    'سلفة دائمة',
    'أخرى',
  ];

  @override
  void initState() {
    super.initState();
    _loadSaved();
  }

  Future<void> _loadSaved() async {
    final values = await FinanceStore.loadAdvances();
    if (mounted) setState(() => _saved = values);
  }

  @override
  void dispose() {
    _amount.dispose();
    _reason.dispose();
    _months.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final value = await showDatePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      initialDate: _startDate,
    );
    if (value != null) setState(() => _startDate = value);
  }

  Future<void> _calculate({bool save = false}) async {
    final amount = _number(_amount.text);
    final months = (_number(_months.text).round()).clamp(1, 360);
    if (amount <= 0) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('أدخل مبلغ السلفة أولاً')));
      return;
    }
    final isPermanent = _type == 'سلفة دائمة';
    final result = AdvanceCalculation(
      amount: amount,
      type: _type,
      reason: _reason.text.trim(),
      startDate: isPermanent
          ? DateTime(DateTime.now().year, DateTime.now().month)
          : _startDate,
      months: months,
      frequency: isPermanent ? 'monthly' : _frequency,
    );
    setState(() => _result = result);
    if (save) {
      final values = [result, ..._saved].take(30).toList();
      await FinanceStore.saveAdvances(values);
      if (mounted) setState(() => _saved = values);
    }
  }

  String _date(DateTime value) => DateFormatter.date(value);

  @override
  Widget build(BuildContext context) {
    final result = _result;
    return Scaffold(
      appBar: AppBar(title: const Text('حاسبة السلف والأقساط')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          DropdownButtonFormField<String>(
            initialValue: _type,
            decoration: const InputDecoration(
              labelText: 'نوع السلفة',
              prefixIcon: Icon(Icons.category_outlined),
            ),
            items: _types
                .map((item) => DropdownMenuItem(value: item, child: Text(item)))
                .toList(),
            onChanged: (value) => setState(() {
              _type = value ?? _types.first;
              if (_type == 'سلفة دائمة') _frequency = 'monthly';
            }),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _amount,
            inputFormatters: [ThousandsSeparatorInputFormatter()],
            keyboardType: const TextInputType.numberWithOptions(decimal: true),
            decoration: const InputDecoration(
              labelText: 'مبلغ السلفة',
              prefixIcon: Icon(Icons.account_balance_wallet_outlined),
            ),
          ),
          const SizedBox(height: 10),
          if (_type == 'سلفة دائمة' || _type == 'أخرى')
            TextField(
              controller: _reason,
              decoration: const InputDecoration(
                labelText: 'سبب السلفة',
                hintText: 'زواج، شراء سيارة، هاتف أو سبب آخر',
                prefixIcon: Icon(Icons.edit_note_outlined),
              ),
            ),
          if (_type == 'سلفة دائمة' || _type == 'أخرى')
            const SizedBox(height: 10),
          if (_type == 'سلفة دائمة')
            const ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.repeat_outlined),
              title: Text('طريقة الخصم'),
              subtitle: Text('شهريًا'),
            )
          else
            DropdownButtonFormField<String>(
              initialValue: _frequency,
              decoration: const InputDecoration(
                labelText: 'طريقة الخصم',
                prefixIcon: Icon(Icons.repeat_outlined),
              ),
              items: const [
                DropdownMenuItem(value: 'monthly', child: Text('شهريًا')),
                DropdownMenuItem(
                  value: 'halfMonthly',
                  child: Text('نصف شهرية'),
                ),
              ],
              onChanged: (value) =>
                  setState(() => _frequency = value ?? 'monthly'),
            ),
          const SizedBox(height: 10),
          TextField(
            controller: _months,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'عدد أشهر السداد',
              prefixIcon: Icon(Icons.date_range_outlined),
            ),
          ),
          if (_type != 'سلفة دائمة')
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.event_outlined),
              title: const Text('بداية الخصم'),
              subtitle: Text(_date(_startDate)),
              onTap: _pickDate,
            ),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: () => _calculate(),
                  icon: const Icon(Icons.calculate),
                  label: const Text('احتساب'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () => _calculate(save: true),
                  icon: const Icon(Icons.save_outlined),
                  label: const Text('احتساب وحفظ'),
                ),
              ),
            ],
          ),
          if (result != null) ...[
            const SizedBox(height: 18),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      '${result.type} — ${_money(result.amount)}',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    if (result.reason.isNotEmpty)
                      Text('السبب: ${result.reason}'),
                    Text(
                      'قسط الخصم: ${_money(result.installment)} ${result.frequency == 'halfMonthly' ? 'كل نصف شهر' : 'شهريًا'}',
                    ),
                    const SizedBox(height: 10),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: DataTable(
                        columns: const [
                          DataColumn(label: Text('#')),
                          DataColumn(label: Text('التاريخ')),
                          DataColumn(label: Text('القسط')),
                          DataColumn(label: Text('المتبقي')),
                        ],
                        rows: result.schedule
                            .map(
                              (item) => DataRow(
                                cells: [
                                  DataCell(Text('${item.number}')),
                                  DataCell(Text(_date(item.date))),
                                  DataCell(Text(_money(item.amount))),
                                  DataCell(Text(_money(item.remaining))),
                                ],
                              ),
                            )
                            .toList(),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
          if (_saved.isNotEmpty) ...[
            const SizedBox(height: 22),
            Text(
              'السلف المحفوظة',
              style: Theme.of(
                context,
              ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
            ),
            ..._saved.map(
              (item) => ListTile(
                dense: true,
                leading: const Icon(Icons.receipt_long_outlined),
                title: Text('${item.type} — ${_money(item.amount)}'),
                subtitle: Text(
                  '${item.reason.isEmpty ? 'بدون سبب' : item.reason} • ${item.months} أشهر',
                ),
                onTap: () => setState(() => _result = item),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
