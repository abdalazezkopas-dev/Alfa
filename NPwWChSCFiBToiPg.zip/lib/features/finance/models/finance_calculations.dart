class SalaryCalculation {
  const SalaryCalculation({
    required this.basic,
    required this.allowances,
    required this.otherIncome,
    required this.insuranceBase,
    required this.insuranceRate,
    required this.tax,
    required this.otherDeductions,
  });

  final double basic;
  final double allowances;
  final double otherIncome;
  final double insuranceBase;
  final double insuranceRate;
  final double tax;
  final double otherDeductions;

  double get gross => basic + allowances + otherIncome;
  double get insurance => insuranceBase * insuranceRate / 100;
  double get totalDeductions => insurance + tax + otherDeductions;
  double get net => gross - totalDeductions;

  Map<String, Object?> toMap() => {
    'basic': basic,
    'allowances': allowances,
    'otherIncome': otherIncome,
    'insuranceBase': insuranceBase,
    'insuranceRate': insuranceRate,
    'tax': tax,
    'otherDeductions': otherDeductions,
  };
}

class AdvanceInstallment {
  const AdvanceInstallment({
    required this.number,
    required this.date,
    required this.amount,
    required this.remaining,
  });
  final int number;
  final DateTime date;
  final double amount;
  final double remaining;
}

class AdvanceCalculation {
  const AdvanceCalculation({
    required this.amount,
    required this.type,
    required this.reason,
    required this.startDate,
    required this.months,
    required this.frequency,
  });

  final double amount;
  final String type;
  final String reason;
  final DateTime startDate;
  final int months;
  final String frequency;

  int get installmentCount => frequency == 'halfMonthly' ? months * 2 : months;
  double get installment => amount / installmentCount;

  List<AdvanceInstallment> get schedule {
    final result = <AdvanceInstallment>[];
    var remaining = amount;
    for (var i = 0; i < installmentCount; i++) {
      final value = i == installmentCount - 1 ? remaining : installment;
      remaining = (remaining - value).clamp(0, amount).toDouble();
      final date = frequency == 'halfMonthly'
          ? DateTime(
              startDate.year,
              startDate.month + (i ~/ 2),
              i.isEven ? 1 : 15,
            )
          : DateTime(startDate.year, startDate.month + i, startDate.day);
      result.add(
        AdvanceInstallment(
          number: i + 1,
          date: date,
          amount: value,
          remaining: remaining,
        ),
      );
    }
    return result;
  }

  Map<String, Object?> toMap() => {
    'amount': amount,
    'type': type,
    'reason': reason,
    'startDate': startDate.toIso8601String(),
    'months': months,
    'frequency': frequency,
  };

  factory AdvanceCalculation.fromMap(Map<String, Object?> map) =>
      AdvanceCalculation(
        amount: (map['amount'] as num?)?.toDouble() ?? 0,
        type: map['type'] as String? ?? 'مساعدة',
        reason: map['reason'] as String? ?? '',
        startDate:
            DateTime.tryParse(map['startDate'] as String? ?? '') ??
            DateTime.now(),
        months: ((map['months'] as num?)?.toInt() ?? 1).clamp(1, 360),
        frequency: map['frequency'] as String? ?? 'monthly',
      );
}
