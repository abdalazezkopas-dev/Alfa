import 'dart:convert';

import '../../../core/security/input_limits.dart';
import '../../../core/security/secure_local_store.dart';
import '../../../core/store_mutex.dart';
import '../models/finance_calculations.dart';

class FinanceStore {
  const FinanceStore._();
  static const _key = 'finance.advances';
  static const _maxItems = 5000;

  static Future<List<AdvanceCalculation>> loadAdvances() =>
      StoreMutex.run(_key, () async {
        final raw = await SecureLocalStore.read(_key);
        if (raw == null || raw.isEmpty) return <AdvanceCalculation>[];
        final decoded = jsonDecode(raw);
        if (decoded is! List || decoded.length > _maxItems)
          throw const FormatException('تخزين السلف المالية غير صحيح');
        return decoded.map((item) => _decode(item)).toList();
      });

  static AdvanceCalculation _decode(Object? value) {
    if (value is! Map) throw const FormatException('سجل سلفة مالية تالف');
    final map = Map<String, Object?>.from(value);
    InputLimits.strictFiniteDouble(map['amount'], field: 'amount', min: 0);
    InputLimits.strictString(map['type'], field: 'type');
    InputLimits.strictString(map['reason'], field: 'reason');
    InputLimits.strictDateTime(map['startDate'], field: 'startDate');
    InputLimits.strictInteger(map['months'], field: 'months', min: 1, max: 360);
    InputLimits.strictString(map['frequency'], field: 'frequency');
    return AdvanceCalculation.fromMap(map);
  }

  static Future<void> saveAdvances(List<AdvanceCalculation> values) =>
      StoreMutex.run(_key, () async {
        if (values.length > _maxItems)
          throw const FormatException('عدد السلف يتجاوز الحد المسموح');
        for (final item in values) _decode(item.toMap());
        final encoded = jsonEncode(values.map((item) => item.toMap()).toList());
        jsonDecode(encoded);
        await SecureLocalStore.writeJson(
          _key,
          values.map((item) => item.toMap()).toList(),
        );
      });
}
