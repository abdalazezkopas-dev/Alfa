class ProductItem {
  const ProductItem({
    required this.id,
    required this.name,
    this.pharmaceuticalForm = '',
    this.strength = '',
    this.category = '',
    this.unit = '',
    this.notes = '',
    this.isActive = true,
  });

  final String id;
  final String name;
  final String pharmaceuticalForm;
  final String strength;
  final String category;
  final String unit;
  final String notes;
  final bool isActive;

  ProductItem copyWith({
    String? id,
    String? name,
    String? pharmaceuticalForm,
    String? strength,
    String? category,
    String? unit,
    String? notes,
    bool? isActive,
  }) => ProductItem(
    id: id ?? this.id,
    name: name ?? this.name,
    pharmaceuticalForm: pharmaceuticalForm ?? this.pharmaceuticalForm,
    strength: strength ?? this.strength,
    category: category ?? this.category,
    unit: unit ?? this.unit,
    notes: notes ?? this.notes,
    isActive: isActive ?? this.isActive,
  );

  Map<String, Object?> toMap() => {
    'id': id,
    'name': name,
    'pharmaceuticalForm': pharmaceuticalForm,
    'strength': strength,
    'category': category,
    'unit': unit,
    'notes': notes,
    'isActive': isActive,
  };

  factory ProductItem.fromMap(Map<String, Object?> map) => ProductItem(
    id: map['id']?.toString() ?? '',
    name: map['name']?.toString() ?? '',
    pharmaceuticalForm: map['pharmaceuticalForm']?.toString() ?? '',
    strength: map['strength']?.toString() ?? '',
    category: map['category']?.toString() ?? '',
    unit: map['unit']?.toString() ?? '',
    notes: map['notes']?.toString() ?? '',
    isActive: map['isActive'] != false,
  );
}
