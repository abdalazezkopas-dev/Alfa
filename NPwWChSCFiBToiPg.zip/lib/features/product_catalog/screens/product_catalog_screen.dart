import 'dart:typed_data';

import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

import '../models/product_item.dart';
import '../services/product_catalog_import_service.dart';
import '../services/product_catalog_store.dart';

class ProductCatalogScreen extends StatefulWidget {
  const ProductCatalogScreen({super.key});

  @override
  State<ProductCatalogScreen> createState() => _ProductCatalogScreenState();
}

class _ProductCatalogScreenState extends State<ProductCatalogScreen> {
  final _search = TextEditingController();
  List<ProductItem> _products = const [];
  bool _loading = true;
  String? _error;
  bool _operationBusy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (mounted) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final products = await ProductCatalogStore.load();
      if (!mounted) return;
      setState(() {
        _products = products;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'تعذر تحميل دليل الأصناف';
      });
    }
  }

  List<ProductItem> get _visibleProducts {
    final query = _search.text.trim().toLowerCase();
    return _products.where((item) {
      if (!item.isActive) return false;
      if (query.isEmpty) return true;
      return '${item.name} ${item.pharmaceuticalForm} ${item.strength} ${item.category}'
          .toLowerCase()
          .contains(query);
    }).toList();
  }

  Future<void> _editProduct({ProductItem? existing}) async {
    if (_operationBusy) return;
    final result = await showDialog<ProductItem>(
      context: context,
      builder: (_) => _ProductDialog(existing: existing),
    );
    if (result == null || !mounted) return;
    setState(() => _operationBusy = true);
    try {
      await ProductCatalogStore.upsert(result);
      if (mounted) await _load();
    } catch (_) {
      if (mounted) _showOperationError('تعذر حفظ الصنف');
    } finally {
      if (mounted) setState(() => _operationBusy = false);
    }
  }

  Future<void> _deactivateProduct(ProductItem item) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تعطيل الصنف؟'),
        content: Text(
          'سيختفي «${item.name}» من قائمة الاختيار، مع الحفاظ عليه داخل الطلبات السابقة.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('تعطيل'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted || _operationBusy) return;
    setState(() => _operationBusy = true);
    try {
      await ProductCatalogStore.deactivate(item.id);
      if (mounted) await _load();
    } catch (_) {
      if (mounted) _showOperationError('تعذر تعطيل الصنف');
    } finally {
      if (mounted) setState(() => _operationBusy = false);
    }
  }

  Future<void> _importExcel() async {
    final result = await FilePicker.pickFiles(
      dialogTitle: 'استيراد دليل الأصناف من Excel أو CSV',
      type: FileType.custom,
      allowedExtensions: ['xlsx', 'xls', 'csv'],
      withData: true,
    );
    if (!mounted) return;
    final file = result?.files.single;
    if (file == null || file.bytes == null) return;
    try {
      ProductCatalogImportService.ensureImportSize(file.bytes!);
    } catch (error) {
      _showOperationError(
        error.toString().replaceFirst('FormatException: ', ''),
      );
      return;
    }
    final bytes = Uint8List.fromList(file.bytes!);
    final isCsv = file.extension?.toLowerCase() == 'csv';
    try {
      final preview = isCsv
          ? ProductCatalogImportService.previewCsv(bytes, existing: _products)
          : ProductCatalogImportService.preview(bytes, existing: _products);
      if (!mounted || preview.headers.isEmpty) return;
      await _showImportPreview(bytes, preview, isCsv: isCsv);
    } catch (_) {
      if (mounted) _showOperationError('تعذر قراءة ملف الأصناف');
    }
  }

  Future<void> _exportExcel() async {
    try {
      final workbook = Excel.createExcel();
      final sheet = workbook[workbook.getDefaultSheet() ?? 'Sheet1'];
      sheet.appendRow(
        ProductCatalogImportService.fields.values
            .map(TextCellValue.new)
            .toList(),
      );
      for (final item in _products) {
        sheet.appendRow([
          TextCellValue(item.id),
          TextCellValue(item.name),
          TextCellValue(item.pharmaceuticalForm),
          TextCellValue(item.strength),
          TextCellValue(item.category),
          TextCellValue(item.unit),
          TextCellValue(item.notes),
        ]);
      }
      final bytes = workbook.encode();
      if (bytes == null || !mounted) return;
      await FilePicker.saveFile(
        dialogTitle: 'تصدير دليل الأصناف إلى Excel',
        fileName: 'دليل_الأصناف.xlsx',
        type: FileType.custom,
        allowedExtensions: ['xlsx'],
        bytes: Uint8List.fromList(bytes),
      );
    } catch (_) {
      if (mounted) _showOperationError('تعذر تصدير دليل الأصناف');
    }
  }

  Future<void> _showImportPreview(
    Uint8List bytes,
    ProductCatalogImportPreview preview, {
    required bool isCsv,
  }) async {
    final decision = await showDialog<_ImportDecision>(
      context: context,
      builder: (context) => _ImportPreviewDialog(
        bytes: bytes,
        initial: preview,
        existing: _products,
        isCsv: isCsv,
      ),
    );
    if (decision == null) return;
    final current = [..._products];
    for (final row in decision.preview.rows) {
      final product = row.product;
      if (!row.isValid || product == null) continue;
      if (row.duplicate && decision.mode == _DuplicateMode.skip) continue;
      final existingIndex = current.indexWhere(
        (item) =>
            ProductCatalogImportService.identityKey(item) ==
            ProductCatalogImportService.identityKey(product),
      );
      if (existingIndex >= 0 && decision.mode == _DuplicateMode.skip) continue;
      if (existingIndex >= 0) {
        current[existingIndex] = product.copyWith(
          id: current[existingIndex].id,
          isActive: current[existingIndex].isActive,
        );
      } else {
        current.add(product);
      }
    }
    if (!mounted || _operationBusy) return;
    setState(() => _operationBusy = true);
    try {
      await ProductCatalogStore.saveAll(current);
      if (mounted) await _load();
    } catch (_) {
      if (mounted) _showOperationError('تعذر حفظ الاستيراد');
    } finally {
      if (mounted) setState(() => _operationBusy = false);
    }
  }

  void _showOperationError(String message) {
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('دليل الأصناف')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _operationBusy ? null : () => _editProduct(),
        icon: const Icon(Icons.add),
        label: const Text('إضافة صنف'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(_error!),
                  const SizedBox(height: 8),
                  FilledButton(
                    onPressed: _load,
                    child: const Text('إعادة المحاولة'),
                  ),
                ],
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text(
                  'أدر الأصناف مرة واحدة ثم اخترها بسرعة عند إنشاء نموذج طلب العينات.',
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _search,
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(
                    labelText: 'بحث في دليل الأصناف',
                    prefixIcon: Icon(Icons.search),
                  ),
                ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: _operationBusy ? null : _importExcel,
                  icon: const Icon(Icons.upload_file_outlined),
                  label: const Text('استيراد من Excel أو CSV'),
                ),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  onPressed: _operationBusy ? null : _exportExcel,
                  icon: const Icon(Icons.download_outlined),
                  label: const Text('تصدير الكتالوج إلى Excel'),
                ),
                const SizedBox(height: 12),
                if (_visibleProducts.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 32),
                    child: Center(child: Text('لا توجد أصناف مطابقة')),
                  ),
                ..._visibleProducts.map(
                  (item) => Card(
                    child: ListTile(
                      title: Text(item.name),
                      subtitle: Text(
                        [
                          item.pharmaceuticalForm,
                          item.strength,
                          item.category,
                        ].where((value) => value.trim().isNotEmpty).join(' — '),
                      ),
                      trailing: Wrap(
                        spacing: 4,
                        children: [
                          IconButton(
                            tooltip: 'تعديل',
                            onPressed: _operationBusy
                                ? null
                                : () => _editProduct(existing: item),
                            icon: const Icon(Icons.edit_outlined),
                          ),
                          IconButton(
                            tooltip: 'تعطيل',
                            onPressed: _operationBusy
                                ? null
                                : () => _deactivateProduct(item),
                            icon: const Icon(Icons.delete_outline),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

enum _DuplicateMode { skip, update }

class _ImportDecision {
  const _ImportDecision(this.preview, this.mode);
  final ProductCatalogImportPreview preview;
  final _DuplicateMode mode;
}

class _ImportPreviewDialog extends StatefulWidget {
  const _ImportPreviewDialog({
    required this.bytes,
    required this.initial,
    required this.existing,
    required this.isCsv,
  });

  final Uint8List bytes;
  final ProductCatalogImportPreview initial;
  final List<ProductItem> existing;
  final bool isCsv;

  @override
  State<_ImportPreviewDialog> createState() => _ImportPreviewDialogState();
}

class _ImportPreviewDialogState extends State<_ImportPreviewDialog> {
  late ProductCatalogImportPreview _preview;
  late Map<String, String> _mapping;
  late String? _selectedSheet;

  @override
  void initState() {
    super.initState();
    _preview = widget.initial;
    _mapping = {...widget.initial.columnMap};
    _selectedSheet = widget.initial.selectedSheet;
  }

  void _changeMapping(String field, String? header) {
    final next = {..._mapping};
    if (header == null || header.isEmpty) {
      next.remove(field);
    } else {
      next[field] = header;
    }
    setState(() {
      _mapping = next;
      _preview = widget.isCsv
          ? ProductCatalogImportService.previewCsv(
              widget.bytes,
              existing: widget.existing,
              columnMapOverride: next,
            )
          : ProductCatalogImportService.preview(
              widget.bytes,
              existing: widget.existing,
              sheetName: _selectedSheet,
              columnMapOverride: next,
            );
    });
  }

  void _changeSheet(String? sheet) {
    if (sheet == null || widget.isCsv) return;
    setState(() {
      _selectedSheet = sheet;
      _preview = ProductCatalogImportService.preview(
        widget.bytes,
        existing: widget.existing,
        sheetName: sheet,
        columnMapOverride: _mapping,
      );
      _mapping = {..._preview.columnMap};
    });
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.isCsv ? 'معاينة CSV' : 'معاينة ومطابقة أعمدة Excel'),
      content: SizedBox(
        width: 760,
        child: ListView(
          shrinkWrap: true,
          children: [
            const Text('راجع المطابقة قبل الحفظ ويمكنك تغيير أي عمود يدويًا.'),
            const SizedBox(height: 8),
            if (!widget.isCsv && _preview.sheetNames.length > 1)
              DropdownButtonFormField<String>(
                initialValue: _selectedSheet,
                decoration: const InputDecoration(labelText: 'ورقة العمل'),
                items: _preview.sheetNames
                    .map(
                      (sheet) =>
                          DropdownMenuItem(value: sheet, child: Text(sheet)),
                    )
                    .toList(),
                onChanged: _changeSheet,
              ),
            ...ProductCatalogImportService.fields.entries.map(
              (entry) => DropdownButtonFormField<String>(
                initialValue: _mapping[entry.key],
                decoration: InputDecoration(labelText: entry.value),
                items: [
                  const DropdownMenuItem<String>(
                    value: '',
                    child: Text('غير مربوط'),
                  ),
                  ..._preview.headers.map(
                    (header) => DropdownMenuItem<String>(
                      value: header,
                      child: Text(header.isEmpty ? 'عمود بلا عنوان' : header),
                    ),
                  ),
                ],
                onChanged: (value) => _changeMapping(entry.key, value),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'صالح: ${_preview.validCount} — مكرر: ${_preview.duplicateCount} — أخطاء: ${_preview.errorCount}',
            ),
            ..._preview.rows
                .take(12)
                .map(
                  (row) => ListTile(
                    dense: true,
                    leading: Icon(
                      row.error != null
                          ? Icons.error_outline
                          : row.duplicate
                          ? Icons.warning_amber_outlined
                          : Icons.check_circle_outline,
                    ),
                    title: Text(row.product?.name ?? 'صف ${row.rowNumber}'),
                    subtitle: Text(
                      row.error ??
                          (row.duplicate ? 'صنف مكرر' : 'جاهز للاستيراد'),
                    ),
                  ),
                ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('إلغاء'),
        ),
        OutlinedButton(
          onPressed: () => Navigator.pop(
            context,
            _ImportDecision(_preview, _DuplicateMode.skip),
          ),
          child: const Text('تجاهل المكرر'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(
            context,
            _ImportDecision(_preview, _DuplicateMode.update),
          ),
          child: const Text('تحديث المكرر'),
        ),
      ],
    );
  }
}

class _ProductDialog extends StatefulWidget {
  const _ProductDialog({this.existing});
  final ProductItem? existing;

  @override
  State<_ProductDialog> createState() => _ProductDialogState();
}

class _ProductDialogState extends State<_ProductDialog> {
  late final TextEditingController _name;
  late final TextEditingController _form;
  late final TextEditingController _strength;
  late final TextEditingController _category;
  late final TextEditingController _unit;
  late final TextEditingController _notes;

  @override
  void initState() {
    super.initState();
    final item = widget.existing;
    _name = TextEditingController(text: item?.name);
    _form = TextEditingController(text: item?.pharmaceuticalForm);
    _strength = TextEditingController(text: item?.strength);
    _category = TextEditingController(text: item?.category);
    _unit = TextEditingController(text: item?.unit);
    _notes = TextEditingController(text: item?.notes);
  }

  @override
  void dispose() {
    for (final controller in [
      _name,
      _form,
      _strength,
      _category,
      _unit,
      _notes,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.existing == null ? 'إضافة صنف جديد' : 'تعديل الصنف'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _field(_name, 'اسم الصنف *'),
            _field(_form, 'الشكل الصيدلاني'),
            _field(_strength, 'التركيز / الوصف'),
            _field(_category, 'التصنيف'),
            _field(_unit, 'الوحدة'),
            _field(_notes, 'ملاحظات'),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('إلغاء'),
        ),
        FilledButton(
          onPressed: () {
            if (_name.text.trim().isEmpty) return;
            Navigator.pop(
              context,
              ProductItem(
                id:
                    widget.existing?.id ??
                    'manual-${DateTime.now().microsecondsSinceEpoch}',
                name: _name.text.trim(),
                pharmaceuticalForm: _form.text.trim(),
                strength: _strength.text.trim(),
                category: _category.text.trim(),
                unit: _unit.text.trim(),
                notes: _notes.text.trim(),
                isActive: widget.existing?.isActive ?? true,
              ),
            );
          },
          child: const Text('حفظ'),
        ),
      ],
    );
  }

  Widget _field(TextEditingController controller, String label) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: TextField(
      controller: controller,
      decoration: InputDecoration(labelText: label),
    ),
  );
}
