import 'package:flutter/foundation.dart' show kDebugMode;
import 'package:flutter/material.dart';

import '../models/product_item.dart';
import '../services/product_catalog_store.dart';
import 'product_catalog_screen.dart';

class ProductPickerScreen extends StatefulWidget {
  const ProductPickerScreen({
    this.initialSelection = const [],
    this.maxItems = 53,
    this.availableProducts,
    super.key,
  });

  final List<ProductItem> initialSelection;
  final int maxItems;
  final List<ProductItem>? availableProducts;

  @override
  State<ProductPickerScreen> createState() => _ProductPickerScreenState();
}

class _ProductPickerScreenState extends State<ProductPickerScreen> {
  final _search = TextEditingController();
  final _productsScrollController = ScrollController();
  List<ProductItem> _products = const [];
  final List<ProductItem> _selected = [];
  bool _loading = true;
  String? _error;
  final GlobalKey _counterRowKey = GlobalKey();
  final GlobalKey _firstProductCardKey = GlobalKey();
  double? _measuredSpacing;
  bool _spacingMeasurementScheduled = false;

  @override
  void initState() {
    super.initState();
    _selected.addAll(widget.initialSelection);
    final availableProducts = widget.availableProducts;
    if (availableProducts != null) {
      _products = availableProducts.where((item) => item.isActive).toList();
      _loading = false;
    } else {
      _load();
    }
    _scheduleSpacingMeasurement();
  }

  @override
  void dispose() {
    _search.dispose();
    _productsScrollController.dispose();
    super.dispose();
  }

  void _resetProductsScroll() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted || !_productsScrollController.hasClients) return;
      _productsScrollController.jumpTo(0);
    });
  }

  void _scheduleSpacingMeasurement() {
    if (!kDebugMode || _spacingMeasurementScheduled) return;
    _spacingMeasurementScheduled = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _spacingMeasurementScheduled = false;
      if (!mounted) return;

      final counterObject = _counterRowKey.currentContext?.findRenderObject();
      final firstProductObject = _firstProductCardKey.currentContext
          ?.findRenderObject();
      if (counterObject is! RenderBox ||
          firstProductObject is! RenderBox ||
          !counterObject.hasSize ||
          !firstProductObject.hasSize) {
        return;
      }

      final counterBottom = counterObject
          .localToGlobal(Offset(0, counterObject.size.height))
          .dy;
      final firstProductTop = firstProductObject.localToGlobal(Offset.zero).dy;
      final spacing = firstProductTop - counterBottom;
      if (_measuredSpacing != null &&
          (_measuredSpacing! - spacing).abs() <= 0.5) {
        return;
      }

      setState(() => _measuredSpacing = spacing);
      debugPrint(
        'فحص المسافة بين العداد وأول صنف: '
        '${spacing.toStringAsFixed(1)} وحدة منطقية',
      );
    });
  }

  Future<void> _load() async {
    if (mounted) {
      setState(() {
        _loading = true;
        _error = null;
      });
    }
    try {
      final products = await ProductCatalogStore.load().timeout(
        const Duration(seconds: 10),
      );
      if (!mounted) return;
      setState(() {
        _products = products.where((item) => item.isActive).toList();
        _loading = false;
      });
      _resetProductsScroll();
      _scheduleSpacingMeasurement();
    } catch (error, stackTrace) {
      debugPrint('تعذر تحميل دليل الأصناف: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'تعذر تحميل دليل الأصناف';
      });
    }
  }

  List<ProductItem> get _filtered {
    final query = _search.text.trim().toLowerCase();
    if (query.isEmpty) return _products;
    return _products
        .where(
          (item) =>
              '${item.name} ${item.pharmaceuticalForm} ${item.strength} ${item.category}'
                  .toLowerCase()
                  .contains(query),
        )
        .toList();
  }

  bool _isSelected(ProductItem item) =>
      _selected.any((value) => value.id == item.id);

  void _setItemSelected(ProductItem item, bool selected) {
    if (selected == _isSelected(item)) return;
    if (!selected) {
      setState(() {
        _selected.removeWhere((value) => value.id == item.id);
      });
      return;
    }
    if (_selected.length >= widget.maxItems) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'لا يمكن اختيار أكثر من ${widget.maxItems} صنفًا في نموذج طلب العينات',
          ),
        ),
      );
      return;
    }
    setState(() => _selected.add(item));
  }

  void _toggleItem(ProductItem item, {bool? selected}) {
    _setItemSelected(item, selected ?? !_isSelected(item));
  }

  void _toggleSelectAllFiltered() {
    final filtered = _filtered;
    final allSelected = filtered.isNotEmpty && filtered.every(_isSelected);
    if (!allSelected &&
        _selected.length + filtered.where((item) => !_isSelected(item)).length >
            widget.maxItems) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'لا يمكن تجاوز الحد الأقصى وهو ${widget.maxItems} صنفًا',
          ),
        ),
      );
      return;
    }
    setState(() {
      if (allSelected) {
        final ids = filtered.map((item) => item.id).toSet();
        _selected.removeWhere((item) => ids.contains(item.id));
      } else {
        for (final item in filtered) {
          if (!_isSelected(item)) _selected.add(item);
        }
      }
    });
  }

  Future<void> _addProduct() async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(builder: (_) => const ProductCatalogScreen()),
    );
    await _load();
  }

  Future<void> _deleteSelectedFromCatalog() async {
    if (_selected.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('حدد صنفًا واحدًا على الأقل للحذف')),
      );
      return;
    }
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تعطيل الأصناف المحددة؟'),
        content: const Text(
          'ستختفي الأصناف من دليل الاختيار، مع الحفاظ عليها داخل الطلبات السابقة والنسخ الاحتياطية.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('تعطيل'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    for (final item in List<ProductItem>.from(_selected)) {
      await ProductCatalogStore.deactivate(item.id);
    }
    if (!mounted) return;
    setState(() {
      final ids = _selected.map((item) => item.id).toSet();
      _selected.removeWhere((item) => ids.contains(item.id));
    });
    await _load();
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم تعطيل الأصناف المحددة بأمان')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final filtered = _filtered;
    final allSelected = filtered.isNotEmpty && filtered.every(_isSelected);
    final controls = [
      OutlinedButton.icon(
        onPressed: filtered.isEmpty ? null : _toggleSelectAllFiltered,
        icon: Icon(
          allSelected ? Icons.deselect_outlined : Icons.select_all_outlined,
        ),
        label: Text(
          allSelected
              ? 'إلغاء تحديد النتائج'
              : 'تحديد النتائج (${filtered.length})',
        ),
      ),
      OutlinedButton.icon(
        onPressed: _selected.isEmpty ? null : () => setState(_selected.clear),
        icon: const Icon(Icons.clear_all_outlined),
        label: const Text('مسح التحديد'),
      ),
      OutlinedButton.icon(
        onPressed: _addProduct,
        icon: const Icon(Icons.add_box_outlined),
        label: const Text('إضافة صنف'),
      ),
      OutlinedButton.icon(
        onPressed: _selected.isEmpty ? null : _deleteSelectedFromCatalog,
        icon: const Icon(Icons.delete_outline),
        label: const Text('تعطيل المحدد'),
      ),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('إضافة أصناف طلب العينات'),
        leading: IconButton(
          tooltip: 'إلغاء',
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.close),
        ),
        actions: [
          IconButton(
            tooltip: 'حفظ الاختيار',
            onPressed: () =>
                Navigator.pop(context, List<ProductItem>.from(_selected)),
            icon: const Icon(Icons.save_outlined),
          ),
        ],
      ),
      floatingActionButton: _buildSpacingBadge(_measuredSpacing),
      body: Theme(
        data: Theme.of(context).copyWith(
          textTheme: Theme.of(
            context,
          ).textTheme.apply(letterSpacingFactor: 0.0),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: TextField(
                controller: _search,
                onChanged: (_) {
                  setState(() {});
                  _resetProductsScroll();
                  _scheduleSpacingMeasurement();
                },
                decoration: const InputDecoration(
                  labelText: 'ابحث باسم الصنف أو الشكل أو التصنيف',
                  prefixIcon: Icon(Icons.search),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: SizedBox(
                height: 48,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      for (final control in controls) ...[
                        control,
                        const SizedBox(width: 8),
                      ],
                    ],
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Row(
                key: kDebugMode ? _counterRowKey : null,
                children: [
                  Expanded(
                    child: Text(
                      'المحدد: ${_selected.length} من ${widget.maxItems}',
                    ),
                  ),
                  FilledButton.icon(
                    style: FilledButton.styleFrom(
                      minimumSize: const Size(0, 52),
                    ),
                    onPressed: () => Navigator.pop(
                      context,
                      List<ProductItem>.from(_selected),
                    ),
                    icon: const Icon(Icons.save_outlined, size: 18),
                    label: const Text('حفظ'),
                  ),
                ],
              ),
            ),
            Expanded(
              child: _loading
                  ? const Center(child: CircularProgressIndicator())
                  : _error != null
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(_error!),
                          const SizedBox(height: 8),
                          FilledButton(
                            onPressed: _load,
                            child: const Text('إعادة المحاولة'),
                          ),
                        ],
                      ),
                    )
                  : filtered.isEmpty
                  ? const Center(child: Text('لا توجد أصناف متاحة للاختيار'))
                  : ListView.builder(
                      controller: _productsScrollController,
                      primary: false,
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                      physics: const AlwaysScrollableScrollPhysics(),
                      itemCount: filtered.length,
                      itemBuilder: (context, index) {
                        final item = filtered[index];
                        final selected = _isSelected(item);
                        return Card(
                          key: kDebugMode && index == 0
                              ? _firstProductCardKey
                              : null,
                          child: CheckboxListTile(
                            key: ValueKey('product-checkbox-${item.id}'),
                            value: selected,
                            onChanged: (value) =>
                                _toggleItem(item, selected: value ?? false),
                            title: Text(item.name),
                            subtitle: Text(
                              [
                                    item.pharmaceuticalForm,
                                    item.strength,
                                    item.category,
                                  ]
                                  .where((value) => value.trim().isNotEmpty)
                                  .join(' — '),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget? _buildSpacingBadge(double? spacing) {
  if (!kDebugMode || spacing == null) return null;
  final isUnexpected = spacing < 0 || spacing > 16;
  return IgnorePointer(
    child: Material(
      color: isUnexpected ? Colors.red.shade700 : Colors.green.shade700,
      elevation: 6,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 280),
          child: Text(
            'المسافة بين العداد وأول صنف: '
            '${spacing.toStringAsFixed(1)} وحدة منطقية',
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: Colors.white, fontSize: 12),
          ),
        ),
      ),
    ),
  );
}
