import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/security/secure_local_store.dart';
import '../../../core/store_mutex.dart';
import '../data/default_product_catalog.dart';
import '../models/product_item.dart';

class ProductCatalogStore {
  ProductCatalogStore._();

  static const _secureKey = 'product_catalog';
  static const _legacyKey = 'alfa_expense_app.product_catalog.v1';
  static const _seedKey = 'alfa_expense_app.product_catalog.defaults_seeded.v1';
  static const _mutexKey = 'product_catalog';

  static Future<List<ProductItem>> load() =>
      StoreMutex.run(_mutexKey, _loadOrSeedUnlocked);

  static Future<void> saveAll(List<ProductItem> products) =>
      StoreMutex.run(_mutexKey, () async {
        _validate(products);
        await SecureLocalStore.writeJson(
          _secureKey,
          products.map((item) => item.toMap()).toList(),
        );
        final preferences = await SharedPreferences.getInstance();
        await preferences.remove(_legacyKey);
        await preferences.setBool(_seedKey, true);
      });

  static Future<void> upsert(ProductItem product) => StoreMutex.run(
    _mutexKey,
    () async {
      final products = await _loadUnlocked();
      final index = products.indexWhere((item) => item.id == product.id);
      _validate([...products.where((item) => item.id != product.id), product]);
      if (index >= 0) {
        products[index] = product;
      } else {
        products.add(product);
      }
      await _saveUnlocked(products);
      final preferences = await SharedPreferences.getInstance();
      await preferences.setBool(_seedKey, true);
    },
  );

  static Future<void> deactivate(String id) =>
      StoreMutex.run(_mutexKey, () async {
        final products = await _loadUnlocked();
        final index = products.indexWhere((item) => item.id == id);
        if (index < 0) return;
        products[index] = products[index].copyWith(isActive: false);
        await _saveUnlocked(products);
      });

  static Future<List<ProductItem>> _loadOrSeedUnlocked() async {
    final products = await _loadUnlocked();
    final preferences = await SharedPreferences.getInstance();
    final seeded = preferences.getBool(_seedKey) ?? false;
    if (products.isNotEmpty || seeded) return products;
    final defaults = List<ProductItem>.of(DefaultProductCatalog.items);
    await _saveUnlocked(defaults);
    await preferences.setBool(_seedKey, true);
    return defaults;
  }

  static Future<List<ProductItem>> _loadUnlocked() async {
    final value = await SecureLocalStore.readJson(_secureKey);
    if (value is List) {
      final products = <ProductItem>[];
      for (final item in value) {
        if (item is! Map) {
          throw const FormatException('يوجد عنصر تالف في دليل الأصناف');
        }
        products.add(ProductItem.fromMap(Map<String, Object?>.from(item)));
      }
      _validate(products);
      return products;
    }
    if (value != null) {
      throw const FormatException('صيغة دليل الأصناف المشفر غير صحيحة');
    }

    final preferences = await SharedPreferences.getInstance();
    final raw = preferences.getString(_legacyKey);
    if (raw == null || raw.isEmpty) return [];
    final decoded = jsonDecode(raw);
    if (decoded is! List) {
      throw const FormatException('صيغة دليل الأصناف القديم غير صحيحة');
    }
    final products = <ProductItem>[];
    for (final item in decoded) {
      if (item is! Map) {
        throw const FormatException('يوجد عنصر تالف في دليل الأصناف القديم');
      }
      products.add(ProductItem.fromMap(Map<String, Object?>.from(item)));
    }
    _validate(products);
    await _saveUnlocked(products);
    return products;
  }

  static void _validate(List<ProductItem> products) {
    final ids = <String>{};
    for (final item in products) {
      if (item.id.trim().isEmpty || item.name.trim().isEmpty) {
        throw const FormatException('يوجد صنف بلا معرف أو اسم');
      }
      if (!ids.add(item.id)) {
        throw const FormatException('دليل الأصناف يحتوي على معرفات مكررة');
      }
    }
  }

  static Future<void> _saveUnlocked(List<ProductItem> products) async {
    await SecureLocalStore.writeJson(
      _secureKey,
      products.map((item) => item.toMap()).toList(),
    );
    final preferences = await SharedPreferences.getInstance();
    await preferences.remove(_legacyKey);
  }
}
