import 'dart:convert';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:excel/excel.dart';

import '../models/product_item.dart';

class ProductCatalogImportRow {
  const ProductCatalogImportRow({
    required this.rowNumber,
    required this.values,
    required this.product,
    required this.error,
    required this.duplicate,
  });

  final int rowNumber;
  final Map<String, String> values;
  final ProductItem? product;
  final String? error;
  final bool duplicate;

  bool get isValid => product != null && error == null;
}

class ProductCatalogImportPreview {
  const ProductCatalogImportPreview({
    required this.headers,
    required this.rows,
    required this.columnMap,
    this.sheetNames = const [],
    this.selectedSheet,
  });

  final List<String> headers;
  final List<ProductCatalogImportRow> rows;
  final Map<String, String> columnMap;
  final List<String> sheetNames;
  final String? selectedSheet;

  int get validCount => rows.where((row) => row.isValid).length;
  int get duplicateCount => rows.where((row) => row.duplicate).length;
  int get errorCount => rows.where((row) => row.error != null).length;
}

class ProductCatalogImportService {
  ProductCatalogImportService._();

  static const maxImportBytes = 20 * 1024 * 1024;

  static void ensureImportSize(Uint8List bytes) {
    if (bytes.length > maxImportBytes) {
      throw const FormatException(
        'حجم ملف دليل الأصناف يتجاوز 20MB؛ اختر ملفًا أصغر ثم أعد المحاولة.',
      );
    }
  }

  static const fields = <String, String>{
    'id': 'معرف الصنف',
    'name': 'اسم الصنف',
    'pharmaceuticalForm': 'الشكل الصيدلاني',
    'strength': 'التركيز / الوصف',
    'category': 'التصنيف',
    'unit': 'الوحدة',
    'notes': 'ملاحظات',
  };

  static ProductCatalogImportPreview preview(
    Uint8List bytes, {
    List<ProductItem> existing = const [],
    Map<String, String>? columnMapOverride,
    String? sheetName,
  }) {
    ensureImportSize(bytes);
    final workbook = Excel.decodeBytes(bytes);
    if (workbook.tables.isEmpty) {
      return const ProductCatalogImportPreview(
        headers: [],
        rows: [],
        columnMap: {},
      );
    }
    final sheetNames = workbook.tables.keys.toList();
    final sheet = workbook.tables[sheetName] ?? workbook.tables.values.first;
    final rawRows = sheet.rows;
    if (rawRows.isEmpty) {
      return const ProductCatalogImportPreview(
        headers: [],
        rows: [],
        columnMap: {},
      );
    }
    String cellValue(dynamic cell) => cell?.value?.toString().trim() ?? '';
    final headers = rawRows.first.map(cellValue).toList();
    final columnMap = columnMapOverride ?? _detectColumns(headers);
    final existingNames = existing.map(identityKey).toSet();
    final seen = <String>{};
    final rows = <ProductCatalogImportRow>[];
    for (var index = 1; index < rawRows.length; index++) {
      final values = <String, String>{};
      for (var column = 0; column < headers.length; column++) {
        values[headers[column]] = cellValue(
          column < rawRows[index].length ? rawRows[index][column] : null,
        );
      }
      final product = _productFromRow(values, columnMap, index + 1);
      final normalized = product == null ? '' : identityKey(product);
      final duplicate =
          normalized.isNotEmpty &&
          (existingNames.contains(normalized) || !seen.add(normalized));
      rows.add(
        ProductCatalogImportRow(
          rowNumber: index + 1,
          values: values,
          product: product,
          error: product == null ? 'اسم الصنف مطلوب' : null,
          duplicate: duplicate,
        ),
      );
    }
    return ProductCatalogImportPreview(
      headers: headers,
      rows: rows,
      columnMap: columnMap,
      sheetNames: sheetNames,
      selectedSheet: sheetName ?? sheetNames.first,
    );
  }

  static ProductCatalogImportPreview previewCsv(
    Uint8List bytes, {
    List<ProductItem> existing = const [],
    Map<String, String>? columnMapOverride,
  }) {
    ensureImportSize(bytes);
    final rawRows = _parseCsv(_decodeCsv(bytes));
    if (rawRows.isEmpty) {
      return const ProductCatalogImportPreview(
        headers: [],
        rows: [],
        columnMap: {},
      );
    }
    final headers = rawRows.first.map((value) => value.trim()).toList();
    final columnMap = columnMapOverride ?? _detectColumns(headers);
    final existingNames = existing.map(identityKey).toSet();
    final seen = <String>{};
    final rows = <ProductCatalogImportRow>[];
    for (var index = 1; index < rawRows.length; index++) {
      final values = <String, String>{};
      for (var column = 0; column < headers.length; column++) {
        values[headers[column]] = column < rawRows[index].length
            ? rawRows[index][column].trim()
            : '';
      }
      final product = _productFromRow(values, columnMap, index + 1);
      final normalized = product == null ? '' : identityKey(product);
      final duplicate =
          normalized.isNotEmpty &&
          (existingNames.contains(normalized) || !seen.add(normalized));
      rows.add(
        ProductCatalogImportRow(
          rowNumber: index + 1,
          values: values,
          product: product,
          error: product == null ? 'اسم الصنف مطلوب' : null,
          duplicate: duplicate,
        ),
      );
    }
    return ProductCatalogImportPreview(
      headers: headers,
      rows: rows,
      columnMap: columnMap,
    );
  }

  static String normalizeName(String value) =>
      value.trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');

  static String identityKey(ProductItem item) => [
    normalizeName(item.name),
    normalizeName(item.pharmaceuticalForm),
    normalizeName(item.strength),
    normalizeName(item.unit),
  ].join('|');

  static String stableProductId(String name) =>
      'product-${sha256.convert(utf8.encode(normalizeName(name))).toString()}';

  static String _decodeCsv(Uint8List bytes) {
    if (bytes.length >= 2 &&
        ((bytes[0] == 0xFF && bytes[1] == 0xFE) ||
            (bytes[0] == 0xFE && bytes[1] == 0xFF))) {
      throw const FormatException(
        'ترميز CSV غير مدعوم. احفظ الملف بترميز UTF-8 ثم أعد المحاولة.',
      );
    }
    final value = utf8.decode(bytes, allowMalformed: false);
    return value.replaceFirst('\uFEFF', '');
  }

  static List<List<String>> _parseCsv(String source) {
    final rows = <List<String>>[];
    final row = <String>[];
    final cell = StringBuffer();
    var quoted = false;
    for (var index = 0; index < source.length; index++) {
      final char = source[index];
      if (char == '"') {
        if (quoted && index + 1 < source.length && source[index + 1] == '"') {
          cell.write('"');
          index++;
        } else {
          quoted = !quoted;
        }
      } else if (char == ',' && !quoted) {
        row.add(cell.toString());
        cell.clear();
      } else if ((char == '\n' || char == '\r') && !quoted) {
        if (char == '\r' &&
            index + 1 < source.length &&
            source[index + 1] == '\n') {
          index++;
        }
        row.add(cell.toString());
        cell.clear();
        if (row.any((value) => value.trim().isNotEmpty)) rows.add(List.of(row));
        row.clear();
      } else {
        cell.write(char);
      }
    }
    if (cell.isNotEmpty || row.isNotEmpty) {
      row.add(cell.toString());
      rows.add(List.of(row));
    }
    return rows;
  }

  static Map<String, String> _detectColumns(List<String> headers) {
    final result = <String, String>{};
    for (final field in fields.keys) {
      final aliases = _aliases[field]!;
      final match = headers.cast<String?>().firstWhere(
        (header) =>
            header != null &&
            aliases.any((alias) => _normal(header).contains(_normal(alias))),
        orElse: () => null,
      );
      if (match != null) result[field] = match;
    }
    return result;
  }

  static ProductItem? _productFromRow(
    Map<String, String> values,
    Map<String, String> columnMap,
    int rowNumber,
  ) {
    String value(String field) => values[columnMap[field]]?.trim() ?? '';
    final name = value('name');
    if (name.isEmpty) return null;
    final sourceId = value('id');
    return ProductItem(
      id: sourceId.isEmpty ? stableProductId(name) : sourceId,
      name: name,
      pharmaceuticalForm: normalizePharmaceuticalForm(
        provided: value('pharmaceuticalForm'),
        name: name,
        strength: value('strength'),
        unit: value('unit'),
      ),
      strength: value('strength'),
      category: value('category'),
      unit: value('unit'),
      notes: value('notes'),
    );
  }

  static String normalizePharmaceuticalForm({
    required String provided,
    String name = '',
    String strength = '',
    String unit = '',
  }) {
    final text = _normal('$provided $name $strength');
    if (text.contains('قطر')) return 'قطرات';
    if (RegExp(r'قرص|اقراص|أقراص|قراص').hasMatch(text)) return 'أقراص';
    if (text.contains('كبسول') || text.contains('كبسولة')) return 'كبسول';
    if (text.contains('بودر') ||
        text.contains('بودرة') ||
        text.contains('مسحوق')) {
      return 'بودرة';
    }
    if (text.contains('مرهم')) return 'مرهم';
    if (text.contains('معلق')) return 'معلق';
    if (text.contains('فوار')) return 'فوار';
    if (text.contains('شراب')) return 'شراب';
    if (_containsMilliliter('$unit $name $strength')) return 'شراب';
    return provided.trim();
  }

  static bool _containsMilliliter(String value) {
    final text = _normal(value);
    if (text.contains('ملجم') || text.contains('mg')) return false;
    return RegExp(
          r'(?:^|[\d\s./()_-])(مل|ملي|ملل|ميل|ml)(?:$|[\s.,/()_-])',
        ).hasMatch(text) ||
        RegExp(r'(مل|ملي|ملل|ميل|ml)$').hasMatch(text);
  }

  static String _normal(String value) => normalizeName(value);

  static const _aliases = <String, List<String>>{
    'id': ['معرف الصنف', 'معرف', 'id', 'product id'],
    'name': ['اسم الصنف', 'الصنف', 'اسم المنتج', 'product', 'name'],
    'pharmaceuticalForm': ['الشكل الصيدلاني', 'الشكل', 'form', 'dosage form'],
    'strength': ['التركيز', 'الوصف', 'strength', 'description'],
    'category': ['التصنيف', 'الفئة', 'category'],
    'unit': ['الوحدة', 'unit'],
    'notes': ['ملاحظات', 'ملاحظة', 'notes', 'note'],
  };
}
