import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/app_release.dart';

import '../../customer/screens/customer_application_screen.dart';
import '../../notes/screens/notes_screen.dart';
import '../../reports/screens/reports_screen.dart';
import '../../requests/screens/saved_requests_screen.dart';
import '../../calculator/screens/calculator_screen.dart';
import '../../debts/screens/debts_screen.dart';
import '../../finance/screens/finance_screens.dart';
import '../../reminders/screens/reminders_screen.dart';
import '../../settings/screens/template_catalog_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _showReleaseNotes());
  }

  Future<void> _showReleaseNotes() async {
    final preferences = await SharedPreferences.getInstance();
    final shownVersion = preferences.getString('alfa_release_notes_version');
    if (shownVersion == appVersionLabel || !mounted) return;
    await preferences.setString('alfa_release_notes_version', appVersionLabel);
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        icon: const Icon(Icons.verified_rounded, size: 42),
        title: const Text('تم تحديث التطبيق بنجاح'),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'الإصدار الجديد: $appVersionLabel',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              const Text(
                'تم تثبيت النسخة الجديدة وتتضمن التحديثات الفعلية التالية:',
              ),
              const SizedBox(height: 8),
              for (final item in appReleaseHighlights)
                Padding(
                  padding: const EdgeInsets.only(bottom: 7),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Icon(Icons.check_circle, size: 18),
                      const SizedBox(width: 6),
                      Expanded(child: Text(item)),
                    ],
                  ),
                ),
            ],
          ),
        ),
        actions: [
          FilledButton.icon(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_forward_rounded),
            label: const Text('متابعة إلى التطبيق'),
          ),
        ],
      ),
    );
  }

  void _showHelp(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('طريقة الاستخدام'),
        content: const Text(
          'اختر الوظيفة المطلوبة من الصفحة الرئيسية. أدخل البيانات ثم احفظ المستند أو أنشئ ملف PDF للطباعة والمشاركة. يتم تحويل المبلغ إلى كلمات عربية تلقائيًا عند إدخاله.',
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('حسنًا'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final shouldExit = await showDialog<bool>(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('الخروج من التطبيق؟'),
            content: const Text('هل تريد الخروج من التطبيق؟'),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text('إلغاء'),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('خروج'),
              ),
            ],
          ),
        );
        if (shouldExit == true) await SystemNavigator.pop();
      },
      child: Scaffold(
        appBar: AppBar(
          leading: Builder(
            builder: (context) => IconButton(
              tooltip: 'القائمة الجانبية',
              icon: const Icon(Icons.menu_rounded),
              onPressed: () => Scaffold.of(context).openDrawer(),
            ),
          ),
          title: const Text('النماذج والمستندات'),
          actions: [
            IconButton(
              tooltip: 'الإعدادات العامة',
              icon: const Icon(Icons.settings_outlined),
              onPressed: () => Navigator.of(context).push(
                MaterialPageRoute<void>(
                  builder: (_) => const GeneralSettingsScreen(),
                ),
              ),
            ),
          ],
        ),
        drawer: const _AppNavigationDrawer(),
        body: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final isWide = constraints.maxWidth >= 760;
              final contentWidth = isWide ? 1040.0 : double.infinity;
              final availableWidth = isWide
                  ? (constraints.maxWidth > contentWidth
                        ? contentWidth
                        : constraints.maxWidth)
                  : constraints.maxWidth;
              final cardWidth = isWide
                  ? (availableWidth - 12) / 2
                  : double.infinity;
              final actions = <Widget>[
                _HomeActionButton(
                  icon: Icons.fact_check_outlined,
                  title: 'اختار نموذجك وقدم',
                  subtitle:
                      'اختر نموذج العملاء أو طلب الصرف أو طلب العينات أو المذكرة الداخلية A4',
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) =>
                          const TemplateCatalogScreen(selectionMode: true),
                    ),
                  ),
                  isPrimary: true,
                ),
                _HomeActionButton(
                  icon: Icons.folder_copy_outlined,
                  title: 'المستندات السابقة',
                  subtitle: 'عرض المستندات المحفوظة والبحث فيها',
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const SavedRequestsScreen(),
                    ),
                  ),
                ),
                _HomeActionButton(
                  icon: Icons.sticky_note_2_outlined,
                  title: 'النوتة والملاحظات',
                  subtitle: 'إضافة الملاحظات والمهام والبحث والأرشفة',
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const NotesScreen(),
                    ),
                  ),
                ),
                _HomeActionButton(
                  icon: Icons.add_alert_outlined,
                  title: 'ذكرني',
                  subtitle: 'منبه محلي بوقت وتاريخ ونص تختاره',
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const RemindersScreen(),
                    ),
                  ),
                ),
                _HomeActionButton(
                  icon: Icons.calculate_outlined,
                  title: 'الحاسبة الاحترافية',
                  subtitle: 'عمليات مالية سريعة قبل تعبئة النماذج',
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const CalculatorScreen(),
                    ),
                  ),
                ),
                _HomeActionButton(
                  icon: Icons.payments_outlined,
                  title: 'صافي الراتب والبدلات',
                  subtitle: 'احسب الإجمالي والتأمينات والضريبة وصافي الراتب',
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const SalaryCalculatorScreen(),
                    ),
                  ),
                ),
                _HomeActionButton(
                  icon: Icons.receipt_long_outlined,
                  title: 'السلف والأقساط',
                  subtitle:
                      'حدد السبب والبداية والمدة وجدول الخصم الشهري أو النصفي',
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const AdvanceCalculatorScreen(),
                    ),
                  ),
                ),
                _HomeActionButton(
                  icon: Icons.account_balance_wallet_outlined,
                  title: 'الحسابات والديون',
                  subtitle:
                      'تسجيل الديون والمعلقات على الأشخاص والمحلات وإصدار التقارير',
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const DebtsScreen(),
                    ),
                  ),
                ),
                _HomeActionButton(
                  icon: Icons.dashboard_customize_outlined,
                  title: 'الإعدادات',
                  subtitle: 'الإعدادات العامة وإعدادات المذكرة والنماذج',
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(
                      builder: (_) => const GeneralSettingsScreen(),
                    ),
                  ),
                ),
              ];
              return SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 32),
                child: Center(
                  child: SizedBox(
                    width: contentWidth,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        const _WelcomeCard(),
                        const SizedBox(height: 20),
                        Text(
                          'الوصول السريع',
                          style: Theme.of(context).textTheme.titleLarge
                              ?.copyWith(fontWeight: FontWeight.w800),
                        ),
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 12,
                          runSpacing: 12,
                          children: [
                            for (final action in actions)
                              SizedBox(width: cardWidth, child: action),
                          ],
                        ),
                        const SizedBox(height: 24),
                        Center(
                          child: Text(
                            'عبدالعزيز كباس',
                            style: Theme.of(context).textTheme.titleMedium
                                ?.copyWith(
                                  fontWeight: FontWeight.w700,
                                  color: Theme.of(context).colorScheme.primary,
                                ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        TextButton.icon(
                          onPressed: () => _showHelp(context),
                          icon: const Icon(Icons.help_outline),
                          label: const Text('مساعدة مختصرة'),
                        ),
                        const SizedBox(height: 18),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _AppNavigationDrawer extends StatelessWidget {
  const _AppNavigationDrawer();

  void _close(BuildContext context) => Navigator.of(context).pop();

  void _open(BuildContext context, Widget page) {
    _close(context);
    Navigator.of(context).push(MaterialPageRoute<void>(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Drawer(
      child: SafeArea(
        child: Column(
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 24, 20, 22),
              color: scheme.primary,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 27,
                    backgroundColor: scheme.onPrimary,
                    child: Icon(
                      Icons.receipt_long_rounded,
                      color: scheme.primary,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'مركز النماذج والمستندات',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: scheme.onPrimary.withValues(alpha: 0.82),
                    ),
                  ),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.home_outlined),
              title: const Text('الرئيسية'),
              onTap: () => _close(context),
            ),
            ListTile(
              leading: const Icon(Icons.folder_copy_outlined),
              title: const Text('المستندات السابقة'),
              onTap: () => _open(context, const SavedRequestsScreen()),
            ),
            ListTile(
              leading: const Icon(Icons.settings_outlined),
              title: const Text('الإعدادات العامة'),
              onTap: () => _open(context, const GeneralSettingsScreen()),
            ),
            ListTile(
              leading: const Icon(Icons.add_alert_outlined),
              title: const Text('ذكرني'),
              onTap: () => _open(context, const RemindersScreen()),
            ),
            ListTile(
              leading: const Icon(Icons.calculate_outlined),
              title: const Text('الحاسبة الاحترافية'),
              onTap: () => _open(context, const CalculatorScreen()),
            ),
            ListTile(
              leading: const Icon(Icons.payments_outlined),
              title: const Text('صافي الراتب والبدلات'),
              onTap: () => _open(context, const SalaryCalculatorScreen()),
            ),
            ListTile(
              leading: const Icon(Icons.receipt_long_outlined),
              title: const Text('السلف والأقساط'),
              onTap: () => _open(context, const AdvanceCalculatorScreen()),
            ),
            ListTile(
              leading: const Icon(Icons.account_balance_wallet_outlined),
              title: const Text('الحسابات والديون'),
              onTap: () => _open(context, const DebtsScreen()),
            ),
            ListTile(
              leading: const Icon(Icons.person_add_alt_1_outlined),
              title: const Text('نموذج العملاء'),
              onTap: () => _open(context, const CustomerApplicationScreen()),
            ),
            ListTile(
              leading: const Icon(Icons.assessment_outlined),
              title: const Text('التقارير'),
              onTap: () => _open(context, const ReportsScreen()),
            ),
            ListTile(
              leading: const Icon(Icons.sticky_note_2_outlined),
              title: const Text('النوتة والمهام'),
              onTap: () => _open(context, const NotesScreen()),
            ),
            const Divider(indent: 16, endIndent: 16),
            const Spacer(),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'افتح القائمة من زر ☰ ثم اختر القسم المطلوب',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WelcomeCard extends StatelessWidget {
  const _WelcomeCard();

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      clipBehavior: Clip.antiAlias,
      color: scheme.primary,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(22, 16, 22, 22),
        child: Column(
          children: [
            Align(
              alignment: AlignmentDirectional.topEnd,
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: scheme.onPrimary.withValues(alpha: 0.14),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  'SHIBA PHARMA',
                  style: Theme.of(context).textTheme.labelSmall?.copyWith(
                    color: scheme.onPrimary,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.1,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'بسم الله الرحمن الرحيم',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: scheme.onPrimary,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'مرحبًا بك في سبا فارما\nقدّم واختار ما تحتاجه بسهولة',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: scheme.onPrimary.withValues(alpha: 0.88),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HomeActionButton extends StatelessWidget {
  const _HomeActionButton({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onPressed,
    this.isPrimary = false,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onPressed;
  final bool isPrimary;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onPressed,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 20),
          child: Row(
            children: [
              CircleAvatar(
                radius: 28,
                backgroundColor: isPrimary
                    ? scheme.primary
                    : scheme.primaryContainer,
                foregroundColor: isPrimary
                    ? scheme.onPrimary
                    : scheme.onPrimaryContainer,
                child: Icon(icon, size: 28),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      title,
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left_rounded, size: 28),
            ],
          ),
        ),
      ),
    );
  }
}
