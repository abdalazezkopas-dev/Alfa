import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/services/attachment_manager.dart';
import '../../../core/services/app_logger.dart';
import '../../../core/app_release.dart';
import '../../../core/security/secure_local_store.dart';
import '../../../core/security/input_limits.dart';
import '../../../core/store_mutex.dart';
import '../../debts/models/debt.dart';
import '../../debts/services/debt_store.dart';
import '../../expense_request/models/expense_request.dart';
import '../../expense_request/services/quick_statement_store.dart';
import '../../expense_request/services/request_store.dart';
import '../../notes/models/note.dart';
import '../../notes/services/notes_store.dart';
import '../../product_catalog/models/product_item.dart';
import '../../product_catalog/services/product_catalog_store.dart';
import '../../representative_reports/models/representative_report.dart';
import '../../representative_reports/services/representative_report_store.dart';
import '../../reminders/models/reminder.dart';
import '../../reminders/services/reminder_notification_service.dart';
import '../../reminders/services/reminder_store.dart';
import '../../settings/models/app_settings.dart';
import '../../settings/services/pattern_store.dart';
import '../../settings/services/settings_store.dart';
import 'encrypted_backup_codec.dart';
import 'backup_schema_migrator.dart';

const requiredBackupScopes = [
  'expenseRequest',
  'clearanceRequest',
  'serviceRequest',
  'fuelRequest',
  'customerApplication',
  'internalMemo',
  'sampleRequest',
  'sampleRequestSinglePage',
  'travelAllowance',
];
const backupSettingsScopes = [...requiredBackupScopes, 'global'];

const _maxBackupAttachments = 100;
const _maxBackupAttachmentBytes = 10 * 1024 * 1024;
const _maxBackupTotalAttachmentBytes = 70 * 1024 * 1024;
const _maxBackupJsonBytes = 100 * 1024 * 1024;
const _maxBackupListItems = 5000;
const _maxImportFileBytes = 200 * 1024 * 1024;
const _localBackupIndexKey = 'backup.local_index.v1';

class LocalBackupRecord {
  const LocalBackupRecord({
    required this.path,
    required this.name,
    required this.createdAt,
  });

  final String path;
  final String name;
  final DateTime createdAt;

  Map<String, Object?> toMap() => {
    'path': path,
    'name': name,
    'createdAt': createdAt.toIso8601String(),
  };

  static LocalBackupRecord? fromMap(Object? value) {
    if (value is! Map) return null;
    final path = value['path']?.toString().trim() ?? '';
    final name = value['name']?.toString().trim() ?? '';
    final createdAt = DateTime.tryParse(value['createdAt']?.toString() ?? '');
    if (path.isEmpty || name.isEmpty || createdAt == null) return null;
    return LocalBackupRecord(path: path, name: name, createdAt: createdAt);
  }
}

class BackupData {
  const BackupData({
    required this.settings,
    required this.requests,
    this.settingsByScope = const {},
    this.reminders = const [],
    this.debts = const [],
    this.notes = const [],
    this.quickStatements = const {},
    this.savedPatterns = const [],
    this.masterPatternsByScope = const {},
    this.debtSettings = const {},
    this.calculatorHistory = const [],
    this.attachments = const [],
    this.productCatalog = const [],
    this.representativeReports = const [],
    this.hasProductCatalog = true,
    this.hasRepresentativeReports = false,
    this.hasReminders = true,
    this.hasDebts = true,
    this.hasNotes = true,
    this.hasQuickStatements = true,
    this.hasSavedPatterns = true,
    this.hasDebtSettings = true,
    this.hasCalculatorHistory = true,
    this.version = 1,
    this.migrationWarnings = const [],
  });

  final AppSettings settings;
  final Map<String, AppSettings> settingsByScope;
  final List<ExpenseRequest> requests;
  final List<Reminder> reminders;
  final List<DebtAccount> debts;
  final List<Note> notes;
  final Map<String, List<String>> quickStatements;
  final List<SavedPattern> savedPatterns;
  final Map<String, SavedPattern> masterPatternsByScope;
  final Map<String, Object?> debtSettings;
  final List<String> calculatorHistory;
  final List<Map<String, Object?>> attachments;
  final List<ProductItem> productCatalog;
  final List<RepresentativeReport> representativeReports;
  final bool hasProductCatalog;
  final bool hasRepresentativeReports;
  final bool hasReminders;
  final bool hasDebts;
  final bool hasNotes;
  final bool hasQuickStatements;
  final bool hasSavedPatterns;
  final bool hasDebtSettings;
  final bool hasCalculatorHistory;
  final int version;
  final List<String> migrationWarnings;
}

class BackupService {
  const BackupService._();

  static void _requireBackupListLimit(String label, int count, {int? limit}) {
    final maximum = limit ?? _maxBackupListItems;
    if (count > maximum) {
      throw FormatException(
        'قائمة $label تتجاوز الحد المسموح ($maximum)؛ لم يتم اقتطاع البيانات.',
      );
    }
  }

  static void _validateExportCounts({
    required List<ExpenseRequest> requests,
    required List<Reminder> reminders,
    required List<DebtAccount> debts,
    required List<Note> notes,
    required Map<String, List<String>> quickStatements,
    required List<SavedPattern> savedPatterns,
    required Map<String, SavedPattern> masterPatternsByScope,
    required List<String> calculatorHistory,
    List<ProductItem>? productCatalog,
    List<RepresentativeReport>? representativeReports,
  }) {
    _requireBackupListLimit('الطلبات', requests.length);
    _requireBackupListLimit('التذكيرات', reminders.length);
    _requireBackupListLimit('الديون', debts.length);
    _requireBackupListLimit('الملاحظات', notes.length);
    _requireBackupListLimit('الأنماط المحفوظة', savedPatterns.length);
    _requireBackupListLimit(
      'النماذج الرئيسية حسب النطاق',
      masterPatternsByScope.length,
    );
    _requireBackupListLimit('سجل الحاسبة', calculatorHistory.length);
    _requireBackupListLimit('مجموعات العبارات السريعة', quickStatements.length);
    var quickStatementCount = 0;
    for (final statements in quickStatements.values) {
      quickStatementCount += statements.length;
    }
    _requireBackupListLimit('العبارات السريعة', quickStatementCount);
    if (productCatalog != null) {
      _requireBackupListLimit('دليل الأصناف', productCatalog.length);
    }
    if (representativeReports != null) {
      _requireBackupListLimit('تقارير المندوبين', representativeReports.length);
    }
  }

  static void _validateExportJson(String json) {
    if (utf8.encode(json).length > _maxBackupJsonBytes) {
      throw const FormatException(
        'حجم بيانات النسخة يتجاوز 100MB؛ لم يتم التصدير لتجنب إنشاء ملف غير قابل للاستعادة.',
      );
    }
    decodeBackup(json);
  }

  static List<String> _decodeCalculatorHistory(Object? value) {
    if (value == null) return const [];
    if (value is! List) {
      throw const FormatException('سجل الحاسبة في النسخة الاحتياطية غير صحيح');
    }
    _requireBackupListLimit('سجل الحاسبة', value.length);
    if (value.any((item) => item is! String)) {
      throw const FormatException('يحتوي سجل الحاسبة على عنصر غير صالح');
    }
    return value.cast<String>().toList();
  }

  static Future<List<LocalBackupRecord>> listLocalBackups() async {
    final preferences = await SharedPreferences.getInstance();
    final raw = preferences.getStringList(_localBackupIndexKey) ?? const [];
    final records = <LocalBackupRecord>[];
    for (final item in raw) {
      try {
        final record = LocalBackupRecord.fromMap(jsonDecode(item));
        if (record == null) continue;
        var normalized = record;
        if (record.path.startsWith('file:')) {
          normalized = LocalBackupRecord(
            path: Uri.parse(record.path).toFilePath(),
            name: record.name,
            createdAt: record.createdAt,
          );
        }
        // Android content:// URIs are not readable through dart:io and were
        // never reliable recovery points; new snapshots use a private file.
        if (!normalized.path.startsWith('/') ||
            !await File(normalized.path).exists()) {
          continue;
        }
        records.add(normalized);
      } on FormatException {
        // Ignore a damaged index entry; the backup files themselves remain safe.
      }
    }
    records.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    if (records.length != raw.length) await _saveLocalBackups(records);
    return records;
  }

  static Future<void> registerLocalBackup(String path) async {
    final trimmed = path.trim();
    if (trimmed.isEmpty) return;
    final current = await listLocalBackups();
    final name = trimmed.split(Platform.pathSeparator).last;
    final combined = [
      LocalBackupRecord(
        path: trimmed,
        name: name.isEmpty ? 'نسخة احتياطية' : name,
        createdAt: DateTime.now(),
      ),
      ...current.where((record) => record.path != trimmed),
    ]..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    final records = combined.take(50).toList();
    final retainedPaths = records.map((record) => record.path).toSet();
    final support = await getApplicationSupportDirectory();
    final ownedPrefix =
        '${support.path}${Platform.pathSeparator}backups${Platform.pathSeparator}';
    for (final old in combined.where(
      (record) => !retainedPaths.contains(record.path),
    )) {
      if (old.path.startsWith(ownedPrefix)) {
        final file = File(old.path);
        if (await file.exists()) await file.delete();
      }
    }
    await _saveLocalBackups(records);
  }

  /// Stores an encrypted copy inside app support so it remains restorable even
  /// when the user cancels an export or Android returns a content URI.
  static Future<String> saveLocalEncryptedBackup(String encrypted) async {
    final support = await getApplicationSupportDirectory();
    final directory = Directory(
      '${support.path}${Platform.pathSeparator}backups',
    );
    await directory.create(recursive: true);
    final stamp = DateTime.now().toIso8601String().replaceAll(
      RegExp(r'[^0-9]'),
      '',
    );
    final file = File(
      '${directory.path}${Platform.pathSeparator}alfa_backup_$stamp.kabas',
    );
    await file.writeAsString(encrypted, encoding: utf8, flush: true);
    await registerLocalBackup(file.path);
    return file.path;
  }

  static Future<String> saveLocalJsonBackup(String json) async {
    final support = await getApplicationSupportDirectory();
    final directory = Directory(
      '${support.path}${Platform.pathSeparator}backups',
    );
    await directory.create(recursive: true);
    final stamp = DateTime.now().toIso8601String().replaceAll(
      RegExp(r'[^0-9]'),
      '',
    );
    final file = File(
      '${directory.path}${Platform.pathSeparator}alfa_backup_$stamp.json',
    );
    await file.writeAsString(json, encoding: utf8, flush: true);
    await registerLocalBackup(file.path);
    return file.path;
  }

  static Future<void> deleteLocalBackup(LocalBackupRecord record) async {
    if (record.path.startsWith('/')) {
      final file = File(record.path);
      if (await file.exists()) await file.delete();
    }
    final current = await listLocalBackups();
    await _saveLocalBackups(
      current.where((item) => item.path != record.path).toList(),
    );
  }

  static Future<void> _saveLocalBackups(List<LocalBackupRecord> records) async {
    final preferences = await SharedPreferences.getInstance();
    await preferences.setStringList(
      _localBackupIndexKey,
      records.map((record) => jsonEncode(record.toMap())).toList(),
    );
  }

  /// Encrypts an already validated legacy JSON payload. The UI should request
  /// a password and use this method for new exports; [decodeBackup] remains a
  /// deliberately explicit legacy JSON import path.
  static Future<String> encryptBackupJson(
    String json, {
    required String password,
  }) => EncryptedBackupCodec.encryptJson(json, password: password);

  static Future<BackupData> decodeEncryptedBackup(
    String source, {
    required String password,
  }) async {
    final json = await EncryptedBackupCodec.decryptJson(
      source,
      password: password,
    );
    return decodeBackup(json);
  }

  static Future<BackupData> decodeAnyBackup(
    String source, {
    Future<String?> Function()? passwordProvider,
  }) async {
    source = EncryptedBackupCodec.normalizeSource(source);
    if (source.startsWith(EncryptedBackupCodec.magic)) {
      final password = await passwordProvider?.call();
      if (password == null) {
        throw const FormatException('يلزم إدخال كلمة المرور');
      }
      return decodeEncryptedBackup(source, password: password);
    }
    return decodeBackup(source);
  }

  static Future<BackupData?> importAnyBackup({
    Future<String?> Function()? passwordProvider,
  }) async {
    final result = await FilePicker.pickFiles(
      dialogTitle: 'استيراد نسخة احتياطية',
      type: FileType.custom,
      allowedExtensions: ['json', 'kabas'],
      withData: true,
    );
    final file = result?.files.single;
    final bytes = await _readPickedFileBytes(file);
    if (bytes == null) return null;
    if (bytes.length > _maxImportFileBytes) {
      throw const FormatException('حجم ملف النسخة يتجاوز 200MB');
    }
    return decodeAnyBackup(
      utf8.decode(bytes),
      passwordProvider: passwordProvider,
    );
  }

  static Future<String> buildPlainBackupJson({
    required AppSettings settings,
    required List<ExpenseRequest> requests,
    List<Reminder> reminders = const [],
    List<DebtAccount> debts = const [],
    List<Note> notes = const [],
    Map<String, List<String>> quickStatements = const {},
    Map<String, AppSettings> settingsByScope = const {},
    List<SavedPattern> savedPatterns = const [],
    Map<String, SavedPattern> masterPatternsByScope = const {},
    Map<String, Object?> debtSettings = const {},
    List<String> calculatorHistory = const [],
    List<RepresentativeReport>? representativeReports,
  }) async {
    _validateExportCounts(
      requests: requests,
      reminders: reminders,
      debts: debts,
      notes: notes,
      quickStatements: quickStatements,
      savedPatterns: savedPatterns,
      masterPatternsByScope: masterPatternsByScope,
      calculatorHistory: calculatorHistory,
    );
    final metadata = await _readMetadata();
    final scoped = <String, Map<String, Object?>>{};
    for (final scope in backupSettingsScopes) {
      scoped[scope] =
          (settingsByScope[scope] ??
                  (scope == 'expenseRequest' || scope == 'global'
                      ? settings
                      : AppSettings.defaultsForScope(scope)))
              .toMap();
    }
    final productCatalog = await ProductCatalogStore.load();

    final reportsToExport =
        representativeReports ?? await RepresentativeReportStore.load();
    _validateExportCounts(
      requests: requests,
      reminders: reminders,
      debts: debts,
      notes: notes,
      quickStatements: quickStatements,
      savedPatterns: savedPatterns,
      masterPatternsByScope: masterPatternsByScope,
      calculatorHistory: calculatorHistory,
      productCatalog: productCatalog,
      representativeReports: reportsToExport,
    );
    final payload = {
      'format': 'alfa_expense_app_backup',
      'version': BackupSchemaMigrator.currentVersion,
      'schema_version': BackupSchemaMigrator.currentVersion,
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'app_version': appVersionLabel,
      'settings_by_scope': scoped,
      'settings': (settingsByScope['expenseRequest'] ?? settings).toMap(),
      'requests': requests.map((request) => request.toMap()).toList(),
      'reminders': reminders.map((item) => item.toMap()).toList(),
      'debts': debts.map((item) => item.toMap()).toList(),
      'notes': notes.map((item) => item.toMap()).toList(),
      'quick_statements': quickStatements,
      'saved_patterns': savedPatterns
          .map((pattern) => pattern.toMap())
          .toList(),
      'master_patterns_by_scope': masterPatternsByScope.map(
        (scope, pattern) => MapEntry(scope, pattern.toMap()),
      ),
      'debt_settings': debtSettings.isEmpty
          ? metadata.debtSettings
          : debtSettings,
      'calculator_history': calculatorHistory.isEmpty
          ? metadata.calculatorHistory
          : calculatorHistory,
      'attachments': await _encodeAttachments(requests, debts: debts),
      'product_catalog': productCatalog.map((item) => item.toMap()).toList(),
      'representative_reports': reportsToExport
          .map((item) => item.toMap())
          .toList(),
    };
    final json = jsonEncode(payload);
    _validateExportJson(json);
    return json;
  }

  static Future<String?> exportBackup({
    required AppSettings settings,
    required List<ExpenseRequest> requests,
    List<Reminder> reminders = const [],
    List<DebtAccount> debts = const [],
    List<Note> notes = const [],
    Map<String, List<String>> quickStatements = const {},
    Map<String, AppSettings> settingsByScope = const {},
    List<SavedPattern> savedPatterns = const [],
    Map<String, SavedPattern> masterPatternsByScope = const {},
    Map<String, Object?> debtSettings = const {},
    List<String> calculatorHistory = const [],
    List<RepresentativeReport>? representativeReports,
  }) async {
    _validateExportCounts(
      requests: requests,
      reminders: reminders,
      debts: debts,
      notes: notes,
      quickStatements: quickStatements,
      savedPatterns: savedPatterns,
      masterPatternsByScope: masterPatternsByScope,
      calculatorHistory: calculatorHistory,
    );
    final metadata = await _readMetadata();
    final scoped = <String, Map<String, Object?>>{};
    for (final scope in backupSettingsScopes) {
      scoped[scope] =
          (settingsByScope[scope] ??
                  (scope == 'expenseRequest' || scope == 'global'
                      ? settings
                      : AppSettings.defaultsForScope(scope)))
              .toMap();
    }
    final attachments = await _encodeAttachments(requests, debts: debts);
    final productCatalog = await ProductCatalogStore.load();

    final reportsToExport =
        representativeReports ?? await RepresentativeReportStore.load();
    _validateExportCounts(
      requests: requests,
      reminders: reminders,
      debts: debts,
      notes: notes,
      quickStatements: quickStatements,
      savedPatterns: savedPatterns,
      masterPatternsByScope: masterPatternsByScope,
      calculatorHistory: calculatorHistory,
      productCatalog: productCatalog,
      representativeReports: reportsToExport,
    );
    final payload = {
      'format': 'alfa_expense_app_backup',
      'version': BackupSchemaMigrator.currentVersion,
      'schema_version': BackupSchemaMigrator.currentVersion,
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'app_version': appVersionLabel,
      'settings_by_scope': scoped,
      'settings': (settingsByScope['expenseRequest'] ?? settings).toMap(),
      'requests': requests.map((request) => request.toMap()).toList(),
      'reminders': reminders.map((item) => item.toMap()).toList(),
      'debts': debts.map((item) => item.toMap()).toList(),
      'notes': notes.map((item) => item.toMap()).toList(),
      'quick_statements': quickStatements,
      'saved_patterns': savedPatterns
          .map((pattern) => pattern.toMap())
          .toList(),
      'master_patterns_by_scope': masterPatternsByScope.map(
        (scope, pattern) => MapEntry(scope, pattern.toMap()),
      ),
      'debt_settings': debtSettings.isEmpty
          ? metadata.debtSettings
          : debtSettings,
      'calculator_history': calculatorHistory.isEmpty
          ? metadata.calculatorHistory
          : calculatorHistory,
      'attachments': attachments,
      'product_catalog': productCatalog.map((item) => item.toMap()).toList(),
      'representative_reports': reportsToExport
          .map((item) => item.toMap())
          .toList(),
    };
    final json = jsonEncode(payload);
    _validateExportJson(json);
    final bytes = Uint8List.fromList(utf8.encode(json));
    return FilePicker.saveFile(
      dialogTitle: 'حفظ نسخة احتياطية',
      fileName: 'alfa_expense_app_backup_v5.json',
      type: FileType.custom,
      allowedExtensions: ['json'],
      bytes: bytes,
    );
  }

  static Future<String> buildEncryptedBackupJson({
    required AppSettings settings,
    required List<ExpenseRequest> requests,
    required String password,
    List<Reminder> reminders = const [],
    List<DebtAccount> debts = const [],
    List<Note> notes = const [],
    Map<String, List<String>> quickStatements = const {},
    Map<String, AppSettings> settingsByScope = const {},
    List<SavedPattern> savedPatterns = const [],
    Map<String, SavedPattern> masterPatternsByScope = const {},
    Map<String, Object?> debtSettings = const {},
    List<String> calculatorHistory = const [],
    List<RepresentativeReport>? representativeReports,
  }) async {
    _validateExportCounts(
      requests: requests,
      reminders: reminders,
      debts: debts,
      notes: notes,
      quickStatements: quickStatements,
      savedPatterns: savedPatterns,
      masterPatternsByScope: masterPatternsByScope,
      calculatorHistory: calculatorHistory,
    );
    final metadata = await _readMetadata();
    final productCatalog = await ProductCatalogStore.load();

    final reportsToExport =
        representativeReports ?? await RepresentativeReportStore.load();
    _validateExportCounts(
      requests: requests,
      reminders: reminders,
      debts: debts,
      notes: notes,
      quickStatements: quickStatements,
      savedPatterns: savedPatterns,
      masterPatternsByScope: masterPatternsByScope,
      calculatorHistory: calculatorHistory,
      productCatalog: productCatalog,
      representativeReports: reportsToExport,
    );
    final scoped = <String, Map<String, Object?>>{};
    for (final scope in backupSettingsScopes) {
      scoped[scope] =
          (settingsByScope[scope] ??
                  (scope == 'expenseRequest' || scope == 'global'
                      ? settings
                      : AppSettings.defaultsForScope(scope)))
              .toMap();
    }
    final payload = <String, Object?>{
      'format': 'alfa_expense_app_backup',
      'version': BackupSchemaMigrator.currentVersion,
      'schema_version': BackupSchemaMigrator.currentVersion,
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'app_version': appVersionLabel,
      'settings_by_scope': scoped,
      'settings': (settingsByScope['expenseRequest'] ?? settings).toMap(),
      'requests': requests.map((request) => request.toMap()).toList(),
      'reminders': reminders.map((item) => item.toMap()).toList(),
      'debts': debts.map((item) => item.toMap()).toList(),
      'notes': notes.map((item) => item.toMap()).toList(),
      'quick_statements': quickStatements,
      'saved_patterns': savedPatterns
          .map((pattern) => pattern.toMap())
          .toList(),
      'master_patterns_by_scope': masterPatternsByScope.map(
        (scope, pattern) => MapEntry(scope, pattern.toMap()),
      ),
      'debt_settings': debtSettings.isEmpty
          ? metadata.debtSettings
          : debtSettings,
      'calculator_history': calculatorHistory.isEmpty
          ? metadata.calculatorHistory
          : calculatorHistory,
      'attachments': await _encodeAttachments(requests, debts: debts),
      'product_catalog': productCatalog.map((item) => item.toMap()).toList(),
      'representative_reports': reportsToExport
          .map((item) => item.toMap())
          .toList(),
    };
    final json = jsonEncode(payload);
    _validateExportJson(json);
    return EncryptedBackupCodec.encryptJson(json, password: password);
  }

  static Future<String?> exportEncryptedBackup({
    required AppSettings settings,
    required List<ExpenseRequest> requests,
    required String password,
    List<Reminder> reminders = const [],
    List<DebtAccount> debts = const [],
    List<Note> notes = const [],
    Map<String, List<String>> quickStatements = const {},
    Map<String, AppSettings> settingsByScope = const {},
    List<SavedPattern> savedPatterns = const [],
    Map<String, SavedPattern> masterPatternsByScope = const {},
    Map<String, Object?> debtSettings = const {},
    List<String> calculatorHistory = const [],
    List<RepresentativeReport>? representativeReports,
    String? dialogTitle,
    String? fileName,
  }) async {
    _validateExportCounts(
      requests: requests,
      reminders: reminders,
      debts: debts,
      notes: notes,
      quickStatements: quickStatements,
      savedPatterns: savedPatterns,
      masterPatternsByScope: masterPatternsByScope,
      calculatorHistory: calculatorHistory,
    );
    final metadata = await _readMetadata();
    final productCatalog = await ProductCatalogStore.load();

    final reportsToExport =
        representativeReports ?? await RepresentativeReportStore.load();
    _validateExportCounts(
      requests: requests,
      reminders: reminders,
      debts: debts,
      notes: notes,
      quickStatements: quickStatements,
      savedPatterns: savedPatterns,
      masterPatternsByScope: masterPatternsByScope,
      calculatorHistory: calculatorHistory,
      productCatalog: productCatalog,
      representativeReports: reportsToExport,
    );
    final scoped = <String, Map<String, Object?>>{};
    for (final scope in backupSettingsScopes) {
      scoped[scope] =
          (settingsByScope[scope] ??
                  (scope == 'expenseRequest' || scope == 'global'
                      ? settings
                      : AppSettings.defaultsForScope(scope)))
              .toMap();
    }
    final payload = {
      'format': 'alfa_expense_app_backup',
      'version': BackupSchemaMigrator.currentVersion,
      'schema_version': BackupSchemaMigrator.currentVersion,
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'app_version': appVersionLabel,
      'settings_by_scope': scoped,
      'settings': (settingsByScope['expenseRequest'] ?? settings).toMap(),
      'requests': requests.map((request) => request.toMap()).toList(),
      'reminders': reminders.map((item) => item.toMap()).toList(),
      'debts': debts.map((item) => item.toMap()).toList(),
      'notes': notes.map((item) => item.toMap()).toList(),
      'quick_statements': quickStatements,
      'saved_patterns': savedPatterns
          .map((pattern) => pattern.toMap())
          .toList(),
      'master_patterns_by_scope': masterPatternsByScope.map(
        (scope, pattern) => MapEntry(scope, pattern.toMap()),
      ),
      'debt_settings': debtSettings.isEmpty
          ? metadata.debtSettings
          : debtSettings,
      'calculator_history': calculatorHistory.isEmpty
          ? metadata.calculatorHistory
          : calculatorHistory,
      'attachments': await _encodeAttachments(requests, debts: debts),
      'product_catalog': productCatalog.map((item) => item.toMap()).toList(),
      'representative_reports': reportsToExport
          .map((item) => item.toMap())
          .toList(),
    };
    final json = jsonEncode(payload);
    _validateExportJson(json);
    final encrypted = await EncryptedBackupCodec.encryptJson(
      json,
      password: password,
    );
    return FilePicker.saveFile(
      dialogTitle: dialogTitle ?? 'حفظ نسخة احتياطية مشفرة',
      fileName: fileName ?? 'alfa_expense_app_backup_v5.kabas',
      type: FileType.custom,
      allowedExtensions: ['kabas'],
      bytes: Uint8List.fromList(utf8.encode(encrypted)),
    );
  }

  static Future<BackupData?> importEncryptedBackup({
    required String password,
    String? dialogTitle,
  }) async {
    final result = await FilePicker.pickFiles(
      dialogTitle: dialogTitle ?? 'استيراد نسخة احتياطية مشفرة',
      type: FileType.custom,
      allowedExtensions: ['kabas'],
      withData: true,
    );
    final file = result?.files.single;
    final bytes = await _readPickedFileBytes(file);
    if (bytes == null) return null;
    if (bytes.length > _maxImportFileBytes) {
      throw const FormatException('حجم ملف النسخة يتجاوز 200MB');
    }
    return decodeEncryptedBackup(utf8.decode(bytes), password: password);
  }

  static Future<List<Map<String, Object?>>> _encodeAttachments(
    List<ExpenseRequest> requests, {
    List<DebtAccount> debts = const [],
  }) async {
    final paths = <String>{};
    void collect(ExpenseRequest request) {
      paths.addAll(request.allAttachmentPaths);
      if (request.secondRequest != null) collect(request.secondRequest!);
    }

    for (final request in requests) {
      collect(request);
    }
    for (final debt in debts) {
      for (final entry in debt.entries) {
        final path = entry.attachmentPath;
        if (path != null && path.trim().isNotEmpty) paths.add(path);
      }
    }
    if (paths.length > _maxBackupAttachments) {
      AppLogger.error(
        'Backup contains more than $_maxBackupAttachments attachments',
        scope: 'backup',
      );
      throw const FormatException(
        'النسخة تحتوي على أكثر من 100 مرفق. لم يتم التصدير حتى لا تفقد بيانات.',
      );
    }
    final result = <Map<String, Object?>>[];
    var totalBytes = 0;
    for (final path in paths) {
      if (!await AttachmentManager.isManagedPath(path)) {
        throw const FormatException(
          'يوجد مرفق خارج مخزن التطبيق ولا يمكن نسخه بأمان',
        );
      }
      final file = File(path);
      if (!await file.exists()) {
        throw const FormatException(
          'يوجد مرفق مفقود ولم يتم التصدير لتجنب فقدان البيانات',
        );
      }
      final bytes = await file.readAsBytes();
      if (bytes.isEmpty || bytes.length > _maxBackupAttachmentBytes) {
        throw const FormatException(
          'يوجد مرفق فارغ أو أكبر من 10MB. افحصه ثم أعد التصدير.',
        );
      }
      totalBytes += bytes.length;
      if (totalBytes > _maxBackupTotalAttachmentBytes) {
        throw const FormatException(
          'إجمالي المرفقات يتجاوز 70MB؛ لم يتم التصدير لتجنب إنشاء نسخة غير قابلة للاستعادة.',
        );
      }
      final name = path.split(Platform.pathSeparator).last;
      result.add({
        'id': path,
        'fileName': name,
        'mimeType': _mimeType(name),
        'base64': base64Encode(bytes),
        'sha256': sha256.convert(bytes).toString(),
      });
    }
    return result;
  }

  static String _mimeType(String name) {
    final lower = name.toLowerCase();
    if (lower.endsWith('.pdf')) return 'application/pdf';
    if (lower.endsWith('.png')) return 'image/png';
    if (lower.endsWith('.webp')) return 'image/webp';
    return 'image/jpeg';
  }

  static Future<BackupData?> importBackup() async {
    final result = await FilePicker.pickFiles(
      dialogTitle: 'استيراد نسخة احتياطية',
      type: FileType.custom,
      allowedExtensions: ['json'],
      withData: true,
    );
    final file = result?.files.single;
    final bytes = await _readPickedFileBytes(file);
    if (bytes == null) return null;
    if (bytes.length > _maxImportFileBytes) {
      throw const FormatException('حجم ملف النسخة يتجاوز 200MB');
    }
    return decodeBackup(utf8.decode(bytes));
  }

  static Future<Uint8List?> _readPickedFileBytes(PlatformFile? file) async {
    if (file == null) return null;
    if (file.bytes != null) return file.bytes;
    final path = file.path;
    if (path == null || path.trim().isEmpty) return null;
    final picked = File(path);
    if (!await picked.exists()) return null;
    return picked.readAsBytes();
  }

  static BackupData decodeBackup(String source) {
    if (source.length > _maxImportFileBytes ||
        utf8.encode(source).length > _maxImportFileBytes) {
      throw const FormatException('حجم ملف النسخة يتجاوز 200MB');
    }
    source = EncryptedBackupCodec.normalizeSource(source);
    final raw = jsonDecode(source);
    if (raw is! Map<String, dynamic>) {
      throw const FormatException('ملف نسخة احتياطية غير مدعوم');
    }
    final original = Map<String, dynamic>.from(raw);
    final migration = BackupSchemaMigrator.migrate(original);
    final decoded = migration.data;
    final version = migration.sourceVersion;

    Map<String, Object?> asObjectMap(Object? value, {required String field}) {
      if (value is! Map) {
        throw FormatException('الحقل $field في النسخة الاحتياطية غير صحيح');
      }
      return InputLimits.strictMap(value, field: field);
    }

    List<T> decodeList<T>(
      Object? value, {
      required String label,
      required T Function(Map<String, Object?>) parse,
    }) {
      if (value == null) return <T>[];
      if (value is! List) {
        throw FormatException('قائمة $label في النسخة الاحتياطية غير صحيحة');
      }
      _requireBackupListLimit(label, value.length);
      if (value.any((item) => item is! Map)) {
        throw FormatException('تحتوي قائمة $label على سجل تالف');
      }
      return value
          .map((item) => parse(asObjectMap(item, field: label)))
          .toList();
    }

    final settingsByScope = <String, AppSettings>{};
    final scopedValue = decoded['settings_by_scope'];
    if (scopedValue is! Map) {
      throw const FormatException('بنية إعدادات النماذج غير صالحة');
    }
    for (final entry in scopedValue.entries) {
      if (entry.key is! String || entry.value is! Map) {
        throw const FormatException('بنية إعدادات النماذج غير صالحة');
      }
      final scope = entry.key as String;
      settingsByScope[scope] = AppSettings.fromMap(
        asObjectMap(entry.value, field: 'settings_by_scope.$scope'),
      );
    }

    if (decoded['requests'] is! List) {
      throw const FormatException(
        'قائمة الطلبات غير موجودة أو غير صحيحة في النسخة الاحتياطية',
      );
    }

    final quick = <String, List<String>>{};
    final rawQuick = decoded['quick_statements'];
    if (rawQuick != null) {
      if (rawQuick is! Map) {
        throw const FormatException(
          'قائمة العبارات السريعة في النسخة الاحتياطية غير صحيحة',
        );
      }
      _requireBackupListLimit('مجموعات العبارات السريعة', rawQuick.length);
      var quickStatementCount = 0;
      for (final entry in rawQuick.entries) {
        if (entry.key is! String || entry.value is! List) {
          throw const FormatException(
            'تحتوي العبارات السريعة على مجموعة تالفة',
          );
        }
        final statements = entry.value as List;
        quickStatementCount += statements.length;
        _requireBackupListLimit('العبارات السريعة', quickStatementCount);
        if (statements.any((item) => item is! String)) {
          throw const FormatException(
            'تحتوي العبارات السريعة على عنصر غير صالح',
          );
        }
        quick[entry.key as String] = statements.cast<String>().toList();
      }
    }

    final masters = <String, SavedPattern>{};
    final rawMasters = decoded['master_patterns_by_scope'];
    if (rawMasters != null) {
      if (rawMasters is! Map) {
        throw const FormatException(
          'قائمة النماذج الرئيسية في النسخة الاحتياطية غير صحيحة',
        );
      }
      _requireBackupListLimit('النماذج الرئيسية حسب النطاق', rawMasters.length);
      for (final entry in rawMasters.entries) {
        if (entry.key is! String || entry.value is! Map) {
          throw const FormatException('تحتوي النماذج الرئيسية على سجل تالف');
        }
        masters[entry.key as String] = SavedPattern.fromMapStrict(
          asObjectMap(entry.value, field: 'master_patterns_by_scope'),
        );
      }
    }

    final attachments = <Map<String, Object?>>[];
    final attachmentIds = <String>{};
    var totalAttachmentBytes = 0;
    final rawAttachments = decoded['attachments'];
    if (rawAttachments != null) {
      if (rawAttachments is! List) {
        throw const FormatException(
          'قائمة المرفقات في النسخة الاحتياطية غير صحيحة',
        );
      }
      if (rawAttachments.length > _maxBackupAttachments) {
        throw const FormatException(
          'النسخة الاحتياطية تحتوي على مرفقات أكثر من الحد المسموح؛ لم يتم اقتطاعها',
        );
      }
      for (final item in rawAttachments) {
        if (item is! Map ||
            item['id'] is! String ||
            item['base64'] is! String ||
            (item['fileName'] != null && item['fileName'] is! String) ||
            (item['mimeType'] != null && item['mimeType'] is! String) ||
            (item['sha256'] != null && item['sha256'] is! String)) {
          throw const FormatException(
            'تحتوي المرفقات في النسخة الاحتياطية على سجل تالف',
          );
        }
        final id = InputLimits.strictString(
          item['id'],
          field: 'attachment.id',
          maxLength: InputLimits.maxIdLength,
        );
        if (id.isEmpty || !attachmentIds.add(id)) {
          throw const FormatException(
            'النسخة الاحتياطية تحتوي على معرفات مرفقات مكررة',
          );
        }
        final encoded = item['base64'] as String;
        if (encoded.length > ((_maxBackupAttachmentBytes + 2) * 4 ~/ 3 + 4)) {
          throw const FormatException(
            'المرفق في النسخة الاحتياطية يتجاوز الحجم المسموح',
          );
        }
        final attachmentBytes = base64Decode(encoded);
        if (attachmentBytes.isEmpty ||
            attachmentBytes.length > _maxBackupAttachmentBytes) {
          throw const FormatException(
            'بيانات المرفق فارغة أو تتجاوز الحجم المسموح',
          );
        }
        totalAttachmentBytes += attachmentBytes.length;
        if (totalAttachmentBytes > _maxBackupTotalAttachmentBytes) {
          throw const FormatException(
            'إجمالي المرفقات في النسخة يتجاوز 70MB؛ لم يتم اقتطاعها',
          );
        }
        final checksum = item['sha256'];
        if (checksum != null &&
            checksum != sha256.convert(attachmentBytes).toString()) {
          throw const FormatException('فشل التحقق من سلامة المرفق');
        }
        attachments.add(Map<String, Object?>.from(item));
      }
    }

    final productCatalog = decodeList(
      decoded['product_catalog'],
      label: 'دليل الأصناف',
      parse: ProductItem.fromMap,
    );
    final hasRepresentativeReports = original.containsKey(
      'representative_reports',
    );
    final rawRepresentativeReports = decoded['representative_reports'];
    if (hasRepresentativeReports && rawRepresentativeReports is! List) {
      throw const FormatException(
        'قائمة تقارير المندوبين في النسخة الاحتياطية غير صحيحة',
      );
    }
    final representativeReports = decodeList(
      rawRepresentativeReports,
      label: 'تقارير المندوبين',
      parse: RepresentativeReport.fromMapStrict,
    );
    return BackupData(
      settings: settingsByScope['expenseRequest'] ?? AppSettings.defaults(),
      settingsByScope: settingsByScope,
      requests: decodeList(
        decoded['requests'],
        label: 'الطلبات',
        parse: ExpenseRequest.fromMapStrict,
      ),
      reminders: decodeList(
        decoded['reminders'],
        label: 'التذكيرات',
        parse: _decodeReminderStrict,
      ),
      debts: decodeList(
        decoded['debts'],
        label: 'الديون',
        parse: DebtAccount.fromMapStrict,
      ),
      notes: decodeList(
        decoded['notes'],
        label: 'الملاحظات',
        parse: Note.fromMapStrict,
      ),
      quickStatements: quick,
      savedPatterns: decodeList(
        decoded['saved_patterns'],
        label: 'الأنماط المحفوظة',
        parse: SavedPattern.fromMapStrict,
      ),
      masterPatternsByScope: masters,
      debtSettings: decoded['debt_settings'] == null
          ? const {}
          : InputLimits.strictMap(
              decoded['debt_settings'],
              field: 'debt_settings',
            ),
      calculatorHistory: _decodeCalculatorHistory(
        decoded['calculator_history'],
      ),
      attachments: attachments,
      productCatalog: productCatalog,
      hasProductCatalog: original['product_catalog'] is List,
      representativeReports: representativeReports,
      hasRepresentativeReports: hasRepresentativeReports,
      hasReminders: version >= 2 && original['reminders'] is List,
      hasDebts: version >= 2 && original['debts'] is List,
      hasNotes: version >= 2 && original['notes'] is List,
      hasQuickStatements:
          version >= 2 && original['quick_statements'] is Map,
      hasSavedPatterns: original['saved_patterns'] is List,
      hasDebtSettings: original['debt_settings'] is Map,
      hasCalculatorHistory: original['calculator_history'] is List,
      version: version,
      migrationWarnings: migration.warnings,
    );
  }

  static Future<void> restoreBackup(BackupData backup) =>
      StoreMutex.run('backup_restore', () => _restoreBackup(backup));

  static Future<void> _restoreBackup(BackupData backup) async {
    _validateBackupData(backup);
    final currentSettings = <String, AppSettings>{};
    final scopesToRollback = <String>{
      ...requiredBackupScopes,
      ...backup.settingsByScope.keys,
    };
    for (final scope in scopesToRollback) {
      currentSettings[scope] = await SettingsStore.load(scope: scope);
    }
    final currentRequests = await RequestStore.load();
    final currentReminders = await ReminderStore.load();
    final currentDebts = await DebtStore.load();
    final currentNotes = await NotesStore.load();
    final currentProductCatalog = await ProductCatalogStore.load();
    final currentRepresentativeReports = await RepresentativeReportStore.load();
    final currentPatterns = await PatternStore.load();
    final currentQuickStatements = <String, List<String>>{
      for (final scope in requiredBackupScopes)
        scope: await QuickStatementStore.load(scope),
    };
    final currentMasterPatterns = <String, SavedPattern>{};
    for (final scope in {...requiredBackupScopes, 'global'}) {
      final pattern = await PatternStore.loadMaster(scope: scope);
      if (pattern != null) currentMasterPatterns[scope] = pattern;
    }
    final currentMetadata = await _readMetadata();
    final createdDuringImport = <File>[];
    try {
      final attachmentIds = backup.attachments
          .map((attachment) => attachment['id'])
          .whereType<String>()
          .toSet();
      void validateAttachmentReferences(ExpenseRequest request) {
        if (request.allAttachmentPaths.any(
          (path) => !attachmentIds.contains(path),
        )) {
          throw const FormatException(
            'النسخة الاحتياطية تحتوي على مسار مرفق غير موجود داخل النسخة',
          );
        }
        if (request.secondRequest != null) {
          validateAttachmentReferences(request.secondRequest!);
        }
      }

      for (final request in backup.requests) {
        validateAttachmentReferences(request);
      }
      for (final debt in backup.debts) {
        for (final entry in debt.entries) {
          final path = entry.attachmentPath;
          if (path != null && !attachmentIds.contains(path)) {
            throw const FormatException(
              'النسخة الاحتياطية تحتوي على مرفق دين غير موجود داخل النسخة',
            );
          }
        }
      }
      final pathMap = <String, String>{};
      final directory = await getApplicationSupportDirectory();
      final attachmentsDirectory = Directory('${directory.path}/attachments');
      await attachmentsDirectory.create(recursive: true);
      for (final attachment in backup.attachments) {
        final id = attachment['id'] as String;
        final fileName =
            (attachment['fileName'] as String?) ?? 'attachment.jpg';
        final safeName =
            'imported_${DateTime.now().microsecondsSinceEpoch}_${fileName.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_')}';
        final file = File('${attachmentsDirectory.path}/$safeName');
        await file.writeAsBytes(base64Decode(attachment['base64'] as String));
        createdDuringImport.add(file);
        pathMap[id] = file.path;
      }
      ExpenseRequest remap(ExpenseRequest request) => ExpenseRequest(
        date: request.date,
        receiver: request.receiver,
        amountNumber: request.amountNumber,
        amountWords: request.amountWords,
        reason: request.reason,
        statement: request.statement,
        branch: request.branch,
        account: request.account,
        requesterName: request.requesterName,
        requesterSignature: request.requesterSignature,
        directManagerName: request.directManagerName,
        directManagerSignature: request.directManagerSignature,
        approvedAuthorityName: request.approvedAuthorityName,
        approvedAuthoritySignature: request.approvedAuthoritySignature,
        accountsManagerName: request.accountsManagerName,
        accountsManagerSignature: request.accountsManagerSignature,
        customFields: request.customFields,
        formCount: request.formCount,
        secondRequest: request.secondRequest == null
            ? null
            : remap(request.secondRequest!),
        isFavorite: request.isFavorite,
        attachmentPath:
            pathMap[request.attachmentPath] ?? request.attachmentPath,
        attachmentPaths: [
          for (final path in request.attachmentPaths) pathMap[path] ?? path,
        ],
        settingsSnapshot: request.settingsSnapshot,
        documentType: request.documentType,
        clearanceEntries: request.clearanceEntries,
        serviceItems: request.serviceItems,
        fuelEntries: request.fuelEntries,
        sampleItems: request.sampleItems,
        memoLayout: request.memoLayout,
      );
      final restoredRequests = backup.requests.map(remap).toList();
      final restoredDebts = backup.debts
          .map(
            (debt) => debt.copyWith(
              entries: debt.entries
                  .map(
                    (entry) => entry.copyWith(
                      attachmentPath: pathMap[entry.attachmentPath],
                    ),
                  )
                  .toList(),
            ),
          )
          .toList();
      await ReminderNotificationService.instance.cancelAll();
      for (final entry in backup.settingsByScope.entries) {
        await SettingsStore.save(entry.value, scope: entry.key);
      }
      await RequestStore.saveAll(restoredRequests);
      if (backup.hasReminders) await ReminderStore.saveAll(backup.reminders);
      if (backup.hasDebts) await DebtStore.saveAll(restoredDebts);
      if (backup.hasNotes) await NotesStore.saveAll(backup.notes);
      if (backup.hasProductCatalog) {
        await ProductCatalogStore.saveAll(backup.productCatalog);
      }
      if (backup.hasRepresentativeReports) {
        await RepresentativeReportStore.saveAll(backup.representativeReports);
      }
      if (backup.hasQuickStatements) {
        await _restoreQuickStatements(backup.quickStatements);
      }
      if (backup.hasDebtSettings || backup.hasCalculatorHistory) {
        await _writeMetadata(
          backup.hasDebtSettings
              ? backup.debtSettings
              : currentMetadata.debtSettings,
          backup.hasCalculatorHistory
              ? backup.calculatorHistory
              : currentMetadata.calculatorHistory,
        );
      }
      if (backup.hasSavedPatterns) {
        await PatternStore.saveAll(backup.savedPatterns);
      }
      for (final entry in backup.masterPatternsByScope.entries) {
        await PatternStore.saveMaster(entry.value.settings, scope: entry.key);
      }
      await ReminderNotificationService.instance.rescheduleSaved();
    } catch (error, stackTrace) {
      try {
        await ReminderNotificationService.instance.cancelAll();
        for (final file in createdDuringImport) {
          if (await file.exists()) await file.delete();
        }
        for (final entry in currentSettings.entries) {
          await SettingsStore.save(entry.value, scope: entry.key);
        }
        await RequestStore.saveAll(currentRequests);
        await ReminderStore.saveAll(currentReminders);
        await DebtStore.saveAll(currentDebts);
        await NotesStore.saveAll(currentNotes);
        await RepresentativeReportStore.saveAll(currentRepresentativeReports);
        await ProductCatalogStore.saveAll(currentProductCatalog);
        await PatternStore.saveAll(currentPatterns);
        await _restoreQuickStatements(currentQuickStatements);
        final masterScopes = <String>{
          ...currentMasterPatterns.keys,
          ...backup.masterPatternsByScope.keys,
        };
        for (final scope in masterScopes) {
          final current = currentMasterPatterns[scope];
          if (current == null) {
            await PatternStore.deleteMaster(scope: scope);
          } else {
            await PatternStore.saveMaster(current.settings, scope: scope);
          }
        }
        await _writeMetadata(
          currentMetadata.debtSettings,
          currentMetadata.calculatorHistory,
        );
        await ReminderNotificationService.instance.rescheduleSaved();
      } catch (rollbackError, rollbackStackTrace) {
        Error.throwWithStackTrace(
          StateError('فشلت الاستعادة وفشل rollback أيضًا: $rollbackError'),
          rollbackStackTrace,
        );
      }
      Error.throwWithStackTrace(error, stackTrace);
    }
  }

  static Reminder _decodeReminderStrict(Map<String, Object?> map) {
    if (map.containsKey('id'))
      InputLimits.strictInteger(map['id'], field: 'id', min: 0, max: 1 << 62);
    if (map.containsKey('title'))
      InputLimits.strictString(map['title'], field: 'title');
    if (map.containsKey('notes'))
      InputLimits.strictString(
        map['notes'],
        field: 'notes',
        maxLength: InputLimits.maxLongTextLength,
      );
    InputLimits.strictDateTime(map['scheduledAt'], field: 'scheduledAt');
    if (map.containsKey('sound'))
      InputLimits.strictString(map['sound'], field: 'sound');
    if (map.containsKey('repeat'))
      InputLimits.strictString(map['repeat'], field: 'repeat', maxLength: 32);
    if (map.containsKey('repeatIntervalDays'))
      InputLimits.strictInteger(
        map['repeatIntervalDays'],
        field: 'repeatIntervalDays',
        min: 1,
        max: 3650,
      );
    if (map.containsKey('isDone'))
      InputLimits.strictBool(map['isDone'], field: 'isDone');
    if (map.containsKey('snoozedUntil') && map['snoozedUntil'] != null)
      InputLimits.strictDateTime(map['snoozedUntil'], field: 'snoozedUntil');
    return Reminder.fromMap(map);
  }

  static void _validateBackupData(BackupData backup) {
    _validateExportCounts(
      requests: backup.requests,
      reminders: backup.reminders,
      debts: backup.debts,
      notes: backup.notes,
      quickStatements: backup.quickStatements,
      savedPatterns: backup.savedPatterns,
      masterPatternsByScope: backup.masterPatternsByScope,
      calculatorHistory: backup.calculatorHistory,
      productCatalog: backup.productCatalog,
      representativeReports: backup.representativeReports,
    );
    for (final request in backup.requests)
      ExpenseRequest.fromMapStrict(request.toMap());
    for (final reminder in backup.reminders)
      _decodeReminderStrict(reminder.toMap());
    for (final debt in backup.debts) DebtAccount.fromMapStrict(debt.toMap());
    for (final note in backup.notes) Note.fromMapStrict(note.toMap());
    for (final pattern in backup.savedPatterns)
      SavedPattern.fromMapStrict(pattern.toMap());
    for (final pattern in backup.masterPatternsByScope.values)
      SavedPattern.fromMapStrict(pattern.toMap());
    for (final report in backup.representativeReports)
      RepresentativeReport.fromMapStrict(report.toMap());
    if (backup.calculatorHistory.length > _maxBackupListItems) {
      throw const FormatException('سجل الحاسبة غير صحيح');
    }
    for (final values in backup.quickStatements.values) {
      if (values.length > _maxBackupListItems)
        throw const FormatException('العبارات السريعة تتجاوز الحد');
      for (final value in values)
        InputLimits.strictString(value, field: 'quick_statements');
    }
    if (backup.attachments.length > _maxBackupAttachments) {
      throw const FormatException('عدد المرفقات يتجاوز الحد المسموح');
    }
    final attachmentIds = <String>{};
    var totalAttachmentBytes = 0;
    for (final attachment in backup.attachments) {
      final id = InputLimits.strictString(
        attachment['id'],
        field: 'attachment.id',
        maxLength: InputLimits.maxIdLength,
      );
      if (id.isEmpty || !attachmentIds.add(id)) {
        throw const FormatException('معرف مرفق فارغ أو مكرر');
      }
      final fileName = attachment['fileName'];
      if (fileName != null) {
        InputLimits.strictString(
          fileName,
          field: 'attachment.fileName',
          maxLength: 512,
        );
      }
      final mimeType = attachment['mimeType'];
      if (mimeType != null) {
        InputLimits.strictString(
          mimeType,
          field: 'attachment.mimeType',
          maxLength: 256,
        );
      }
      final encoded = InputLimits.strictString(
        attachment['base64'],
        field: 'attachment.base64',
        maxLength: ((_maxBackupAttachmentBytes + 2) * 4 ~/ 3 + 4),
      );
      final bytes = base64Decode(encoded);
      if (bytes.isEmpty || bytes.length > _maxBackupAttachmentBytes) {
        throw const FormatException('المرفق فارغ أو يتجاوز الحجم المسموح');
      }
      totalAttachmentBytes += bytes.length;
      if (totalAttachmentBytes > _maxBackupTotalAttachmentBytes) {
        throw const FormatException('إجمالي المرفقات يتجاوز 70MB');
      }
      final checksum = attachment['sha256'];
      if (checksum != null) {
        final expected = InputLimits.strictString(
          checksum,
          field: 'attachment.sha256',
          maxLength: 64,
        );
        if (expected != sha256.convert(bytes).toString()) {
          throw const FormatException('فشل التحقق من سلامة المرفق');
        }
      }
    }
  }

  static Future<void> _restoreQuickStatements(
    Map<String, List<String>> values,
  ) async {
    for (final scope in requiredBackupScopes) {
      await QuickStatementStore.save(scope, values[scope] ?? const []);
    }
  }

  static Future<
    ({Map<String, Object?> debtSettings, List<String> calculatorHistory})
  >
  _readMetadata() => StoreMutex.run('backup_metadata', () async {
    final preferences = await SharedPreferences.getInstance();
    final secure = await SecureLocalStore.readJson('backup.metadata');
    final debtSettings = secure == null
        ? <String, Object?>{
            'currency': preferences.getString('alfa_debt_currency') ?? 'ريال',
            'reportTitle':
                preferences.getString('alfa_debt_report_title') ??
                'تقرير الحسابات والديون',
            'decimals': preferences.getInt('alfa_debt_decimals') ?? 2,
            'hideZero': preferences.getBool('alfa_debt_hide_zero') ?? false,
          }
        : InputLimits.strictMap(
            InputLimits.strictMap(
              secure,
              field: 'backup.metadata',
            )['debtSettings'],
            field: 'debtSettings',
          );
    final rawHistory = secure == null
        ? preferences.getStringList('alfa_calculator_history') ??
              const <String>[]
        : InputLimits.strictList(
            InputLimits.strictMap(
              secure,
              field: 'backup.metadata',
            )['calculatorHistory'],
            field: 'calculatorHistory',
            maxLength: _maxBackupListItems,
          );
    if (rawHistory.length > _maxBackupListItems ||
        rawHistory.any((item) => item is! String)) {
      throw const FormatException('سجل الحاسبة في metadata غير صحيح');
    }
    final normalizedDebtSettings = <String, Object?>{
      'currency': InputLimits.strictString(
        debtSettings['currency'] ?? 'ريال',
        field: 'currency',
        maxLength: 128,
      ),
      'reportTitle': InputLimits.strictString(
        debtSettings['reportTitle'] ?? 'تقرير الحسابات والديون',
        field: 'reportTitle',
        maxLength: 512,
      ),
      'decimals': InputLimits.strictInteger(
        debtSettings['decimals'] ?? 2,
        field: 'decimals',
        min: 0,
        max: 8,
      ),
      'hideZero': InputLimits.strictBool(
        debtSettings['hideZero'] ?? false,
        field: 'hideZero',
      ),
    };
    return (
      debtSettings: normalizedDebtSettings,
      calculatorHistory: rawHistory.cast<String>(),
    );
  });

  static Future<void> _writeMetadata(
    Map<String, Object?> debtSettings,
    List<String> calculatorHistory,
  ) => StoreMutex.run('backup_metadata', () async {
    final preferences = await SharedPreferences.getInstance();
    if (calculatorHistory.length > _maxBackupListItems) {
      throw const FormatException('سجل الحاسبة غير صحيح');
    }
    final currency = InputLimits.strictString(
      debtSettings['currency'] ?? 'ريال',
      field: 'currency',
      maxLength: 128,
    );
    final reportTitle = InputLimits.strictString(
      debtSettings['reportTitle'] ?? 'تقرير الحسابات والديون',
      field: 'reportTitle',
      maxLength: 512,
    );
    final decimals = InputLimits.strictInteger(
      debtSettings['decimals'] ?? 2,
      field: 'decimals',
      min: 0,
      max: 8,
    );
    final hideZero = debtSettings['hideZero'] ?? false;
    InputLimits.strictBool(hideZero, field: 'hideZero');
    await SecureLocalStore.writeJson('backup.metadata', {
      'debtSettings': {
        'currency': currency,
        'reportTitle': reportTitle,
        'decimals': decimals,
        'hideZero': hideZero,
      },
      'calculatorHistory': calculatorHistory,
    });
    await _removeLegacyMetadata(preferences);
  });

  static Future<void> _removeLegacyMetadata(
    SharedPreferences preferences,
  ) async {
    await preferences.remove('alfa_debt_currency');
    await preferences.remove('alfa_debt_report_title');
    await preferences.remove('alfa_debt_decimals');
    await preferences.remove('alfa_debt_hide_zero');
    await preferences.remove('alfa_calculator_history');
  }
}
