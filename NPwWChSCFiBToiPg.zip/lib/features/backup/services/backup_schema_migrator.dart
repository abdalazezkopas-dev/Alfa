import 'dart:convert';

import '../../settings/models/app_settings.dart';

/// Backup data schema is independent of the application release version.
/// Historical input is copied before migration so callers and source bytes are
/// never mutated. Unknown future versions are rejected before restore begins.
abstract final class BackupSchemaMigrator {
  static const format = 'alfa_expense_app_backup';
  static const currentVersion = 5;
  static const scopes = <String>[
    'expenseRequest',
    'clearanceRequest',
    'serviceRequest',
    'fuelRequest',
    'customerApplication',
    'internalMemo',
    'sampleRequest',
    'sampleRequestSinglePage',
    'travelAllowance',
  ];

  static BackupMigrationResult migrate(Map<String, dynamic> input) {
    if (input['format'] != format) {
      throw const FormatException('ملف نسخة احتياطية غير مدعوم');
    }
    final rawVersion = input['version'];
    if (rawVersion is! num ||
        !rawVersion.isFinite ||
        rawVersion != rawVersion.toInt() ||
        rawVersion < 1) {
      throw const FormatException('رقم إصدار بيانات النسخة غير صالح');
    }
    final sourceVersion = rawVersion.toInt();
    if (sourceVersion > currentVersion) {
      throw const FormatException(
        'أُنشئت النسخة بإصدار بيانات أحدث. حدّث التطبيق قبل استيرادها.',
      );
    }

    // Deep copy preserves optional absent sections and the original payload.
    final data = jsonDecode(jsonEncode(input)) as Map<String, dynamic>;
    final warnings = <String>[];
    for (var version = sourceVersion; version < currentVersion; version++) {
      switch (version) {
        case 1:
          for (final key in ['reminders', 'debts', 'notes']) {
            data.putIfAbsent(key, () => <Object?>[]);
          }
          data.putIfAbsent('quick_statements', () => <String, Object?>{});
        case 2:
          data.putIfAbsent('settings_by_scope', () => <String, Object?>{});
        case 3:
          // v4 added scoped form settings; defaults are filled below.
          break;
        case 4:
          data.putIfAbsent('schema_version', () => currentVersion);
      }
      data['version'] = version + 1;
    }

    final schemaVersion = data['schema_version'];
    if (schemaVersion != null && schemaVersion != currentVersion) {
      throw const FormatException('رقم مخطط البيانات لا يطابق إصدار النسخة');
    }
    data['schema_version'] = currentVersion;

    final rawScopes = data['settings_by_scope'];
    if (rawScopes != null && rawScopes is! Map) {
      throw const FormatException('بنية إعدادات النماذج غير صالحة');
    }
    final scoped = <String, Object?>{};
    if (rawScopes is Map) {
      for (final entry in rawScopes.entries) {
        if (entry.key is! String || entry.value is! Map) {
          throw const FormatException('بنية إعدادات النماذج غير صالحة');
        }
        scoped[entry.key as String] = Map<String, Object?>.from(
          entry.value as Map,
        );
      }
    }
    final legacySettings = data['settings'];
    if (legacySettings != null && legacySettings is! Map) {
      throw const FormatException('بنية الإعدادات القديمة غير صالحة');
    }
    for (final scope in scopes) {
      if (scoped.containsKey(scope)) continue;
      scoped[scope] = scope == 'expenseRequest' && legacySettings is Map
          ? Map<String, Object?>.from(legacySettings)
          : AppSettings.defaultsForScope(scope).toMap();
      if (sourceVersion >= 3) {
        warnings.add(
          'لا تتضمن النسخة إعدادات النطاق «$scope»؛ سيُستخدم له الإعداد الافتراضي عند المتابعة.',
        );
      }
    }
    data['settings_by_scope'] = scoped;
    data['settings'] = scoped['expenseRequest'];

    return BackupMigrationResult(
      data: data,
      sourceVersion: sourceVersion,
      warnings: List.unmodifiable(warnings),
    );
  }
}

class BackupMigrationResult {
  const BackupMigrationResult({
    required this.data,
    required this.sourceVersion,
    required this.warnings,
  });

  final Map<String, dynamic> data;
  final int sourceVersion;
  final List<String> warnings;
}
