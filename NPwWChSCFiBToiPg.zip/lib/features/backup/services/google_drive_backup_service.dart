import 'dart:async';
import 'dart:typed_data';

import 'package:extension_google_sign_in_as_googleapis_auth/extension_google_sign_in_as_googleapis_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:googleapis/drive/v3.dart' as drive;
import 'package:googleapis_auth/googleapis_auth.dart' as auth;

class GoogleDriveBackupRecord {
  const GoogleDriveBackupRecord({
    required this.id,
    required this.name,
    required this.createdTime,
    required this.size,
  });

  final String id;
  final String name;
  final DateTime? createdTime;
  final int? size;
}

class GoogleDriveBackupService {
  GoogleDriveBackupService._();

  static final GoogleDriveBackupService instance = GoogleDriveBackupService._();
  static const scopes = <String>[
    'https://www.googleapis.com/auth/drive.appdata',
  ];
  // For a direct Google Cloud registration (without google-services.json),
  // provide the Web OAuth client ID at build time with
  // --dart-define=GOOGLE_SERVER_CLIENT_ID=... . This ID is public, not a secret.
  static const _serverClientId = String.fromEnvironment(
    'GOOGLE_SERVER_CLIENT_ID',
  );
  static final GoogleSignIn _signIn = GoogleSignIn.instance;
  static bool _initialized = false;
  GoogleSignInAccount? _user;

  GoogleSignInAccount? get currentUser => _user;

  Future<void> initialize() async {
    if (_initialized) return;
    await _signIn.initialize(
      serverClientId: _serverClientId.isEmpty ? null : _serverClientId,
    );
    _initialized = true;
  }

  Future<GoogleSignInAccount?> signIn() async {
    await initialize();
    if (!_signIn.supportsAuthenticate()) {
      throw StateError('تسجيل الدخول إلى Google غير متاح على هذا الجهاز');
    }
    _user = await _signIn.authenticate();
    return _user;
  }

  Future<void> signOut() async {
    await initialize();
    await _signIn.signOut();
    _user = null;
  }

  Future<auth.AuthClient> _authenticatedClient() async {
    await initialize();
    final user = _user ?? await signIn();
    if (user == null) throw StateError('لم يتم تسجيل الدخول إلى Google');
    final authorization =
        await user.authorizationClient.authorizationForScopes(scopes) ??
        await user.authorizationClient.authorizeScopes(scopes);
    return authorization.authClient(scopes: scopes);
  }

  Future<GoogleDriveBackupRecord> upload({
    required Uint8List bytes,
    String fileName = 'alfa_expense_app_backup_v4.kabas',
  }) async {
    final client = await _authenticatedClient();
    try {
      final api = drive.DriveApi(client);
      final metadata = drive.File()
        ..name = fileName
        ..parents = ['appDataFolder'];
      final media = drive.Media(Stream<Uint8List>.value(bytes), bytes.length);
      final uploaded = await api.files.create(
        metadata,
        uploadMedia: media,
        $fields: 'id,name,createdTime,size',
      );
      return GoogleDriveBackupRecord(
        id: uploaded.id ?? '',
        name: uploaded.name ?? fileName,
        createdTime: uploaded.createdTime,
        size: int.tryParse(uploaded.size ?? '${bytes.length}'),
      );
    } finally {
      client.close();
    }
  }

  Future<List<GoogleDriveBackupRecord>> list() async {
    final client = await _authenticatedClient();
    try {
      final response = await drive.DriveApi(client).files.list(
        spaces: 'appDataFolder',
        orderBy: 'createdTime desc',
        $fields: 'files(id,name,createdTime,size)',
      );
      return (response.files ?? const <drive.File>[])
          .where((file) => file.id != null)
          .map(
            (file) => GoogleDriveBackupRecord(
              id: file.id!,
              name: file.name ?? 'نسخة احتياطية',
              createdTime: file.createdTime,
              size: int.tryParse(file.size ?? ''),
            ),
          )
          .toList();
    } finally {
      client.close();
    }
  }

  Future<Uint8List> download(String fileId) async {
    final client = await _authenticatedClient();
    try {
      final response = await drive.DriveApi(
        client,
      ).files.get(fileId, downloadOptions: drive.DownloadOptions.fullMedia);
      if (response is! drive.Media) {
        throw StateError('لم يُرجع Google Drive ملف النسخة الاحتياطية');
      }
      final builder = BytesBuilder();
      await for (final chunk in response.stream) {
        builder.add(chunk);
      }
      return builder.takeBytes();
    } finally {
      client.close();
    }
  }

  Future<void> delete(String fileId) async {
    final client = await _authenticatedClient();
    try {
      await drive.DriveApi(client).files.delete(fileId);
    } finally {
      client.close();
    }
  }
}
