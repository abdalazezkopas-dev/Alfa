import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/security/secure_local_store.dart';
import '../../../core/services/app_logger.dart';
import '../../../core/store_mutex.dart';
import '../models/note.dart';

class NotesStore {
  const NotesStore._();
  static const _key = 'alfa_expense_app.notes.v1';
  static const _maxItems = 5000;

  static Future<List<Note>> load() => StoreMutex.run('notes', _loadUnlocked);

  static Future<List<Note>> _loadUnlocked() async {
    final preferences = await SharedPreferences.getInstance();
    String? raw;
    try {
      raw = await SecureLocalStore.read('notes');
    } catch (error, stackTrace) {
      AppLogger.error(
        'تعذر قراءة التخزين الآمن للملاحظات',
        error: error,
        stackTrace: stackTrace,
        scope: 'notes',
      );
      rethrow;
    }
    final fromSecure = raw != null && raw.isNotEmpty;
    raw ??= preferences.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    final notes = _decode(raw);
    if (!fromSecure) {
      await SecureLocalStore.writeJson(
        'notes',
        notes.map((note) => note.toMap()).toList(),
      );
      await preferences.remove(_key);
    }
    return notes;
  }

  static List<Note> _decode(String raw) {
    final decoded = jsonDecode(raw);
    if (decoded is! List || decoded.length > _maxItems) {
      throw const FormatException('تخزين الملاحظات غير صحيح');
    }
    return decoded.map((item) => Note.fromMapStrict(_map(item))).toList();
  }

  static Map<String, Object?> _map(Object? value) {
    if (value is! Map) throw const FormatException('سجل ملاحظة تالف');
    return Map<String, Object?>.from(value);
  }

  static Future<void> saveAll(List<Note> notes) =>
      StoreMutex.run('notes', () async {
        _validate(notes);
        await _saveUnlocked(notes);
      });

  static Future<void> upsert(Note note) => StoreMutex.run('notes', () async {
    final notes = await _loadUnlocked();
    final index = notes.indexWhere((item) => item.id == note.id);
    if (index >= 0) {
      notes[index] = note;
    } else {
      notes.insert(0, note);
    }
    await _saveUnlocked(notes);
  });

  static Future<bool> delete(String id) => StoreMutex.run('notes', () async {
    final notes = await _loadUnlocked();
    final originalLength = notes.length;
    notes.removeWhere((note) => note.id == id);
    if (notes.length == originalLength) return false;
    await _saveUnlocked(notes);
    return true;
  });

  static void _validate(List<Note> notes) {
    if (notes.length > _maxItems)
      throw const FormatException('عدد الملاحظات يتجاوز الحد المسموح');
    for (final note in notes) Note.fromMapStrict(note.toMap());
  }

  static Future<void> _saveUnlocked(List<Note> notes) async {
    _validate(notes);
    final encoded = jsonEncode(notes.map((note) => note.toMap()).toList());
    _decode(encoded);
    final preferences = await SharedPreferences.getInstance();
    await SecureLocalStore.write('notes', encoded);
    await preferences.remove(_key);
  }
}
