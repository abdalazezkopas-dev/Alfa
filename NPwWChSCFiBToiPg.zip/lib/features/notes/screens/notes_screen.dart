import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/note.dart';
import '../services/notes_store.dart';

class NotesScreen extends StatefulWidget {
  const NotesScreen({super.key});

  @override
  State<NotesScreen> createState() => _NotesScreenState();
}

class _NotesScreenState extends State<NotesScreen> {
  final _searchController = TextEditingController();
  List<Note> _notes = [];
  bool _isLoading = true;
  bool _showArchived = false;
  Object? _loadError;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final notes = await NotesStore.load();
      if (!mounted) return;
      setState(() {
        _notes = notes;
        _loadError = null;
        _isLoading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loadError = error;
        _isLoading = false;
      });
    }
  }

  Future<void> _save(List<Note> notes) async {
    final previous = _notes;
    setState(() => _notes = notes);
    try {
      await NotesStore.saveAll(notes);
    } catch (error) {
      if (!mounted) return;
      setState(() => _notes = previous);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('تعذر حفظ الملاحظة: $error')));
    }
  }

  Future<void> _createNote() async {
    final note = await Navigator.of(
      context,
    ).push<Note>(MaterialPageRoute(builder: (_) => const NoteEditorScreen()));
    if (note != null) await _save([note, ..._notes]);
  }

  Future<void> _editNote(Note note) async {
    final updated = await Navigator.of(context).push<Note>(
      MaterialPageRoute(builder: (_) => NoteEditorScreen(note: note)),
    );
    if (updated == null) return;
    await _save(
      _notes.map((item) => item.id == updated.id ? updated : item).toList(),
    );
  }

  Future<void> _toggleArchive(Note note) async {
    await _save(
      _notes
          .map(
            (item) => item.id == note.id
                ? item.copyWith(isArchived: !item.isArchived)
                : item,
          )
          .toList(),
    );
  }

  Future<void> _delete(Note note) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف الملاحظة؟'),
        content: const Text('سيتم حذف الملاحظة وقائمة المهام المرتبطة بها.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await _save(_notes.where((item) => item.id != note.id).toList());
    }
  }

  List<Note> get _visibleNotes {
    final query = _searchController.text.trim().toLowerCase();
    final filtered = _notes.where((note) {
      if (note.isArchived != _showArchived) return false;
      if (query.isEmpty) return true;
      return '${note.title} ${note.body} ${note.category}'
          .toLowerCase()
          .contains(query);
    }).toList();
    filtered.sort((a, b) {
      if (a.isPinned != b.isPinned) return a.isPinned ? -1 : 1;
      return b.updatedAt.compareTo(a.updatedAt);
    });
    return filtered;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('النوتة'),
        actions: [
          IconButton(
            tooltip: _showArchived ? 'الملاحظات النشطة' : 'الأرشيف',
            onPressed: () => setState(() => _showArchived = !_showArchived),
            icon: Icon(
              _showArchived ? Icons.note_alt_outlined : Icons.archive_outlined,
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _createNote,
        icon: const Icon(Icons.add),
        label: const Text('ملاحظة جديدة'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _loadError != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline, size: 48),
                    const SizedBox(height: 12),
                    const Text('تعذر تحميل الملاحظات'),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: () {
                        setState(() {
                          _isLoading = true;
                          _loadError = null;
                        });
                        _load();
                      },
                      icon: const Icon(Icons.refresh),
                      label: const Text('إعادة المحاولة'),
                    ),
                  ],
                ),
              ),
            )
          : RefreshIndicator(
              onRefresh: _load,
              child: CustomScrollView(
                slivers: [
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                      child: SearchBar(
                        controller: _searchController,
                        onChanged: (_) => setState(() {}),
                        leading: const Icon(Icons.search),
                        hintText: 'ابحث في الملاحظات والمهام',
                        trailing: [
                          if (_searchController.text.isNotEmpty)
                            IconButton(
                              onPressed: () {
                                _searchController.clear();
                                setState(() {});
                              },
                              icon: const Icon(Icons.clear),
                            ),
                        ],
                      ),
                    ),
                  ),
                  SliverPadding(
                    padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
                    sliver: _visibleNotes.isEmpty
                        ? SliverFillRemaining(
                            hasScrollBody: false,
                            child: _EmptyNotes(
                              archived: _showArchived,
                              onCreate: _createNote,
                            ),
                          )
                        : SliverList.builder(
                            itemCount: _visibleNotes.length,
                            itemBuilder: (context, index) {
                              final note = _visibleNotes[index];
                              return _NoteCard(
                                note: note,
                                onTap: () => _editNote(note),
                                onArchive: () => _toggleArchive(note),
                                onDelete: () => _delete(note),
                                onPin: () => _save(
                                  _notes
                                      .map(
                                        (item) => item.id == note.id
                                            ? item.copyWith(
                                                isPinned: !item.isPinned,
                                              )
                                            : item,
                                      )
                                      .toList(),
                                ),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
    );
  }
}

class _EmptyNotes extends StatelessWidget {
  const _EmptyNotes({required this.archived, required this.onCreate});
  final bool archived;
  final VoidCallback onCreate;
  @override
  Widget build(BuildContext context) => Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(
          archived ? Icons.archive_outlined : Icons.sticky_note_2_outlined,
          size: 64,
          color: Theme.of(context).colorScheme.primary,
        ),
        const SizedBox(height: 12),
        Text(
          archived ? 'الأرشيف فارغ' : 'ابدأ أول ملاحظة لك',
          style: Theme.of(context).textTheme.titleLarge,
        ),
        const SizedBox(height: 8),
        Text(
          archived
              ? 'ستظهر هنا الملاحظات المؤرشفة.'
              : 'اكتب فكرة أو أنشئ قائمة مهام واحفظها تلقائيًا.',
          textAlign: TextAlign.center,
        ),
        if (!archived) ...[
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: onCreate,
            icon: const Icon(Icons.add),
            label: const Text('إنشاء ملاحظة'),
          ),
        ],
      ],
    ),
  );
}

class _NoteCard extends StatelessWidget {
  const _NoteCard({
    required this.note,
    required this.onTap,
    required this.onArchive,
    required this.onDelete,
    required this.onPin,
  });
  final Note note;
  final VoidCallback onTap;
  final VoidCallback onArchive;
  final VoidCallback onDelete;
  final VoidCallback onPin;
  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final completed = note.tasks.where((task) => task.isDone).length;
    return Card(
      color: Color(note.colorValue).withValues(alpha: 0.96),
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      note.title.isEmpty ? 'بدون عنوان' : note.title,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  if (note.isPinned)
                    Icon(Icons.push_pin, size: 18, color: scheme.primary),
                  PopupMenuButton<String>(
                    onSelected: (value) {
                      if (value == 'pin') onPin();
                      if (value == 'archive') onArchive();
                      if (value == 'delete') onDelete();
                    },
                    itemBuilder: (_) => [
                      PopupMenuItem(
                        value: 'pin',
                        child: Text(note.isPinned ? 'إلغاء التثبيت' : 'تثبيت'),
                      ),
                      PopupMenuItem(
                        value: 'archive',
                        child: Text(note.isArchived ? 'استعادة' : 'أرشفة'),
                      ),
                      const PopupMenuItem(value: 'delete', child: Text('حذف')),
                    ],
                  ),
                ],
              ),
              if (note.body.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(note.body, maxLines: 3, overflow: TextOverflow.ellipsis),
              ],
              if (note.tasks.isNotEmpty) ...[
                const SizedBox(height: 10),
                Row(
                  children: [
                    Icon(
                      Icons.checklist_rounded,
                      size: 18,
                      color: scheme.primary,
                    ),
                    const SizedBox(width: 6),
                    Text('$completed من ${note.tasks.length} مهام'),
                  ],
                ),
              ],
              const SizedBox(height: 10),
              Text(
                note.category,
                style: Theme.of(
                  context,
                ).textTheme.labelSmall?.copyWith(color: scheme.primary),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class NoteEditorScreen extends StatefulWidget {
  const NoteEditorScreen({this.note, super.key});
  final Note? note;
  @override
  State<NoteEditorScreen> createState() => _NoteEditorScreenState();
}

class _NoteEditorScreenState extends State<NoteEditorScreen> {
  late final TextEditingController _title;
  late final TextEditingController _body;
  late List<NoteTask> _tasks;
  late String _category;
  late int _color;
  late bool _pinned;
  late List<NoteAttachment> _attachments;
  final _taskController = TextEditingController();
  static const _colors = [
    0xFFFFFFFF,
    0xFFFFF3CD,
    0xFFE3F2FD,
    0xFFE8F5E9,
    0xFFFCE4EC,
    0xFFF3E5F5,
  ];

  @override
  void initState() {
    super.initState();
    final note = widget.note;
    _title = TextEditingController(text: note?.title ?? '');
    _body = TextEditingController(text: note?.body ?? '');
    _tasks = [...?note?.tasks];
    _category = note?.category ?? 'ملاحظات';
    _color = note?.colorValue ?? _colors.first;
    _pinned = note?.isPinned ?? false;
    _attachments = [...?note?.attachments];
  }

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    _taskController.dispose();
    super.dispose();
  }

  Future<void> _pickAttachments() async {
    final result = await FilePicker.pickFiles(
      withData: true,
      allowMultiple: true,
    );
    if (result == null) return;
    final selected = <NoteAttachment>[];
    for (final file in result.files) {
      final bytes = file.bytes;
      if (bytes == null || bytes.length > 10 * 1024 * 1024) continue;
      selected.add(
        NoteAttachment(name: file.name, base64: base64Encode(bytes)),
      );
    }
    if (selected.isNotEmpty && mounted) {
      setState(
        () => _attachments = [..._attachments, ...selected].take(20).toList(),
      );
    }
  }

  void _addTask() {
    final text = _taskController.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _tasks.add(
        NoteTask(
          id: DateTime.now().microsecondsSinceEpoch.toString(),
          text: text,
        ),
      );
      _taskController.clear();
    });
  }

  Future<void> _exportPdf() async {
    final regular = pw.Font.ttf(
      await rootBundle.load('assets/fonts/NotoSansArabic-Regular.ttf'),
    );
    final bold = pw.Font.ttf(
      await rootBundle.load('assets/fonts/NotoKufiArabic-Bold.ttf'),
    );
    final document = pw.Document(title: _title.text.trim());
    document.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        textDirection: pw.TextDirection.rtl,
        theme: pw.ThemeData.withFont(base: regular, bold: bold),
        build: (_) => [
          pw.Text(
            _title.text.trim().isEmpty ? 'ملاحظة' : _title.text.trim(),
            style: pw.TextStyle(font: bold, fontSize: 18),
          ),
          pw.SizedBox(height: 12),
          if (_body.text.trim().isNotEmpty) pw.Text(_body.text.trim()),
          if (_tasks.isNotEmpty) ...[
            pw.SizedBox(height: 12),
            pw.Text('المهام', style: pw.TextStyle(font: bold, fontSize: 13)),
            ..._tasks.map(
              (task) => pw.Text('${task.isDone ? '✓' : '□'} ${task.text}'),
            ),
          ],
          if (_attachments.isNotEmpty) ...[
            pw.SizedBox(height: 12),
            pw.Text('المرفقات', style: pw.TextStyle(font: bold, fontSize: 13)),
            ..._attachments.map((item) => pw.Text('• ${item.name}')),
          ],
        ],
      ),
    );
    final bytes = await document.save();
    await FilePicker.saveFile(
      dialogTitle: 'تصدير الملاحظة PDF',
      fileName:
          '${_title.text.trim().isEmpty ? 'note' : _title.text.trim()}.pdf',
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      bytes: bytes,
    );
  }

  void _save() {
    final now = DateTime.now();
    final original = widget.note;
    Navigator.pop(
      context,
      Note(
        id: original?.id ?? now.microsecondsSinceEpoch.toString(),
        title: _title.text.trim(),
        body: _body.text.trim(),
        tasks: _tasks,
        createdAt: original?.createdAt ?? now,
        updatedAt: now,
        category: _category,
        colorValue: _color,
        isPinned: _pinned,
        isArchived: original?.isArchived ?? false,
        attachments: _attachments,
      ),
    );
  }

  @override
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.note == null ? 'ملاحظة جديدة' : 'تعديل الملاحظة'),
        actions: [
          IconButton(
            tooltip: 'تثبيت',
            onPressed: () => setState(() => _pinned = !_pinned),
            icon: Icon(_pinned ? Icons.push_pin : Icons.push_pin_outlined),
          ),
          IconButton(
            tooltip: 'تصدير PDF',
            onPressed: _exportPdf,
            icon: const Icon(Icons.picture_as_pdf_outlined),
          ),
          IconButton(
            tooltip: 'حفظ',
            onPressed: _save,
            icon: const Icon(Icons.check),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _title,
            textDirection: TextDirection.rtl,
            style: Theme.of(
              context,
            ).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold),
            decoration: const InputDecoration(
              hintText: 'العنوان',
              border: InputBorder.none,
            ),
          ),
          DropdownButtonFormField<String>(
            initialValue: _category,
            decoration: const InputDecoration(
              labelText: 'التصنيف',
              prefixIcon: Icon(Icons.label_outline),
            ),
            items: const ['ملاحظات', 'مهام', 'أفكار', 'متابعة']
                .map((item) => DropdownMenuItem(value: item, child: Text(item)))
                .toList(),
            onChanged: (value) {
              if (value != null) setState(() => _category = value);
            },
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _body,
            minLines: 6,
            maxLines: 14,
            textDirection: TextDirection.rtl,
            decoration: const InputDecoration(
              hintText: 'اكتب ملاحظتك هنا...',
              alignLabelWithHint: true,
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              const Icon(Icons.palette_outlined),
              const SizedBox(width: 8),
              const Text('لون الملاحظة'),
            ],
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 10,
            children: _colors
                .map(
                  (color) => GestureDetector(
                    onTap: () => setState(() => _color = color),
                    child: CircleAvatar(
                      backgroundColor: Color(color),
                      radius: 18,
                      child: _color == color
                          ? const Icon(Icons.check, size: 18)
                          : null,
                    ),
                  ),
                )
                .toList(),
          ),
          const SizedBox(height: 18),
          OutlinedButton.icon(
            onPressed: _pickAttachments,
            icon: const Icon(Icons.attach_file),
            label: const Text('إضافة مرفق (حتى 10MB)'),
          ),
          if (_attachments.isNotEmpty)
            Wrap(
              spacing: 6,
              children: _attachments
                  .asMap()
                  .entries
                  .map(
                    (entry) => Chip(
                      label: Text(
                        entry.value.name,
                        overflow: TextOverflow.ellipsis,
                      ),
                      onDeleted: () =>
                          setState(() => _attachments.removeAt(entry.key)),
                    ),
                  )
                  .toList(),
            ),
          const SizedBox(height: 24),
          Row(
            children: [
              Text(
                'قائمة المهام',
                style: Theme.of(
                  context,
                ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
              ),
              const Spacer(),
              Text('${_tasks.length}'),
            ],
          ),
          const SizedBox(height: 8),
          if (_tasks.isEmpty) const Text('أضف مهامًا صغيرة لتتابع إنجازك.'),
          ..._tasks.asMap().entries.map(
            (entry) => CheckboxListTile(
              contentPadding: EdgeInsets.zero,
              value: entry.value.isDone,
              title: Text(
                entry.value.text,
                style: TextStyle(
                  decoration: entry.value.isDone
                      ? TextDecoration.lineThrough
                      : null,
                ),
              ),
              onChanged: (done) => setState(
                () => _tasks[entry.key] = entry.value.copyWith(isDone: done),
              ),
            ),
          ),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _taskController,
                  onSubmitted: (_) => _addTask(),
                  decoration: const InputDecoration(
                    hintText: 'مهمة جديدة',
                    prefixIcon: Icon(Icons.add_task),
                  ),
                ),
              ),
              IconButton(
                onPressed: _addTask,
                icon: const Icon(Icons.add_circle),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
