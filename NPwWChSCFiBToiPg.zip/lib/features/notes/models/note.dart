import '../../../core/security/input_limits.dart';

class Note {
  const Note({
    required this.id,
    required this.title,
    required this.body,
    required this.tasks,
    required this.createdAt,
    required this.updatedAt,
    this.category = 'ملاحظات',
    this.colorValue = 0xFFFFFFFF,
    this.isPinned = false,
    this.isArchived = false,
    this.attachments = const [],
  });

  final String id;
  final String title;
  final String body;
  final List<NoteTask> tasks;
  final DateTime createdAt;
  final DateTime updatedAt;
  final String category;
  final int colorValue;
  final bool isPinned;
  final bool isArchived;
  final List<NoteAttachment> attachments;

  Note copyWith({
    String? title,
    String? body,
    List<NoteTask>? tasks,
    DateTime? updatedAt,
    String? category,
    int? colorValue,
    bool? isPinned,
    bool? isArchived,
    List<NoteAttachment>? attachments,
  }) => Note(
    id: id,
    title: title ?? this.title,
    body: body ?? this.body,
    tasks: tasks ?? this.tasks,
    createdAt: createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
    category: category ?? this.category,
    colorValue: colorValue ?? this.colorValue,
    isPinned: isPinned ?? this.isPinned,
    isArchived: isArchived ?? this.isArchived,
    attachments: attachments ?? this.attachments,
  );

  Map<String, Object?> toMap() => {
    'id': id,
    'title': title,
    'body': body,
    'tasks': tasks.map((task) => task.toMap()).toList(),
    'createdAt': createdAt.toIso8601String(),
    'updatedAt': updatedAt.toIso8601String(),
    'category': category,
    'colorValue': colorValue,
    'isPinned': isPinned,
    'isArchived': isArchived,
    'attachments': attachments.map((item) => item.toMap()).toList(),
  };

  factory Note.fromMap(Map<String, Object?> map) => Note(
    id: InputLimits.id(
      map['id'],
      fallback: DateTime.now().microsecondsSinceEpoch.toString(),
    ),
    title: InputLimits.string(map['title'], fallback: 'ملاحظة جديدة'),
    body: InputLimits.string(
      map['body'],
      maxLength: InputLimits.maxLongTextLength,
    ),
    tasks: InputLimits.list(map['tasks'], maxLength: InputLimits.maxTasks)
        .whereType<Map>()
        .map((item) => NoteTask.fromMap(Map<String, Object?>.from(item)))
        .toList(),
    createdAt:
        DateTime.tryParse(
          map['createdAt'] is String ? map['createdAt'] as String : '',
        ) ??
        DateTime.now(),
    updatedAt:
        DateTime.tryParse(
          map['updatedAt'] is String ? map['updatedAt'] as String : '',
        ) ??
        DateTime.now(),
    category: InputLimits.string(
      map['category'],
      fallback: 'ملاحظات',
      maxLength: InputLimits.maxCategoryLength,
    ),
    colorValue: InputLimits.integer(
      map['colorValue'],
      fallback: 0xFFFFFFFF,
      max: 0xFFFFFFFF,
    ),
    isPinned: map['isPinned'] == true,
    isArchived: map['isArchived'] == true,
    attachments: InputLimits.list(map['attachments'], maxLength: 20)
        .whereType<Map>()
        .map((item) => NoteAttachment.fromMap(Map<String, Object?>.from(item)))
        .toList(),
  );

  static Note fromMapStrict(Map<String, Object?> map) {
    _text(map, 'id', maxLength: InputLimits.maxIdLength);
    _text(map, 'title');
    _text(map, 'body', maxLength: InputLimits.maxLongTextLength);
    _text(map, 'category', maxLength: InputLimits.maxCategoryLength);
    _date(map, 'createdAt');
    _date(map, 'updatedAt');
    _bool(map, 'isPinned');
    _bool(map, 'isArchived');
    if (map.containsKey('colorValue')) {
      InputLimits.strictInteger(
        map['colorValue'],
        field: 'colorValue',
        min: 0,
        max: 0xFFFFFFFF,
      );
    }
    _mapList(
      map['tasks'],
      field: 'tasks',
      limit: InputLimits.maxTasks,
      validate: (item) {
        _text(item, 'id', maxLength: InputLimits.maxIdLength);
        _text(item, 'text');
        _bool(item, 'isDone');
      },
    );
    _mapList(
      map['attachments'],
      field: 'attachments',
      limit: 20,
      validate: (item) {
        _text(item, 'name', maxLength: 180);
        _text(item, 'base64', maxLength: 14 * 1024 * 1024);
      },
    );
    return Note.fromMap(map);
  }

  static void _text(
    Map<String, Object?> map,
    String key, {
    int maxLength = InputLimits.maxShortTextLength,
  }) {
    if (map.containsKey(key)) {
      InputLimits.strictString(map[key], field: key, maxLength: maxLength);
    }
  }

  static void _date(Map<String, Object?> map, String key) {
    if (map.containsKey(key)) InputLimits.strictDateTime(map[key], field: key);
  }

  static void _bool(Map<String, Object?> map, String key) {
    if (map.containsKey(key)) InputLimits.strictBool(map[key], field: key);
  }

  static void _mapList(
    Object? value, {
    required String field,
    required int limit,
    required void Function(Map<String, Object?>) validate,
  }) {
    if (value == null) return;
    for (final item in InputLimits.strictList(
      value,
      field: field,
      maxLength: limit,
    )) {
      validate(InputLimits.strictMap(item, field: field));
    }
  }
}

class NoteAttachment {
  const NoteAttachment({required this.name, required this.base64});
  final String name;
  final String base64;
  Map<String, Object?> toMap() => {'name': name, 'base64': base64};
  factory NoteAttachment.fromMap(Map<String, Object?> map) => NoteAttachment(
    name: InputLimits.string(map['name'], maxLength: 180),
    base64: InputLimits.string(map['base64'], maxLength: 14 * 1024 * 1024),
  );
}

class NoteTask {
  const NoteTask({required this.id, required this.text, this.isDone = false});

  final String id;
  final String text;
  final bool isDone;

  NoteTask copyWith({String? text, bool? isDone}) =>
      NoteTask(id: id, text: text ?? this.text, isDone: isDone ?? this.isDone);

  Map<String, Object?> toMap() => {'id': id, 'text': text, 'isDone': isDone};

  factory NoteTask.fromMap(Map<String, Object?> map) => NoteTask(
    id: InputLimits.id(
      map['id'],
      fallback: DateTime.now().microsecondsSinceEpoch.toString(),
    ),
    text: InputLimits.string(map['text']),
    isDone: map['isDone'] == true,
  );
}
