import '../../../core/utils/date_formatter.dart';
import '../../../core/utils/number_normalizer.dart';
import '../../expense_request/models/expense_request.dart';

class SampleRequestValidationResult {
  const SampleRequestValidationResult.valid()
    : error = null,
      normalizedValue = null;

  const SampleRequestValidationResult.invalid(this.error)
    : normalizedValue = null;

  const SampleRequestValidationResult.normalized(this.normalizedValue)
    : error = null;

  final String? error;
  final String? normalizedValue;

  bool get isValid => error == null;
}

class SampleRequestValidator {
  const SampleRequestValidator._();

  static SampleRequestValidationResult quantity(String value) {
    final normalized = NumberNormalizer.digits(
      value,
    ).replaceAll('٬', '').replaceAll(',', '').trim();
    if (normalized.isEmpty) {
      return const SampleRequestValidationResult.invalid('الكمية مطلوبة');
    }
    if (!RegExp(r'^\d+$').hasMatch(normalized)) {
      return const SampleRequestValidationResult.invalid(
        'أدخل عددًا صحيحًا موجبًا دون كسور أو أحرف',
      );
    }
    final parsed = int.tryParse(normalized);
    if (parsed == null) {
      return const SampleRequestValidationResult.invalid(
        'الكمية أكبر من الحد الذي يمكن تخزينه بأمان',
      );
    }
    if (parsed <= 0) {
      return const SampleRequestValidationResult.invalid(
        'يجب أن تكون الكمية أكبر من صفر',
      );
    }
    return SampleRequestValidationResult.normalized(normalized);
  }

  static SampleRequestValidationResult date(String value) {
    if (DateFormatter.parse(value) == null) {
      return const SampleRequestValidationResult.invalid(
        'أدخل تاريخًا صحيحًا ضمن المجال المسموح',
      );
    }
    return const SampleRequestValidationResult.valid();
  }

  static SampleRequestValidationResult request(ExpenseRequest request) {
    final dateResult = date(request.date);
    if (!dateResult.isValid) return dateResult;
    if (request.sampleItems.isEmpty) {
      return const SampleRequestValidationResult.invalid(
        'يجب اختيار صنف واحد على الأقل',
      );
    }
    for (final item in request.sampleItems) {
      final result = quantity(item.quantityNumber);
      if (!result.isValid) return result;
    }
    return const SampleRequestValidationResult.valid();
  }
}
