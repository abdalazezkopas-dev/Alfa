import 'package:flutter/material.dart';

import '../../expense_request/models/expense_request.dart';
import 'sample_request_screen.dart';

class SampleRequestSinglePageScreen extends StatelessWidget {
  const SampleRequestSinglePageScreen({
    this.initialRequest,
    this.editingIndex,
    super.key,
  });

  final ExpenseRequest? initialRequest;
  final int? editingIndex;

  @override
  Widget build(BuildContext context) => SampleRequestFormScreen(
    key: key,
    initialRequest: initialRequest,
    editingIndex: editingIndex,
    singlePage: true,
  );
}
