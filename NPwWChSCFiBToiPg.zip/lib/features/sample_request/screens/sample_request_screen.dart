import 'dart:async';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:flutter/services.dart';
import 'package:printing/printing.dart';

import '../../expense_request/models/expense_request.dart';
import '../../expense_request/services/amount_to_words.dart';
import '../../expense_request/services/pdf_service.dart';
import '../../expense_request/services/request_store.dart';
import '../../expense_request/services/share_service.dart';
import '../../product_catalog/models/product_item.dart';
import '../../product_catalog/screens/product_picker_screen.dart';
import '../../settings/models/app_settings.dart';
import '../../settings/models/template_configuration.dart';
import '../../settings/screens/settings_screen.dart';
import '../../settings/screens/template_preview_screen.dart';
import '../../settings/services/settings_store.dart';
import '../../../core/utils/date_formatter.dart';
import '../services/sample_request_validator.dart';

class SampleRequestFormScreen extends StatefulWidget {
  const SampleRequestFormScreen({
    this.initialRequest,
    this.editingIndex,
    required this.singlePage,
    super.key,
  });

  final ExpenseRequest? initialRequest;
  final int? editingIndex;
  final bool singlePage;

  @override
  State<SampleRequestFormScreen> createState() =>
      _SampleRequestFormScreenState();
}

class _SampleRequestFormScreenState extends State<SampleRequestFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _date = TextEditingController();
  final _receiver = TextEditingController();
  final _requester = TextEditingController();
  final _purpose = TextEditingController();
  final _dateFocus = FocusNode();
  final _receiverFocus = FocusNode();
  final _requesterFocus = FocusNode();
  final Map<String, TextEditingController> _quantityNumber = {};
  final Map<String, FocusNode> _quantityFocus = {};
  final Map<String, TextEditingController> _itemNotes = {};
  final List<ProductItem> _selected = [];
  String _usage = 'تسويقية';
  AppSettings _settings = AppSettings.defaults();
  bool _loading = true;
  bool _busy = false;
  bool _finalizing = false;
  bool get _singlePage => widget.singlePage;
  Future<Uint8List>? _previewFuture;
  String? _loadError;
  String _diagnosticStage = 'بدء تهيئة الشاشة';
  String? _diagnosticError;
  String? _diagnosticStack;
  String? _highlightedField;
  Timer? _highlightTimer;
  int _currentStep = 0;
  static const _loadTimeout = Duration(seconds: 12);

  String get _settingsScope =>
      _singlePage ? 'sampleRequestSinglePage' : 'sampleRequest';
  int get _maxItems => _singlePage ? 25 : 53;
  static const _defaultUsage = 'تسويقية';
  static const _usageOptions = {
    _defaultUsage,
    'استخدام أطباء',
    'استخدام موظفين',
    'أخرى',
  };

  String get _safeUsage =>
      _usageOptions.contains(_usage) ? _usage : _defaultUsage;

  void _setDiagnostic(String stage, {Object? error, StackTrace? stackTrace}) {
    _diagnosticStage = stage;
    if (error != null) _diagnosticError = error.toString();
    if (stackTrace != null) _diagnosticStack = stackTrace.toString();
    debugPrint('[SAMPLE][DIAGNOSTIC] $stage');
    if (error != null) debugPrint('[SAMPLE][DIAGNOSTIC] error=$error');
    if (mounted) setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _date.text = _formatDate(DateTime.now());
    _loadInitialData();
  }

  Future<void> _loadInitialData() async {
    _setDiagnostic('بدء تحميل البيانات');
    try {
      await _loadInitialDataInternal().timeout(_loadTimeout);
    } catch (error, stackTrace) {
      _setDiagnostic('فشل التهيئة', error: error, stackTrace: stackTrace);
      debugPrint('[SAMPLE] initialization failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (!mounted) return;
      setState(() {
        _loadError = 'تعذر تحميل نموذج طلب العينات';
        _loading = false;
      });
    } finally {
      if (mounted && _loading) {
        setState(() {
          _loading = false;
          _loadError ??= 'تعذر تجهيز نموذج طلب العينات. اضغط إعادة المحاولة.';
        });
      }
    }
  }

  Future<void> _loadInitialDataInternal() async {
    _setDiagnostic('بدء تجهيز نموذج طلب العينات');
    debugPrint('[SAMPLE] screen init started');
    var request = widget.initialRequest;
    debugPrint('[SAMPLE] selected template = $_settingsScope');
    _setDiagnostic('تحميل إعدادات القالب: $_settingsScope');
    var settings = AppSettings.defaultsForScope(_settingsScope);
    debugPrint('[SAMPLE] settings load started');
    try {
      settings = await SettingsStore.load(
        scope: _settingsScope,
      ).timeout(const Duration(seconds: 5));
      _setDiagnostic('اكتمل تحميل الإعدادات');
      debugPrint('[SAMPLE] settings load completed');
    } catch (error, stackTrace) {
      _setDiagnostic('تعذر تحميل الإعدادات؛ استخدام الافتراضية', error: error);
      debugPrint('[SAMPLE] settings load failed; using defaults: $error');
      debugPrintStack(stackTrace: stackTrace);
      settings = AppSettings.defaultsForScope(_settingsScope);
    }
    if (!mounted) return;
    if (request != null) {
      try {
        _applyRequest(request);
      } catch (error, stackTrace) {
        debugPrint('[SAMPLE] request restore failed: $error');
        debugPrintStack(stackTrace: stackTrace);
        _selected.clear();
        for (final controller in [
          ..._quantityNumber.values,
          ..._itemNotes.values,
        ]) {
          controller.dispose();
        }
        _quantityNumber.clear();
        _itemNotes.clear();
        request = null;
      }
    }
    setState(() {
      _settings = settings;
      _loading = false;
    });
    _setDiagnostic('اكتملت التهيئة وبدأ بناء الواجهة');
    debugPrint('[SAMPLE] template resolved');
    debugPrint('[SAMPLE] request ready');
  }

  void _applyRequest(ExpenseRequest request) {
    _date.text = request.date;
    _receiver.text = request.receiver;
    _requester.text = request.requesterName;
    _purpose.text = request.reason;
    final savedUsage = request.customFields['sampleUsage'];
    if (savedUsage != null && _usageOptions.contains(savedUsage)) {
      _usage = savedUsage;
    }
    for (final item in request.sampleItems) {
      final product = ProductItem(
        id: item.productId,
        name: item.productName,
        pharmaceuticalForm: item.pharmaceuticalForm,
      );
      _selected.add(product);
      _ensureControllers(item.productId, item);
    }
  }

  String _formatDate(DateTime value) =>
      '${value.day.toString().padLeft(2, '0')}/${value.month.toString().padLeft(2, '0')}/${value.year}';

  Future<void> _pickDate() async {
    final selected = await showDatePicker(
      context: context,
      initialDate: _parseDate(_date.text) ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      locale: const Locale('ar'),
      helpText: 'اختر تاريخ الطلب',
      cancelText: 'إلغاء',
      confirmText: 'اختيار',
    );
    if (selected == null || !mounted) return;
    _date.text = _formatDate(selected);
    _markDirty(fieldKey: 'date');
  }

  DateTime? _parseDate(String value) => DateFormatter.parse(value);

  void _ensureControllers(String id, [SampleItem? initial]) {
    _quantityNumber.putIfAbsent(
      id,
      () => TextEditingController(text: initial?.quantityNumber ?? ''),
    );
    _quantityFocus.putIfAbsent(id, FocusNode.new);
    _itemNotes.putIfAbsent(
      id,
      () => TextEditingController(text: initial?.notes ?? ''),
    );
  }

  @override
  void dispose() {
    for (final controller in [
      _date,
      _receiver,
      _requester,
      _purpose,
      ..._quantityNumber.values,
      ..._itemNotes.values,
    ]) {
      controller.dispose();
    }
    _dateFocus.dispose();
    _receiverFocus.dispose();
    _requesterFocus.dispose();
    for (final focusNode in _quantityFocus.values) {
      focusNode.dispose();
    }
    _highlightTimer?.cancel();
    super.dispose();
  }

  void _markDirty({String? fieldKey}) {
    if (mounted) {
      _previewFuture = null;
      if (fieldKey != null && _highlightedField == fieldKey) {
        _highlightTimer?.cancel();
        setState(() => _highlightedField = null);
      } else {
        setState(() {});
      }
    }
  }

  bool _focusAndHighlight(FocusNode focusNode, String fieldKey, {int? step}) {
    _highlightTimer?.cancel();
    setState(() {
      if (step != null) _currentStep = step;
      _highlightedField = fieldKey;
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) focusNode.requestFocus();
    });
    _highlightTimer = Timer(const Duration(seconds: 3), () {
      if (mounted && _highlightedField == fieldKey) {
        setState(() => _highlightedField = null);
      }
    });
    return false;
  }

  InputDecoration _fieldDecoration(
    String fieldKey, {
    required String labelText,
    Widget? suffixIcon,
  }) {
    final highlighted = _highlightedField == fieldKey;
    return InputDecoration(
      labelText: labelText,
      suffixIcon: suffixIcon,
      filled: highlighted,
      fillColor: highlighted ? Colors.red.withValues(alpha: 0.18) : null,
    );
  }

  int _pdfPageCount(Uint8List bytes) {
    const marker = <int>[47, 84, 121, 112, 101, 32, 47, 80, 97, 103, 101];
    var count = 0;
    for (var i = 0; i <= bytes.length - marker.length; i++) {
      var matches = true;
      for (var j = 0; j < marker.length; j++) {
        if (bytes[i + j] != marker[j]) {
          matches = false;
          break;
        }
      }
      if (matches) count++;
    }
    return count;
  }

  Future<Uint8List> _buildPreviewPdf() async {
    debugPrint('[SAMPLE] pdf build started');
    try {
      final bytes = await PdfService.buildRequestPdf(
        _collect(),
        settings: _settings,
      );
      if (bytes.length < 5 ||
          bytes[0] != 37 ||
          bytes[1] != 80 ||
          bytes[2] != 68 ||
          bytes[3] != 70) {
        throw StateError('تم إنشاء ملف PDF غير صالح');
      }
      debugPrint('[SAMPLE] pdf build completed');
      debugPrint('[SAMPLE] pdf bytes = ${bytes.length}');
      debugPrint('[SAMPLE] page count = ${_pdfPageCount(bytes)}');
      return bytes;
    } catch (error, stackTrace) {
      debugPrint('[SAMPLE] pdf build failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      rethrow;
    }
  }

  Future<void> _chooseProducts() async {
    final result = await Navigator.of(context).push<List<ProductItem>>(
      MaterialPageRoute<List<ProductItem>>(
        builder: (_) => ProductPickerScreen(
          initialSelection: _selected,
          maxItems: _maxItems,
        ),
      ),
    );
    if (!mounted || result == null) return;
    final ids = result.map((item) => item.id).toSet();
    for (final id in _quantityNumber.keys.toList()) {
      if (!ids.contains(id)) {
        _quantityNumber.remove(id)?.dispose();
        _quantityFocus.remove(id)?.dispose();
        _itemNotes.remove(id)?.dispose();
      }
    }
    for (final item in result) {
      _ensureControllers(item.id);
    }
    setState(() {
      _selected
        ..clear()
        ..addAll(result);
    });
  }

  void _applyAutomaticQuantity(int quantity) {
    for (final item in _selected) {
      _quantityNumber[item.id]?.text = quantity.toString();
    }
    _markDirty();
  }

  void _clearSelectedProducts() {
    for (final controller in _quantityNumber.values) {
      controller.dispose();
    }
    for (final controller in _itemNotes.values) {
      controller.dispose();
    }
    for (final focusNode in _quantityFocus.values) {
      focusNode.dispose();
    }
    _quantityNumber.clear();
    _quantityFocus.clear();
    _itemNotes.clear();
    setState(() => _selected.clear());
  }

  String _quantityWords(String value) {
    final words = AmountToWords.fromNumber(value.trim());
    if (words.isEmpty) return '';
    return words
        .replaceFirst(RegExp(r'^ريالان$'), 'اثنان')
        .replaceFirst(RegExp(r'^ريال واحد$'), 'واحد')
        .replaceAll(RegExp(r' ريال(?:ات)?$'), '');
  }

  ExpenseRequest _collect() => ExpenseRequest(
    date: _date.text.trim(),
    receiver: _receiver.text.trim(),
    amountNumber: '',
    amountWords: '',
    reason: _purpose.text.trim(),
    statement: '',
    branch: '',
    account: '',
    requesterName: _requester.text.trim(),
    requesterSignature: '',
    directManagerName: '',
    directManagerSignature: '',
    approvedAuthorityName: '',
    approvedAuthoritySignature: '',
    accountsManagerName: '',
    accountsManagerSignature: '',
    customFields: {
      'sampleUsage': _usage,
      'sampleTemplate': _singlePage ? 'singlePage' : 'threePage',
    },
    documentType: ExpenseDocumentType.sampleRequest,
    sampleItems: [
      for (final item in _selected)
        SampleItem(
          productId: item.id,
          productName: item.name,
          pharmaceuticalForm: item.pharmaceuticalForm,
          quantityNumber:
              SampleRequestValidator.quantity(
                _quantityNumber[item.id]!.text,
              ).normalizedValue ??
              _quantityNumber[item.id]!.text.trim(),
          quantityWords: _quantityWords(_quantityNumber[item.id]!.text),
          notes: _itemNotes[item.id]!.text.trim(),
        ),
    ],
  );

  bool _validate() {
    if (_date.text.trim().isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('التاريخ مطلوب')));
      return _focusAndHighlight(_dateFocus, 'date');
    }
    if (_receiver.text.trim().isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('الجهة مطلوبة')));
      return _focusAndHighlight(_receiverFocus, 'receiver');
    }
    if (_requester.text.trim().isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('مقدم الطلب مطلوب')));
      return _focusAndHighlight(_requesterFocus, 'requester');
    }
    if (!(_formKey.currentState?.validate() ?? false)) return false;
    final dateResult = SampleRequestValidator.date(_date.text);
    if (!dateResult.isValid) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(dateResult.error!)));
      return _focusAndHighlight(_dateFocus, 'date');
    }
    if (_selected.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اختر صنفًا واحدًا على الأقل')),
      );
      return false;
    }
    if (_selected.length > _maxItems) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('لا يمكن اختيار أكثر من $_maxItems صنفًا لهذا النموذج'),
        ),
      );
      return false;
    }
    for (final item in _selected) {
      final result = SampleRequestValidator.quantity(
        _quantityNumber[item.id]?.text ?? '',
      );
      if (!result.isValid) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('${item.name}: ${result.error}')),
        );
        return _focusAndHighlight(
          _quantityFocus[item.id]!,
          'quantity:${item.id}',
          step: 1,
        );
      }
    }
    return true;
  }

  Future<void> _save() async {
    if (_busy || _finalizing || !_validate()) return;
    final request = _collect();
    setState(() {
      _busy = true;
      _finalizing = true;
    });
    var saved = false;
    String? errorMessage;
    try {
      saved = widget.editingIndex == null
          ? await RequestStore.add(request)
          : await RequestStore.updateAt(widget.editingIndex!, request);
      if (!saved) {
        errorMessage =
            'تعذر حفظ الطلب: يوجد سجل مطابق أو لم يعد السجل المطلوب موجودًا';
      } else {}
    } catch (error, stackTrace) {
      debugPrint('[SAMPLE] save failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      errorMessage = saved
          ? 'تم حفظ الطلب، لكن تعذر حذف المسودة القديمة.'
          : 'تعذر حفظ نموذج طلب العينات. لم يتم حذف المسودة.';
    } finally {
      if (mounted) {
        setState(() {
          _busy = false;
          _finalizing = false;
        });
      }
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(errorMessage ?? 'تم حفظ نموذج طلب العينات')),
    );
    if (saved) Navigator.pop(context);
  }

  String _pdfFilename(ExpenseRequest request) =>
      'sample_request_${request.date.replaceAll('/', '-')}.pdf';

  Future<void> _createAndSharePdf() async {
    if (!_validate() || _busy) return;
    setState(() => _busy = true);
    try {
      final request = _collect();
      final bytes = await PdfService.buildRequestPdf(
        request,
        settings: _settings,
      );
      await ShareService.sharePdf(
        bytes: bytes,
        filename: _pdfFilename(request),
        subject: 'طلب عينات',
        body: 'مرفق نموذج طلب العينات بصيغة PDF',
      );
    } catch (error, stackTrace) {
      debugPrint('[SAMPLE] share failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تعذر إنشاء أو مشاركة نموذج العينات بصيغة PDF'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _printPdf() async {
    if (!_validate() || _busy) return;
    setState(() => _busy = true);
    try {
      final request = _collect();
      final bytes = await PdfService.buildRequestPdf(
        request,
        settings: _settings,
      );
      await ShareService.printPdf(
        bytes,
        filename: _pdfFilename(request),
        format: PdfPageFormat.letter,
      );
    } catch (error, stackTrace) {
      debugPrint('[SAMPLE] print failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تعذر إنشاء أو طباعة نموذج العينات بصيغة PDF'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _savePdfAs() async {
    if (!_validate() || _busy) return;
    setState(() => _busy = true);
    try {
      final request = _collect();
      final bytes = await PdfService.buildRequestPdf(
        request,
        settings: _settings,
      );
      await FilePicker.saveFile(
        dialogTitle: 'حفظ نموذج طلب العينات بصيغة PDF',
        fileName: _pdfFilename(request),
        type: FileType.custom,
        allowedExtensions: ['pdf'],
        bytes: bytes,
      );
    } catch (error, stackTrace) {
      debugPrint('[SAMPLE] save PDF failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('تعذر إنشاء أو حفظ نموذج العينات بصيغة PDF'),
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _previewPdf() async {
    if (!_validate() || _busy) return;
    setState(() => _busy = true);
    try {
      final bytes = await _buildPreviewPdf();
      if (!mounted) return;
      debugPrint('[SAMPLE] preview started');
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => Scaffold(
            appBar: AppBar(
              title: const Text('معاينة نموذج طلب العينات'),
              actions: [
                IconButton(
                  tooltip: 'مشاركة PDF',
                  onPressed: _busy ? null : _createAndSharePdf,
                  icon: const Icon(Icons.share_outlined),
                ),
                IconButton(
                  tooltip: 'طباعة PDF',
                  onPressed: _busy ? null : _printPdf,
                  icon: const Icon(Icons.print_outlined),
                ),
                IconButton(
                  tooltip: 'حفظ PDF باسم',
                  onPressed: _busy ? null : _savePdfAs,
                  icon: const Icon(Icons.save_alt_outlined),
                ),
                IconButton(
                  tooltip: 'تحرير وضبط مواضع الحقول',
                  onPressed: _busy ? null : _openPositionEditor,
                  icon: const Icon(Icons.open_with_outlined),
                ),
                IconButton(
                  tooltip: 'إعدادات النموذج',
                  onPressed: _busy ? null : _openSettings,
                  icon: const Icon(Icons.settings_outlined),
                ),
              ],
            ),
            body: PdfPreview(
              canChangePageFormat: false,
              canChangeOrientation: false,
              build: (_) async => bytes,
            ),
          ),
        ),
      );
    } catch (error, stackTrace) {
      debugPrint('[SAMPLE] preview failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تعذر فتح معاينة نموذج العينات')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openSettings() async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => SettingsScreen(
          templateKind: _singlePage
              ? TemplateKind.sampleRequestSinglePage
              : TemplateKind.sampleRequest,
        ),
      ),
    );
    if (!mounted) return;
    try {
      final settings = await SettingsStore.load(scope: _settingsScope);
      if (!mounted) return;
      setState(() {
        _settings = settings;
        _previewFuture = null;
      });
    } catch (error, stackTrace) {
      debugPrint('[SAMPLE] settings reload failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      // Keep the current settings if loading after return fails.
    }
  }

  Future<void> _openPositionEditor() async {
    final updated = await Navigator.of(context).push<AppSettings>(
      MaterialPageRoute<AppSettings>(
        builder: (_) => TemplatePreviewScreen(
          settings: _settings,
          templateScope: _settingsScope,
          sampleRequest: true,
          documentTitle: _singlePage
              ? 'نموذج طلب العينات — صفحة واحدة'
              : 'نموذج طلب العينات',
        ),
      ),
    );
    if (updated == null || !mounted) return;
    try {
      await SettingsStore.save(updated, scope: _settingsScope);
      if (!mounted) return;
      setState(() => _settings = updated);
    } catch (error, stackTrace) {
      debugPrint('[SAMPLE] position settings save failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      // Keep the previous settings if persistence fails.
    }
  }

  void _clearForm() {
    _date.text = _formatDate(DateTime.now());
    _receiver.clear();
    _requester.clear();
    _purpose.clear();
    for (final controller in _quantityNumber.values) {
      controller.dispose();
    }
    for (final controller in _itemNotes.values) {
      controller.dispose();
    }
    for (final focusNode in _quantityFocus.values) {
      focusNode.dispose();
    }
    _quantityNumber.clear();
    _quantityFocus.clear();
    _itemNotes.clear();
    setState(() {
      _selected.clear();
      _usage = _defaultUsage;
      _currentStep = 0;
    });
  }

  bool _validateGeneralStep() {
    if (_date.text.trim().isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('التاريخ مطلوب')));
      return _focusAndHighlight(_dateFocus, 'date');
    }
    final dateResult = SampleRequestValidator.date(_date.text);
    if (!dateResult.isValid) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(dateResult.error!)));
      return _focusAndHighlight(_dateFocus, 'date');
    }
    if (_receiver.text.trim().isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('الجهة مطلوبة')));
      return _focusAndHighlight(_receiverFocus, 'receiver');
    }
    final requesterRequired =
        _settings.fieldSettings['requesterName']?.required ?? false;
    if (requesterRequired && _requester.text.trim().isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('مقدم الطلب مطلوب')));
      return _focusAndHighlight(_requesterFocus, 'requester');
    }
    return true;
  }

  void _continueStep() {
    if (_currentStep == 0 && !_validateGeneralStep()) return;
    if (_currentStep == 1 && !_validate()) return;
    if (_currentStep < 2) setState(() => _currentStep++);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return Scaffold(
        appBar: AppBar(title: const Text('نموذج طلب عينات')),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircularProgressIndicator(),
              const SizedBox(height: 16),
              const Text('جاري تجهيز نموذج طلب العينات...'),
              const SizedBox(height: 12),
              Text(
                _diagnosticStage,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ],
          ),
        ),
      );
    }
    if (_loadError != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('نموذج طلب عينات')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.error_outline, size: 56),
                const SizedBox(height: 12),
                Text(_loadError!, textAlign: TextAlign.center),
                const SizedBox(height: 8),
                Text(
                  _diagnosticStage,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 12),
                ),
                if (_diagnosticError != null) ...[
                  const SizedBox(height: 8),
                  SelectableText(
                    _diagnosticError!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 11, color: Colors.red),
                  ),
                ],
                if (_diagnosticStack != null)
                  ExpansionTile(
                    title: const Text('التفاصيل التقنية'),
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8),
                        child: SelectableText(
                          _diagnosticStack!,
                          style: const TextStyle(fontSize: 10),
                        ),
                      ),
                    ],
                  ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: () {
                    setState(() {
                      _loading = true;
                      _loadError = null;
                    });
                    unawaited(_loadInitialData());
                  },
                  icon: const Icon(Icons.refresh),
                  label: const Text('إعادة المحاولة'),
                ),
              ],
            ),
          ),
        ),
      );
    }
    return PopScope(
      canPop: true,
      onPopInvokedWithResult: (_, _) {},
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            MediaQuery.sizeOf(context).width < 600
                ? 'طلب عينات'
                : widget.editingIndex == null
                ? 'نموذج طلب عينات'
                : 'تعديل نموذج طلب عينات',
          ),
          actions: MediaQuery.sizeOf(context).width < 600
              ? [
                  IconButton(
                    tooltip: 'إعدادات النموذج',
                    onPressed: _busy ? null : _openSettings,
                    icon: const Icon(Icons.settings_outlined),
                  ),
                  IconButton(
                    tooltip: 'معاينة PDF',
                    onPressed: _busy ? null : _previewPdf,
                    icon: const Icon(Icons.preview_outlined),
                  ),
                  IconButton(
                    tooltip: 'تحرير وضبط مواضع الخانات',
                    onPressed: _busy ? null : _openPositionEditor,
                    icon: const Icon(Icons.open_with_outlined),
                  ),
                  PopupMenuButton<String>(
                    tooltip: 'عمليات نموذج طلب العينات',
                    onSelected: (value) {
                      switch (value) {
                        case 'save':
                          unawaited(_save());
                        case 'share':
                          unawaited(_createAndSharePdf());
                        case 'preview':
                          unawaited(_previewPdf());
                        case 'print':
                          unawaited(_printPdf());
                        case 'saveAs':
                          unawaited(_savePdfAs());
                        case 'settings':
                          unawaited(_openSettings());
                        case 'clear':
                          _clearForm();
                        case 'positions':
                          unawaited(_openPositionEditor());
                      }
                    },
                    itemBuilder: (_) => const [
                      PopupMenuItem(value: 'save', child: Text('حفظ الطلب')),
                      PopupMenuItem(value: 'share', child: Text('مشاركة PDF')),
                      PopupMenuItem(
                        value: 'preview',
                        child: Text('معاينة PDF'),
                      ),
                      PopupMenuItem(value: 'print', child: Text('طباعة PDF')),
                      PopupMenuItem(
                        value: 'saveAs',
                        child: Text('حفظ PDF باسم'),
                      ),
                      PopupMenuItem(
                        value: 'settings',
                        child: Text('الإعدادات'),
                      ),
                      PopupMenuItem(value: 'clear', child: Text('مسح النموذج')),
                      PopupMenuItem(
                        value: 'positions',
                        child: Text('تحرير مواضع الخانات'),
                      ),
                    ],
                  ),
                ]
              : [
                  IconButton(
                    tooltip: 'حفظ الطلب',
                    onPressed: _busy ? null : _save,
                    icon: const Icon(Icons.save_outlined),
                  ),
                  IconButton(
                    tooltip: 'مشاركة PDF',
                    onPressed: _busy ? null : _createAndSharePdf,
                    icon: const Icon(Icons.share_outlined),
                  ),
                  IconButton(
                    tooltip: 'معاينة PDF',
                    onPressed: _busy ? null : _previewPdf,
                    icon: const Icon(Icons.preview_outlined),
                  ),
                  IconButton(
                    tooltip: 'طباعة PDF',
                    onPressed: _busy ? null : _printPdf,
                    icon: const Icon(Icons.print_outlined),
                  ),
                  IconButton(
                    tooltip: 'حفظ PDF باسم',
                    onPressed: _busy ? null : _savePdfAs,
                    icon: const Icon(Icons.save_alt_outlined),
                  ),
                  IconButton(
                    tooltip: 'الإعدادات',
                    onPressed: _busy ? null : _openSettings,
                    icon: const Icon(Icons.settings_outlined),
                  ),
                  IconButton(
                    tooltip: 'مسح النموذج',
                    onPressed: _busy ? null : _clearForm,
                    icon: const Icon(Icons.refresh_rounded),
                  ),
                  IconButton(
                    tooltip: 'تحرير وضبط مواضع الخانات',
                    onPressed: _busy ? null : _openPositionEditor,
                    icon: const Icon(Icons.open_with_outlined),
                  ),
                ],
        ),
        body: Form(
          key: _formKey,
          child: Stepper(
            currentStep: _currentStep,
            onStepContinue: _continueStep,
            onStepCancel: () {
              if (_currentStep > 0) setState(() => _currentStep--);
            },
            onStepTapped: (step) {
              if (step <= _currentStep) {
                setState(() => _currentStep = step);
              } else if (_currentStep == 0) {
                _continueStep();
              } else if (_currentStep == 1 && _validate()) {
                setState(() => _currentStep = step);
              }
            },
            controlsBuilder: (context, details) => Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Row(
                children: [
                  FilledButton(
                    onPressed: _busy ? null : details.onStepContinue,
                    child: Text(_currentStep == 2 ? 'تم' : 'التالي'),
                  ),
                  if (_currentStep > 0) ...[
                    const SizedBox(width: 8),
                    TextButton(
                      onPressed: details.onStepCancel,
                      child: const Text('السابق'),
                    ),
                  ],
                ],
              ),
            ),
            steps: [
              Step(
                title: const Text('البيانات العامة'),
                subtitle: const Text('التاريخ والجهة ومقدم الطلب'),
                isActive: _currentStep >= 0,
                state: _currentStep > 0
                    ? StepState.complete
                    : StepState.indexed,
                content: _generalStep(),
              ),
              Step(
                title: const Text('اختيار الأصناف والكميات'),
                subtitle: const Text('اختر الأصناف وأدخل الكمية بالأرقام'),
                isActive: _currentStep >= 1,
                state: _currentStep > 1
                    ? StepState.complete
                    : StepState.indexed,
                content: _itemsStep(),
              ),
              Step(
                title: const Text('المعاينة والتصدير'),
                subtitle: const Text('راجع النموذج ثم احفظه أو اطبعه'),
                isActive: _currentStep >= 2,
                content: _currentStep == 2
                    ? _previewStep()
                    : const SizedBox.shrink(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _generalStep() =>
      _section('البيانات العامة', Icons.description_outlined, [
        TextFormField(
          controller: _date,
          focusNode: _dateFocus,
          readOnly: true,
          onTap: _pickDate,
          decoration: _fieldDecoration(
            'date',
            labelText: 'التاريخ',
            suffixIcon: const Icon(Icons.calendar_month_outlined),
          ),
          validator: (value) => value!.trim().isEmpty ? 'التاريخ مطلوب' : null,
        ),
        TextFormField(
          controller: _receiver,
          focusNode: _receiverFocus,
          onChanged: (_) => _markDirty(fieldKey: 'receiver'),
          decoration: _fieldDecoration(
            'receiver',
            labelText: 'الجهة / المحترم',
            suffixIcon: PopupMenuButton<String>(
              tooltip: 'مقترحات الجهات المعنية',
              icon: const Icon(Icons.arrow_drop_down),
              onSelected: (value) {
                setState(() => _receiver.text = value);
                _markDirty();
              },
              itemBuilder: (_) => const [
                PopupMenuItem<String>(
                  value: 'أ/ حميد المقحفي',
                  child: Text('أ/ حميد المقحفي'),
                ),
              ],
            ),
          ),
          validator: (value) => value!.trim().isEmpty ? 'الجهة مطلوبة' : null,
        ),
        TextFormField(
          controller: _requester,
          focusNode: _requesterFocus,
          onChanged: (_) => _markDirty(fieldKey: 'requester'),
          decoration: _fieldDecoration(
            'requester',
            labelText: 'مقدم الطلب',
            suffixIcon: PopupMenuButton<String>(
              tooltip: 'مقترحات مقدمي الطلب',
              icon: const Icon(Icons.arrow_drop_down),
              onSelected: (value) {
                setState(() => _requester.text = value);
                _markDirty();
              },
              itemBuilder: (_) => const [
                PopupMenuItem<String>(
                  value: 'د/ آيه العراسي',
                  child: Text('د/ آيه العراسي'),
                ),
              ],
            ),
          ),
          validator: (value) =>
              value!.trim().isEmpty ? 'مقدم الطلب مطلوب' : null,
        ),
        DropdownButtonFormField<String>(
          initialValue: _safeUsage,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'نوع الاستخدام'),
          items: const [
            DropdownMenuItem(value: 'تسويقية', child: Text('تسويقية')),
            DropdownMenuItem(
              value: 'استخدام أطباء',
              child: Text('استخدام أطباء'),
            ),
            DropdownMenuItem(
              value: 'استخدام موظفين',
              child: Text('استخدام موظفين'),
            ),
            DropdownMenuItem(value: 'أخرى', child: Text('أخرى')),
          ],
          onChanged: (value) {
            setState(() => _usage = value ?? _defaultUsage);
          },
        ),
        TextFormField(
          controller: _purpose,
          onChanged: (_) => _markDirty(),
          decoration: const InputDecoration(labelText: 'الغرض'),
          maxLines: 2,
        ),
      ]);

  Widget _itemsStep() =>
      _section('الأصناف المطلوبة', Icons.inventory_2_outlined, [
        Row(
          children: [
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _chooseProducts,
                icon: const Icon(Icons.playlist_add_outlined),
                label: Text('اختيار الأصناف (${_selected.length})'),
              ),
            ),
            const SizedBox(width: 4),
            IconButton(
              tooltip: 'إلغاء تحديد الأصناف',
              onPressed: _selected.isEmpty ? null : _clearSelectedProducts,
              icon: const Icon(Icons.deselect_outlined),
            ),
          ],
        ),
        const SizedBox(height: 6),
        SizedBox(
          width: double.infinity,
          child: PopupMenuButton<int>(
            enabled: _selected.isNotEmpty,
            tooltip: 'اختيار الكمية التلقائية',
            onSelected: _applyAutomaticQuantity,
            itemBuilder: (_) => [
              for (var quantity = 5; quantity <= 100; quantity += 5)
                PopupMenuItem<int>(
                  value: quantity,
                  child: Text(quantity.toString()),
                ),
            ],
            child: OutlinedButton.icon(
              onPressed: null,
              icon: const Icon(Icons.auto_awesome_outlined),
              label: const Text('اختيار الكمية التلقائية'),
            ),
          ),
        ),
        const SizedBox(height: 8),
        ..._selected.asMap().entries.map(
          (entry) => _itemCard(entry.key + 1, entry.value),
        ),
        if (_selected.isEmpty)
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text('لم يتم اختيار أصناف بعد'),
          ),
      ]);

  Widget _previewStep() => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      const Text(
        'المعاينة الحية للطلب الحالي',
        style: TextStyle(fontWeight: FontWeight.bold),
      ),
      const SizedBox(height: 8),
      SizedBox(
        height: 520,
        child: FutureBuilder<Uint8List>(
          future: _previewFuture ??= _buildPreviewPdf(),
          builder: (context, snapshot) {
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError || snapshot.data == null) {
              return const Center(
                child: Text(
                  'تعذر إنشاء PDF للمعاينة. راجع البيانات ثم أعد المحاولة.',
                ),
              );
            }
            final bytes = snapshot.data!;
            debugPrint('[SAMPLE] preview started');
            return PdfPreview(
              canChangePageFormat: false,
              canChangeOrientation: false,
              allowPrinting: false,
              allowSharing: false,
              build: (_) async => bytes,
            );
          },
        ),
      ),
      const SizedBox(height: 12),
      FilledButton.icon(
        onPressed: _busy ? null : _save,
        icon: const Icon(Icons.save_outlined),
        label: const Text('حفظ الطلب'),
      ),
    ],
  );

  Widget _itemCard(int number, ProductItem item) {
    _ensureControllers(item.id);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '$number. ${item.name}',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                ),
                SizedBox(
                  width: 92,
                  child: TextField(
                    controller: _quantityNumber[item.id],
                    focusNode: _quantityFocus[item.id],
                    keyboardType: TextInputType.number,
                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                    textInputAction: TextInputAction.next,
                    textAlign: TextAlign.center,
                    onChanged: (_) =>
                        _markDirty(fieldKey: 'quantity:${item.id}'),
                    onSubmitted: (_) {
                      final nextIndex = number;
                      if (nextIndex < _selected.length) {
                        FocusScope.of(
                          context,
                        ).requestFocus(_quantityFocus[_selected[nextIndex].id]);
                      }
                    },
                    decoration: _fieldDecoration(
                      'quantity:${item.id}',
                      labelText: 'الكمية',
                    ),
                  ),
                ),
              ],
            ),
            if (item.pharmaceuticalForm.trim().isNotEmpty)
              Text('الشكل الصيدلاني: ${item.pharmaceuticalForm}'),
            ValueListenableBuilder<TextEditingValue>(
              valueListenable: _quantityNumber[item.id]!,
              builder: (context, value, child) => Text(
                'الكمية كتابة: ${_quantityWords(value.text).isEmpty ? '—' : _quantityWords(value.text)}',
              ),
            ),
            TextField(
              controller: _itemNotes[item.id],
              onChanged: (_) => _markDirty(),
              decoration: const InputDecoration(labelText: 'ملاحظات الصنف'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _section(String title, IconData icon, List<Widget> children) => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(icon),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...children.map(
            (child) => Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: child,
            ),
          ),
        ],
      ),
    ),
  );
}
