import 'package:flutter/material.dart';

import '../../expense_request/models/expense_request.dart';
import 'sample_request_screen.dart';

class SampleRequestThreePageScreen extends StatelessWidget {
  const SampleRequestThreePageScreen({
    this.initialRequest,
    this.editingIndex,
    super.key,
  });

  final ExpenseRequest? initialRequest;
  final int? editingIndex;

  @override
  Widget build(BuildContext context) => SampleRequestFormScreen(
    key: key,
    initialRequest: initialRequest,
    editingIndex: editingIndex,
    singlePage: false,
  );
}
