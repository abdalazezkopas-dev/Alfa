import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../../expense_request/services/pdf_text_sanitizer.dart';
import '../models/representative_report.dart';

class RepresentativeReportPdfService {
  const RepresentativeReportPdfService._();

  static const PdfColor _headerFill = PdfColor.fromInt(0xFFD5EAF2);
  static const PdfColor _line = PdfColor.fromInt(0xFF222222);
  static const String _headerAsset =
      'assets/templates/representative_report_header.png';

  static Future<Uint8List> build(RepresentativeReport report) async {
    final regular = pw.Font.ttf(
      await rootBundle.load('assets/fonts/NotoSansArabic-Regular.ttf'),
    );
    final fallback = pw.Font.ttf(
      await rootBundle.load('assets/fonts/DejaVuSans.ttf'),
    );
    final bold = pw.Font.ttf(
      await rootBundle.load('assets/fonts/NotoKufiArabic-Bold.ttf'),
    );
    final header = pw.MemoryImage(
      (await rootBundle.load(_headerAsset)).buffer.asUint8List(),
    );
    final theme = pw.ThemeData.withFont(
      base: regular,
      bold: bold,
      fontFallback: [fallback],
    );
    final document = pw.Document(title: 'Representative Daily Report');

    pw.Widget lineField(String label, String value) => pw.Expanded(
      child: pw.Row(
        children: [
          pw.Text(
            label,
            style: pw.TextStyle(
              font: bold,
              fontFallback: [fallback],
              fontSize: 8,
            ),
          ),
          pw.SizedBox(width: 3),
          pw.Expanded(
            child: pw.Container(
              height: 13,
              alignment: pw.Alignment.centerLeft,
              decoration: const pw.BoxDecoration(
                border: pw.Border(
                  bottom: pw.BorderSide(color: _line, width: 0.45),
                ),
              ),
              padding: const pw.EdgeInsets.symmetric(horizontal: 2),
              child: pw.Text(
                PdfTextSanitizer.normalize(value),
                textDirection: pw.TextDirection.rtl,
                maxLines: 1,
                overflow: pw.TextOverflow.clip,
                style: pw.TextStyle(
                  font: regular,
                  fontFallback: [fallback],
                  fontSize: 8,
                ),
              ),
            ),
          ),
        ],
      ),
    );

    pw.Widget physicianTable(
      String heading,
      List<RepresentativePhysicianEntry> entries,
      String samplesHeading,
    ) {
      final rows = <List<String>>[
        [
          'No',
          heading,
          'Specialty',
          'Class',
          'Address',
          samplesHeading,
          'Observation',
        ],
        for (var i = 0; i < representativePhysicianRowCount; i++)
          [
            '${i + 1}',
            entries[i].name,
            entries[i].specialty,
            entries[i].className,
            entries[i].address,
            entries[i].samplesDelivered,
            entries[i].observation,
          ],
      ];
      return pw.TableHelper.fromTextArray(
        data: rows
            .map((row) => row.map(PdfTextSanitizer.normalize).toList())
            .toList(),
        headerCount: 1,
        headerStyle: pw.TextStyle(
          font: bold,
          fontFallback: [fallback],
          fontSize: 7,
        ),
        cellStyle: pw.TextStyle(
          font: regular,
          fontFallback: [fallback],
          fontSize: 7,
        ),
        headerDecoration: const pw.BoxDecoration(color: _headerFill),
        border: pw.TableBorder.all(color: _line, width: 0.45),
        cellPadding: const pw.EdgeInsets.symmetric(horizontal: 2, vertical: 2),
        cellHeight: 11,
        headerDirection: pw.TextDirection.ltr,
        tableDirection: pw.TextDirection.rtl,
        cellAlignments: const {
          0: pw.Alignment.center,
          1: pw.Alignment.center,
          2: pw.Alignment.center,
          3: pw.Alignment.center,
          4: pw.Alignment.center,
          5: pw.Alignment.center,
          6: pw.Alignment.center,
        },
        columnWidths: const {
          0: pw.FixedColumnWidth(28),
          1: pw.FixedColumnWidth(142),
          2: pw.FixedColumnWidth(82),
          3: pw.FixedColumnWidth(50),
          4: pw.FixedColumnWidth(112),
          5: pw.FixedColumnWidth(165),
          6: pw.FixedColumnWidth(222),
        },
      );
    }

    pw.Widget pharmacyTable(
      String heading,
      List<RepresentativePharmacyEntry> entries,
    ) {
      final rows = <List<String>>[
        ['No', heading, 'Notice'],
        for (var i = 0; i < representativePharmacyRowCount; i++)
          ['${i + 1}', entries[i].name, entries[i].notice],
      ];
      return pw.TableHelper.fromTextArray(
        data: rows
            .map((row) => row.map(PdfTextSanitizer.normalize).toList())
            .toList(),
        headerCount: 1,
        headerStyle: pw.TextStyle(
          font: bold,
          fontFallback: [fallback],
          fontSize: 7,
        ),
        cellStyle: pw.TextStyle(
          font: regular,
          fontFallback: [fallback],
          fontSize: 7,
        ),
        headerDecoration: const pw.BoxDecoration(color: _headerFill),
        border: pw.TableBorder.all(color: _line, width: 0.45),
        cellPadding: const pw.EdgeInsets.symmetric(horizontal: 2, vertical: 2),
        cellHeight: 11,
        headerDirection: pw.TextDirection.ltr,
        tableDirection: pw.TextDirection.rtl,
        cellAlignments: const {
          0: pw.Alignment.center,
          1: pw.Alignment.center,
          2: pw.Alignment.center,
        },
        columnWidths: const {
          0: pw.FlexColumnWidth(0.12),
          1: pw.FlexColumnWidth(0.48),
          2: pw.FlexColumnWidth(0.40),
        },
      );
    }

    document.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4.landscape,
        margin: const pw.EdgeInsets.fromLTRB(20, 12, 20, 10),
        theme: theme,
        build: (_) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.stretch,
          children: [
            pw.SizedBox(
              height: 44,
              child: pw.Image(header, fit: pw.BoxFit.contain),
            ),
            pw.SizedBox(height: 3),
            pw.Row(
              children: [
                lineField('Med. Rep :', report.medRep),
                pw.SizedBox(width: 10),
                lineField('City:', report.city),
              ],
            ),
            pw.SizedBox(height: 2),
            pw.Row(
              children: [
                lineField('Day:', report.day),
                pw.SizedBox(width: 10),
                lineField('District:', report.district),
              ],
            ),
            pw.SizedBox(height: 2),
            pw.Row(
              children: [
                lineField('Date:', report.date),
                pw.SizedBox(width: 10),
                lineField('Section:', report.section),
              ],
            ),
            pw.SizedBox(height: 2),
            pw.Container(
              alignment: pw.Alignment.center,
              child: pw.Text(
                'Daily',
                style: pw.TextStyle(
                  font: bold,
                  fontFallback: [fallback],
                  fontSize: 13,
                ),
              ),
            ),
            pw.SizedBox(height: 3),
            physicianTable(
              'Morning Physicians',
              report.morningPhysicians,
              'Samples Delivered-Morning',
            ),
            physicianTable(
              'Evening Physicians',
              report.eveningPhysicians,
              'Samples delivered-Evening',
            ),
            pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Expanded(
                  child: pharmacyTable(
                    'Pharmacies-Morning',
                    report.morningPharmacies,
                  ),
                ),
                pw.SizedBox(width: 5),
                pw.Expanded(
                  child: pharmacyTable(
                    'Pharmacies-Evening',
                    report.eveningPharmacies,
                  ),
                ),
              ],
            ),
            pw.SizedBox(height: 6),
            pw.Row(
              crossAxisAlignment: pw.CrossAxisAlignment.end,
              children: [
                pw.Expanded(child: _signature('Med. Rep. Signature:')),
                pw.SizedBox(width: 28),
                pw.Expanded(child: _signature('Direct Manager Signature:')),
              ],
            ),
            pw.Spacer(),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                _footer('Document No.: SHIBA-IMSF-33-03'),
                _footer('Issue Date: 2025/06/01'),
                _footer('Revision No.: 01'),
              ],
            ),
          ],
        ),
      ),
    );
    return document.save();
  }

  static pw.Widget _signature(String label) => pw.Column(
    crossAxisAlignment: pw.CrossAxisAlignment.stretch,
    children: [
      pw.Text(
        label,
        textAlign: pw.TextAlign.center,
        style: const pw.TextStyle(fontSize: 8),
      ),
      pw.SizedBox(height: 15),
      pw.Container(
        height: 1,
        color: _line,
        margin: const pw.EdgeInsets.symmetric(horizontal: 34),
      ),
    ],
  );

  static pw.Widget _footer(String text) =>
      pw.Text(text, style: const pw.TextStyle(fontSize: 7));
}
