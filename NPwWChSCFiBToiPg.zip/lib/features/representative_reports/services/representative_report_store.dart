import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/security/secure_local_store.dart';
import '../../../core/store_mutex.dart';
import '../models/representative_report.dart';

class RepresentativeReportStore {
  const RepresentativeReportStore._();

  static const _secureKey = 'representative_reports';
  static const _legacyKey = 'alfa_expense_app.representative_reports.v1';

  static Future<List<RepresentativeReport>> load() =>
      StoreMutex.run('representative_reports', _loadUnlocked);

  static Future<List<RepresentativeReport>> _loadUnlocked() async {
    final preferences = await SharedPreferences.getInstance();
    final secure = await SecureLocalStore.read(_secureKey);
    final raw = secure?.isNotEmpty == true
        ? secure!
        : preferences.getString(_legacyKey);
    if (raw == null || raw.isEmpty) return [];

    final decoded = jsonDecode(raw);
    if (decoded is! List) {
      throw const FormatException('صيغة تقارير المندوبين المحفوظة غير صحيحة');
    }
    final reports = <RepresentativeReport>[];
    for (final item in decoded) {
      if (item is! Map) {
        throw const FormatException('يوجد سجل تقرير مندوب تالف');
      }
      reports.add(
        RepresentativeReport.fromMap(Map<String, Object?>.from(item)),
      );
    }

    if (secure == null || secure.isEmpty) {
      await _saveUnlocked(reports);
    }
    return reports;
  }

  static Future<void> saveAll(List<RepresentativeReport> reports) =>
      StoreMutex.run('representative_reports', () => _saveUnlocked(reports));

  static Future<void> _saveUnlocked(List<RepresentativeReport> reports) async {
    final encoded = jsonEncode(
      reports.map((report) => report.toMap()).toList(),
    );
    await SecureLocalStore.write(_secureKey, encoded);
    final preferences = await SharedPreferences.getInstance();
    await preferences.remove(_legacyKey);
  }

  static Future<void> add(RepresentativeReport report) =>
      StoreMutex.run('representative_reports', () async {
        final reports = await _loadUnlocked();
        if (reports.any((item) => item.id == report.id)) {
          throw StateError('معرّف تقرير المندوب موجود مسبقًا');
        }
        reports.insert(0, report);
        await _saveUnlocked(reports);
      });

  static Future<bool> update(RepresentativeReport report) =>
      StoreMutex.run('representative_reports', () async {
        final reports = await _loadUnlocked();
        final index = reports.indexWhere((item) => item.id == report.id);
        if (index < 0) return false;
        reports[index] = report;
        await _saveUnlocked(reports);
        return true;
      });
}
