import '../../../core/security/input_limits.dart';

const int representativePhysicianRowCount = 7;
const int representativePharmacyRowCount = 5;

class RepresentativePhysicianEntry {
  const RepresentativePhysicianEntry({
    this.name = '',
    this.specialty = '',
    this.className = '',
    this.address = '',
    this.samplesDelivered = '',
    this.observation = '',
  });

  final String name;
  final String specialty;
  final String className;
  final String address;
  final String samplesDelivered;
  final String observation;

  Map<String, Object?> toMap() => {
    'name': name,
    'specialty': specialty,
    'className': className,
    'address': address,
    'samplesDelivered': samplesDelivered,
    'observation': observation,
  };

  factory RepresentativePhysicianEntry.fromMap(Map<String, Object?> map) =>
      RepresentativePhysicianEntry(
        name: map['name']?.toString() ?? '',
        specialty: map['specialty']?.toString() ?? '',
        className: map['className']?.toString() ?? '',
        address: map['address']?.toString() ?? '',
        samplesDelivered: map['samplesDelivered']?.toString() ?? '',
        observation: map['observation']?.toString() ?? '',
      );
}

class RepresentativePharmacyEntry {
  const RepresentativePharmacyEntry({this.name = '', this.notice = ''});

  final String name;
  final String notice;

  Map<String, Object?> toMap() => {'name': name, 'notice': notice};

  factory RepresentativePharmacyEntry.fromMap(Map<String, Object?> map) =>
      RepresentativePharmacyEntry(
        name: map['name']?.toString() ?? '',
        notice: map['notice']?.toString() ?? '',
      );
}

class RepresentativeReport {
  const RepresentativeReport({
    required this.id,
    this.medRep = '',
    this.day = '',
    this.date = '',
    this.city = '',
    this.district = '',
    this.section = '',
    this.morningPhysicians = const [],
    this.eveningPhysicians = const [],
    this.morningPharmacies = const [],
    this.eveningPharmacies = const [],
  });

  final String id;
  final String medRep;
  final String day;
  final String date;
  final String city;
  final String district;
  final String section;
  final List<RepresentativePhysicianEntry> morningPhysicians;
  final List<RepresentativePhysicianEntry> eveningPhysicians;
  final List<RepresentativePharmacyEntry> morningPharmacies;
  final List<RepresentativePharmacyEntry> eveningPharmacies;

  factory RepresentativeReport.empty({required String id, String date = ''}) =>
      RepresentativeReport(
        id: id,
        date: date,
        morningPhysicians: List<RepresentativePhysicianEntry>.unmodifiable(
          List.generate(
            representativePhysicianRowCount,
            (_) => const RepresentativePhysicianEntry(),
          ),
        ),
        eveningPhysicians: List<RepresentativePhysicianEntry>.unmodifiable(
          List.generate(
            representativePhysicianRowCount,
            (_) => const RepresentativePhysicianEntry(),
          ),
        ),
        morningPharmacies: List<RepresentativePharmacyEntry>.unmodifiable(
          List.generate(
            representativePharmacyRowCount,
            (_) => const RepresentativePharmacyEntry(),
          ),
        ),
        eveningPharmacies: List<RepresentativePharmacyEntry>.unmodifiable(
          List.generate(
            representativePharmacyRowCount,
            (_) => const RepresentativePharmacyEntry(),
          ),
        ),
      );

  RepresentativeReport copyWith({
    String? id,
    String? medRep,
    String? day,
    String? date,
    String? city,
    String? district,
    String? section,
    List<RepresentativePhysicianEntry>? morningPhysicians,
    List<RepresentativePhysicianEntry>? eveningPhysicians,
    List<RepresentativePharmacyEntry>? morningPharmacies,
    List<RepresentativePharmacyEntry>? eveningPharmacies,
  }) => RepresentativeReport(
    id: id ?? this.id,
    medRep: medRep ?? this.medRep,
    day: day ?? this.day,
    date: date ?? this.date,
    city: city ?? this.city,
    district: district ?? this.district,
    section: section ?? this.section,
    morningPhysicians: morningPhysicians ?? this.morningPhysicians,
    eveningPhysicians: eveningPhysicians ?? this.eveningPhysicians,
    morningPharmacies: morningPharmacies ?? this.morningPharmacies,
    eveningPharmacies: eveningPharmacies ?? this.eveningPharmacies,
  );

  Map<String, Object?> toMap() => {
    'id': id,
    'medRep': medRep,
    'day': day,
    'date': date,
    'city': city,
    'district': district,
    'section': section,
    'morningPhysicians': morningPhysicians.map((row) => row.toMap()).toList(),
    'eveningPhysicians': eveningPhysicians.map((row) => row.toMap()).toList(),
    'morningPharmacies': morningPharmacies.map((row) => row.toMap()).toList(),
    'eveningPharmacies': eveningPharmacies.map((row) => row.toMap()).toList(),
  };

  factory RepresentativeReport.fromMap(Map<String, Object?> map) {
    List<T> fixedRows<T>(
      Object? raw,
      int count,
      T Function(Map<String, Object?>) parse,
      T Function() empty,
    ) {
      final values = <T>[];
      if (raw is List) {
        for (final item in raw.take(count)) {
          values.add(
            item is Map ? parse(Map<String, Object?>.from(item)) : empty(),
          );
        }
      }
      while (values.length < count) {
        values.add(empty());
      }
      return List<T>.unmodifiable(values);
    }

    return RepresentativeReport(
      id: map['id']?.toString() ?? '',
      medRep: map['medRep']?.toString() ?? '',
      day: map['day']?.toString() ?? '',
      date: map['date']?.toString() ?? '',
      city: map['city']?.toString() ?? '',
      district: map['district']?.toString() ?? '',
      section: map['section']?.toString() ?? '',
      morningPhysicians: fixedRows(
        map['morningPhysicians'],
        representativePhysicianRowCount,
        RepresentativePhysicianEntry.fromMap,
        () => const RepresentativePhysicianEntry(),
      ),
      eveningPhysicians: fixedRows(
        map['eveningPhysicians'],
        representativePhysicianRowCount,
        RepresentativePhysicianEntry.fromMap,
        () => const RepresentativePhysicianEntry(),
      ),
      morningPharmacies: fixedRows(
        map['morningPharmacies'],
        representativePharmacyRowCount,
        RepresentativePharmacyEntry.fromMap,
        () => const RepresentativePharmacyEntry(),
      ),
      eveningPharmacies: fixedRows(
        map['eveningPharmacies'],
        representativePharmacyRowCount,
        RepresentativePharmacyEntry.fromMap,
        () => const RepresentativePharmacyEntry(),
      ),
    );
  }

  static RepresentativeReport fromMapStrict(Map<String, Object?> map) {
    _text(map, 'id', maxLength: InputLimits.maxIdLength);
    for (final key in const [
      'medRep',
      'day',
      'date',
      'city',
      'district',
      'section',
    ]) {
      _text(map, key);
    }
    _rows(
      map,
      'morningPhysicians',
      representativePhysicianRowCount,
      (item) => _validatePhysician(item),
    );
    _rows(
      map,
      'eveningPhysicians',
      representativePhysicianRowCount,
      (item) => _validatePhysician(item),
    );
    _rows(map, 'morningPharmacies', representativePharmacyRowCount, (item) {
      _text(item, 'name');
      _text(item, 'notice', maxLength: InputLimits.maxLongTextLength);
    });
    _rows(map, 'eveningPharmacies', representativePharmacyRowCount, (item) {
      _text(item, 'name');
      _text(item, 'notice', maxLength: InputLimits.maxLongTextLength);
    });
    return RepresentativeReport.fromMap(map);
  }

  static void _text(
    Map<String, Object?> map,
    String key, {
    int maxLength = InputLimits.maxShortTextLength,
  }) {
    if (map.containsKey(key)) {
      InputLimits.strictString(map[key], field: key, maxLength: maxLength);
    }
  }

  static void _validatePhysician(Map<String, Object?> map) {
    for (final key in const [
      'name',
      'specialty',
      'className',
      'address',
      'samplesDelivered',
    ]) {
      _text(map, key);
    }
    _text(map, 'observation', maxLength: InputLimits.maxLongTextLength);
  }

  static void _rows(
    Map<String, Object?> map,
    String key,
    int count,
    void Function(Map<String, Object?>) validate,
  ) {
    if (!map.containsKey(key)) return;
    final rows = InputLimits.strictList(map[key], field: key, maxLength: count);
    if (rows.length != count) {
      throw FormatException('قائمة $key يجب أن تحتوي $count صفوف');
    }
    for (final item in rows) validate(InputLimits.strictMap(item, field: key));
  }
}
