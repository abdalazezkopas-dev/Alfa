import 'package:flutter/material.dart';

import '../../../core/id_generator.dart';
import '../../../core/utils/date_formatter.dart';
import '../../settings/services/settings_store.dart';
import '../models/representative_report.dart';
import '../services/representative_report_store.dart';
import 'representative_report_form_screen.dart';

class RepresentativeReportsScreen extends StatefulWidget {
  const RepresentativeReportsScreen({super.key});

  @override
  State<RepresentativeReportsScreen> createState() =>
      _RepresentativeReportsScreenState();
}

class _RepresentativeReportsScreenState
    extends State<RepresentativeReportsScreen> {
  List<RepresentativeReport> _reports = const [];
  bool _loading = true;
  Object? _error;
  final _searchController = TextEditingController();
  String _query = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  List<String> get _searchSuggestions {
    final values = <String>{};
    void collect(Object? value) {
      if (value is String) {
        final clean = value.trim();
        if (clean.isNotEmpty) values.add(clean);
      } else if (value is Iterable) {
        for (final item in value) collect(item);
      } else if (value is Map) {
        for (final item in value.values) collect(item);
      }
    }

    for (final report in _reports) {
      final data = Map<String, Object?>.from(report.toMap())..remove('id');
      collect(data);
    }
    return values.toList()..sort();
  }

  List<RepresentativeReport> get _visibleReports {
    final query = _query.trim().toLowerCase();
    if (query.isEmpty) return _reports;
    return _reports
        .where((report) {
          // Search only persisted report data; this intentionally includes every
          // existing model field without adding a second filter schema.
          return report.toMap().toString().toLowerCase().contains(query);
        })
        .toList(growable: false);
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final reports = await RepresentativeReportStore.load();
      if (!mounted) return;
      setState(() {
        _reports = reports;
        _loading = false;
        _error = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _error = error;
        _loading = false;
      });
    }
  }

  Future<void> _create() async {
    try {
      final id =
          'representative-${await IdGenerator.next('representative_reports')}';
      if (!mounted) return;
      final settings = await SettingsStore.load();
      // Saudi Arabia uses UTC+03:00 year-round; derive both values from the
      // same Riyadh instant so a midnight boundary cannot disagree.
      final riyadhNow = DateTime.now().toUtc().add(const Duration(hours: 3));
      const weekdays = <String>[
        '',
        'الاثنين',
        'الثلاثاء',
        'الأربعاء',
        'الخميس',
        'الجمعة',
        'السبت',
        'الأحد',
      ];
      final report =
          RepresentativeReport.empty(
            id: id,
            date: DateFormatter.date(riyadhNow),
          ).copyWith(
            day: weekdays[riyadhNow.weekday],
            medRep: settings.representativeReportMedRep,
            city: settings.representativeReportCity,
            district: settings.representativeReportDistrict,
            section: settings.representativeReportSection,
          );
      final saved = await Navigator.of(context).push<bool>(
        MaterialPageRoute<bool>(
          builder: (_) =>
              RepresentativeReportFormScreen(report: report, isNew: true),
        ),
      );
      if (saved == true) await _load();
    } catch (error) {
      _showError('تعذر بدء تقرير جديد: $error');
    }
  }

  Future<void> _edit(RepresentativeReport report) async {
    final saved = await Navigator.of(context).push<bool>(
      MaterialPageRoute<bool>(
        builder: (_) => RepresentativeReportFormScreen(report: report),
      ),
    );
    if (saved == true) await _load();
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('تقارير المندوبين'),
        actions: [
          IconButton(
            tooltip: 'تحديث',
            onPressed: _load,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _create,
        icon: const Icon(Icons.add),
        label: const Text('تقرير جديد'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline, size: 44),
                    const SizedBox(height: 12),
                    const Text('تعذر تحميل تقارير المندوبين'),
                    const SizedBox(height: 8),
                    Text(
                      'راجع التخزين المحلي ثم أعد المحاولة.',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: () {
                        setState(() => _loading = true);
                        _load();
                      },
                      icon: const Icon(Icons.refresh),
                      label: const Text('إعادة المحاولة'),
                    ),
                  ],
                ),
              ),
            )
          : _reports.isEmpty
          ? const _EmptyRepresentativeReports()
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView.separated(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 88),
                itemCount: _visibleReports.isEmpty
                    ? 2
                    : _visibleReports.length + 1,
                separatorBuilder: (_, _) => const SizedBox(height: 10),
                itemBuilder: (context, index) {
                  if (index == 0) {
                    return Autocomplete<String>(
                      initialValue: TextEditingValue(text: _query),
                      optionsBuilder: (value) {
                        final query = value.text.trim().toLowerCase();
                        return _searchSuggestions.where(
                          (option) =>
                              query.isEmpty ||
                              option.toLowerCase().contains(query),
                        );
                      },
                      onSelected: (value) {
                        _searchController.text = value;
                        setState(() => _query = value);
                      },
                      fieldViewBuilder:
                          (
                            context,
                            fieldController,
                            focusNode,
                            onSubmitted,
                          ) => TextField(
                            controller: fieldController,
                            focusNode: focusNode,
                            decoration: const InputDecoration(
                              labelText: 'بحث وفلترة التقارير',
                              hintText:
                                  'اسم المندوب، التاريخ، المدينة، المنطقة، القسم أو أي حقل محفوظ',
                              prefixIcon: Icon(Icons.search),
                              border: OutlineInputBorder(),
                            ),
                            onChanged: (value) {
                              _searchController.text = value;
                              setState(() => _query = value);
                            },
                            onSubmitted: (_) => onSubmitted(),
                          ),
                    );
                  }
                  if (_visibleReports.isEmpty) {
                    return const Padding(
                      padding: EdgeInsets.all(24),
                      child: Center(child: Text('لا توجد نتائج مطابقة')),
                    );
                  }
                  final report = _visibleReports[index - 1];
                  final title = report.medRep.trim().isEmpty
                      ? 'تقرير مندوب'
                      : report.medRep.trim();
                  final details = <String>[
                    if (report.date.trim().isNotEmpty) report.date.trim(),
                    if (report.city.trim().isNotEmpty) report.city.trim(),
                    if (report.district.trim().isNotEmpty)
                      report.district.trim(),
                  ];
                  return Card(
                    child: ListTile(
                      leading: const CircleAvatar(
                        child: Icon(Icons.assignment_outlined),
                      ),
                      title: Text(title),
                      subtitle: Text(
                        details.isEmpty
                            ? 'تقرير يومي محفوظ'
                            : details.join(' • '),
                      ),
                      trailing: const Icon(Icons.chevron_left_rounded),
                      onTap: () => _edit(report),
                    ),
                  );
                },
              ),
            ),
    );
  }
}

class _EmptyRepresentativeReports extends StatelessWidget {
  const _EmptyRepresentativeReports();

  @override
  Widget build(BuildContext context) => Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            Icons.assignment_outlined,
            size: 54,
            color: Theme.of(context).colorScheme.primary,
          ),
          const SizedBox(height: 12),
          Text(
            'لا توجد تقارير محفوظة',
            style: Theme.of(context).textTheme.titleMedium,
          ),
          const SizedBox(height: 6),
          const Text(
            'أنشئ تقريرًا يوميًا للمندوب واملأ بيانات الزيارات.',
            textAlign: TextAlign.center,
          ),
        ],
      ),
    ),
  );
}
