import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';

import '../../../core/utils/date_formatter.dart';
import '../../expense_request/services/share_service.dart';
import '../../settings/services/settings_store.dart';
import '../models/representative_report.dart';
import '../services/representative_report_pdf_service.dart';
import '../services/representative_report_store.dart';

class RepresentativeReportFormScreen extends StatefulWidget {
  const RepresentativeReportFormScreen({
    required this.report,
    this.isNew = false,
    super.key,
  });

  final RepresentativeReport report;
  final bool isNew;

  @override
  State<RepresentativeReportFormScreen> createState() =>
      _RepresentativeReportFormScreenState();
}

class _RepresentativeReportFormScreenState
    extends State<RepresentativeReportFormScreen> {
  late final TextEditingController _medRep;
  late final TextEditingController _day;
  late final TextEditingController _date;
  late final TextEditingController _city;
  late final TextEditingController _district;
  late final TextEditingController _section;
  late final List<List<TextEditingController>> _morningPhysicians;
  late final List<List<TextEditingController>> _eveningPhysicians;
  late final List<List<TextEditingController>> _morningPharmacies;
  late final List<List<TextEditingController>> _eveningPharmacies;
  bool _saving = false;
  bool _exporting = false;
  Map<String, List<String>> _suggestions = const {};

  @override
  void initState() {
    super.initState();
    final report = widget.report;
    _medRep = TextEditingController(text: report.medRep);
    _day = TextEditingController(text: report.day);
    _date = TextEditingController(text: report.date);
    _city = TextEditingController(text: report.city);
    _district = TextEditingController(text: report.district);
    _section = TextEditingController(text: report.section);
    _morningPhysicians = _doctorControllers(report.morningPhysicians);
    _eveningPhysicians = _doctorControllers(report.eveningPhysicians);
    _morningPharmacies = _pharmacyControllers(report.morningPharmacies);
    _eveningPharmacies = _pharmacyControllers(report.eveningPharmacies);
    _date.addListener(_syncDayFromDate);
    _loadSuggestions();
    if (widget.isNew) _loadNewDefaults();
  }

  static const _arabicWeekdays = <String>[
    '',
    'الاثنين',
    'الثلاثاء',
    'الأربعاء',
    'الخميس',
    'الجمعة',
    'السبت',
    'الأحد',
  ];

  Future<void> _loadSuggestions() async {
    try {
      final reports = await RepresentativeReportStore.load();
      final values = <String, Set<String>>{
        'medRep': <String>{},
        'city': <String>{},
        'district': <String>{},
        'section': <String>{},
      };
      for (final report in reports) {
        values['medRep']!.add(report.medRep.trim());
        values['city']!.add(report.city.trim());
        values['district']!.add(report.district.trim());
        values['section']!.add(report.section.trim());
      }
      if (mounted) {
        setState(() {
          _suggestions = {
            for (final entry in values.entries)
              entry.key: entry.value
                  .where((value) => value.isNotEmpty)
                  .toList(),
          };
        });
      }
    } catch (_) {
      // Suggestions are optional; a local-storage failure must not block entry.
    }
  }

  Future<void> _loadNewDefaults() async {
    try {
      final settings = await SettingsStore.load();
      if (!mounted) return;
      if (_medRep.text.trim().isEmpty)
        _medRep.text = settings.representativeReportMedRep;
      if (_city.text.trim().isEmpty)
        _city.text = settings.representativeReportCity;
      if (_district.text.trim().isEmpty)
        _district.text = settings.representativeReportDistrict;
      if (_section.text.trim().isEmpty)
        _section.text = settings.representativeReportSection;
    } catch (_) {
      // The list screen already applies defaults; keep the form usable if load fails.
    }
  }

  void _syncDayFromDate() {
    final parsed = DateFormatter.parse(_date.text);
    if (parsed != null && _day.text != _arabicWeekdays[parsed.weekday]) {
      _day.text = _arabicWeekdays[parsed.weekday];
    }
  }

  String? _dateConflictMessage() {
    final parsed = DateFormatter.parse(_date.text);
    if (parsed == null) return 'أدخل تاريخًا صحيحًا بصيغة مYYYY/MM/DD.';
    final expected = _arabicWeekdays[parsed.weekday];
    if (_day.text.trim() != expected) {
      return 'اليوم لا يطابق التاريخ؛ المتوقع: $expected.';
    }
    return null;
  }

  Widget _suggestionField(
    String label,
    TextEditingController controller,
    String key,
  ) => Autocomplete<String>(
    initialValue: TextEditingValue(text: controller.text),
    optionsBuilder: (value) {
      final query = value.text.trim().toLowerCase();
      return (_suggestions[key] ?? const <String>[]).where(
        (option) => query.isEmpty || option.toLowerCase().contains(query),
      );
    },
    onSelected: (value) => controller.text = value,
    fieldViewBuilder: (context, fieldController, focusNode, onSubmitted) =>
        TextField(
          controller: fieldController,
          focusNode: focusNode,
          decoration: InputDecoration(
            labelText: label,
            border: const OutlineInputBorder(),
          ),
          textInputAction: TextInputAction.next,
          onChanged: (value) => controller.text = value,
          onSubmitted: (_) => onSubmitted(),
        ),
  );

  List<List<TextEditingController>> _doctorControllers(
    List<RepresentativePhysicianEntry> entries,
  ) => entries
      .map(
        (entry) => [
          TextEditingController(text: entry.name),
          TextEditingController(text: entry.specialty),
          TextEditingController(text: entry.className),
          TextEditingController(text: entry.address),
          TextEditingController(text: entry.samplesDelivered),
          TextEditingController(text: entry.observation),
        ],
      )
      .toList();

  List<List<TextEditingController>> _pharmacyControllers(
    List<RepresentativePharmacyEntry> entries,
  ) => entries
      .map(
        (entry) => [
          TextEditingController(text: entry.name),
          TextEditingController(text: entry.notice),
        ],
      )
      .toList();

  Iterable<TextEditingController> get _controllers sync* {
    yield* [_medRep, _day, _date, _city, _district, _section];
    for (final row in [
      ..._morningPhysicians,
      ..._eveningPhysicians,
      ..._morningPharmacies,
      ..._eveningPharmacies,
    ]) {
      yield* row;
    }
  }

  @override
  void dispose() {
    for (final controller in _controllers) {
      controller.dispose();
    }
    super.dispose();
  }

  RepresentativeReport _currentReport() => RepresentativeReport(
    id: widget.report.id,
    medRep: _medRep.text,
    day: _day.text,
    date: _date.text,
    city: _city.text,
    district: _district.text,
    section: _section.text,
    morningPhysicians: _doctorEntries(_morningPhysicians),
    eveningPhysicians: _doctorEntries(_eveningPhysicians),
    morningPharmacies: _pharmacyEntries(_morningPharmacies),
    eveningPharmacies: _pharmacyEntries(_eveningPharmacies),
  );

  List<RepresentativePhysicianEntry> _doctorEntries(
    List<List<TextEditingController>> rows,
  ) => [
    for (final row in rows)
      RepresentativePhysicianEntry(
        name: row[0].text,
        specialty: row[1].text,
        className: row[2].text,
        address: row[3].text,
        samplesDelivered: row[4].text,
        observation: row[5].text,
      ),
  ];

  List<RepresentativePharmacyEntry> _pharmacyEntries(
    List<List<TextEditingController>> rows,
  ) => [
    for (final row in rows)
      RepresentativePharmacyEntry(name: row[0].text, notice: row[1].text),
  ];

  Future<void> _save() async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      final conflict = _dateConflictMessage();
      if (conflict != null) {
        _message(conflict);
        return;
      }
      final report = _currentReport();
      if (widget.isNew) {
        await RepresentativeReportStore.add(report);
      } else if (!await RepresentativeReportStore.update(report)) {
        throw StateError('لم يعد التقرير موجودًا في التخزين المحلي');
      }
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (error) {
      _message('تعذر حفظ التقرير: $error');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _preview() async {
    if (_saving || _exporting) return;
    final conflict = _dateConflictMessage();
    if (conflict != null) {
      _message(conflict);
      return;
    }
    try {
      final report = _currentReport();
      if (!mounted) return;
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => Scaffold(
            appBar: AppBar(title: const Text('معاينة تقرير المندوب')),
            body: PdfPreview(
              canChangePageFormat: false,
              canChangeOrientation: false,
              build: (_) => RepresentativeReportPdfService.build(report),
            ),
          ),
        ),
      );
    } catch (error) {
      _message('تعذرت معاينة التقرير: $error');
    }
  }

  Future<void> _export({required bool print}) async {
    if (_exporting) return;
    final conflict = _dateConflictMessage();
    if (conflict != null) {
      _message(conflict);
      return;
    }
    setState(() => _exporting = true);
    try {
      final bytes = await RepresentativeReportPdfService.build(
        _currentReport(),
      );
      final filename = _filename();
      if (print) {
        await ShareService.printPdf(
          bytes,
          filename: filename,
          format: PdfPageFormat.a4.landscape,
        );
      } else {
        await ShareService.sharePdf(
          bytes: bytes,
          filename: filename,
          subject: 'تقرير مندوب يومي',
          body: 'تقرير المندوب اليومي بصيغة PDF',
        );
      }
    } catch (error) {
      _message('تعذرت ${print ? 'طباعة' : 'مشاركة'} التقرير: $error');
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  String _filename() {
    final date = _date.text.trim().replaceAll(RegExp(r'[^0-9A-Za-z-]'), '_');
    return 'representative_report_${date.isEmpty ? 'daily' : date}.pdf';
  }

  void _message(String value) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(value)));
  }

  Widget _field(String label, TextEditingController controller) => TextField(
    controller: controller,
    decoration: InputDecoration(
      labelText: label,
      border: const OutlineInputBorder(),
    ),
    textInputAction: TextInputAction.next,
  );

  Widget _headerFields() => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _suggestionField('اسم المندوب الطبي', _medRep, 'medRep'),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _field('اليوم', _day)),
              const SizedBox(width: 10),
              Expanded(child: _field('التاريخ', _date)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _suggestionField('المدينة', _city, 'city')),
              const SizedBox(width: 10),
              Expanded(
                child: _suggestionField('المنطقة', _district, 'district'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _suggestionField('القسم', _section, 'section'),
        ],
      ),
    ),
  );

  Widget _physicianSection(
    String title,
    List<List<TextEditingController>> rows,
  ) => Card(
    child: Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          for (var i = 0; i < rows.length; i++) ...[
            ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: Text('الطبيب ${i + 1}'),
              childrenPadding: const EdgeInsets.only(bottom: 8),
              children: [
                LayoutBuilder(
                  builder: (context, constraints) {
                    final width = constraints.maxWidth > 620
                        ? (constraints.maxWidth - 16) / 3
                        : (constraints.maxWidth - 8) / 2;
                    final labels = [
                      'اسم الطبيب',
                      'التخصص',
                      'الفئة',
                      'العنوان',
                      'العينات المسلّمة',
                      'ملاحظة',
                    ];
                    return Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (
                          var fieldIndex = 0;
                          fieldIndex < labels.length;
                          fieldIndex++
                        )
                          SizedBox(
                            width: width,
                            child: _field(
                              labels[fieldIndex],
                              rows[i][fieldIndex],
                            ),
                          ),
                      ],
                    );
                  },
                ),
              ],
            ),
            if (i < rows.length - 1) const Divider(height: 1),
          ],
        ],
      ),
    ),
  );

  Widget _pharmacySection(
    String title,
    List<List<TextEditingController>> rows,
  ) => Card(
    child: Padding(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          for (var i = 0; i < rows.length; i++) ...[
            ExpansionTile(
              tilePadding: EdgeInsets.zero,
              title: Text('الصيدلية ${i + 1}'),
              childrenPadding: const EdgeInsets.only(bottom: 8),
              children: [
                Row(
                  children: [
                    Expanded(child: _field('اسم الصيدلية', rows[i][0])),
                    const SizedBox(width: 8),
                    Expanded(child: _field('إشعار', rows[i][1])),
                  ],
                ),
              ],
            ),
            if (i < rows.length - 1) const Divider(height: 1),
          ],
        ],
      ),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final busy = _saving || _exporting;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.isNew ? 'تقرير مندوب جديد' : 'تعديل تقرير المندوب'),
        actions: [
          IconButton(
            tooltip: 'معاينة PDF',
            onPressed: busy ? null : _preview,
            icon: const Icon(Icons.picture_as_pdf_outlined),
          ),
          IconButton(
            tooltip: 'طباعة',
            onPressed: busy ? null : () => _export(print: true),
            icon: const Icon(Icons.print_outlined),
          ),
          IconButton(
            tooltip: 'مشاركة PDF',
            onPressed: busy ? null : () => _export(print: false),
            icon: const Icon(Icons.share_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 20),
        children: [
          _headerFields(),
          _physicianSection('أطباء الصباح', _morningPhysicians),
          _physicianSection('أطباء المساء', _eveningPhysicians),
          _pharmacySection('صيدليات الصباح', _morningPharmacies),
          _pharmacySection('صيدليات المساء', _eveningPharmacies),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: _saving ? null : _save,
            icon: _saving
                ? const SizedBox.square(
                    dimension: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.save_outlined),
            label: Text(_saving ? 'جارٍ الحفظ' : 'حفظ التقرير'),
          ),
        ],
      ),
    );
  }
}
