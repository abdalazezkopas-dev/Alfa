import '../../../core/utils/date_formatter.dart';

import 'package:flutter/material.dart';
import 'package:printing/printing.dart';

import '../../expense_request/models/expense_request.dart';
import '../../expense_request/services/request_store.dart';
import '../../expense_request/services/share_service.dart';
import '../../settings/services/settings_store.dart';
import '../services/report_service.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  final _keywordController = TextEditingController();
  List<ExpenseRequest> _requests = [];
  DateTime? _from;
  DateTime? _to;
  ReportFormFilter _formFilter = ReportFormFilter.both;
  ReportSortField _sortField = ReportSortField.date;
  bool _ascending = false;
  bool _isLoading = true;
  bool _isExporting = false;
  bool _isPreviewing = false;
  Object? _loadError;

  ReportFilter get _filter => ReportFilter(
    from: _from,
    to: _to,
    statementKeyword: _keywordController.text,
    formFilter: _formFilter,
    sortField: _sortField,
    ascending: _ascending,
  );

  List<ExpenseRequest> get _filteredRequests =>
      ReportService.filterAndSort(_requests, _filter);

  double get _totalAmount => _filteredRequests.fold<double>(
    0,
    (sum, request) => sum + ReportService.totalAmount(request),
  );

  @override
  void initState() {
    super.initState();
    _keywordController.addListener(_refresh);
    _loadRequests();
  }

  @override
  void dispose() {
    _keywordController
      ..removeListener(_refresh)
      ..dispose();
    super.dispose();
  }

  Future<bool> _loadRequests() async {
    if (mounted) {
      setState(() {
        _isLoading = true;
        _loadError = null;
      });
    }
    try {
      final requests = await RequestStore.load();
      if (!mounted) return true;
      setState(() {
        _requests = requests;
        _isLoading = false;
        _loadError = null;
      });
      return true;
    } catch (error) {
      if (!mounted) return false;
      setState(() {
        _isLoading = false;
        _loadError = error;
      });
      return false;
    }
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  Future<void> _pickDate({required bool from}) async {
    final initial = from
        ? (_from ?? DateTime.now())
        : (_to ?? _from ?? DateTime.now());
    final selected = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      locale: const Locale('ar'),
      helpText: from ? 'اختر بداية الفترة' : 'اختر نهاية الفترة',
      cancelText: 'إلغاء',
      confirmText: 'اختيار',
    );
    if (selected == null) return;
    setState(() {
      if (from) {
        _from = selected;
        if (_to != null && _to!.isBefore(selected)) _to = selected;
      } else {
        _to = selected;
        if (_from != null && _from!.isAfter(selected)) _from = selected;
      }
    });
  }

  void _clearFilters() {
    setState(() {
      _from = null;
      _to = null;
      _keywordController.clear();
      _formFilter = ReportFormFilter.both;
      _sortField = ReportSortField.date;
      _ascending = false;
    });
  }

  Future<void> _export({required bool print}) async {
    // Capture the current filter before the async refresh so refreshing the
    // source never resets or silently changes the user's filter choices.
    final filter = _filter;
    setState(() => _isExporting = true);
    try {
      if (!await _loadRequests()) {
        throw StateError('تعذر تحديث مصدر التقرير');
      }
      final requests = ReportService.filterAndSort(_requests, filter);
      if (requests.isEmpty) {
        _showMessage('لا توجد طلبات مطابقة للفلاتر الحالية');
        return;
      }
      final settings = await SettingsStore.load();
      final bytes = await ReportPdfService.buildReport(
        requests: requests,
        filter: filter,
        settings: settings,
      );
      final date = DateTime.now();
      final filename =
          'expense_report_${DateFormatter.date(date).replaceAll('/', '_')}.pdf';
      if (print) {
        await ShareService.printPdf(bytes, filename: filename);
      } else {
        await ShareService.sharePdf(bytes: bytes, filename: filename);
      }
    } catch (error) {
      _showMessage(
        print
            ? 'تعذرت طباعة التقرير بعد إنشائه: ${_friendlyError(error)}'
            : 'تعذرت مشاركة التقرير بعد إنشائه: ${_friendlyError(error)}',
        onRetry: () => _export(print: print),
      );
    } finally {
      if (mounted) setState(() => _isExporting = false);
    }
  }

  Future<void> _preview() async {
    final filter = _filter;
    setState(() => _isPreviewing = true);
    try {
      if (!await _loadRequests()) {
        throw StateError('تعذر تحديث مصدر التقرير');
      }
      final requests = ReportService.filterAndSort(_requests, filter);
      if (requests.isEmpty) {
        _showMessage('لا توجد طلبات مطابقة للفلاتر الحالية');
        return;
      }
      final settings = await SettingsStore.load();
      final bytes = await ReportPdfService.buildReport(
        requests: requests,
        filter: filter,
        settings: settings,
      );
      if (bytes.isEmpty) throw StateError('تم إنشاء ملف PDF فارغ');
      if (!mounted) return;
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => Scaffold(
            appBar: AppBar(title: const Text('معاينة التقرير العام')),
            body: PdfPreview(
              canChangePageFormat: false,
              canChangeOrientation: false,
              build: (_) async => bytes,
            ),
          ),
        ),
      );
    } catch (error) {
      _showMessage('تعذرت معاينة التقرير العام.', onRetry: _preview);
    } finally {
      if (mounted) setState(() => _isPreviewing = false);
    }
  }

  String _friendlyError(Object error) {
    final text = error.toString().toLowerCase();
    if (text.contains('font') || text.contains('asset')) {
      return 'تحقق من ملفات الخطوط والقالب.';
    }
    return 'تحقق من البيانات وحاول مرة أخرى.';
  }

  void _showMessage(String message, {VoidCallback? onRetry}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        action: onRetry == null
            ? null
            : SnackBarAction(label: 'إعادة المحاولة', onPressed: onRetry),
      ),
    );
  }

  String _dateLabel(DateTime? value) {
    if (value == null) return 'بدون تحديد';
    return DateFormatter.date(value);
  }

  @override
  Widget build(BuildContext context) {
    final requests = _filteredRequests;
    return Scaffold(
      appBar: AppBar(
        title: const Text('طباعة التقارير'),
        actions: [
          IconButton(
            tooltip: 'تحديث الطلبات',
            onPressed: _isLoading ? null : () => _loadRequests(),
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _loadError != null
          ? _ReportLoadError(onRetry: _loadRequests)
          : RefreshIndicator(
              onRefresh: () async {
                await _loadRequests();
              },
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                children: [
                  _ReportSummary(count: requests.length, total: _totalAmount),
                  const SizedBox(height: 12),
                  _buildFilters(),
                  const SizedBox(height: 12),
                  _buildExportButtons(),
                  const SizedBox(height: 16),
                  if (requests.isEmpty)
                    const _EmptyReport()
                  else
                    ...requests.map(
                      (request) => _ReportRequestCard(request: request),
                    ),
                ],
              ),
            ),
    );
  }

  Widget _buildFilters() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const Icon(Icons.filter_alt_outlined),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'خيارات التقرير',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: _clearFilters,
                  child: const Text('تصفير'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickDate(from: true),
                    icon: const Icon(Icons.event_outlined),
                    label: Text('من: ${_dateLabel(_from)}'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => _pickDate(from: false),
                    icon: const Icon(Icons.event_available_outlined),
                    label: Text('إلى: ${_dateLabel(_to)}'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            TextField(
              controller: _keywordController,
              decoration: const InputDecoration(
                labelText: 'بحث داخل البيان',
                hintText: 'اكتب كلمة أو عبارة',
                prefixIcon: Icon(Icons.search),
              ),
              textInputAction: TextInputAction.search,
            ),
            const SizedBox(height: 10),
            Text('نوع النماذج', style: Theme.of(context).textTheme.labelLarge),
            const SizedBox(height: 6),
            SegmentedButton<ReportFormFilter>(
              segments: const [
                ButtonSegment(
                  value: ReportFormFilter.one,
                  label: Text('نموذج واحد'),
                ),
                ButtonSegment(
                  value: ReportFormFilter.two,
                  label: Text('نموذجان'),
                ),
                ButtonSegment(
                  value: ReportFormFilter.both,
                  label: Text('كلاهما'),
                ),
              ],
              selected: {_formFilter},
              onSelectionChanged: (selection) {
                if (selection.isNotEmpty) {
                  setState(() => _formFilter = selection.first);
                }
              },
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<ReportSortField>(
                    initialValue: _sortField,
                    decoration: const InputDecoration(labelText: 'ترتيب حسب'),
                    items: const [
                      DropdownMenuItem(
                        value: ReportSortField.date,
                        child: Text('التاريخ'),
                      ),
                      DropdownMenuItem(
                        value: ReportSortField.amount,
                        child: Text('المبلغ'),
                      ),
                      DropdownMenuItem(
                        value: ReportSortField.receiver,
                        child: Text('المرسل إليه'),
                      ),
                      DropdownMenuItem(
                        value: ReportSortField.requester,
                        child: Text('مقدم الطلب'),
                      ),
                    ],
                    onChanged: (value) {
                      if (value != null) setState(() => _sortField = value);
                    },
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: SegmentedButton<bool>(
                    segments: const [
                      ButtonSegment(value: true, label: Text('تصاعدي')),
                      ButtonSegment(value: false, label: Text('تنازلي')),
                    ],
                    selected: {_ascending},
                    onSelectionChanged: (selection) {
                      if (selection.isNotEmpty) {
                        setState(() => _ascending = selection.first);
                      }
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildExportButtons() {
    return Row(
      children: [
        Expanded(
          child: FilledButton.icon(
            onPressed: _isExporting || _isPreviewing
                ? null
                : () => _export(print: false),
            icon: _isExporting
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.share_outlined),
            label: const Text('إنشاء ومشاركة PDF'),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: _isExporting || _isPreviewing
                ? null
                : () => _export(print: true),
            icon: const Icon(Icons.print_outlined),
            label: const Text('طباعة التقرير'),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: OutlinedButton.icon(
            onPressed: _isExporting || _isPreviewing ? null : _preview,
            icon: _isPreviewing
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.preview_outlined),
            label: const Text('معاينة التقرير'),
          ),
        ),
      ],
    );
  }
}

class _ReportLoadError extends StatelessWidget {
  const _ReportLoadError({required this.onRetry});

  final Future<bool> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 48),
            const SizedBox(height: 12),
            const Text('تعذر تحميل مصدر التقرير'),
            const SizedBox(height: 6),
            const Text(
              'تحقق من التخزين المحلي ثم أعد المحاولة.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () {
                onRetry();
              },
              icon: const Icon(Icons.refresh),
              label: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      ),
    );
  }
}

class _ReportSummary extends StatelessWidget {
  const _ReportSummary({required this.count, required this.total});

  final int count;
  final double total;

  @override
  Widget build(BuildContext context) {
    final settingsColor = Theme.of(context).colorScheme.primaryContainer;
    return Card(
      color: settingsColor,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(Icons.summarize_outlined, size: 34),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'ملخص النتائج',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text('عدد الطلبات: $count   |   الإجمالي: ${_format(total)}'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _format(double value) {
    if (value == value.roundToDouble()) return value.toStringAsFixed(0);
    return value.toStringAsFixed(2);
  }
}

class _ReportRequestCard extends StatelessWidget {
  const _ReportRequestCard({required this.request});

  final ExpenseRequest request;

  @override
  Widget build(BuildContext context) {
    final amount = ReportService.formatAmount(
      ReportService.totalAmount(request),
    );
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    DateFormatter.parse(request.date) == null
                        ? request.date
                        : DateFormatter.date(
                            DateFormatter.parse(request.date)!,
                          ),
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                Text(
                  '$amount   ${ReportService.formLabel(request)}',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    color: Theme.of(context).colorScheme.primary,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
            const Divider(height: 16),
            Text('المرسل إليه: ${request.receiver}'),
            Text('مقدم الطلب: ${request.requesterName}'),
            if (request.statement.trim().isNotEmpty)
              Text(
                'البيان: ${request.statement}',
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
          ],
        ),
      ),
    );
  }
}

class _EmptyReport extends StatelessWidget {
  const _EmptyReport();

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          children: [
            const Icon(Icons.filter_alt_off_outlined, size: 42),
            const SizedBox(height: 10),
            Text(
              'لا توجد نتائج',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 4),
            const Text('غيّر الفلاتر أو أضف نموذج صرف جديداً.'),
          ],
        ),
      ),
    );
  }
}
