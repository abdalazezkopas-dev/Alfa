import '../../../core/utils/date_formatter.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../../expense_request/models/expense_request.dart';
import '../../../core/utils/number_normalizer.dart';
import '../../expense_request/services/pdf_text_sanitizer.dart';
import '../../settings/models/app_settings.dart';

/// The field used to order report rows.
enum ReportSortField { date, amount, receiver, requester }

/// Which saved request shape should be included in the report.
enum ReportFormFilter { one, two, both }

class ReportFilter {
  const ReportFilter({
    this.from,
    this.to,
    this.statementKeyword = '',
    this.formFilter = ReportFormFilter.both,
    this.sortField = ReportSortField.date,
    this.ascending = false,
  });

  final DateTime? from;
  final DateTime? to;
  final String statementKeyword;
  final ReportFormFilter formFilter;
  final ReportSortField sortField;
  final bool ascending;
}

class ReportService {
  const ReportService._();

  static List<ExpenseRequest> filterAndSort(
    Iterable<ExpenseRequest> source,
    ReportFilter filter,
  ) {
    final keyword = _normalize(filter.statementKeyword);
    final result = source.where((request) {
      final requestDate = parseDate(request.date);
      if (filter.from != null &&
          (requestDate == null || requestDate.isBefore(_day(filter.from!)))) {
        return false;
      }
      if (filter.to != null &&
          (requestDate == null || requestDate.isAfter(_day(filter.to!)))) {
        return false;
      }

      final isTwoForms = request.hasSecondRequest;
      if (filter.formFilter == ReportFormFilter.one && isTwoForms) {
        return false;
      }
      if (filter.formFilter == ReportFormFilter.two && !isTwoForms) {
        return false;
      }

      if (keyword.isNotEmpty &&
          !_normalize(request.statement).contains(keyword)) {
        return false;
      }
      return true;
    }).toList();

    result.sort((left, right) {
      final comparison = switch (filter.sortField) {
        ReportSortField.date => _compareDates(left.date, right.date),
        ReportSortField.amount => totalAmount(
          left,
        ).compareTo(totalAmount(right)),
        ReportSortField.receiver => _normalize(
          left.receiver,
        ).compareTo(_normalize(right.receiver)),
        ReportSortField.requester => _normalize(
          left.requesterName,
        ).compareTo(_normalize(right.requesterName)),
      };
      if (comparison != 0) {
        return filter.ascending ? comparison : -comparison;
      }
      return _normalize(left.date).compareTo(_normalize(right.date));
    });
    return result;
  }

  static DateTime? parseDate(String value) => DateFormatter.parse(value);

  static double totalAmount(ExpenseRequest request) {
    final primary = _parseAmount(request.amountNumber);
    final secondary = request.hasSecondRequest
        ? _parseAmount(request.secondRequest!.amountNumber)
        : 0;
    return primary + secondary;
  }

  static String formatAmount(double amount) {
    if (amount == amount.roundToDouble()) return amount.toStringAsFixed(0);
    return amount.toStringAsFixed(2).replaceFirst(RegExp(r'0+$'), '');
  }

  static String formLabel(ExpenseRequest request) {
    return request.hasSecondRequest ? 'نموذجان' : 'نموذج واحد';
  }

  static String _normalize(String value) {
    return _toAsciiDigits(
      value,
    ).toLowerCase().replaceAll(RegExp(r'[\s,،٬]'), '').replaceAll('٫', '.');
  }

  static String _toAsciiDigits(String value) => NumberNormalizer.digits(value);

  static DateTime _day(DateTime value) =>
      DateTime(value.year, value.month, value.day);

  static int _compareDates(String left, String right) {
    final leftDate = parseDate(left);
    final rightDate = parseDate(right);
    if (leftDate == null && rightDate == null) return 0;
    if (leftDate == null) return -1;
    if (rightDate == null) return 1;
    return leftDate.compareTo(rightDate);
  }

  static double _parseAmount(String value) {
    final normalized = _toAsciiDigits(
      value,
    ).replaceAll(',', '').replaceAll('٬', '').replaceAll('٫', '.');
    return double.tryParse(normalized) ?? 0;
  }
}

class ReportPdfService {
  const ReportPdfService._();

  static final Map<String, Future<pw.Font>> _fontCache = {};

  static Future<pw.Font> _loadFont(String path) =>
      _fontCache[path] ??= rootBundle.load(path).then(pw.Font.ttf);

  static Future<Uint8List> buildReport({
    required List<ExpenseRequest> requests,
    required ReportFilter filter,
    required AppSettings settings,
  }) async {
    final regularFont = await _loadFont(
      'assets/fonts/NotoSansArabic-Regular.ttf',
    );
    final latinFallback = await _loadFont('assets/fonts/DejaVuSans.ttf');
    final document = pw.Document(
      title: PdfTextSanitizer.normalize('تقرير طلبات الصرف'),
      author: PdfTextSanitizer.normalize(settings.companyName),
    );

    final total = requests.fold<double>(
      0,
      (sum, request) => sum + ReportService.totalAmount(request),
    );
    final rows = <List<String>>[];
    for (final request in requests) {
      rows.add(
        _reportRow(
          request,
          typeLabel: request.hasSecondRequest ? 'الأول' : 'واحد',
          currency: settings.currencyName,
        ),
      );
      if (request.secondRequest != null) {
        rows.add(
          _reportRow(
            request.secondRequest!,
            typeLabel: 'الثاني',
            currency: settings.currencyName,
          ),
        );
      }
    }

    final cellStyle = pw.TextStyle(
      font: regularFont,
      fontFallback: [latinFallback],
      fontSize: 7.2,
      height: 1,
    );
    final headerStyle = pw.TextStyle(
      font: regularFont,
      fontFallback: [latinFallback],
      fontSize: 7.5,
      fontWeight: pw.FontWeight.bold,
      color: PdfColors.white,
      height: 1,
    );

    document.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(24, 28, 24, 28),
        footer: (context) => pw.Directionality(
          textDirection: pw.TextDirection.rtl,
          child: pw.Text(
            'صفحة ${context.pageNumber}',
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(
              font: regularFont,
              fontFallback: [latinFallback],
              fontSize: 7,
              color: PdfColors.grey700,
            ),
          ),
        ),
        build: (context) => [
          pw.Directionality(
            textDirection: pw.TextDirection.rtl,
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.stretch,
              children: [
                pw.Text(
                  _safe(settings.companyName, 80),
                  textAlign: pw.TextAlign.center,
                  style: pw.TextStyle(
                    font: regularFont,
                    fontFallback: [latinFallback],
                    fontSize: 15,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
                pw.SizedBox(height: 5),
                pw.Text(
                  _safe(settings.formTitle, 80),
                  textAlign: pw.TextAlign.center,
                  style: pw.TextStyle(
                    font: regularFont,
                    fontFallback: [latinFallback],
                    fontSize: 11,
                  ),
                ),
                pw.SizedBox(height: 4),
                pw.Text(
                  'تقرير طلبات الصرف',
                  textAlign: pw.TextAlign.center,
                  style: pw.TextStyle(
                    font: regularFont,
                    fontFallback: [latinFallback],
                    fontSize: 12,
                    fontWeight: pw.FontWeight.bold,
                  ),
                ),
                pw.SizedBox(height: 14),
                _summary(
                  requests.length,
                  total,
                  settings.currencyName,
                  filter,
                  regularFont,
                  latinFallback,
                ),
                pw.SizedBox(height: 14),
                pw.TableHelper.fromTextArray(
                  headers: const [
                    'النوع',
                    'المبلغ',
                    'مقدم الطلب',
                    'المرسل إليه',
                    'التاريخ',
                    'البيان',
                  ],
                  data: rows,
                  headerStyle: headerStyle,
                  cellStyle: cellStyle,
                  headerDecoration: const pw.BoxDecoration(
                    color: PdfColor.fromInt(0xFF2E5D7B),
                  ),
                  rowDecoration: const pw.BoxDecoration(
                    color: PdfColor.fromInt(0xFFF6F8FA),
                  ),
                  oddRowDecoration: const pw.BoxDecoration(
                    color: PdfColors.white,
                  ),
                  cellPadding: const pw.EdgeInsets.symmetric(
                    horizontal: 4,
                    vertical: 5,
                  ),
                  border: pw.TableBorder.all(
                    color: PdfColors.grey500,
                    width: 0.5,
                  ),
                  columnWidths: {
                    0: const pw.FixedColumnWidth(48),
                    1: const pw.FixedColumnWidth(62),
                    2: const pw.FixedColumnWidth(78),
                    3: const pw.FixedColumnWidth(78),
                    4: const pw.FixedColumnWidth(52),
                    5: const pw.FlexColumnWidth(1),
                  },
                  cellAlignments: const {
                    0: pw.Alignment.center,
                    1: pw.Alignment.center,
                    2: pw.Alignment.centerRight,
                    3: pw.Alignment.centerRight,
                    4: pw.Alignment.center,
                    5: pw.Alignment.centerRight,
                  },
                  headerAlignments: const {
                    0: pw.Alignment.center,
                    1: pw.Alignment.center,
                    2: pw.Alignment.center,
                    3: pw.Alignment.center,
                    4: pw.Alignment.center,
                    5: pw.Alignment.center,
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
    return document.save();
  }

  static pw.Widget _summary(
    int count,
    double total,
    String currency,
    ReportFilter filter,
    pw.Font font,
    pw.Font fallback,
  ) {
    final period = [
      if (filter.from != null) 'من ${_date(filter.from!)}',
      if (filter.to != null) 'إلى ${_date(filter.to!)}',
    ].join(' ');
    final keyword = filter.statementKeyword.trim();
    final details = [
      'عدد الطلبات: $count',
      'إجمالي المبالغ: ${ReportService.formatAmount(total)} $currency',
      if (period.isNotEmpty) period,
      if (keyword.isNotEmpty) 'البيان يحتوي: ${_safe(keyword, 36)}',
    ].join('   |   ');
    return pw.Container(
      padding: const pw.EdgeInsets.all(9),
      decoration: pw.BoxDecoration(
        color: const PdfColor.fromInt(0xFFEAF1F5),
        border: pw.Border.all(
          color: const PdfColor.fromInt(0xFF8BA7B8),
          width: 0.7,
        ),
        borderRadius: const pw.BorderRadius.all(pw.Radius.circular(5)),
      ),
      child: pw.Text(
        _safe(details, 220),
        textAlign: pw.TextAlign.right,
        style: pw.TextStyle(font: font, fontFallback: [fallback], fontSize: 8),
      ),
    );
  }

  static List<String> _reportRow(
    ExpenseRequest request, {
    required String typeLabel,
    required String currency,
  }) {
    return [
      typeLabel,
      '${ReportService.formatAmount(ReportService.totalAmount(request))} $currency',
      _safe(request.requesterName, 34),
      _safe(request.receiver, 34),
      _safe(_displayDate(request.date), 14),
      _full(request.statement),
    ];
  }

  static String _displayDate(String value) {
    final parsed = DateFormatter.parse(value);
    return parsed == null ? value : DateFormatter.date(parsed);
  }

  static String _date(DateTime value) {
    return DateFormatter.date(value);
  }

  static String _full(String value) {
    return PdfTextSanitizer.normalize(value).replaceAll('…', '...');
  }

  static String _safe(String value, int maxRunes) {
    final normalized = _full(value);
    final runes = normalized.runes.toList();
    if (runes.length <= maxRunes) return normalized;
    return '${String.fromCharCodes(runes.take(maxRunes - 3))}...';
  }
}
