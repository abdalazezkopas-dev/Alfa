import 'dart:io';

import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';

import '../../../core/services/attachment_manager.dart';
import '../../../core/utils/number_normalizer.dart';
import '../../expense_request/models/expense_request.dart';
import '../../expense_request/services/pdf_service.dart';
import '../../expense_request/services/request_store.dart';
import '../../expense_request/services/share_service.dart';
import '../../settings/models/app_settings.dart';
import '../../settings/models/template_configuration.dart';
import '../../settings/screens/settings_screen.dart';
import '../../settings/screens/template_preview_screen.dart';
import '../../settings/services/settings_store.dart';

class FuelRequestScreen extends StatefulWidget {
  const FuelRequestScreen({this.initialRequest, this.editingIndex, super.key});

  final ExpenseRequest? initialRequest;
  final int? editingIndex;

  @override
  State<FuelRequestScreen> createState() => _FuelRequestScreenState();
}

class _FuelRequestScreenState extends State<FuelRequestScreen> {
  final _formKey = GlobalKey<FormState>();
  final _formScrollController = ScrollController();
  final _branch = TextEditingController();
  final _vehicleNumber = TextEditingController();
  final _collector = TextEditingController();
  final _fuelType = TextEditingController();
  final _periodFrom = TextEditingController();
  final _periodTo = TextEditingController();
  final _beneficiary = TextEditingController();
  final _branchAccountant = TextEditingController();
  final _branchManager = TextEditingController();
  final _administrationAccountant = TextEditingController();
  final _accountsManager = TextEditingController();
  final List<_FuelRowControllers> _rows = [];
  String? _attachmentPath;
  AppSettings _settings = AppSettings.defaults();
  bool _busy = false;
  bool _fuelTypeValidationFailed = false;

  static const _scope = 'fuelRequest';

  @override
  void initState() {
    super.initState();
    _addRow(notify: false);
    _load();
  }

  Future<void> _load() async {
    final settings = await SettingsStore.load(scope: _scope);
    final request = widget.initialRequest;
    if (!mounted) return;
    setState(() {
      _settings = settings;
      if (request != null) _fill(request);
    });
  }

  void _fill(ExpenseRequest request) {
    final general = request.customFields;
    _branch.text = general['fuelBranch'] ?? request.branch;
    _vehicleNumber.text = general['vehicleNumber'] ?? '';
    _collector.text = (general['collector'] ?? general['beneficiary'] ?? '')
        .trim();
    _beneficiary.text = _collector.text;
    _fuelType.text = general['fuelType'] ?? '';
    _periodFrom.text = general['periodFrom'] ?? '';
    _periodTo.text = general['periodTo'] ?? '';
    if (_collector.text.isEmpty) {
      _collector.text = request.receiver.trim();
    }
    _beneficiary.text = _collector.text;
    _branchAccountant.text = general['branchAccountant'] ?? '';
    _branchManager.text = general['branchManager'] ?? '';
    _administrationAccountant.text = general['administrationAccountant'] ?? '';
    final savedAccountsManager = general['accountsManager']?.trim() ?? '';
    _accountsManager.text = savedAccountsManager.isNotEmpty
        ? savedAccountsManager
        : request.accountsManagerName;
    _attachmentPath = request.attachmentPath;
    for (var index = 0; index < request.fuelEntries.length; index++) {
      final saved = request.fuelEntries[index];
      if (index > 0 && _rows.length < 50) _addRow(notify: false);
      final row = _rows[index];
      row.date.text = saved.date;
      row.meter.text = saved.meter;
      row.liters.text = saved.liters;
      row.price.text = saved.literPrice;
      row.amount.text = saved.fuelAmount;
      row.collection.text = saved.collection;
      row.sales.text = saved.sales;
      row.route.text = saved.route;
    }
    if (request.fuelEntries.isEmpty && _rows.length > 1) {
      _removeRow(_rows.length - 1);
    }
  }

  @override
  void dispose() {
    _formScrollController.dispose();
    for (final controller in [
      _branch,
      _vehicleNumber,
      _collector,
      _fuelType,
      _periodFrom,
      _periodTo,
      _beneficiary,
      _branchAccountant,
      _branchManager,
      _administrationAccountant,
      _accountsManager,
    ]) {
      controller.dispose();
    }
    for (final row in _rows) {
      row.dispose();
    }
    super.dispose();
  }

  FieldSetting _field(String key) =>
      _settings.fieldSettings[key] ??
      const FieldSetting(label: '', visible: true, required: false);

  bool _visible(String key) => _field(key).visible;

  String _label(String key, String fallback) {
    final label = _field(key).label.trim();
    return label.isEmpty ? fallback : label;
  }

  String _formatDate(DateTime date) =>
      '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';

  DateTime? _parseDate(String value) {
    final parts = value.trim().split('/');
    if (parts.length != 3) return null;
    final day = int.tryParse(parts[0]);
    final month = int.tryParse(parts[1]);
    final year = int.tryParse(parts[2]);
    if (day == null || month == null || year == null) return null;
    final parsed = DateTime(year, month, day);
    return parsed.year == year && parsed.month == month && parsed.day == day
        ? parsed
        : null;
  }

  Future<void> _pickDate(TextEditingController controller) async {
    final selected = await showDatePicker(
      context: context,
      initialDate: _parseDate(controller.text) ?? DateTime.now(),
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
      locale: const Locale('ar'),
      cancelText: 'إلغاء',
      confirmText: 'اختيار',
    );
    if (selected != null) controller.text = _formatDate(selected);
  }

  String _formatNumber(String value) {
    final parsed = NumberNormalizer.parseDouble(value);
    if (parsed == null) return value;
    final fixed = parsed == parsed.roundToDouble()
        ? parsed.toStringAsFixed(0)
        : parsed.toStringAsFixed(2);
    final parts = fixed.split('.');
    final integer = parts.first;
    final sign = integer.startsWith('-') ? '-' : '';
    final digits = sign.isEmpty ? integer : integer.substring(1);
    final grouped = digits.replaceAllMapped(
      RegExp(r'(?<=\d)(?=(\d{3})+$)'),
      (_) => ',',
    );
    return '$sign$grouped${parts.length == 2 ? '.${parts[1]}' : ''}';
  }

  Widget _stakeholderField(
    String key,
    String fallback,
    TextEditingController controller,
    List<String> suggestions,
  ) {
    if (!_visible(key)) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextFormField(
        controller: controller,
        textDirection: TextDirection.rtl,
        decoration: InputDecoration(
          labelText: _label(key, fallback),
          prefixIcon: const Icon(Icons.person_outline),
          suffixIcon: PopupMenuButton<String>(
            tooltip: 'اختيار جهة معنية',
            icon: const Icon(Icons.arrow_drop_down),
            onSelected: (value) => setState(() => controller.text = value),
            itemBuilder: (_) => [
              for (final item in suggestions)
                PopupMenuItem<String>(value: item, child: Text(item)),
            ],
          ),
        ),
        validator: (value) =>
            _field(key).required && (value == null || value.trim().isEmpty)
            ? 'هذا الحقل مطلوب'
            : null,
      ),
    );
  }

  Widget _fuelTypeSelector() {
    if (!_visible('fuelType')) return const SizedBox.shrink();
    const options = <String>['بترول', 'ديزل', 'غاز'];
    return InputDecorator(
      decoration: InputDecoration(
        labelText: _label('fuelType', 'نوع الوقود'),
        prefixIcon: const Icon(Icons.local_gas_station_outlined),
        errorText: _fuelTypeValidationFailed ? 'نوع الوقود مطلوب' : null,
      ),
      child: Wrap(
        alignment: WrapAlignment.center,
        spacing: 8,
        children: [
          for (final option in options)
            ChoiceChip(
              label: Text(option),
              selected: _fuelType.text == option,
              onSelected: (_) => setState(() {
                _fuelType.text = option;
                _fuelTypeValidationFailed = false;
              }),
            ),
        ],
      ),
    );
  }

  List<String> _optionsFor(String key, {List<String> fallback = const []}) {
    final values = <String>{
      ...fallback,
      if (key == 'fuelBranch') ..._settings.branchOptions,
      ...?_settings.stakeholderOptions[key],
    };
    return values.where((value) => value.trim().isNotEmpty).toList();
  }

  Widget _textField(
    String key,
    String fallback,
    TextEditingController controller, {
    bool number = false,
    bool date = false,
    ValueChanged<String>? onChanged,
    List<String> suggestions = const [],
    bool showDropdown = false,
  }) {
    if (!_visible(key)) return const SizedBox.shrink();
    final meterField = key.startsWith('fuelMeter');
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextFormField(
        controller: controller,
        textDirection: meterField ? TextDirection.ltr : TextDirection.rtl,
        keyboardType: meterField
            ? TextInputType.number
            : number
            ? const TextInputType.numberWithOptions(decimal: true)
            : TextInputType.text,
        inputFormatters: meterField
            ? [FilteringTextInputFormatter.allow(RegExp(r'[0-9]'))]
            : number
            ? [FilteringTextInputFormatter.allow(RegExp(r'[0-9٠-٩۰-۹.,٬٫-]'))]
            : null,
        decoration: InputDecoration(
          labelText: _label(key, fallback),
          prefixIcon: Icon(
            date
                ? Icons.calendar_month_outlined
                : number
                ? Icons.numbers_outlined
                : Icons.edit_outlined,
          ),
          suffixIcon: date
              ? IconButton(
                  onPressed: () => _pickDate(controller),
                  icon: const Icon(Icons.event_outlined),
                )
              : (suggestions.isNotEmpty || showDropdown)
              ? PopupMenuButton<String>(
                  tooltip: 'اختيار من القائمة أو اكتب يدويًا',
                  icon: const Icon(Icons.arrow_drop_down),
                  onSelected: (value) {
                    setState(() {
                      controller.text = value;
                      onChanged?.call(value);
                    });
                  },
                  itemBuilder: (_) => suggestions.isEmpty
                      ? const [
                          PopupMenuItem<String>(
                            enabled: false,
                            value: '',
                            child: Text('لا توجد خيارات محفوظة'),
                          ),
                        ]
                      : [
                          for (final item in suggestions)
                            PopupMenuItem<String>(
                              value: item,
                              child: Text(item),
                            ),
                        ],
                )
              : null,
        ),
        readOnly: date,
        validator: (value) =>
            _field(key).required && (value == null || value.trim().isEmpty)
            ? 'هذا الحقل مطلوب'
            : null,
        onChanged: onChanged,
        onEditingComplete: number
            ? () => controller.text = _formatNumber(controller.text)
            : null,
      ),
    );
  }

  void _addRow({bool notify = true}) {
    if (notify) {
      setState(() => _rows.add(_FuelRowControllers()));
    } else {
      _rows.add(_FuelRowControllers());
    }
  }

  void _removeRow(int index) {
    if (_rows.length <= 1) return;
    final row = _rows.removeAt(index);
    row.dispose();
    setState(() {});
  }

  Future<void> _copyRows() async {
    final lines = _rows
        .map(
          (row) => [
            row.date.text,
            row.meter.text,
            row.liters.text,
            row.price.text,
            row.amount.text,
            row.collection.text,
            row.sales.text,
            row.route.text,
          ].join('\t'),
        )
        .join('\n');
    await Clipboard.setData(ClipboardData(text: lines));
    if (mounted) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('تم نسخ صفوف المحروقات')));
    }
  }

  Future<void> _pasteRows() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    final text = data?.text?.trim();
    if (text == null || text.isEmpty) return;
    for (final row in _rows) {
      row.dispose();
    }
    _rows.clear();
    for (final line in text.split('\n').take(50)) {
      final values = line.split('\t');
      final row = _FuelRowControllers();
      final target = [
        row.date,
        row.meter,
        row.liters,
        row.price,
        row.amount,
        row.collection,
        row.sales,
        row.route,
      ];
      for (var i = 0; i < target.length && i < values.length; i++) {
        target[i].text = values[i].trim();
      }
      _rows.add(row);
    }
    if (_rows.isEmpty) _rows.add(_FuelRowControllers());
    setState(() {});
  }

  Future<void> _pickAttachments() async {
    final result = await FilePicker.pickFiles(
      withData: false,
      allowMultiple: false,
      type: FileType.custom,
      allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png'],
    );
    final path = result?.files.single.path;
    if (path == null) return;
    final stored = await AttachmentManager.saveAttachment(File(path));
    if (mounted) setState(() => _attachmentPath = stored.path);
  }

  Future<void> _takePhoto() async {
    if (_busy) return;
    final image = await ImagePicker().pickImage(
      source: ImageSource.camera,
      imageQuality: 88,
      maxWidth: 1800,
    );
    if (image == null) return;
    setState(() => _busy = true);
    try {
      final stored = await AttachmentManager.saveAttachment(File(image.path));
      if (mounted) setState(() => _attachmentPath = stored.path);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _syncCollectorBeneficiary() {
    if (_beneficiary.text != _collector.text) {
      _beneficiary.text = _collector.text;
    }
  }

  void _recalculateAmount(_FuelRowControllers row) {
    if (row.amountManuallyEdited) return;
    final liters = NumberNormalizer.parseDouble(row.liters.text);
    final price = NumberNormalizer.parseDouble(row.price.text);
    if (liters == null || price == null) {
      row.amount.clear();
      return;
    }
    row.amount.text = _formatNumber((liters * price).toString());
  }

  Future<void> _openPositionEditor() async {
    final updated = await Navigator.of(context).push<AppSettings>(
      MaterialPageRoute<AppSettings>(
        builder: (_) => TemplatePreviewScreen(
          settings: _settings,
          templateScope: 'fuelRequest',
          fullPageForm: true,
          backgroundAsset: 'assets/images/forms/fuel_request-1.png',
          documentTitle: 'محرر نموذج المحروقات',
        ),
      ),
    );
    if (updated == null || !mounted) return;
    await SettingsStore.save(updated, scope: _scope);
    setState(() => _settings = updated);
  }

  Listenable _livePreviewListenable() {
    return Listenable.merge([
      _branch,
      _vehicleNumber,
      _collector,
      _fuelType,
      _periodFrom,
      _periodTo,
      _beneficiary,
      _branchAccountant,
      _branchManager,
      _administrationAccountant,
      _accountsManager,
      for (final row in _rows) ...[
        row.date,
        row.meter,
        row.liters,
        row.price,
        row.amount,
        row.collection,
        row.sales,
        row.route,
      ],
    ]);
  }

  bool _validateForOutput() {
    final formValid = _formKey.currentState?.validate() ?? false;
    final fuelTypeValid =
        !_field('fuelType').required || _fuelType.text.trim().isNotEmpty;
    if (!formValid || !fuelTypeValid) {
      if (_fuelTypeValidationFailed != !fuelTypeValid && mounted) {
        setState(() => _fuelTypeValidationFailed = !fuelTypeValid);
      }
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || !_formScrollController.hasClients) return;
        _formScrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOut,
        );
      });
      return false;
    }
    return true;
  }

  Future<void> _preview() async {
    if (!_validateForOutput()) return;
    final changes = _livePreviewListenable();
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => AnimatedBuilder(
          animation: changes,
          builder: (context, _) {
            // Re-collect on every keystroke so the preview is the exact PDF
            // output for the current values, geometry, and selected colors.
            final liveRequest = _collect();
            return Scaffold(
              appBar: AppBar(
                title: const Text('المعاينة الحية — نموذج المحروقات'),
                actions: [
                  IconButton(
                    tooltip: 'محرر النموذج',
                    onPressed: _openPositionEditor,
                    icon: const Icon(Icons.open_with_outlined),
                  ),
                ],
              ),
              body: PdfPreview(
                canChangePageFormat: false,
                canChangeOrientation: false,
                build: (_) => PdfService.buildRequestPdf(
                  liveRequest,
                  settings: _settings,
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Future<void> _output({required bool print}) async {
    if (!_validateForOutput()) return;
    setState(() => _busy = true);
    try {
      final bytes = await PdfService.buildRequestPdf(
        _collect(),
        settings: _settings,
      );
      if (print) {
        await ShareService.printPdf(
          bytes,
          filename: 'fuel_request.pdf',
          format: PdfPageFormat.a4.landscape,
        );
      } else {
        await ShareService.sharePdf(bytes: bytes, filename: 'fuel_request.pdf');
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openSettings() async {
    await Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) =>
            const SettingsScreen(templateKind: TemplateKind.fuelRequest),
      ),
    );
    final settings = await SettingsStore.load(scope: _scope);
    if (mounted) setState(() => _settings = settings);
  }

  ExpenseRequest _collect() => ExpenseRequest(
    date: _periodFrom.text.trim(),
    receiver: _collector.text.trim(),
    // حسابات قسم الحسابات تُترك فارغة للتعبئة اليدوية على النسخة المطبوعة.
    amountNumber: '',
    amountWords: '',
    reason: 'محروقات',
    statement: _periodTo.text.trim(),
    branch: _branch.text.trim(),
    account: '',
    requesterName: _collector.text.trim(),
    requesterSignature: '',
    directManagerName: _branchManager.text.trim(),
    directManagerSignature: '',
    approvedAuthorityName: _branchAccountant.text.trim(),
    approvedAuthoritySignature: '',
    accountsManagerName: _accountsManager.text.trim(),
    accountsManagerSignature: '',
    attachmentPath: _attachmentPath,
    documentType: ExpenseDocumentType.fuelRequest,
    settingsSnapshot: _settings.toMap(),
    fuelEntries: _rows
        .map(
          (row) => FuelEntry(
            date: row.date.text.trim(),
            meter: row.meter.text.trim(),
            liters: row.liters.text.trim(),
            literPrice: row.price.text.trim(),
            fuelAmount: row.amount.text.trim(),
            collection: row.collection.text.trim(),
            sales: row.sales.text.trim(),
            route: row.route.text.trim(),
          ),
        )
        .where(
          (row) =>
              row.date.isNotEmpty ||
              row.liters.isNotEmpty ||
              row.fuelAmount.isNotEmpty,
        )
        .toList(),
    customFields: {
      'fuelBranch': _branch.text.trim(),
      'vehicleNumber': _vehicleNumber.text.trim(),
      'collector': _collector.text.trim(),
      'fuelType': _fuelType.text.trim(),
      'periodFrom': _periodFrom.text.trim(),
      'periodTo': _periodTo.text.trim(),
      'beneficiary': _collector.text.trim(),
      'branchAccountant': _branchAccountant.text.trim(),
      'branchManager': _branchManager.text.trim(),
      'administrationAccountant': _administrationAccountant.text.trim(),
      'accountsManager': _accountsManager.text.trim(),
    },
  );

  Future<void> _save() async {
    if (!_validateForOutput()) return;
    setState(() => _busy = true);
    final request = _collect();
    final saved = widget.editingIndex == null
        ? await RequestStore.add(request)
        : await RequestStore.updateAt(widget.editingIndex!, request);
    if (!mounted) return;
    setState(() => _busy = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          saved ? 'تم حفظ نموذج المحروقات' : 'هذا النموذج محفوظ سابقًا',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('نموذج المحروقات'),
        actions: [
          IconButton(
            tooltip: 'إعدادات النموذج',
            onPressed: _openSettings,
            icon: const Icon(Icons.settings_outlined),
          ),
          IconButton(
            tooltip: 'محرر النموذج',
            onPressed: _busy ? null : _openPositionEditor,
            icon: const Icon(Icons.open_with_outlined),
          ),
          IconButton(
            tooltip: 'معاينة',
            onPressed: _busy ? null : _preview,
            icon: const Icon(Icons.preview_outlined),
          ),
          IconButton(
            tooltip: 'مشاركة PDF',
            onPressed: _busy ? null : () => _output(print: false),
            icon: const Icon(Icons.share_outlined),
          ),
          IconButton(
            tooltip: 'طباعة',
            onPressed: _busy ? null : () => _output(print: true),
            icon: const Icon(Icons.print_outlined),
          ),
          IconButton(
            tooltip: 'حفظ النموذج',
            onPressed: _busy ? null : _save,
            icon: const Icon(Icons.save_outlined),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          controller: _formScrollController,
          padding: const EdgeInsets.all(16),
          children: [
            _section('البيانات العامة', Icons.info_outline),
            _textField(
              'fuelBranch',
              'الفرع',
              _branch,
              suggestions: _optionsFor(
                'الفرع',
                fallback: _optionsFor('fuelBranch'),
              ),
              showDropdown: true,
            ),
            _textField(
              'vehicleNumber',
              'رقم السيارة',
              _vehicleNumber,
              showDropdown: true,
            ),
            _textField(
              'collector',
              'اسم المحصل / الموظف المستفيد',
              _collector,
              onChanged: (_) => _syncCollectorBeneficiary(),
              suggestions: _optionsFor(
                'مقدم الطلب',
                fallback: _optionsFor('المحصل'),
              ),
              showDropdown: true,
            ),
            const Padding(
              padding: EdgeInsets.only(bottom: 10),
              child: Text(
                'يُطبع الاسم نفسه في موضعي المحصل والموظف المستفيد، ويمكن ضبط كل موضع من محرر النموذج.',
              ),
            ),
            _fuelTypeSelector(),
            Row(
              children: [
                Expanded(
                  child: _textField(
                    'periodFrom',
                    'الفترة من تاريخ',
                    _periodFrom,
                    date: true,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: _textField(
                    'periodTo',
                    'إلى تاريخ',
                    _periodTo,
                    date: true,
                  ),
                ),
              ],
            ),
            _stakeholderField(
              'branchAccountant',
              'مختص حسابات الفرع',
              _branchAccountant,
              _optionsFor(
                'مختص حسابات الفرع',
                fallback: const ['مختص حسابات الفرع'],
              ),
            ),
            _stakeholderField(
              'branchManager',
              'مدير الفرع',
              _branchManager,
              const ['مدير الفرع'],
            ),
            _stakeholderField(
              'administrationAccountant',
              'محاسب الإدارة',
              _administrationAccountant,
              _optionsFor('محاسب الإدارة', fallback: const ['عبدالعزيز كباس']),
            ),
            _stakeholderField(
              'accountsManager',
              'مدير الحسابات',
              _accountsManager,
              _optionsFor('مدير الحسابات', fallback: const ['أ/ توفيق القاضي']),
            ),
            _section('بيانات تعبئة الوقود', Icons.local_gas_station_outlined),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _copyRows,
                    icon: const Icon(Icons.copy_outlined),
                    label: const Text('نسخ الصفوف'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _pasteRows,
                    icon: const Icon(Icons.content_paste_outlined),
                    label: const Text('لصق الصفوف'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            ..._rows.asMap().entries.map(
              (entry) => _rowCard(entry.key, entry.value),
            ),
            OutlinedButton.icon(
              onPressed: _addRow,
              icon: const Icon(Icons.add_circle_outline),
              label: const Text('إضافة صف جديد'),
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                leading: Icon(
                  _attachmentPath == null
                      ? Icons.attach_file
                      : Icons.attachment,
                ),
                title: Text(
                  _attachmentPath == null
                      ? 'لا يوجد مرفق'
                      : 'تم إرفاق ملف بهذا النموذج',
                ),
                trailing: _attachmentPath == null
                    ? null
                    : IconButton(
                        tooltip: 'حذف المرفق',
                        onPressed: () => setState(() => _attachmentPath = null),
                        icon: const Icon(Icons.delete_outline),
                      ),
              ),
            ),
            OutlinedButton.icon(
              onPressed: _busy ? null : _pickAttachments,
              icon: const Icon(Icons.attach_file),
              label: const Text('إضافة مرفق'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _busy ? null : _takePhoto,
              icon: const Icon(Icons.camera_alt_outlined),
              label: const Text('الكاميرا / التقاط صورة'),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: _busy ? null : _save,
              icon: const Icon(Icons.save),
              label: const Text('حفظ نموذج المحروقات'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _section(String title, IconData icon) => Padding(
    padding: const EdgeInsets.only(top: 12, bottom: 10),
    child: Row(
      children: [
        Icon(icon, color: Theme.of(context).colorScheme.primary),
        const SizedBox(width: 8),
        Text(
          title,
          style: Theme.of(
            context,
          ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
        ),
      ],
    ),
  );

  Widget _rowCard(int index, _FuelRowControllers row) => Card(
    margin: const EdgeInsets.only(bottom: 12),
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Text(
                'الصف ${index + 1}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              const Spacer(),
              IconButton(
                tooltip: 'حذف الصف',
                onPressed: _rows.length == 1 ? null : () => _removeRow(index),
                icon: const Icon(Icons.delete_outline),
              ),
            ],
          ),
          _textField(
            'fuelDate${index + 1}',
            'تاريخ تعبئة الوقود',
            row.date,
            date: true,
          ),
          Row(
            children: [
              Expanded(
                child: _textField(
                  'fuelMeter${index + 1}',
                  'رقم العداد',
                  row.meter,
                  number: true,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _textField(
                  'fuelLiters${index + 1}',
                  'عدد اللترات',
                  row.liters,
                  number: true,
                  onChanged: (_) => setState(() => _recalculateAmount(row)),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(
                child: _textField(
                  'fuelPrice${index + 1}',
                  'سعر اللتر',
                  row.price,
                  number: true,
                  onChanged: (_) => setState(() => _recalculateAmount(row)),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _textField(
                  'fuelAmount${index + 1}',
                  'مبلغ الوقود',
                  row.amount,
                  number: true,
                  onChanged: (_) => row.amountManuallyEdited = true,
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(
                child: _textField(
                  'fuelCollection${index + 1}',
                  'التحصيل',
                  row.collection,
                  number: true,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _textField(
                  'fuelSales${index + 1}',
                  'المبيعات',
                  row.sales,
                  number: true,
                ),
              ),
            ],
          ),
          _textField('fuelRoute${index + 1}', 'خط سير السيارة', row.route),
        ],
      ),
    ),
  );
}

class _FuelRowControllers {
  final date = TextEditingController();
  final meter = TextEditingController();
  final liters = TextEditingController();
  final price = TextEditingController();
  final amount = TextEditingController();
  bool amountManuallyEdited = false;
  final collection = TextEditingController();
  final sales = TextEditingController();
  final route = TextEditingController();

  void dispose() {
    for (final item in [
      date,
      meter,
      liters,
      price,
      amount,
      collection,
      sales,
      route,
    ]) {
      item.dispose();
    }
  }
}
