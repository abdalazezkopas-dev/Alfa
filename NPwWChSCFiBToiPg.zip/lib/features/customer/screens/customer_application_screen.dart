import '../../../core/utils/date_formatter.dart';
import '../../../core/utils/number_normalizer.dart';
import 'dart:async';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:printing/printing.dart';

import '../../../core/services/attachment_manager.dart';
import '../../../core/widgets/attachment_picker_field.dart';
import '../../expense_request/models/expense_request.dart';
import '../../expense_request/services/pdf_service.dart';
import '../../expense_request/services/request_store.dart';
import '../../expense_request/services/share_service.dart';
import '../../expense_request/services/quick_statement_store.dart';
import '../../settings/models/app_settings.dart';
import '../../settings/models/template_configuration.dart';
import '../../settings/services/settings_store.dart';
import '../../settings/screens/settings_screen.dart';
import '../../settings/screens/template_preview_screen.dart';

class CustomerApplicationScreen extends StatefulWidget {
  const CustomerApplicationScreen({
    super.key,
    this.initialRequest,
    this.editingIndex,
  });

  final ExpenseRequest? initialRequest;
  final int? editingIndex;

  @override
  State<CustomerApplicationScreen> createState() =>
      _CustomerApplicationScreenState();
}

class _CustomerApplicationScreenState extends State<CustomerApplicationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _formScrollController = ScrollController();
  final Map<String, TextEditingController> _controllers = {
    for (final key in const [
      'date',
      'exceptionType',
      'customer',
      'branch',
      'customerType',
      'customerTypeNew',
      'customerTypePrevious',
      'otherDetails',
      'previousPurchases',
      'previousPayments',
      'currentPurchases',
      'currentPayments',
      'bonusPercent',
      'statementOne',
      'statementTwo',
      'requester',
      'branchAccountant',
      'branchManager',
      'salesManager',
    ])
      key: TextEditingController(),
  };
  final Map<String, TextEditingController> _customControllers = {};
  AppSettings _settings = AppSettings.defaults();
  bool _busy = false;
  bool _exceptionTypeValidationFailed = false;
  List<String> _attachmentPaths = [];
  Timer? _deleteRepeatTimer;

  TextEditingController get _date => _controllers['date']!;
  String _formatDate(DateTime value) => DateFormatter.date(value);

  Future<void> _pickDate() async {
    final initialDate = DateFormatter.parse(_date.text) ?? DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked == null || !mounted) return;
    final formatted = _formatDate(picked);
    // Replace the existing value and reset the selection so the date can
    // never be appended beside the previous value.
    _date.value = TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    _date.text = _formatDate(DateTime.now());
    _load();
  }

  Future<void> _load() async {
    final settings = await SettingsStore.load(scope: 'customerApplication');
    _syncCustomControllers(settings);
    final request = widget.initialRequest;
    if (request != null) {
      for (final entry in request.customFields.entries) {
        final value =
            const {
              'previousPurchases',
              'previousPayments',
              'currentPurchases',
              'currentPayments',
            }.contains(entry.key)
            ? NumberNormalizer.formatGrouped(entry.value)
            : entry.value;
        _controllers[entry.key]?.text = value;
        _customControllers[entry.key]?.text = value;
      }
      final legacyCustomerType = _value('customerType');
      if (legacyCustomerType == 'جديد') {
        _controllers['customerTypeNew']!.text = 'جديد';
      } else if (legacyCustomerType == 'سابق') {
        _controllers['customerTypePrevious']!.text = 'سابق';
      }
      _date.text = DateFormatter.parse(request.date) == null
          ? request.date
          : DateFormatter.date(DateFormatter.parse(request.date)!);
      _controllers['requester']!.text = request.requesterName;
      _attachmentPaths = request.allAttachmentPaths;
    }
    if (mounted) setState(() => _settings = settings);
  }

  Future<void> _openSettings() async {
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => const SettingsScreen(
          templateKind: TemplateKind.customerApplication,
        ),
      ),
    );
    if (!mounted) return;
    final settings = await SettingsStore.load(scope: 'customerApplication');
    _syncCustomControllers(settings);
    setState(() => _settings = settings);
  }

  @override
  void dispose() {
    _formScrollController.dispose();
    _deleteRepeatTimer?.cancel();
    for (final controller in _controllers.values) {
      controller.dispose();
    }
    for (final controller in _customControllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  void _syncCustomControllers(AppSettings settings) {
    final keys = settings.customerFieldSettings.keys
        .where((key) => key.startsWith('custom_'))
        .toSet();
    for (final key in keys) {
      _customControllers.putIfAbsent(key, TextEditingController.new);
    }
    for (final key
        in _customControllers.keys
            .where((key) => !keys.contains(key))
            .toList()) {
      _customControllers.remove(key)?.dispose();
    }
  }

  String _label(String key, String fallback) =>
      _settings.customerFieldSettings[key]?.label ?? fallback;
  String _value(String key) => _controllers[key]!.text.trim();

  bool _isRequired(String key) {
    final settingKey = switch (key) {
      'requester' => 'requesterName',
      'branchManager' => 'directManagerName',
      'salesManager' => 'accountsManagerName',
      'branchAccountant' => 'approvedAuthorityName',
      _ => key,
    };
    return _settings.customerFieldSettings[settingKey]?.required ?? false;
  }

  bool _validateForOutput() {
    final formValid = _formKey.currentState?.validate() ?? false;
    var valid = formValid;
    final exceptionTypeValid =
        !_isRequired('exceptionType') || _value('exceptionType').isNotEmpty;
    if (!exceptionTypeValid) {
      _exceptionTypeValidationFailed = true;
      valid = false;
    } else if (_exceptionTypeValidationFailed) {
      _exceptionTypeValidationFailed = false;
    }
    final dateText = _value('date');
    final parsedDate = DateFormatter.parse(dateText);
    final dateSetting = _settings.customerFieldSettings['date'];
    final dateValid =
        !(dateSetting?.visible ?? true) ||
        dateText.isEmpty ||
        (parsedDate != null && _formatDate(parsedDate) == dateText);
    if (!dateValid) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('أدخل تاريخاً صحيحاً قبل المتابعة')),
      );
      valid = false;
    }
    if (!valid) {
      if (mounted) setState(() {});
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted || !_formScrollController.hasClients) return;
        _formScrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOut,
        );
      });
    }
    return valid;
  }

  ExpenseRequest _collect() {
    final custom = <String, String>{
      for (final entry in _controllers.entries)
        entry.key: entry.value.text.trim(),
      for (final entry in _customControllers.entries)
        entry.key: entry.value.text.trim(),
    };
    return ExpenseRequest(
      date: _value('date'),
      receiver: '',
      amountNumber: '',
      amountWords: '',
      reason: '',
      statement: '${_value('statementOne')}\n${_value('statementTwo')}'.trim(),
      branch: _value('branch'),
      account: '',
      requesterName: _value('requester'),
      requesterSignature: '',
      directManagerName: _value('branchManager'),
      directManagerSignature: '',
      approvedAuthorityName: _value('salesManager'),
      approvedAuthoritySignature: '',
      accountsManagerName: _value('branchAccountant'),
      accountsManagerSignature: '',
      customFields: custom,
      documentType: ExpenseDocumentType.customerApplication,
      settingsSnapshot: _settings.toMap(),
      attachmentPath: _attachmentPaths.isEmpty ? null : _attachmentPaths.first,
      attachmentPaths: _attachmentPaths,
    );
  }

  Future<void> _removeAttachment(String path) async {
    final requests = await RequestStore.load();
    await AttachmentManager.deleteAttachment(path, activeRequests: requests);
  }

  Future<void> _save() async {
    if (!_validateForOutput()) return;
    final request = _collect();
    await _rememberStakeholderValues();
    bool saved;
    if (widget.editingIndex == null) {
      saved = await RequestStore.add(request);
    } else {
      saved = await RequestStore.updateAt(widget.editingIndex!, request);
    }
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            !saved
                ? 'لم يتم الحفظ: هذا النموذج مطابق لنموذج محفوظ سابقًا'
                : widget.editingIndex == null
                ? 'تم حفظ نموذج العملاء'
                : 'تم تحديث نموذج العملاء',
          ),
        ),
      );
    }
  }

  Future<void> _rememberStakeholderValues() async {
    final grouped = <String, List<String>>{
      for (final entry in _settings.stakeholderOptions.entries)
        entry.key: [...entry.value],
    };
    var changed = false;
    for (final key in const ['customer', 'branch']) {
      final value = _value(key);
      if (value.isEmpty) continue;
      final group = _stakeholderGroup(key);
      final options = grouped.putIfAbsent(group, () => <String>[]);
      if (!options.contains(value)) {
        options.add(value);
        changed = true;
      }
    }
    if (!changed) return;
    final updated = _settings.copyWith(
      stakeholderOptions: grouped,
      receiverOptions: grouped['المقدم إليه'] ?? const [],
      requesterHistory: grouped['مقدم الطلب'] ?? const [],
    );
    await SettingsStore.save(updated, scope: 'customerApplication');
    if (mounted) setState(() => _settings = updated);
  }

  void _clearForm() {
    for (final controller in _controllers.values) {
      controller.clear();
    }
    for (final controller in _customControllers.values) {
      controller.clear();
    }
    _date.text = _formatDate(DateTime.now());
    _attachmentPaths = [];
    setState(() {});
  }

  Future<void> _openPositionEditor() async {
    final updated = await Navigator.of(context).push<AppSettings>(
      MaterialPageRoute<AppSettings>(
        builder: (_) => TemplatePreviewScreen(
          settings: _settings,
          templateScope: 'customerApplication',
          editCustomer: true,
          documentTitle: 'نموذج العملاء',
        ),
      ),
    );
    if (updated == null || !mounted) return;
    await SettingsStore.save(updated, scope: 'customerApplication');
    setState(() => _settings = updated);
  }

  Future<void> _preview() async {
    if (!_validateForOutput()) return;
    final request = _collect();
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => Scaffold(
          appBar: AppBar(
            title: const Text('معاينة نموذج العملاء'),
            actions: [
              IconButton(
                tooltip: 'ضبط مواضع الحقول',
                onPressed: _openPositionEditor,
                icon: const Icon(Icons.open_with_outlined),
              ),
            ],
          ),
          body: PdfPreview(
            canChangePageFormat: false,
            canChangeOrientation: false,
            build: (_) =>
                PdfService.buildRequestPdf(request, settings: _settings),
          ),
        ),
      ),
    );
  }

  Future<void> _output({required bool print}) async {
    if (!_validateForOutput()) return;
    setState(() => _busy = true);
    try {
      final bytes = await PdfService.buildRequestPdf(
        _collect(),
        settings: _settings,
      );
      if (print) {
        await ShareService.printPdf(
          bytes,
          filename: 'customer_application.pdf',
        );
      } else {
        await ShareService.sharePdf(
          bytes: bytes,
          filename: 'customer_application.pdf',
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _savePdf() async {
    if (!_validateForOutput()) return;
    setState(() => _busy = true);
    try {
      final bytes = await PdfService.buildRequestPdf(
        _collect(),
        settings: _settings,
      );
      await FilePicker.saveFile(
        dialogTitle: 'حفظ نموذج العملاء PDF',
        fileName: 'customer_application.pdf',
        type: FileType.custom,
        allowedExtensions: ['pdf'],
        bytes: bytes,
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  InputDecoration _decoration(String key, String fallback) =>
      InputDecoration(labelText: _label(key, fallback));

  FieldInputType _inputType(String key) {
    final configured = _settings.customerFieldSettings[key]?.inputType;
    if (configured != null && configured != FieldInputType.text) {
      return configured;
    }
    if (key == 'date') return FieldInputType.date;
    if (const {
      'previousPurchases',
      'previousPayments',
      'currentPurchases',
      'currentPayments',
      'bonusPercent',
    }.contains(key)) {
      return FieldInputType.amount;
    }
    if (const {
      'customer',
      'branch',
      'requester',
      'branchAccountant',
      'branchManager',
      'salesManager',
    }.contains(key)) {
      return FieldInputType.stakeholder;
    }
    return FieldInputType.text;
  }

  String _stakeholderGroup(String key) => switch (key) {
    'receiver' => 'المقدم إليه',
    'customer' => 'العملاء',
    'branch' => 'الفرع',
    'requester' => 'مقدم الطلب',
    'branchAccountant' => 'محاسب الفرع',
    'branchManager' => 'المدير المباشر',
    'salesManager' => 'مدير المبيعات',
    _ => 'مقدم الطلب',
  };

  Future<void> _addStakeholder(String key) async {
    final controller = TextEditingController();
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('إضافة مقترح جديد'),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: const InputDecoration(labelText: 'اسم الجهة أو الشخص'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, controller.text),
            child: const Text('إضافة'),
          ),
        ],
      ),
    );
    controller.dispose();
    final clean = value?.trim() ?? '';
    if (clean.isEmpty || !mounted) return;
    final group = _stakeholderGroup(key);
    final grouped = <String, List<String>>{
      for (final entry in _settings.stakeholderOptions.entries)
        entry.key: [...entry.value],
    };
    final options = grouped[group] ?? <String>[];
    if (!options.contains(clean)) options.add(clean);
    grouped[group] = options;
    final updated = _settings.copyWith(
      stakeholderOptions: grouped,
      receiverOptions: grouped['المقدم إليه'] ?? const [],
      requesterHistory: grouped['مقدم الطلب'] ?? const [],
    );
    await SettingsStore.save(updated, scope: 'customerApplication');
    setState(() {
      _settings = updated;
      _controllers[key]!.text = clean;
    });
  }

  Widget _stakeholderText(String key, String fallback, {bool? required}) {
    final requiredField = required ?? _isRequired(key);
    final group = _stakeholderGroup(key);
    final options = _settings.stakeholderOptions[group] ?? const <String>[];
    final controller = _controllers[key] ?? _customControllers[key]!;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: controller,
        maxLength: _settings.customerFieldSettings[key]?.maxLength,
        buildCounter:
            (
              context, {
              required currentLength,
              maxLength,
              required isFocused,
            }) => maxLength == null
            ? null
            : Text(
                '$currentLength/$maxLength',
                style: const TextStyle(fontSize: 10),
              ),
        decoration: _decoration(key, fallback).copyWith(
          hintText: key == 'branchAccountant' ? 'مثال: عارف الهبل' : null,
          suffixIcon: PopupMenuButton<String>(
            tooltip: 'فتح المحفوظات',
            icon: const Icon(Icons.arrow_drop_down),
            onSelected: (value) {
              if (value == '__add__') {
                _addStakeholder(key);
              } else {
                setState(() => controller.text = value);
              }
            },
            itemBuilder: (context) => [
              ...options.map(
                (item) => PopupMenuItem(value: item, child: Text(item)),
              ),
              const PopupMenuDivider(),
              const PopupMenuItem(
                value: '__add__',
                child: Text('إضافة مقترح جديد'),
              ),
            ],
          ),
        ),
        validator: requiredField
            ? (value) => value == null || value.trim().isEmpty
                  ? 'هذا الحقل مطلوب'
                  : null
            : null,
      ),
    );
  }

  Widget _text(
    String key,
    String fallback, {
    int minLines = 1,
    bool? required,
  }) {
    final requiredField = required ?? _isRequired(key);
    final type = _inputType(key);
    if (type == FieldInputType.stakeholder) {
      return _stakeholderText(key, fallback, required: requiredField);
    }
    final setting = _settings.customerFieldSettings[key];
    final amount = type == FieldInputType.amount;
    final date = type == FieldInputType.date;
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: _controllers[key] ?? _customControllers[key],
        readOnly: date,
        textDirection: date ? TextDirection.ltr : null,
        textAlign: date ? TextAlign.left : TextAlign.start,
        onTap: date ? _pickDate : null,
        keyboardType: amount
            ? const TextInputType.numberWithOptions(decimal: true)
            : null,
        inputFormatters: amount && key != 'bonusPercent'
            ? [ThousandsSeparatorInputFormatter()]
            : null,
        maxLength: setting?.maxLength,
        buildCounter:
            (
              context, {
              required currentLength,
              maxLength,
              required isFocused,
            }) => maxLength == null
            ? null
            : Text(
                '$currentLength/$maxLength',
                style: const TextStyle(fontSize: 10),
              ),
        minLines: minLines,
        maxLines: minLines > 1 ? 8 : 1,
        decoration: date
            ? _decoration(
                key,
                fallback,
              ).copyWith(suffixIcon: const Icon(Icons.calendar_month_outlined))
            : _decoration(
                key,
                fallback,
              ).copyWith(suffixText: key == 'bonusPercent' ? '%' : null),
        validator: requiredField
            ? (value) => value == null || value.trim().isEmpty
                  ? 'هذا الحقل مطلوب'
                  : null
            : null,
      ),
    );
  }

  Future<void> _pasteStatement(String key) async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (data?.text == null) return;
    setState(() => _controllers[key]!.text = data!.text!);
  }

  Future<void> _insertStatementDate(String key) async {
    final selected = await showDatePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
      initialDate: DateTime.now(),
    );
    if (selected == null || !mounted) return;
    final date = DateFormatter.date(selected);
    final controller = _controllers[key]!;
    final value = controller.value;
    final selection = value.selection;
    final start = selection.isValid ? selection.start : value.text.length;
    final end = selection.isValid ? selection.end : value.text.length;
    final safeStart = start.clamp(0, value.text.length).toInt();
    final safeEnd = end.clamp(safeStart, value.text.length).toInt();
    controller.value = value.copyWith(
      text: value.text.replaceRange(safeStart, safeEnd, date),
      selection: TextSelection.collapsed(offset: safeStart + date.length),
    );
    setState(() {});
  }

  void _deleteStatement(String key, {required bool forward}) {
    final controller = _controllers[key]!;
    final value = controller.value;
    if (!value.selection.isValid) return;
    if (!value.selection.isCollapsed) {
      final start = value.selection.start;
      final end = value.selection.end;
      controller.value = value.copyWith(
        text: value.text.replaceRange(start, end, ''),
        selection: TextSelection.collapsed(offset: start),
      );
    } else {
      final offset = value.selection.start;
      final start = forward ? offset : offset - 1;
      final end = forward ? offset + 1 : offset;
      if (start < 0 || end > value.text.length) return;
      controller.value = value.copyWith(
        text: value.text.replaceRange(start, end, ''),
        selection: TextSelection.collapsed(offset: start),
      );
    }
    setState(() {});
  }

  void _startDeleteRepeat(String key, {required bool forward}) {
    _deleteRepeatTimer?.cancel();
    _deleteStatement(key, forward: forward);
    Future<void>.delayed(const Duration(milliseconds: 280), () {
      if (!mounted) return;
      _deleteRepeatTimer = Timer.periodic(const Duration(milliseconds: 75), (
        _,
      ) {
        _deleteStatement(key, forward: forward);
      });
    });
  }

  void _stopDeleteRepeat() {
    _deleteRepeatTimer?.cancel();
    _deleteRepeatTimer = null;
  }

  Future<void> _insertQuickStatement(String key) async {
    final controller = _controllers[key]!;
    final selected = await showQuickStatementPicker(
      context,
      scope: 'customerApplication',
      query: controller.text,
    );
    if (selected == null || !mounted) return;
    final value = controller.value;
    final selection = value.selection;
    final start = selection.isValid ? selection.start : value.text.length;
    final end = selection.isValid ? selection.end : value.text.length;
    final safeStart = start.clamp(0, value.text.length).toInt();
    final safeEnd = end.clamp(safeStart, value.text.length).toInt();
    controller.value = value.copyWith(
      text: value.text.replaceRange(safeStart, safeEnd, selected),
      selection: TextSelection.collapsed(offset: safeStart + selected.length),
    );
    setState(() {});
  }

  Widget _statementText(
    String key,
    String fallback, {
    int minLines = 3,
    bool? required,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Wrap(
          alignment: WrapAlignment.end,
          children: [
            IconButton(
              tooltip: 'عبارات سريعة',
              visualDensity: VisualDensity.compact,
              onPressed: () => _insertQuickStatement(key),
              icon: const Icon(Icons.bolt_outlined),
            ),
            IconButton(
              tooltip: 'إدراج تاريخ في موضع المؤشر',
              visualDensity: VisualDensity.compact,
              onPressed: () => _insertStatementDate(key),
              icon: const Icon(Icons.calendar_month_outlined),
            ),
            IconButton(
              tooltip: 'نسخ البيان',
              visualDensity: VisualDensity.compact,
              onPressed: () => Clipboard.setData(
                ClipboardData(text: _controllers[key]!.text),
              ),
              icon: const Icon(Icons.copy_outlined),
            ),
            IconButton(
              tooltip: 'لصق البيان',
              visualDensity: VisualDensity.compact,
              onPressed: () => _pasteStatement(key),
              icon: const Icon(Icons.content_paste_outlined),
            ),
            GestureDetector(
              onLongPressStart: (_) => _startDeleteRepeat(key, forward: false),
              onLongPressEnd: (_) => _stopDeleteRepeat(),
              onLongPressCancel: _stopDeleteRepeat,
              child: IconButton(
                tooltip: 'حذف للخلف',
                visualDensity: VisualDensity.compact,
                onPressed: () => _deleteStatement(key, forward: false),
                icon: const Icon(Icons.backspace_outlined),
              ),
            ),
            GestureDetector(
              onLongPressStart: (_) => _startDeleteRepeat(key, forward: true),
              onLongPressEnd: (_) => _stopDeleteRepeat(),
              onLongPressCancel: _stopDeleteRepeat,
              child: IconButton(
                tooltip: 'حذف للأمام',
                visualDensity: VisualDensity.compact,
                onPressed: () => _deleteStatement(key, forward: true),
                icon: const Icon(Icons.delete_sweep_outlined),
              ),
            ),
            IconButton(
              tooltip: 'مسح البيان',
              visualDensity: VisualDensity.compact,
              onPressed: () => setState(() => _controllers[key]!.clear()),
              icon: const Icon(Icons.delete_outline),
            ),
          ],
        ),
        _text(key, fallback, minLines: minLines, required: required),
      ],
    );
  }

  Widget _exceptionTypeSelector() {
    const options = [
      'بونص إضافي',
      'تعويض عميل',
      'عرض سداد',
      'خصم نقدي',
      'أخرى',
    ];
    final selected = _value('exceptionType');
    return InputDecorator(
      decoration: _decoration('exceptionType', 'نوع الطلب الاستثنائي').copyWith(
        errorText: _exceptionTypeValidationFailed ? 'هذا الحقل مطلوب' : null,
      ),
      child: Wrap(
        alignment: WrapAlignment.center,
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final option in options)
            ChoiceChip(
              label: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (selected == option) ...[
                    const Icon(Icons.check, size: 26, color: Colors.white),
                    const SizedBox(width: 4),
                  ],
                  Text(option, textAlign: TextAlign.center),
                ],
              ),
              selected: selected == option,
              showCheckmark: false,
              selectedColor: Theme.of(context).colorScheme.primary,
              labelStyle: TextStyle(
                color: selected == option
                    ? Colors.white
                    : Theme.of(context).textTheme.bodyMedium?.color,
                fontWeight: selected == option
                    ? FontWeight.bold
                    : FontWeight.normal,
              ),
              onSelected: (_) => setState(() {
                _controllers['exceptionType']!.text = option;
                _exceptionTypeValidationFailed = false;
              }),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.editingIndex == null
              ? 'نموذج تقديم خاص للمبيعات'
              : 'تعديل نموذج تقديم خاص للمبيعات',
        ),
        actions: [
          IconButton(
            tooltip: 'إعدادات نموذج المبيعات',
            onPressed: _busy ? null : _openSettings,
            icon: const Icon(Icons.settings_outlined),
          ),
          IconButton(
            tooltip: 'معاينة',
            onPressed: _busy ? null : _preview,
            icon: const Icon(Icons.preview_outlined),
          ),
          IconButton(
            tooltip: 'مشاركة PDF',
            onPressed: _busy ? null : () => _output(print: false),
            icon: const Icon(Icons.share_outlined),
          ),
          IconButton(
            tooltip: 'طباعة',
            onPressed: _busy ? null : () => _output(print: true),
            icon: const Icon(Icons.print_outlined),
          ),
          IconButton(
            tooltip: 'حفظ PDF',
            onPressed: _busy ? null : _savePdf,
            icon: const Icon(Icons.save_alt_outlined),
          ),
          IconButton(
            tooltip: 'ضبط مواضع الحقول',
            onPressed: _busy ? null : _openPositionEditor,
            icon: const Icon(Icons.open_with_outlined),
          ),
          IconButton(
            tooltip: 'تفريغ النموذج',
            onPressed: _busy ? null : _clearForm,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      body: Form(
        key: _formKey,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 900),
            child: ListView(
              controller: _formScrollController,
              padding: EdgeInsets.fromLTRB(
                16,
                16,
                16,
                32 + MediaQuery.of(context).padding.bottom + 72,
              ),
              children: [
                Text(
                  'بيانات نموذج المبيعات والعملاء',
                  style: Theme.of(
                    context,
                  ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 16),
                _text('date', 'التاريخ', required: _isRequired('date')),
                _exceptionTypeSelector(),
                if (_value('exceptionType') == 'أخرى')
                  _text(
                    'otherDetails',
                    'تفاصيل أخرى',
                    required: _isRequired('otherDetails'),
                  ),
                _text('customer', 'العميل', required: _isRequired('customer')),
                _text('branch', 'الفرع', required: _isRequired('branch')),
                InputDecorator(
                  decoration: _decoration('customerType', 'نوع العميل'),
                  child: Row(
                    children: [
                      for (final item in const [
                        ('جديد', 'customerTypeNew'),
                        ('سابق', 'customerTypePrevious'),
                      ])
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 4),
                            child: InkWell(
                              borderRadius: BorderRadius.circular(12),
                              onTap: () => setState(() {
                                _controllers['customerType']!.text = item.$1;
                                _controllers['customerTypeNew']!.text =
                                    item.$1 == 'جديد' ? 'جديد' : '';
                                _controllers['customerTypePrevious']!.text =
                                    item.$1 == 'سابق' ? 'سابق' : '';
                              }),
                              child: Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 12,
                                  vertical: 6,
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: _value('customerType') == item.$1
                                        ? Theme.of(context).colorScheme.primary
                                        : Theme.of(context).dividerColor,
                                    width: _value('customerType') == item.$1
                                        ? 2.5
                                        : 1,
                                  ),
                                  color: _value('customerType') == item.$1
                                      ? Theme.of(
                                          context,
                                        ).colorScheme.primaryContainer
                                      : Colors.transparent,
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    if (_value('customerType') == item.$1)
                                      Icon(
                                        Icons.check,
                                        size: 26,
                                        color: Theme.of(
                                          context,
                                        ).colorScheme.primary,
                                      ),
                                    if (_value('customerType') == item.$1)
                                      const SizedBox(width: 5),
                                    Text(item.$1),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                _text('previousPurchases', 'سحبيات العام السابق'),
                _text('previousPayments', 'مدفوعات العام السابق'),
                _text('currentPurchases', 'سحبيات العام الحالي'),
                _text('currentPayments', 'مدفوعات العام الحالي'),
                _text('bonusPercent', 'نسبة بونص العميل المعتمدة'),
                _statementText(
                  'statementOne',
                  'البيان الأول — ولكون العميل...',
                  minLines: 3,
                  required: _isRequired('statementOne'),
                ),
                _statementText(
                  'statementTwo',
                  'البيان الثاني — وعليه نرجو منكم...',
                  minLines: 3,
                ),
                _text(
                  'requester',
                  'مقدم الطلب',
                  required: _isRequired('requester'),
                ),
                _text('branchAccountant', 'محاسب الفرع'),
                _text('branchManager', 'مدير الفرع'),
                _text('salesManager', 'مدير المبيعات'),
                ..._buildCustomFields(),
                AttachmentPickerField(
                  paths: _attachmentPaths,
                  onChanged: (paths) =>
                      setState(() => _attachmentPaths = paths),
                  onRemove: _removeAttachment,
                ),
                const SizedBox(height: 8),
                FilledButton.icon(
                  onPressed: _busy ? null : _save,
                  icon: const Icon(Icons.save_outlined),
                  label: const Text('حفظ نموذج العملاء'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildCustomFields() {
    return _settings.customerFieldSettings.entries
        .where((entry) => entry.key.startsWith('custom_'))
        .where((entry) => entry.value.visible)
        .map(
          (entry) => _text(
            entry.key,
            entry.value.label,
            required: entry.value.required,
          ),
        )
        .toList();
  }
}
