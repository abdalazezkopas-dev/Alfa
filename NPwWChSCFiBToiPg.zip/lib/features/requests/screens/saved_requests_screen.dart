import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';

import '../../expense_request/screens/expense_request_screen.dart';
import '../../fuel/screens/fuel_request_screen.dart';
import '../../sample_request/screens/sample_request_single_page_screen.dart';
import '../../sample_request/screens/sample_request_three_page_screen.dart';
import '../../memos/screens/internal_memo_screen.dart';
import '../../expense_request/models/expense_request.dart';
import '../../settings/models/template_configuration.dart';
import '../../expense_request/services/pdf_service.dart';
import '../../expense_request/services/request_store.dart';
import '../../expense_request/services/share_service.dart';
import '../../settings/models/app_settings.dart';
import '../../settings/screens/template_catalog_screen.dart';
import '../../settings/screens/settings_screen.dart';
import '../../settings/screens/template_preview_screen.dart';
import '../../settings/services/settings_store.dart';
import '../../customer/screens/customer_application_screen.dart';
import '../../travel_allowance/models/travel_allowance_request.dart';
import '../../travel_allowance/screens/travel_allowance_request_screen.dart';
import '../../travel_allowance/services/travel_allowance_pdf_service.dart';
import '../../travel_allowance/services/travel_allowance_store.dart';

class SavedRequestsScreen extends StatefulWidget {
  const SavedRequestsScreen({
    this.expenseRequestsLoader,
    this.travelAllowanceLoader,
    this.travelAllowanceDeleteAt,
    super.key,
  });

  final Future<List<ExpenseRequest>> Function()? expenseRequestsLoader;
  final Future<List<TravelAllowanceRequest>> Function()? travelAllowanceLoader;
  final Future<void> Function(int index)? travelAllowanceDeleteAt;

  @override
  State<SavedRequestsScreen> createState() => _SavedRequestsScreenState();
}

class _SavedRequestsScreenState extends State<SavedRequestsScreen> {
  final _searchController = TextEditingController();
  List<ExpenseRequest> _requests = [];
  List<TravelAllowanceRequest> _travelRequests = [];
  bool _isLoading = true;
  bool _isActionLoading = false;
  Object? _loadError;
  bool _onlyFavorites = false;
  int _recordFilter = 0; // 0: all, 1: expense, 2: memo, 3: customer
  final Set<String> _selectedKeys = <String>{};

  @override
  void initState() {
    super.initState();
    _loadRequests();
    _searchController.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _loadRequests() async {
    if (mounted) {
      setState(() {
        _isLoading = true;
        _loadError = null;
      });
    }
    try {
      final results = await Future.wait<Object>([
        widget.expenseRequestsLoader == null
            ? RequestStore.load()
            : widget.expenseRequestsLoader!(),
        widget.travelAllowanceLoader == null
            ? TravelAllowanceStore.load()
            : widget.travelAllowanceLoader!(),
      ]);
      if (!mounted) return;
      setState(() {
        _requests = results[0] as List<ExpenseRequest>;
        _travelRequests = results[1] as List<TravelAllowanceRequest>;
        _isLoading = false;
        _loadError = null;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _loadError = error;
      });
    }
  }

  String _normalizeSearch(String value) {
    return value
        .toLowerCase()
        .replaceAll(RegExp(r'[\s,،٬]'), '')
        .replaceAll('٫', '.');
  }

  String _requestSearchText(ExpenseRequest request) {
    final values = <String>[
      request.date,
      request.receiver,
      request.amountNumber,
      request.amountWords,
      request.statement,
      request.requesterName,
      request.directManagerName,
      request.approvedAuthorityName,
      request.accountsManagerName,
      ...request.customFields.entries.expand(
        (entry) => [entry.key, entry.value],
      ),
      ...request.sampleItems.expand(
        (item) => [
          item.productName,
          item.pharmaceuticalForm,
          item.quantityNumber,
          item.quantityWords,
          item.notes,
        ],
      ),
    ];
    if (request.secondRequest != null) {
      values.add(_requestSearchText(request.secondRequest!));
    }
    return _normalizeSearch(values.join(' '));
  }

  String _travelSearchText(TravelAllowanceRequest request) => _normalizeSearch(
    [
      request.branch,
      request.month,
      request.year,
      request.beneficiary,
      request.branchManager,
      request.departmentManager,
      request.administrationAccountant,
      request.accountsManager,
      ...request.rows.expand(
        (row) => [
          row.day,
          row.date,
          row.dailyAmount,
          row.region,
          row.statement,
        ],
      ),
    ].join(' '),
  );

  String _selectionKey(ExpenseRequest request) =>
      '${request.documentType.name}|${request.date}|${request.receiver}|${request.requesterName}|${request.statement.hashCode}';

  int _expenseIndex(ExpenseRequest request) {
    for (var index = 0; index < _requests.length; index++) {
      if (identical(_requests[index], request)) return index;
    }
    return _requests.indexOf(request);
  }

  void _toggleSelection(ExpenseRequest request, bool selected) {
    final key = _selectionKey(request);
    setState(() {
      if (selected) {
        _selectedKeys.add(key);
      } else {
        _selectedKeys.remove(key);
      }
    });
  }

  Future<void> _bulkExport({required bool print}) async {
    final selected = _requests
        .where((request) => _selectedKeys.contains(_selectionKey(request)))
        .toList();
    if (selected.isEmpty) return;
    var succeeded = true;
    for (final request in selected) {
      succeeded = await _exportPdf(request, print: print) && succeeded;
    }
    if (succeeded && mounted) setState(() => _selectedKeys.clear());
  }

  List<ExpenseRequest> get _filteredRequests {
    final query = _normalizeSearch(_searchController.text.trim());
    return _requests.where((request) {
      final matchesFavorite = !_onlyFavorites || request.isFavorite;
      final matchesType =
          _recordFilter == 0 ||
          (_recordFilter == 1 &&
              request.documentType == ExpenseDocumentType.expenseRequest) ||
          (_recordFilter == 2 &&
              request.documentType == ExpenseDocumentType.internalMemo) ||
          (_recordFilter == 3 &&
              request.documentType ==
                  ExpenseDocumentType.customerApplication) ||
          (_recordFilter == 4 &&
              request.documentType == ExpenseDocumentType.clearanceRequest) ||
          (_recordFilter == 5 &&
              request.documentType == ExpenseDocumentType.serviceRequest) ||
          (_recordFilter == 6 &&
              request.documentType == ExpenseDocumentType.fuelRequest) ||
          (_recordFilter == 7 &&
              request.documentType == ExpenseDocumentType.sampleRequest);
      final matchesQuery =
          query.isEmpty || _requestSearchText(request).contains(query);
      return matchesFavorite && matchesType && matchesQuery;
    }).toList();
  }

  List<TravelAllowanceRequest> get _filteredTravelRequests {
    final query = _normalizeSearch(_searchController.text.trim());
    if (_recordFilter != 0 && _recordFilter != 8) return const [];
    return _travelRequests
        .where(
          (request) =>
              query.isEmpty || _travelSearchText(request).contains(query),
        )
        .toList();
  }

  Future<void> _toggleFavorite(ExpenseRequest request) async {
    final index = _expenseIndex(request);
    if (index < 0) return;
    await RequestStore.updateAt(
      index,
      ExpenseRequest.fromMap({
        ...request.toMap(),
        'isFavorite': !request.isFavorite,
      }),
    );
    await _loadRequests();
  }

  String _pdfFilename(ExpenseRequest request) {
    final prefix = switch (request.documentType) {
      ExpenseDocumentType.clearanceRequest => 'clearance_request',
      ExpenseDocumentType.serviceRequest => 'service_request',
      ExpenseDocumentType.fuelRequest => 'fuel_request',
      ExpenseDocumentType.customerApplication => 'customer_application',
      ExpenseDocumentType.internalMemo => 'internal_memo',
      ExpenseDocumentType.expenseRequest => 'expense_request',
      ExpenseDocumentType.sampleRequest => 'sample_request',
    };
    return '${prefix}_${request.date.replaceAll('/', '-')}.pdf';
  }

  bool _isSinglePageSampleRequest(ExpenseRequest request) =>
      request.customFields['sampleTemplate'] == 'singlePage';

  Future<bool> _exportPdf(ExpenseRequest request, {required bool print}) async {
    var stage = 'بدء العملية';
    if (_isActionLoading) return false;
    setState(() => _isActionLoading = true);
    try {
      stage = 'تحميل الإعدادات';
      final settings = request.settingsSnapshot.isEmpty
          ? await SettingsStore.load(
              scope:
                  request.documentType == ExpenseDocumentType.sampleRequest &&
                      request.customFields['sampleTemplate'] == 'singlePage'
                  ? 'sampleRequestSinglePage'
                  : request.documentType == ExpenseDocumentType.sampleRequest
                  ? 'sampleRequest'
                  : 'global',
            )
          : AppSettings.fromMap(request.settingsSnapshot);
      stage = 'إنشاء ملف PDF';
      final bytes = await PdfService.buildRequestPdf(
        request,
        settings: settings,
      );
      if (bytes.isEmpty) {
        throw StateError('تم إنشاء ملف PDF فارغ');
      }
      final filename = _pdfFilename(request);
      stage = print ? 'فتح نافذة الطباعة' : 'فتح نافذة المشاركة';
      if (print) {
        await ShareService.printPdf(
          bytes,
          filename: filename,
          format: request.documentType == ExpenseDocumentType.fuelRequest
              ? PdfPageFormat.a4.landscape
              : request.documentType == ExpenseDocumentType.sampleRequest
              ? PdfPageFormat.letter
              : PdfPageFormat.a4,
        );
      } else {
        final isSample =
            request.documentType == ExpenseDocumentType.sampleRequest;
        await ShareService.sharePdf(
          bytes: bytes,
          filename: filename,
          subject: isSample ? 'طلب عينات' : 'طلب صرف',
          body: isSample
              ? 'مرفق نموذج طلب العينات بصيغة PDF'
              : 'مرفق ملف طلب الصرف بصيغة PDF',
        );
      }
      return true;
    } catch (error, stackTrace) {
      debugPrint('PDF export failed at "$stage": $error');
      debugPrintStack(stackTrace: stackTrace);
      if (!mounted) return false;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(_friendlyExportError(stage: stage, print: print)),
          behavior: SnackBarBehavior.floating,
          action: SnackBarAction(
            label: 'إعادة المحاولة',
            onPressed: () {
              _exportPdf(request, print: print);
            },
          ),
        ),
      );
      return false;
    } finally {
      if (mounted) setState(() => _isActionLoading = false);
    }
  }

  String _friendlyExportError({required String stage, required bool print}) {
    if (stage == 'إنشاء ملف PDF') {
      return 'تعذر إنشاء ملف PDF بسبب إعدادات الحقول أو محتوى الطلب.';
    }
    if (stage == 'فتح نافذة الطباعة') {
      return 'تم إنشاء PDF، لكن تعذر فتح نافذة الطباعة. تحقق من خدمة الطباعة.';
    }
    if (stage == 'فتح نافذة المشاركة') {
      return 'تم إنشاء PDF، لكن تعذر فتح نافذة المشاركة. حاول مرة أخرى.';
    }
    return print
        ? 'تعذرت الطباعة أثناء: $stage. حاول مرة أخرى.'
        : 'تعذرت مشاركة PDF أثناء: $stage. حاول مرة أخرى.';
  }

  Future<void> _previewRequest(ExpenseRequest request) async {
    if (_isActionLoading) return;
    setState(() => _isActionLoading = true);
    try {
      final settings = request.settingsSnapshot.isEmpty
          ? await SettingsStore.load(
              scope:
                  request.documentType == ExpenseDocumentType.sampleRequest &&
                      request.customFields['sampleTemplate'] == 'singlePage'
                  ? 'sampleRequestSinglePage'
                  : request.documentType == ExpenseDocumentType.sampleRequest
                  ? 'sampleRequest'
                  : 'global',
            )
          : AppSettings.fromMap(request.settingsSnapshot);
      final bytes = await PdfService.buildRequestPdf(
        request,
        settings: settings,
      );
      if (bytes.isEmpty) throw StateError('تم إنشاء ملف PDF فارغ');
      if (!mounted) return;
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => Scaffold(
            appBar: AppBar(title: const Text('معاينة النموذج المحفوظ')),
            body: PdfPreview(
              canChangePageFormat: false,
              canChangeOrientation: false,
              build: (_) async => bytes,
            ),
          ),
        ),
      );
    } catch (error, stackTrace) {
      debugPrint('Saved request preview failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('تعذرت معاينة النموذج المحفوظ.'),
          action: SnackBarAction(
            label: 'إعادة المحاولة',
            onPressed: () {
              _previewRequest(request);
            },
          ),
        ),
      );
    } finally {
      if (mounted) setState(() => _isActionLoading = false);
    }
  }

  bool _isSampleRequest(ExpenseRequest request) =>
      request.documentType == ExpenseDocumentType.sampleRequest;

  String _sampleSettingsScope(ExpenseRequest request) =>
      request.customFields['sampleTemplate'] == 'singlePage'
      ? 'sampleRequestSinglePage'
      : 'sampleRequest';

  TemplateKind _sampleTemplateKind(ExpenseRequest request) =>
      request.customFields['sampleTemplate'] == 'singlePage'
      ? TemplateKind.sampleRequestSinglePage
      : TemplateKind.sampleRequest;

  Future<AppSettings> _loadSampleSettings(ExpenseRequest request) async {
    if (request.settingsSnapshot.isNotEmpty) {
      return AppSettings.fromMap(request.settingsSnapshot);
    }
    return SettingsStore.load(scope: _sampleSettingsScope(request));
  }

  Future<void> _previewSampleRequest(ExpenseRequest request) async {
    if (_isActionLoading) return;
    setState(() => _isActionLoading = true);
    try {
      final settings = await _loadSampleSettings(request);
      final bytes = await PdfService.buildRequestPdf(
        request,
        settings: settings,
      );
      if (bytes.isEmpty) throw StateError('تم إنشاء ملف PDF فارغ');
      if (!mounted) return;
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => Scaffold(
            appBar: AppBar(title: const Text('معاينة نموذج طلب العينات')),
            body: PdfPreview(
              canChangePageFormat: false,
              canChangeOrientation: false,
              build: (_) async => bytes,
            ),
          ),
        ),
      );
    } catch (error, stackTrace) {
      debugPrint('Sample request preview failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('تعذر فتح معاينة نموذج طلب العينات.'),
          action: SnackBarAction(
            label: 'إعادة المحاولة',
            onPressed: () {
              _previewSampleRequest(request);
            },
          ),
        ),
      );
    } finally {
      if (mounted) setState(() => _isActionLoading = false);
    }
  }

  Future<void> _openSampleSettings(ExpenseRequest request) async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) =>
            SettingsScreen(templateKind: _sampleTemplateKind(request)),
      ),
    );
  }

  Future<void> _openSamplePositionEditor(ExpenseRequest request) async {
    try {
      final settings = await _loadSampleSettings(request);
      if (!mounted) return;
      final updated = await Navigator.of(context).push<AppSettings>(
        MaterialPageRoute<AppSettings>(
          builder: (_) => TemplatePreviewScreen(
            settings: settings,
            templateScope: _sampleSettingsScope(request),
            sampleRequest: true,
            documentTitle:
                request.customFields['sampleTemplate'] == 'singlePage'
                ? 'نموذج طلب العينات — صفحة واحدة'
                : 'نموذج طلب العينات',
          ),
        ),
      );
      if (updated != null) {
        await SettingsStore.save(updated, scope: _sampleSettingsScope(request));
      }
    } catch (error, stackTrace) {
      debugPrint('Sample request position editor failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تعذر فتح محرر مواضع نموذج طلب العينات')),
      );
    }
  }

  Future<void> _editRequest(ExpenseRequest request) async {
    final originalIndex = _expenseIndex(request);
    if (originalIndex < 0) return;
    final page = switch (request.documentType) {
      ExpenseDocumentType.internalMemo => InternalMemoScreen(
        initialRequest: request,
        editingIndex: originalIndex,
      ),
      ExpenseDocumentType.customerApplication => CustomerApplicationScreen(
        initialRequest: request,
        editingIndex: originalIndex,
      ),
      ExpenseDocumentType.expenseRequest => ExpenseRequestScreen(
        initialRequest: request,
        editingIndex: originalIndex,
      ),
      ExpenseDocumentType.clearanceRequest => ExpenseRequestScreen(
        initialRequest: request,
        editingIndex: originalIndex,
        documentType: ExpenseDocumentType.clearanceRequest,
      ),
      ExpenseDocumentType.serviceRequest => ExpenseRequestScreen(
        initialRequest: request,
        editingIndex: originalIndex,
        documentType: ExpenseDocumentType.serviceRequest,
      ),
      ExpenseDocumentType.fuelRequest => FuelRequestScreen(
        initialRequest: request,
        editingIndex: originalIndex,
      ),
      ExpenseDocumentType.sampleRequest =>
        _isSinglePageSampleRequest(request)
            ? SampleRequestSinglePageScreen(
                initialRequest: request,
                editingIndex: originalIndex,
              )
            : SampleRequestThreePageScreen(
                initialRequest: request,
                editingIndex: originalIndex,
              ),
    };
    await Navigator.of(
      context,
    ).push<void>(MaterialPageRoute<void>(builder: (_) => page));
    if (mounted) await _loadRequests();
  }

  Future<void> _addFromRequest(ExpenseRequest request) async {
    final page = switch (request.documentType) {
      ExpenseDocumentType.internalMemo => InternalMemoScreen(
        initialRequest: request,
        editingIndex: null,
      ),
      ExpenseDocumentType.customerApplication => CustomerApplicationScreen(
        initialRequest: request,
        editingIndex: null,
      ),
      ExpenseDocumentType.clearanceRequest => ExpenseRequestScreen(
        initialRequest: request,
        editingIndex: null,
        documentType: ExpenseDocumentType.clearanceRequest,
      ),
      ExpenseDocumentType.serviceRequest => ExpenseRequestScreen(
        initialRequest: request,
        editingIndex: null,
        documentType: ExpenseDocumentType.serviceRequest,
      ),
      ExpenseDocumentType.fuelRequest => FuelRequestScreen(
        initialRequest: request,
        editingIndex: null,
      ),
      ExpenseDocumentType.expenseRequest => ExpenseRequestScreen(
        initialRequest: request,
        editingIndex: null,
      ),
      ExpenseDocumentType.sampleRequest =>
        _isSinglePageSampleRequest(request)
            ? SampleRequestSinglePageScreen(initialRequest: request)
            : SampleRequestThreePageScreen(initialRequest: request),
    };
    await Navigator.of(
      context,
    ).push<void>(MaterialPageRoute<void>(builder: (_) => page));
    if (mounted) await _loadRequests();
  }

  Future<void> _editTravelRequest(TravelAllowanceRequest request) async {
    final index = _travelRequests.indexOf(request);
    if (index < 0) return;
    await Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => TravelAllowanceRequestScreen(
          initialRequest: request,
          editingIndex: index,
        ),
      ),
    );
    if (mounted) await _loadRequests();
  }

  Future<void> _previewTravelRequest(TravelAllowanceRequest request) async {
    if (_isActionLoading) return;
    setState(() => _isActionLoading = true);
    try {
      final settings = await SettingsStore.load(scope: 'travelAllowance');
      final bytes = await TravelAllowancePdfService.build(
        request,
        settings: settings,
      );
      if (bytes.isEmpty) throw StateError('تم إنشاء ملف PDF فارغ');
      if (!mounted) return;
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => Scaffold(
            appBar: AppBar(title: const Text('معاينة طلب بدل السفر')),
            body: PdfPreview(
              canChangePageFormat: false,
              canChangeOrientation: false,
              build: (_) async => bytes,
            ),
          ),
        ),
      );
    } catch (error, stackTrace) {
      debugPrint('Travel allowance preview failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('تعذرت معاينة طلب بدل السفر.'),
          action: SnackBarAction(
            label: 'إعادة المحاولة',
            onPressed: () {
              _previewTravelRequest(request);
            },
          ),
        ),
      );
    } finally {
      if (mounted) setState(() => _isActionLoading = false);
    }
  }

  Future<void> _exportTravelRequest(
    TravelAllowanceRequest request, {
    required bool print,
  }) async {
    if (_isActionLoading) return;
    setState(() => _isActionLoading = true);
    try {
      final settings = await SettingsStore.load(scope: 'travelAllowance');
      final bytes = await TravelAllowancePdfService.build(
        request,
        settings: settings,
      );
      if (bytes.isEmpty) throw StateError('تم إنشاء ملف PDF فارغ');
      final filename = 'travel_allowance_${request.year}.pdf';
      if (print) {
        await ShareService.printPdf(
          bytes,
          filename: filename,
          format: PdfPageFormat.a4.landscape,
        );
      } else {
        await ShareService.sharePdf(
          bytes: bytes,
          filename: filename,
          subject: 'كشف بدل السفر',
          body: 'مرفق كشف بدل السفر بصيغة PDF',
        );
      }
    } catch (error, stackTrace) {
      debugPrint('Travel allowance export failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            print
                ? 'تعذرت طباعة طلب بدل السفر.'
                : 'تعذرت مشاركة طلب بدل السفر.',
          ),
          action: SnackBarAction(
            label: 'إعادة المحاولة',
            onPressed: () {
              _exportTravelRequest(request, print: print);
            },
          ),
        ),
      );
    } finally {
      if (mounted) setState(() => _isActionLoading = false);
    }
  }

  Future<void> _deleteTravelRequest(TravelAllowanceRequest request) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف طلب بدل السفر؟'),
        content: const Text('لن يمكن استعادة هذا الطلب بعد حذفه.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    final index = _travelRequests.indexOf(request);
    if (index < 0) return;
    final deleteAt =
        widget.travelAllowanceDeleteAt ?? TravelAllowanceStore.deleteAt;
    await deleteAt(index);
    await _loadRequests();
  }

  Future<void> _addRequest() async {
    final type = await showModalBottomSheet<String>(
      context: context,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: Text(
                'اختر نوع النموذج',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.request_quote_outlined),
              title: const Text('طلب صرف'),
              onTap: () => Navigator.pop(context, 'expense'),
            ),
            ListTile(
              leading: const Icon(Icons.description_outlined),
              title: const Text('مذكرة داخلية — A4 كاملة'),
              onTap: () => Navigator.pop(context, 'memoA4'),
            ),
            ListTile(
              leading: const Icon(Icons.person_add_alt_1_outlined),
              title: const Text('نموذج العملاء'),
              onTap: () => Navigator.pop(context, 'customer'),
            ),
            ListTile(
              leading: const Icon(Icons.assignment_return_outlined),
              title: const Text('طلب إخلاء عهدة'),
              onTap: () => Navigator.pop(context, 'clearance'),
            ),
            ListTile(
              leading: const Icon(Icons.miscellaneous_services_outlined),
              title: const Text('طلب خدمة'),
              onTap: () => Navigator.pop(context, 'service'),
            ),
            ListTile(
              leading: const Icon(Icons.local_gas_station_outlined),
              title: const Text('نموذج المحروقات'),
              onTap: () => Navigator.pop(context, 'fuel'),
            ),
            ListTile(
              leading: const Icon(Icons.inventory_2_outlined),
              title: const Text('نموذج طلب عينات'),
              onTap: () => Navigator.pop(context, 'sample'),
            ),
            ListTile(
              leading: const Icon(Icons.flight_takeoff_outlined),
              title: const Text('طلب بدل السفر'),
              onTap: () => Navigator.pop(context, 'travelAllowance'),
            ),
          ],
        ),
      ),
    );
    if (!mounted || type == null) return;
    final page = switch (type) {
      'memoA4' => const InternalMemoScreen(
        initialLayout: InternalMemoLayout.fullA4,
      ),
      'customer' => const CustomerApplicationScreen(),
      'clearance' => const ExpenseRequestScreen(
        documentType: ExpenseDocumentType.clearanceRequest,
      ),
      'service' => const ExpenseRequestScreen(
        documentType: ExpenseDocumentType.serviceRequest,
      ),
      'fuel' => const FuelRequestScreen(),
      'sample' => const SampleRequestThreePageScreen(),
      'travelAllowance' => const TravelAllowanceRequestScreen(),
      _ => const ExpenseRequestScreen(),
    };
    await Navigator.of(
      context,
    ).push<void>(MaterialPageRoute<void>(builder: (_) => page));
    if (mounted) await _loadRequests();
  }

  Future<void> _deleteRequest(ExpenseRequest request) async {
    final originalIndex = _expenseIndex(request);
    if (originalIndex < 0) return;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('حذف المسودة؟'),
        content: const Text('لن يمكن استعادة هذه المسودة بعد حذفها.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    await RequestStore.deleteAt(originalIndex);
    await _loadRequests();
  }

  @override
  Widget build(BuildContext context) {
    final requests = _filteredRequests;
    final travelRequests = _filteredTravelRequests;
    return Scaffold(
      appBar: AppBar(
        title: const Text('النماذج السابقة'),
        actions: [
          IconButton(
            tooltip: 'الإعدادات',
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute<void>(
                builder: (_) => const GeneralSettingsScreen(),
              ),
            ),
            icon: const Icon(Icons.settings_outlined),
          ),
          IconButton(
            tooltip: 'تحديث',
            onPressed: _loadRequests,
            icon: const Icon(Icons.refresh_rounded),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addRequest,
        icon: const Icon(Icons.add),
        label: const Text('إضافة نموذج'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _loadError != null
          ? _SavedRequestsLoadError(onRetry: _loadRequests)
          : RefreshIndicator(
              onRefresh: _loadRequests,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (_isActionLoading) const LinearProgressIndicator(),
                  if (_isActionLoading) const SizedBox(height: 8),
                  TextField(
                    controller: _searchController,
                    decoration: const InputDecoration(
                      labelText: 'بحث في النماذج',
                      prefixIcon: Icon(Icons.search),
                    ),
                  ),
                  const SizedBox(height: 8),
                  DropdownButtonFormField<int>(
                    initialValue: _recordFilter,
                    decoration: const InputDecoration(
                      labelText: 'نوع المستند',
                      prefixIcon: Icon(Icons.filter_list_outlined),
                    ),
                    items: const [
                      DropdownMenuItem(value: 0, child: Text('كل المستندات')),
                      DropdownMenuItem(
                        value: 1,
                        child: Text('نماذج طلب الصرف'),
                      ),
                      DropdownMenuItem(
                        value: 2,
                        child: Text('نماذج المذكرات الداخلية'),
                      ),
                      DropdownMenuItem(value: 3, child: Text('نماذج العملاء')),
                      DropdownMenuItem(
                        value: 4,
                        child: Text('طلبات إخلاء العهدة'),
                      ),
                      DropdownMenuItem(value: 5, child: Text('طلبات الخدمة')),
                      DropdownMenuItem(
                        value: 6,
                        child: Text('نماذج المحروقات'),
                      ),
                      DropdownMenuItem(
                        value: 7,
                        child: Text('نماذج طلب العينات'),
                      ),
                      DropdownMenuItem(
                        value: 8,
                        child: Text('طلبات بدل السفر'),
                      ),
                    ],
                    onChanged: (value) {
                      if (value != null) setState(() => _recordFilter = value);
                    },
                  ),
                  const SizedBox(height: 8),
                  Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: FilterChip(
                      selected: _onlyFavorites,
                      avatar: const Icon(Icons.star_outline),
                      label: const Text('المفضلة فقط'),
                      onSelected: (value) =>
                          setState(() => _onlyFavorites = value),
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (_selectedKeys.isNotEmpty)
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(8),
                        child: Wrap(
                          spacing: 8,
                          children: [
                            Text('تم تحديد ${_selectedKeys.length} نماذج'),
                            FilledButton.icon(
                              onPressed: () => _bulkExport(print: true),
                              icon: const Icon(Icons.print_outlined),
                              label: const Text('طباعة المحدد'),
                            ),
                            OutlinedButton.icon(
                              onPressed: () => _bulkExport(print: false),
                              icon: const Icon(Icons.share_outlined),
                              label: const Text('مشاركة المحدد'),
                            ),
                            TextButton(
                              onPressed: () => setState(_selectedKeys.clear),
                              child: const Text('إلغاء التحديد'),
                            ),
                          ],
                        ),
                      ),
                    ),
                  if (requests.isEmpty && travelRequests.isEmpty)
                    const _EmptyRequests()
                  else
                    ...List.generate(
                      requests.length,
                      (index) => _RequestCard(
                        request: requests[index],
                        onEdit: () => _editRequest(requests[index]),
                        onAddFrom: () => _addFromRequest(requests[index]),
                        onPreview: _isSampleRequest(requests[index])
                            ? null
                            : () => _previewRequest(requests[index]),
                        onCreatePdf: () {
                          _exportPdf(requests[index], print: false);
                        },
                        onPrint: () {
                          _exportPdf(requests[index], print: true);
                        },
                        onSampleSettings: _isSampleRequest(requests[index])
                            ? () => _openSampleSettings(requests[index])
                            : null,
                        onSamplePreview: _isSampleRequest(requests[index])
                            ? () => _previewSampleRequest(requests[index])
                            : null,
                        onSamplePositionEditor:
                            _isSampleRequest(requests[index])
                            ? () => _openSamplePositionEditor(requests[index])
                            : null,
                        onDelete: () => _deleteRequest(requests[index]),
                        selected: _selectedKeys.contains(
                          _selectionKey(requests[index]),
                        ),
                        onSelected: (value) =>
                            _toggleSelection(requests[index], value),
                        onToggleFavorite: () =>
                            _toggleFavorite(requests[index]),
                      ),
                    ),
                  ...List.generate(
                    travelRequests.length,
                    (index) => _TravelAllowanceCard(
                      request: travelRequests[index],
                      onEdit: () => _editTravelRequest(travelRequests[index]),
                      onPreview: () =>
                          _previewTravelRequest(travelRequests[index]),
                      onCreatePdf: () => _exportTravelRequest(
                        travelRequests[index],
                        print: false,
                      ),
                      onPrint: () => _exportTravelRequest(
                        travelRequests[index],
                        print: true,
                      ),
                      onDelete: () =>
                          _deleteTravelRequest(travelRequests[index]),
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}

class _RequestCard extends StatelessWidget {
  const _RequestCard({
    required this.request,
    required this.onEdit,
    required this.onAddFrom,
    this.onPreview,
    required this.onCreatePdf,
    required this.onPrint,
    this.onSampleSettings,
    this.onSamplePreview,
    this.onSamplePositionEditor,
    required this.onDelete,
    required this.onToggleFavorite,
    required this.selected,
    required this.onSelected,
  });

  final ExpenseRequest request;
  final VoidCallback onEdit;
  final VoidCallback onAddFrom;
  final VoidCallback? onPreview;
  final VoidCallback onCreatePdf;
  final VoidCallback onPrint;
  final VoidCallback? onSampleSettings;
  final VoidCallback? onSamplePreview;
  final VoidCallback? onSamplePositionEditor;
  final VoidCallback onDelete;
  final VoidCallback onToggleFavorite;
  final bool selected;
  final ValueChanged<bool> onSelected;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 14, 12, 6),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Checkbox(
                  value: selected,
                  onChanged: (value) => onSelected(value ?? false),
                ),
                CircleAvatar(
                  backgroundColor: scheme.primaryContainer,
                  child: Icon(
                    Icons.description_outlined,
                    color: scheme.onPrimaryContainer,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        request.receiver.isEmpty
                            ? 'طلب صرف بدون مرسل إليه'
                            : request.receiver,
                        style: Theme.of(context).textTheme.titleMedium,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      if (request.requesterName.trim().isNotEmpty)
                        Text(
                          'مقدم الطلب: ${request.requesterName}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      if (request.statement.trim().isNotEmpty)
                        Text(
                          'البيان: ${request.statement}',
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                        ),
                      Text(
                        '${request.date}  •  ${request.amountNumber.isEmpty ? 'بدون مبلغ' : '${request.amountNumber} ريال'}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              alignment: WrapAlignment.spaceBetween,
              crossAxisAlignment: WrapCrossAlignment.center,
              runSpacing: 4,
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: scheme.primaryContainer,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child:
                      request.documentType == ExpenseDocumentType.internalMemo
                      ? const RotatedBox(
                          quarterTurns: 1,
                          child: Text('مذكرة داخلية A4'),
                        )
                      : Text(
                          request.documentType ==
                                  ExpenseDocumentType.clearanceRequest
                              ? 'طلب إخلاء عهدة'
                              : request.documentType ==
                                    ExpenseDocumentType.serviceRequest
                              ? 'طلب خدمة'
                              : request.documentType ==
                                    ExpenseDocumentType.fuelRequest
                              ? 'نموذج المحروقات'
                              : request.documentType ==
                                    ExpenseDocumentType.sampleRequest
                              ? 'نموذج طلب عينات'
                              : request.hasSecondRequest
                              ? 'طلب صرف — نموذج إضافي محفوظ'
                              : 'طلب صرف رسمي',
                          style: Theme.of(context).textTheme.labelMedium,
                        ),
                ),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      tooltip: 'إضافة من هذا النموذج',
                      onPressed: onAddFrom,
                      icon: const Icon(Icons.content_copy_outlined),
                    ),
                    IconButton(
                      tooltip: request.isFavorite
                          ? 'إزالة من المفضلة'
                          : 'إضافة إلى المفضلة',
                      onPressed: onToggleFavorite,
                      icon: Icon(
                        request.isFavorite ? Icons.star : Icons.star_border,
                        color: request.isFavorite
                            ? Colors.amber
                            : scheme.outline,
                      ),
                    ),
                    if (onPreview != null)
                      IconButton(
                        tooltip: 'معاينة PDF',
                        onPressed: onPreview,
                        icon: const Icon(Icons.preview_outlined),
                      ),
                    IconButton(
                      tooltip: 'إنشاء ومشاركة PDF',
                      onPressed: onCreatePdf,
                      icon: const Icon(Icons.picture_as_pdf_outlined),
                    ),
                    IconButton(
                      tooltip: 'طباعة',
                      onPressed: onPrint,
                      icon: const Icon(Icons.print_outlined),
                    ),
                    if (onSampleSettings != null)
                      IconButton(
                        tooltip: 'إعدادات نموذج طلب العينات',
                        onPressed: onSampleSettings!,
                        icon: const Icon(Icons.settings_outlined),
                      ),
                    if (onSamplePreview != null)
                      IconButton(
                        tooltip: 'معاينة نموذج طلب العينات',
                        onPressed: onSamplePreview!,
                        icon: const Icon(Icons.preview_outlined),
                      ),
                    if (onSamplePositionEditor != null)
                      IconButton(
                        tooltip: 'تحرير مواضع نموذج طلب العينات',
                        onPressed: onSamplePositionEditor!,
                        icon: const Icon(Icons.open_with_outlined),
                      ),
                    IconButton(
                      tooltip: 'تعديل النموذج',
                      onPressed: onEdit,
                      icon: const Icon(Icons.edit_outlined),
                    ),
                    IconButton(
                      tooltip: 'حذف',
                      onPressed: onDelete,
                      icon: const Icon(Icons.delete_outline),
                    ),
                  ],
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _TravelAllowanceCard extends StatelessWidget {
  const _TravelAllowanceCard({
    required this.request,
    required this.onEdit,
    required this.onPreview,
    required this.onCreatePdf,
    required this.onPrint,
    required this.onDelete,
  });

  final TravelAllowanceRequest request;
  final VoidCallback onEdit;
  final VoidCallback onPreview;
  final VoidCallback onCreatePdf;
  final VoidCallback onPrint;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 14, 12, 6),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: scheme.primaryContainer,
                  child: Icon(
                    Icons.flight_takeoff_outlined,
                    color: scheme.onPrimaryContainer,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        request.beneficiary.isEmpty
                            ? 'طلب بدل سفر بدون مستفيد'
                            : request.beneficiary,
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      Text(
                        'الفرع: ${request.branch.isEmpty ? 'غير محدد' : request.branch}',
                      ),
                      Text(
                        '${request.month} ${request.year} • ${request.totalDays} أيام • ${request.totalAmount.toStringAsFixed(2)}',
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              alignment: WrapAlignment.end,
              children: [
                const Chip(label: Text('طلب بدل السفر')),
                IconButton(
                  tooltip: 'معاينة طلب بدل السفر',
                  onPressed: onPreview,
                  icon: const Icon(Icons.preview_outlined),
                ),
                IconButton(
                  tooltip: 'إنشاء ومشاركة PDF',
                  onPressed: onCreatePdf,
                  icon: const Icon(Icons.picture_as_pdf_outlined),
                ),
                IconButton(
                  tooltip: 'طباعة',
                  onPressed: onPrint,
                  icon: const Icon(Icons.print_outlined),
                ),
                IconButton(
                  tooltip: 'تعديل طلب بدل السفر',
                  onPressed: onEdit,
                  icon: const Icon(Icons.edit_outlined),
                ),
                IconButton(
                  tooltip: 'حذف',
                  onPressed: onDelete,
                  icon: const Icon(Icons.delete_outline),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SavedRequestsLoadError extends StatelessWidget {
  const _SavedRequestsLoadError({required this.onRetry});

  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 48),
            const SizedBox(height: 12),
            const Text('تعذر تحميل النماذج المحفوظة'),
            const SizedBox(height: 6),
            const Text(
              'تحقق من التخزين المحلي ثم أعد المحاولة.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: () {
                onRetry();
              },
              icon: const Icon(Icons.refresh),
              label: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyRequests extends StatelessWidget {
  const _EmptyRequests();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 80),
      child: Column(
        children: [
          Icon(
            Icons.folder_open_outlined,
            size: 64,
            color: Theme.of(context).colorScheme.outline,
          ),
          const SizedBox(height: 12),
          const Text('لا توجد نماذج محفوظة حتى الآن'),
        ],
      ),
    );
  }
}
