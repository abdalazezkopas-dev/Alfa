import '../../../core/security/input_limits.dart';

class Reminder {
  const Reminder({
    required this.id,
    required this.title,
    required this.notes,
    required this.scheduledAt,
    this.sound = 'reminder_default',
    this.repeat = 'none',
    this.repeatIntervalDays = 1,
    this.isDone = false,
    this.snoozedUntil,
  });

  final int id;
  final String title;
  final String notes;
  final DateTime scheduledAt;
  final String sound;
  final String repeat;
  final int repeatIntervalDays;
  final bool isDone;
  final DateTime? snoozedUntil;

  Reminder copyWith({
    String? title,
    String? notes,
    DateTime? scheduledAt,
    String? sound,
    String? repeat,
    int? repeatIntervalDays,
    bool? isDone,
    DateTime? snoozedUntil,
    bool clearSnoozedUntil = false,
  }) {
    return Reminder(
      id: id,
      title: title ?? this.title,
      notes: notes ?? this.notes,
      scheduledAt: scheduledAt ?? this.scheduledAt,
      sound: sound ?? this.sound,
      repeat: repeat ?? this.repeat,
      repeatIntervalDays: repeatIntervalDays ?? this.repeatIntervalDays,
      isDone: isDone ?? this.isDone,
      snoozedUntil: clearSnoozedUntil
          ? null
          : snoozedUntil ?? this.snoozedUntil,
    );
  }

  Map<String, Object?> toMap() => {
    'id': id,
    'title': title,
    'notes': notes,
    'scheduledAt': scheduledAt.toIso8601String(),
    'sound': sound,
    'repeat': repeat,
    'repeatIntervalDays': repeatIntervalDays,
    'isDone': isDone,
    'snoozedUntil': snoozedUntil?.toIso8601String(),
  };

  factory Reminder.fromMap(Map<String, Object?> map) {
    final parsedDate = DateTime.tryParse(
      map['scheduledAt'] is String ? map['scheduledAt'] as String : '',
    );
    final parsedSnoozedUntil = DateTime.tryParse(
      map['snoozedUntil'] is String ? map['snoozedUntil'] as String : '',
    );
    return Reminder(
      id: InputLimits.integer(
        map['id'],
        fallback: DateTime.now().microsecondsSinceEpoch,
        max: 1 << 62,
      ),
      title: InputLimits.string(map['title']),
      notes: InputLimits.string(
        map['notes'],
        maxLength: InputLimits.maxLongTextLength,
      ),
      scheduledAt: parsedDate ?? DateTime.now(),
      sound: InputLimits.string(map['sound'], fallback: 'reminder_default'),
      repeat: InputLimits.string(
        map['repeat'],
        fallback: 'none',
        maxLength: 32,
      ),
      repeatIntervalDays: InputLimits.integer(
        map['repeatIntervalDays'],
        fallback: 1,
        max: 3650,
      ).clamp(1, 3650),
      isDone: map['isDone'] == true,
      snoozedUntil: parsedSnoozedUntil,
    );
  }
}
