import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/security/input_limits.dart';
import '../../../core/security/secure_local_store.dart';
import '../../../core/services/app_logger.dart';
import '../../../core/store_mutex.dart';
import '../models/reminder.dart';

class ReminderStore {
  const ReminderStore._();
  static const _key = 'alfa_expense_app.reminders.v1';
  static const _maxItems = 5000;

  static Future<List<Reminder>> load() =>
      StoreMutex.run('reminders', _loadUnlocked);

  static Future<List<Reminder>> _loadUnlocked() async {
    final preferences = await SharedPreferences.getInstance();
    String? raw;
    try {
      raw = await SecureLocalStore.read('reminders');
    } catch (error, stackTrace) {
      AppLogger.error(
        'تعذر قراءة التخزين الآمن للتذكيرات',
        error: error,
        stackTrace: stackTrace,
        scope: 'reminders',
      );
      rethrow;
    }
    final fromSecure = raw != null && raw.isNotEmpty;
    raw ??= preferences.getString(_key);
    if (raw == null || raw.isEmpty) return [];
    final reminders = _decode(raw);
    if (!fromSecure) {
      await SecureLocalStore.writeJson(
        'reminders',
        reminders.map((item) => item.toMap()).toList(),
      );
      await preferences.remove(_key);
    }
    return reminders;
  }

  static List<Reminder> _decode(String raw) {
    final decoded = jsonDecode(raw);
    if (decoded is! List || decoded.length > _maxItems) {
      throw const FormatException('تخزين التذكيرات غير صحيح');
    }
    return decoded.map((item) => _decodeItem(item)).toList();
  }

  static Reminder _decodeItem(Object? value) {
    if (value is! Map) throw const FormatException('سجل تذكير تالف');
    final map = Map<String, Object?>.from(value);
    if (map.containsKey('id'))
      InputLimits.strictInteger(map['id'], field: 'id', min: 0, max: 1 << 62);
    for (final key in const ['title', 'sound', 'repeat']) {
      if (map.containsKey(key))
        InputLimits.strictString(
          map[key],
          field: key,
          maxLength: key == 'repeat' ? 32 : 512,
        );
    }
    if (map.containsKey('notes'))
      InputLimits.strictString(
        map['notes'],
        field: 'notes',
        maxLength: InputLimits.maxLongTextLength,
      );
    InputLimits.strictDateTime(map['scheduledAt'], field: 'scheduledAt');
    if (map.containsKey('repeatIntervalDays'))
      InputLimits.strictInteger(
        map['repeatIntervalDays'],
        field: 'repeatIntervalDays',
        min: 1,
        max: 3650,
      );
    if (map.containsKey('isDone'))
      InputLimits.strictBool(map['isDone'], field: 'isDone');
    if (map.containsKey('snoozedUntil') && map['snoozedUntil'] != null)
      InputLimits.strictDateTime(map['snoozedUntil'], field: 'snoozedUntil');
    return Reminder.fromMap(map);
  }

  static Future<void> saveAll(List<Reminder> reminders) =>
      StoreMutex.run('reminders', () => _saveUnlocked(reminders));

  static Future<void> _saveUnlocked(List<Reminder> reminders) async {
    if (reminders.length > _maxItems)
      throw const FormatException('عدد التذكيرات يتجاوز الحد المسموح');
    for (final item in reminders) _decodeItem(item.toMap());
    final encoded = jsonEncode(reminders.map((item) => item.toMap()).toList());
    _decode(encoded);
    final preferences = await SharedPreferences.getInstance();
    await SecureLocalStore.write('reminders', encoded);
    await preferences.remove(_key);
  }

  static Future<void> upsert(Reminder reminder) =>
      StoreMutex.run('reminders', () async {
        final reminders = await _loadUnlocked();
        final index = reminders.indexWhere((item) => item.id == reminder.id);
        if (index == -1) {
          reminders.add(reminder);
        } else {
          reminders[index] = reminder;
        }
        await _saveUnlocked(reminders);
      });

  static Future<void> delete(int id) => StoreMutex.run('reminders', () async {
    final reminders = await _loadUnlocked();
    reminders.removeWhere((item) => item.id == id);
    await _saveUnlocked(reminders);
  });
}
