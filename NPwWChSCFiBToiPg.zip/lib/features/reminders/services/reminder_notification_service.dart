import 'dart:async';
import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

import '../models/reminder.dart';
import 'reminder_store.dart';

class ReminderNotificationSoundProfile {
  const ReminderNotificationSoundProfile({
    required this.channelId,
    required this.channelName,
    this.resourceName,
  });

  final String channelId;
  final String channelName;
  final String? resourceName;

  AndroidNotificationSound? get sound => resourceName == null
      ? null
      : RawResourceAndroidNotificationSound(resourceName!);
}

class ReminderNotificationService {
  ReminderNotificationService._();

  static final instance = ReminderNotificationService._();
  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;
  bool? _notificationsGranted;
  bool? _exactAlarmsGranted;
  bool _notificationPermissionRequested = false;
  bool _exactAlarmPermissionRequested = false;
  static const _systemSettingsChannel = MethodChannel(
    'com.shibapharma/formsuite/system_settings',
  );

  bool? get notificationsGranted => _notificationsGranted;
  bool? get exactAlarmsGranted => _exactAlarmsGranted;

  Future<bool> openNotificationSettings() async {
    try {
      return await _systemSettingsChannel.invokeMethod<bool>(
            'openNotificationSettings',
          ) ??
          false;
    } on MissingPluginException {
      return false;
    } on PlatformException {
      return false;
    }
  }

  Future<bool> openExactAlarmSettings() async {
    try {
      return await _systemSettingsChannel.invokeMethod<bool>(
            'openExactAlarmSettings',
          ) ??
          false;
    } on MissingPluginException {
      return false;
    } on PlatformException {
      return false;
    }
  }

  static const _defaultSoundProfile = ReminderNotificationSoundProfile(
    channelId: 'spa_pharma_reminders_v2_default',
    channelName: 'التذكيرات المجدولة - نغمة افتراضية',
  );

  static const _previewNotificationId = 2147483646;

  /// Android notification APIs use signed 32-bit IDs, while app record IDs
  /// are generated from microsecond timestamps. Keep distinct stable IDs for
  /// the main alarm and a reminder's independent snooze alarm.
  static int _notificationIdForKey(String key) {
    var hash = 0x811c9dc5;
    for (final byte in utf8.encode(key)) {
      hash ^= byte;
      hash = (hash * 0x01000193) & 0xffffffff;
    }
    return (hash & 0x7fffffff) % 2147483645 + 1;
  }

  static int notificationIdFor(int reminderId) =>
      _notificationIdForKey('reminder:$reminderId');

  static int snoozeNotificationIdFor(int reminderId) =>
      _notificationIdForKey('snooze:$reminderId');

  static DateTimeComponents? repeatComponentsFor(String repeat) =>
      switch (repeat) {
        'daily' => DateTimeComponents.time,
        'weekly' => DateTimeComponents.dayOfWeekAndTime,
        'monthly' => DateTimeComponents.dayOfMonthAndTime,
        'yearly' => DateTimeComponents.dateAndTime,
        _ => null,
      };

  static ReminderNotificationSoundProfile soundProfileFor(String selection) =>
      switch (selection) {
        'reminder_default' => _defaultSoundProfile,
        'reminder_soft' => const ReminderNotificationSoundProfile(
          channelId: 'spa_pharma_reminders_v2_soft',
          channelName: 'التذكيرات المجدولة - نغمة هادئة',
          resourceName: 'reminder_soft',
        ),
        'reminder_urgent' => const ReminderNotificationSoundProfile(
          channelId: 'spa_pharma_reminders_v2_urgent',
          channelName: 'التذكيرات المجدولة - نغمة قوية',
          resourceName: 'reminder_urgent',
        ),
        _ => _defaultSoundProfile,
      };

  NotificationDetails _detailsFor(ReminderNotificationSoundProfile profile) =>
      NotificationDetails(
        android: AndroidNotificationDetails(
          profile.channelId,
          profile.channelName,
          channelDescription: 'تنبيهات التذكيرات المجدولة داخل التطبيق',
          importance: Importance.high,
          priority: Priority.high,
          sound: profile.sound,
          playSound: true,
          enableVibration: true,
        ),
      );

  Future<void> previewSound(String selection) async {
    await initialize();
    final androidPlugin = _plugin
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >();
    if (_notificationsGranted != true && !_notificationPermissionRequested) {
      _notificationPermissionRequested = true;
      _notificationsGranted = await androidPlugin
          ?.requestNotificationsPermission();
    }
    if (_notificationsGranted == false) {
      throw StateError('فعّل إذن الإشعارات من إعدادات الجهاز لمعاينة النغمة.');
    }
    final profile = soundProfileFor(selection);
    await _plugin.show(
      _previewNotificationId,
      'معاينة نغمة التذكير',
      'هذه معاينة للنغمة المختارة.',
      _detailsFor(profile),
    );
    unawaited(_cancelPreviewLater());
  }

  Future<void> _cancelPreviewLater() async {
    await Future<void>.delayed(const Duration(seconds: 8));
    try {
      await _plugin.cancel(_previewNotificationId);
    } catch (_) {
      // The preview is best-effort; never affect saved or scheduled reminders.
    }
  }

  Future<void> initialize() async {
    if (_initialized) return;
    tz.initializeTimeZones();
    // التطبيق مخصص لبيئة Shiba Pharma في السعودية؛ لا تترك timezone.local
    // على UTC لأن ذلك يؤخر التنبيهات ثلاث ساعات.
    tz.setLocalLocation(tz.getLocation('Asia/Riyadh'));
    const android = AndroidInitializationSettings('ic_notification');
    const settings = InitializationSettings(android: android);
    await _plugin.initialize(settings);
    final androidPlugin = _plugin
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >();
    _notificationsGranted = await androidPlugin?.areNotificationsEnabled();
    _exactAlarmsGranted = await androidPlugin?.canScheduleExactNotifications();
    _initialized = true;
  }

  Future<void> schedule(
    Reminder reminder, {
    bool requestPermissions = true,
  }) async {
    await initialize();
    if (reminder.isDone) {
      await cancel(reminder.id);
      return;
    }
    final now = DateTime.now();
    var scheduledAt = reminder.scheduledAt;
    if (!scheduledAt.isAfter(now)) {
      scheduledAt = _nextOccurrence(reminder, now) ?? reminder.scheduledAt;
      if (!scheduledAt.isAfter(now)) {
        await _plugin.cancel(notificationIdFor(reminder.id));
        return;
      }
    }
    await _scheduleAt(
      reminder,
      notificationIdFor(reminder.id),
      scheduledAt,
      requestPermissions: requestPermissions,
    );
    final snoozedUntil = reminder.snoozedUntil;
    if (snoozedUntil != null && snoozedUntil.isAfter(now)) {
      await _scheduleAt(
        reminder,
        snoozeNotificationIdFor(reminder.id),
        snoozedUntil,
        snooze: true,
        requestPermissions: requestPermissions,
      );
    } else {
      await _plugin.cancel(snoozeNotificationIdFor(reminder.id));
    }
  }

  Future<void> _scheduleAt(
    Reminder reminder,
    int notificationId,
    DateTime scheduledAt, {
    bool snooze = false,
    bool requestPermissions = true,
  }) async {
    final soundProfile = soundProfileFor(reminder.sound);
    final androidPlugin = _plugin
        .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin
        >();
    if (requestPermissions &&
        _notificationsGranted != true &&
        !_notificationPermissionRequested) {
      _notificationPermissionRequested = true;
      _notificationsGranted = await androidPlugin
          ?.requestNotificationsPermission();
    } else {
      _notificationsGranted =
          await androidPlugin?.areNotificationsEnabled() ??
          _notificationsGranted;
    }

    if (requestPermissions &&
        _exactAlarmsGranted != true &&
        !_exactAlarmPermissionRequested) {
      _exactAlarmPermissionRequested = true;
      _exactAlarmsGranted = await androidPlugin?.requestExactAlarmsPermission();
    } else {
      _exactAlarmsGranted =
          await androidPlugin?.canScheduleExactNotifications() ??
          _exactAlarmsGranted;
    }
    final exactGranted = _exactAlarmsGranted ?? false;
    final scheduled = tz.TZDateTime.from(scheduledAt, tz.local);
    await _plugin.zonedSchedule(
      notificationId,
      reminder.title,
      snooze
          ? 'حان موعد التذكير المؤجل'
          : reminder.notes.isEmpty
          ? 'حان موعد التذكير'
          : reminder.notes,
      scheduled,
      _detailsFor(soundProfile),
      uiLocalNotificationDateInterpretation:
          UILocalNotificationDateInterpretation.absoluteTime,
      androidScheduleMode: exactGranted
          ? AndroidScheduleMode.exactAllowWhileIdle
          : AndroidScheduleMode.inexactAllowWhileIdle,
      matchDateTimeComponents: snooze
          ? null
          : repeatComponentsFor(reminder.repeat),
      payload: snooze ? '${reminder.id}:snooze' : reminder.id.toString(),
    );
  }

  Future<List<int>> rescheduleSaved() async {
    final reminders = await ReminderStore.load();
    final now = DateTime.now();
    final failedIds = <int>[];
    for (final reminder in reminders) {
      try {
        if (reminder.isDone) {
          await cancel(reminder.id);
          continue;
        }

        var current = reminder;
        if (current.snoozedUntil != null &&
            !current.snoozedUntil!.isAfter(now)) {
          current = current.copyWith(clearSnoozedUntil: true);
          await ReminderStore.upsert(current);
        }

        final next = _nextOccurrence(current, now);
        if (next == null) {
          await cancel(current.id);
        } else {
          await schedule(
            current.copyWith(scheduledAt: next),
            requestPermissions: false,
          );
        }
      } catch (error, stackTrace) {
        // فشل إذن/تذكير واحد لا يمنع جدولة بقية التذكيرات.
        failedIds.add(reminder.id);
        // ignore: avoid_print
        print('تعذر جدولة التذكير ${reminder.id}: $error');
        // ignore: avoid_print
        print(stackTrace);
      }
    }
    return failedIds;
  }

  Future<void> cancel(int id) async {
    await initialize();
    final notificationId = notificationIdFor(id);
    await _plugin.cancel(notificationId);
    await _plugin.cancel(snoozeNotificationIdFor(id));
    // Clear notifications made by older app versions when their original ID
    // happened to fit Android's native integer range.
    if (id != notificationId && id >= 0 && id <= 2147483647) {
      await _plugin.cancel(id);
    }
  }

  Future<Reminder> snooze(
    Reminder reminder, {
    Duration duration = const Duration(minutes: 10),
  }) async {
    final until = DateTime.now().add(duration);
    final updated = reminder.repeat == 'none'
        ? reminder.copyWith(scheduledAt: until, clearSnoozedUntil: true)
        : reminder.copyWith(snoozedUntil: until);
    await ReminderStore.upsert(updated);
    await schedule(updated);
    return updated;
  }

  Future<void> cancelAll() async {
    await initialize();
    await _plugin.cancelAll();
  }

  DateTime? nextOccurrence(Reminder reminder, DateTime now) =>
      _nextOccurrence(reminder, now);

  DateTime? _nextOccurrence(Reminder reminder, DateTime now) {
    final saved = reminder.scheduledAt;
    switch (reminder.repeat) {
      case 'none':
        return saved.isAfter(now) ? saved : null;
      case 'daily':
        var candidate = DateTime(
          now.year,
          now.month,
          now.day,
          saved.hour,
          saved.minute,
          saved.second,
          saved.millisecond,
          saved.microsecond,
        );
        if (!candidate.isAfter(now)) {
          candidate = candidate.add(const Duration(days: 1));
        }
        return candidate;
      case 'weekly':
        final daysUntil = (saved.weekday - now.weekday + 7) % 7;
        var candidate = DateTime(
          now.year,
          now.month,
          now.day + daysUntil,
          saved.hour,
          saved.minute,
          saved.second,
          saved.millisecond,
          saved.microsecond,
        );
        if (!candidate.isAfter(now)) {
          candidate = candidate.add(const Duration(days: 7));
        }
        return candidate;
      case 'monthly':
        var year = now.year;
        var month = now.month;
        for (var attempt = 0; attempt < 24; attempt++) {
          if (year > 9999) return null;
          final lastDay = DateTime(year, month + 1, 0).day;
          if (saved.day <= lastDay) {
            final candidate = DateTime(
              year,
              month,
              saved.day,
              saved.hour,
              saved.minute,
              saved.second,
              saved.millisecond,
              saved.microsecond,
            );
            if (candidate.isAfter(now)) return candidate;
          }
          month++;
          if (month == 13) {
            month = 1;
            year++;
          }
        }
        return null;
      case 'yearly':
        for (var year = now.year; year <= 9999; year++) {
          final lastDay = DateTime(year, saved.month + 1, 0).day;
          if (saved.day > lastDay) continue;
          final candidate = DateTime(
            year,
            saved.month,
            saved.day,
            saved.hour,
            saved.minute,
            saved.second,
            saved.millisecond,
            saved.microsecond,
          );
          if (candidate.isAfter(now)) return candidate;
        }
        return null;
      case 'custom':
        var candidate = saved;
        final days = reminder.repeatIntervalDays.clamp(1, 3650);
        while (!candidate.isAfter(now)) {
          candidate = candidate.add(Duration(days: days));
        }
        return candidate;
      default:
        return saved.isAfter(now) ? saved : null;
    }
  }
}
