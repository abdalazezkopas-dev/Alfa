import '../../../core/utils/date_formatter.dart';

import 'package:flutter/material.dart';

import '../models/reminder.dart';
import '../services/reminder_notification_service.dart';
import '../services/reminder_store.dart';
import '../../../core/id_generator.dart';

class RemindersScreen extends StatefulWidget {
  const RemindersScreen({super.key});

  @override
  State<RemindersScreen> createState() => _RemindersScreenState();
}

class _RemindersScreenState extends State<RemindersScreen> {
  List<Reminder> _reminders = const [];
  bool _loading = true;
  bool _showCompleted = false;
  Object? _loadError;

  @override
  void initState() {
    super.initState();
    _load();
    _refreshNotificationPermissions();
  }

  Future<void> _refreshNotificationPermissions() async {
    try {
      await ReminderNotificationService.instance.initialize();
      if (mounted) setState(() {});
    } catch (_) {
      // Loading reminders remains available if Android settings are unavailable.
    }
  }

  Future<void> _openNotificationSettings() async {
    final service = ReminderNotificationService.instance;
    final opened = service.notificationsGranted == false
        ? await service.openNotificationSettings()
        : service.exactAlarmsGranted == false
        ? await service.openExactAlarmSettings()
        : false;
    await _refreshNotificationPermissions();
    if (!opened && mounted) {
      _showError(
        'تعذر فتح إعدادات التنبيهات على هذا الجهاز. افتح إعدادات التطبيق يدويًا.',
      );
    }
  }

  Future<void> _load() async {
    try {
      final reminders = await ReminderStore.load();
      if (!mounted) return;
      setState(() {
        _reminders = reminders
          ..sort((a, b) => _displayDate(a).compareTo(_displayDate(b)));
        _loadError = null;
        _loading = false;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loadError = error;
        _loading = false;
      });
    }
  }

  Future<void> _addReminder() async {
    final reminder = await showDialog<Reminder>(
      context: context,
      builder: (_) => const _ReminderEditor(),
    );
    if (reminder == null) return;
    try {
      await ReminderStore.upsert(reminder);
      await _load();
    } catch (error) {
      _showError('تعذر حفظ التذكير: $error');
      return;
    }
    try {
      await ReminderNotificationService.instance.schedule(reminder);
      _showPermissionHint();
    } catch (error) {
      _showError('حُفظ التذكير، لكن تعذر تفعيل التنبيه: $error');
    }
  }

  Future<void> _delete(Reminder reminder) async {
    try {
      await ReminderNotificationService.instance.cancel(reminder.id);
      await ReminderStore.delete(reminder.id);
      await _load();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text('حُذف التذكير'),
          action: SnackBarAction(
            label: 'تراجع',
            onPressed: () async {
              try {
                await ReminderStore.upsert(reminder);
                if (!reminder.isDone) {
                  await ReminderNotificationService.instance.schedule(reminder);
                }
                await _load();
              } catch (error) {
                _showError('تعذر استعادة التذكير: $error');
              }
            },
          ),
        ),
      );
    } catch (error) {
      _showError('تعذر حذف التذكير: $error');
    }
  }

  Future<void> _snooze(
    Reminder reminder, {
    Duration duration = const Duration(minutes: 10),
  }) async {
    try {
      await ReminderNotificationService.instance.snooze(
        reminder,
        duration: duration,
      );
      await _load();
      final durationLabel = duration.inHours > 0
          ? '${duration.inHours} ساعة'
          : '${duration.inMinutes} دقيقة';
      if (mounted) _showError('تم تأجيل التذكير $durationLabel');
    } catch (error) {
      await _load();
      _showError('تعذر تأجيل التذكير: $error');
    }
  }

  Future<void> _toggleDone(Reminder reminder) async {
    final updated = reminder.copyWith(
      isDone: !reminder.isDone,
      clearSnoozedUntil: true,
    );
    try {
      await ReminderStore.upsert(updated);
      await _load();
    } catch (error) {
      _showError('تعذر حفظ حالة التذكير: $error');
      return;
    }
    try {
      if (updated.isDone) {
        await ReminderNotificationService.instance.cancel(reminder.id);
      } else {
        await ReminderNotificationService.instance.schedule(updated);
      }
      await _load();
      if (mounted) {
        final next = ReminderNotificationService.instance.nextOccurrence(
          updated,
          DateTime.now(),
        );
        if (updated.isDone) {
          _showError('تم وضع التذكير ضمن المنجزة');
        } else if (next == null) {
          _showError('أُعيد فتحه؛ موعده السابق مضى. عدّله لتحديد موعد جديد.');
        } else if (ReminderNotificationService.instance.notificationsGranted ==
                false ||
            ReminderNotificationService.instance.exactAlarmsGranted == false) {
          _showPermissionHint();
        } else {
          _showError('أُعيد تفعيل التذكير');
        }
      }
    } catch (error) {
      await _load();
      _showError('حُفظت الحالة، لكن تعذر تحديث التنبيه: $error');
    }
  }

  void _showPermissionHint() {
    final service = ReminderNotificationService.instance;
    final message = service.notificationsGranted == false
        ? 'حُفظ التذكير، لكن إذن الإشعارات مرفوض. فعّله من إعدادات التطبيق ليصل التنبيه.'
        : service.exactAlarmsGranted == false
        ? 'حُفظ التذكير. قد يتأخر قليلًا لأن إذن المنبهات الدقيقة غير مفعّل.'
        : null;
    if (message != null) _showError(message);
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> _editReminder(Reminder reminder) async {
    final updated = await showDialog<Reminder>(
      context: context,
      builder: (_) => _ReminderEditor(initial: reminder),
    );
    if (updated == null) return;
    try {
      await ReminderNotificationService.instance.cancel(reminder.id);
      await ReminderStore.upsert(updated);
      await _load();
    } catch (error) {
      _showError('تعذر حفظ تعديل التذكير: $error');
      return;
    }
    try {
      await ReminderNotificationService.instance.schedule(updated);
      _showPermissionHint();
    } catch (error) {
      _showError('حُفظ التعديل، لكن تعذر تفعيل التنبيه: $error');
    }
  }

  String _formatDate(DateTime date) => DateFormatter.dateTime(date);

  DateTime _displayDate(Reminder reminder) {
    if (reminder.isDone) return reminder.scheduledAt;
    final snooze = reminder.snoozedUntil;
    if (!reminder.isDone && snooze != null && snooze.isAfter(DateTime.now())) {
      return snooze;
    }
    return ReminderNotificationService.instance.nextOccurrence(
          reminder,
          DateTime.now(),
        ) ??
        reminder.scheduledAt;
  }

  bool _isOverdue(Reminder reminder) =>
      !reminder.isDone &&
      reminder.repeat == 'none' &&
      (reminder.snoozedUntil == null ||
          !reminder.snoozedUntil!.isAfter(DateTime.now())) &&
      reminder.scheduledAt.isBefore(DateTime.now());

  String _repeatLabel(String repeat) => switch (repeat) {
    'daily' => 'يومي',
    'weekly' => 'أسبوعي',
    'monthly' => 'شهري',
    'yearly' => 'سنوي',
    'custom' => 'مخصص قديم',
    _ => 'مرة واحدة',
  };

  @override
  Widget build(BuildContext context) {
    final activeCount = _reminders.where((item) => !item.isDone).length;
    final completedCount = _reminders.where((item) => item.isDone).length;
    final overdueCount = _reminders.where(_isOverdue).length;
    final visibleReminders = _reminders
        .where((item) => item.isDone == _showCompleted)
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('التذكيرات'),
        actions: [
          IconButton(
            tooltip: 'إعدادات تنبيهات الجهاز',
            onPressed: _openNotificationSettings,
            icon: const Icon(Icons.notifications_active_outlined),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addReminder,
        icon: const Icon(Icons.add_alert_outlined),
        label: const Text('تذكير جديد'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _loadError != null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline, size: 48),
                    const SizedBox(height: 12),
                    const Text('تعذر تحميل التذكيرات'),
                    const SizedBox(height: 12),
                    OutlinedButton.icon(
                      onPressed: () {
                        setState(() {
                          _loading = true;
                          _loadError = null;
                        });
                        _load();
                      },
                      icon: const Icon(Icons.refresh),
                      label: const Text('إعادة المحاولة'),
                    ),
                  ],
                ),
              ),
            )
          : _reminders.isEmpty
          ? _EmptyReminders(onAdd: _addReminder)
          : Column(
              children: [
                if (ReminderNotificationService.instance.notificationsGranted ==
                        false ||
                    ReminderNotificationService.instance.exactAlarmsGranted ==
                        false)
                  Card(
                    margin: const EdgeInsets.fromLTRB(16, 8, 16, 8),
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        children: [
                          const Icon(Icons.notifications_off_outlined),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              ReminderNotificationService
                                          .instance
                                          .notificationsGranted ==
                                      false
                                  ? 'إذن الإشعارات غير مفعّل؛ قد لا تصل التذكيرات.'
                                  : 'إذن المنبهات الدقيقة غير مفعّل؛ قد يتأخر التنبيه.',
                            ),
                          ),
                          TextButton(
                            onPressed: _openNotificationSettings,
                            child: const Text('فتح الإعدادات'),
                          ),
                        ],
                      ),
                    ),
                  ),
                Card(
                  margin: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 14,
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: _SummaryCount(
                            label: 'نشطة',
                            value: activeCount,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                        Expanded(
                          child: _SummaryCount(
                            label: 'متأخرة',
                            value: overdueCount,
                            color: overdueCount == 0
                                ? Theme.of(context).colorScheme.outline
                                : Theme.of(context).colorScheme.error,
                          ),
                        ),
                        Expanded(
                          child: _SummaryCount(
                            label: 'منجزة',
                            value: completedCount,
                            color: Theme.of(context).colorScheme.tertiary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: [
                      ChoiceChip(
                        label: Text('النشطة ($activeCount)'),
                        selected: !_showCompleted,
                        onSelected: (_) =>
                            setState(() => _showCompleted = false),
                      ),
                      const SizedBox(width: 8),
                      ChoiceChip(
                        label: Text('المنجزة ($completedCount)'),
                        selected: _showCompleted,
                        onSelected: (_) =>
                            setState(() => _showCompleted = true),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                Expanded(
                  child: visibleReminders.isEmpty
                      ? Center(
                          child: Text(
                            _showCompleted
                                ? 'لا توجد تذكيرات منجزة بعد.'
                                : 'لا توجد تذكيرات نشطة.',
                          ),
                        )
                      : ListView.separated(
                          padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                          itemCount: visibleReminders.length,
                          separatorBuilder: (_, _) => const SizedBox(height: 8),
                          itemBuilder: (context, index) {
                            final reminder = visibleReminders[index];
                            final overdue = _isOverdue(reminder);
                            final snooze = reminder.snoozedUntil;
                            final isSnoozed =
                                !reminder.isDone &&
                                snooze != null &&
                                snooze.isAfter(DateTime.now());
                            final colors = Theme.of(context).colorScheme;
                            return Card(
                              clipBehavior: Clip.antiAlias,
                              child: ListTile(
                                contentPadding:
                                    const EdgeInsetsDirectional.only(
                                      start: 12,
                                      end: 4,
                                      top: 4,
                                      bottom: 4,
                                    ),
                                leading: CircleAvatar(
                                  backgroundColor: reminder.isDone
                                      ? colors.tertiaryContainer
                                      : overdue
                                      ? colors.errorContainer
                                      : colors.primaryContainer,
                                  child: Icon(
                                    reminder.isDone
                                        ? Icons.check_rounded
                                        : overdue
                                        ? Icons.warning_amber_rounded
                                        : Icons.notifications_active_outlined,
                                    color: reminder.isDone
                                        ? colors.onTertiaryContainer
                                        : overdue
                                        ? colors.onErrorContainer
                                        : colors.onPrimaryContainer,
                                  ),
                                ),
                                title: Text(
                                  reminder.title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: reminder.isDone
                                      ? const TextStyle(
                                          decoration:
                                              TextDecoration.lineThrough,
                                        )
                                      : null,
                                ),
                                subtitle: Padding(
                                  padding: const EdgeInsets.only(top: 5),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Wrap(
                                        spacing: 6,
                                        runSpacing: 4,
                                        children: [
                                          _StatusBadge(
                                            label: reminder.isDone
                                                ? 'منجز'
                                                : overdue
                                                ? 'متأخر'
                                                : isSnoozed
                                                ? 'مؤجل'
                                                : 'قادم',
                                            color: reminder.isDone
                                                ? colors.tertiary
                                                : overdue
                                                ? colors.error
                                                : isSnoozed
                                                ? colors.secondary
                                                : colors.primary,
                                          ),
                                          _StatusBadge(
                                            label: _repeatLabel(
                                              reminder.repeat,
                                            ),
                                            color: colors.outline,
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        _formatDate(_displayDate(reminder)),
                                        style: Theme.of(
                                          context,
                                        ).textTheme.bodySmall,
                                      ),
                                      if (reminder.notes.trim().isNotEmpty) ...[
                                        const SizedBox(height: 3),
                                        Text(
                                          reminder.notes,
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ],
                                      if (reminder.repeat == 'custom') ...[
                                        const SizedBox(height: 3),
                                        Text(
                                          'هذا تكرار قديم؛ عدّله إلى يومي أو أسبوعي أو شهري أو سنوي لضمان استمراره.',
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(color: colors.error),
                                        ),
                                      ],
                                    ],
                                  ),
                                ),
                                isThreeLine: false,
                                onTap: reminder.isDone
                                    ? null
                                    : () => _editReminder(reminder),
                                trailing: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    IconButton(
                                      tooltip: reminder.isDone
                                          ? 'إعادة التفعيل'
                                          : 'وضع علامة مكتمل',
                                      onPressed: () => _toggleDone(reminder),
                                      icon: Icon(
                                        reminder.isDone
                                            ? Icons.restart_alt_rounded
                                            : Icons.check_circle_outline,
                                      ),
                                    ),
                                    PopupMenuButton<String>(
                                      tooltip: 'خيارات التذكير',
                                      onSelected: (action) {
                                        switch (action) {
                                          case 'snooze10':
                                            _snooze(reminder);
                                            break;
                                          case 'snooze30':
                                            _snooze(
                                              reminder,
                                              duration: const Duration(
                                                minutes: 30,
                                              ),
                                            );
                                            break;
                                          case 'snooze60':
                                            _snooze(
                                              reminder,
                                              duration: const Duration(
                                                hours: 1,
                                              ),
                                            );
                                            break;
                                          case 'edit':
                                            _editReminder(reminder);
                                            break;
                                          case 'delete':
                                            _delete(reminder);
                                            break;
                                        }
                                      },
                                      itemBuilder: (_) => [
                                        if (!reminder.isDone)
                                          const PopupMenuItem(
                                            value: 'snooze10',
                                            child: Text('تأجيل 10 دقائق'),
                                          ),
                                        if (!reminder.isDone)
                                          const PopupMenuItem(
                                            value: 'snooze30',
                                            child: Text('تأجيل 30 دقيقة'),
                                          ),
                                        if (!reminder.isDone)
                                          const PopupMenuItem(
                                            value: 'snooze60',
                                            child: Text('تأجيل ساعة'),
                                          ),
                                        if (!reminder.isDone)
                                          const PopupMenuItem(
                                            value: 'edit',
                                            child: Text('تعديل'),
                                          ),
                                        PopupMenuItem(
                                          value: 'delete',
                                          child: Text(
                                            reminder.isDone
                                                ? 'حذف من السجل'
                                                : 'حذف',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

class _SummaryCount extends StatelessWidget {
  const _SummaryCount({
    required this.label,
    required this.value,
    required this.color,
  });

  final String label;
  final int value;
  final Color color;

  @override
  Widget build(BuildContext context) => Column(
    mainAxisSize: MainAxisSize.min,
    children: [
      Text(
        '$value',
        style: Theme.of(context).textTheme.titleLarge?.copyWith(
          color: color,
          fontWeight: FontWeight.bold,
        ),
      ),
      const SizedBox(height: 2),
      Text(label, style: Theme.of(context).textTheme.labelSmall),
    ],
  );
}

class _StatusBadge extends StatelessWidget {
  const _StatusBadge({required this.label, required this.color});

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return DecoratedBox(
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        child: Text(
          label,
          style: Theme.of(context).textTheme.labelSmall?.copyWith(
            color: color == scheme.outline ? scheme.onSurfaceVariant : color,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}

class _EmptyReminders extends StatelessWidget {
  const _EmptyReminders({required this.onAdd});

  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircleAvatar(
              radius: 34,
              backgroundColor: colors.primaryContainer,
              child: Icon(
                Icons.notifications_none_rounded,
                size: 36,
                color: colors.onPrimaryContainer,
              ),
            ),
            const SizedBox(height: 18),
            Text(
              'ابدأ بتنظيم يومك',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 6),
            Text(
              'أضف تذكيرًا وسيظهر هنا موعده وحالته.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: onAdd,
              icon: const Icon(Icons.add_alert_outlined),
              label: const Text('إنشاء أول تذكير'),
            ),
          ],
        ),
      ),
    );
  }
}

class _ReminderEditor extends StatefulWidget {
  const _ReminderEditor({this.initial});

  final Reminder? initial;

  @override
  State<_ReminderEditor> createState() => _ReminderEditorState();
}

class _ReminderEditorState extends State<_ReminderEditor> {
  final _title = TextEditingController();
  final _notes = TextEditingController();
  DateTime _date = DateTime.now().add(const Duration(minutes: 5));
  String _sound = 'reminder_default';
  String _repeat = 'none';
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final initial = widget.initial;
    if (initial != null) {
      _title.text = initial.title;
      _notes.text = initial.notes;
      _date = initial.scheduledAt;
      _sound =
          const {
            'reminder_default',
            'reminder_soft',
            'reminder_urgent',
          }.contains(initial.sound)
          ? initial.sound
          : 'reminder_default';
      _repeat =
          const {
            'none',
            'daily',
            'weekly',
            'monthly',
            'yearly',
          }.contains(initial.repeat)
          ? initial.repeat
          : 'none';
    }
  }

  @override
  void dispose() {
    _title.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final firstDate = DateTime(now.year, now.month, now.day);
    final date = await showDatePicker(
      context: context,
      firstDate: firstDate,
      lastDate: firstDate.add(const Duration(days: 3650)),
      initialDate: _date.isBefore(firstDate) ? firstDate : _date,
    );
    if (date == null || !mounted) return;
    setState(() {
      _date = DateTime(
        date.year,
        date.month,
        date.day,
        _date.hour,
        _date.minute,
      );
    });
  }

  Future<void> _pickTime() async {
    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(_date),
    );
    if (time == null) return;
    setState(() {
      _date = DateTime(
        _date.year,
        _date.month,
        _date.day,
        time.hour,
        time.minute,
      );
    });
  }

  Future<void> _previewSound() async {
    try {
      await ReminderNotificationService.instance.previewSound(_sound);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'أُرسل إشعار تجريبي بالنغمة المختارة. افحص وضع الصوت في الجهاز.',
          ),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('تعذرت معاينة النغمة: $error')));
    }
  }

  Future<void> _submit() async {
    if (_title.text.trim().isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('أدخل عنوان التذكير أولاً')));
      return;
    }
    if (_date.isBefore(DateTime.now())) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اختر تاريخاً ووقتاً مستقبلياً')),
      );
      return;
    }
    setState(() => _saving = true);
    try {
      final id = widget.initial?.id ?? await IdGenerator.next('reminders');
      if (!mounted) return;
      Navigator.of(context).pop(
        Reminder(
          id: id,
          title: _title.text.trim(),
          notes: _notes.text.trim(),
          scheduledAt: _date,
          sound: _sound,
          repeat: _repeat,
          repeatIntervalDays: widget.initial?.repeatIntervalDays ?? 1,
        ),
      );
    } catch (error) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('تعذر حفظ التذكير: $error')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final dateText = DateFormatter.dateTime(_date);
    return AlertDialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 24),
      title: Text(widget.initial == null ? 'تذكير جديد' : 'تعديل التذكير'),
      content: ConstrainedBox(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.sizeOf(context).height * 0.58,
        ),
        child: SingleChildScrollView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _title,
                autofocus: true,
                maxLength: 120,
                textInputAction: TextInputAction.next,
                decoration: const InputDecoration(
                  labelText: 'عنوان التذكير',
                  prefixIcon: Icon(Icons.edit_note_outlined),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _notes,
                maxLength: 500,
                maxLines: 2,
                decoration: const InputDecoration(
                  labelText: 'تفاصيل إضافية (اختياري)',
                  prefixIcon: Icon(Icons.notes_outlined),
                ),
              ),
              const SizedBox(height: 4),
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  'موعد سريع',
                  style: Theme.of(context).textTheme.labelLarge,
                ),
              ),
              const SizedBox(height: 6),
              Wrap(
                spacing: 6,
                runSpacing: 4,
                children: [
                  ActionChip(
                    label: const Text('بعد 10 دقائق'),
                    onPressed: () => setState(
                      () => _date = DateTime.now().add(
                        const Duration(minutes: 10),
                      ),
                    ),
                  ),
                  ActionChip(
                    label: const Text('بعد ساعة'),
                    onPressed: () => setState(
                      () =>
                          _date = DateTime.now().add(const Duration(hours: 1)),
                    ),
                  ),
                  ActionChip(
                    label: const Text('غدًا 9 صباحًا'),
                    onPressed: () {
                      final tomorrow = DateTime.now().add(
                        const Duration(days: 1),
                      );
                      setState(
                        () => _date = DateTime(
                          tomorrow.year,
                          tomorrow.month,
                          tomorrow.day,
                          9,
                        ),
                      );
                    },
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Align(
                alignment: Alignment.centerRight,
                child: Text(
                  'إعدادات التنبيه',
                  style: Theme.of(
                    context,
                  ).textTheme.titleSmall?.copyWith(fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickDate,
                      icon: const Icon(Icons.calendar_month_outlined),
                      label: Text(DateFormatter.date(_date)),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _pickTime,
                      icon: const Icon(Icons.schedule_outlined),
                      label: Text(
                        '${_date.hour.toString().padLeft(2, '0')}:${_date.minute.toString().padLeft(2, '0')}',
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'موعد التنبيه المحدد: $dateText',
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(
                initialValue: _sound,
                decoration: const InputDecoration(
                  labelText: 'نغمة التنبيه',
                  prefixIcon: Icon(Icons.volume_up_outlined),
                ),
                items: const [
                  DropdownMenuItem(
                    value: 'reminder_default',
                    child: Text('نغمة افتراضية'),
                  ),
                  DropdownMenuItem(
                    value: 'reminder_soft',
                    child: Text('نغمة هادئة'),
                  ),
                  DropdownMenuItem(
                    value: 'reminder_urgent',
                    child: Text('نغمة تنبيه قوية'),
                  ),
                ],
                onChanged: (value) =>
                    setState(() => _sound = value ?? 'reminder_default'),
              ),
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: _previewSound,
                  icon: const Icon(Icons.play_arrow_rounded),
                  label: const Text('تجربة النغمة'),
                ),
              ),
              const SizedBox(height: 4),
              DropdownButtonFormField<String>(
                initialValue: _repeat,
                decoration: const InputDecoration(
                  labelText: 'تكرار التنبيه',
                  prefixIcon: Icon(Icons.repeat_outlined),
                ),
                items: const [
                  DropdownMenuItem(value: 'none', child: Text('مرة واحدة')),
                  DropdownMenuItem(value: 'daily', child: Text('يوميًا')),
                  DropdownMenuItem(value: 'weekly', child: Text('أسبوعيًا')),
                  DropdownMenuItem(value: 'monthly', child: Text('شهريًا')),
                  DropdownMenuItem(value: 'yearly', child: Text('سنويًا')),
                ],
                onChanged: (value) => setState(() => _repeat = value ?? 'none'),
              ),
              const SizedBox(height: 6),
              Text(
                'التكرار اليومي والأسبوعي والشهري والسنوي يستمر تلقائيًا.',
                style: Theme.of(context).textTheme.bodySmall,
                textAlign: TextAlign.start,
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: _saving ? null : () => Navigator.pop(context),
          child: const Text('إلغاء'),
        ),
        FilledButton.icon(
          onPressed: _saving ? null : _submit,
          icon: _saving
              ? const SizedBox.square(
                  dimension: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.notifications_active_outlined),
          label: Text(_saving ? 'جارٍ الحفظ...' : 'حفظ وتفعيل'),
        ),
      ],
    );
  }
}
