import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

import 'core/theme/app_theme.dart';
import 'features/settings/models/app_settings.dart';
import 'features/settings/services/settings_store.dart';
import 'features/welcome/screens/welcome_screen.dart';

class AlfaExpenseApp extends StatefulWidget {
  const AlfaExpenseApp({super.key});

  @override
  State<AlfaExpenseApp> createState() => _AlfaExpenseAppState();
}

class _AlfaExpenseAppState extends State<AlfaExpenseApp> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<AppSettings>(
      valueListenable: SettingsStore.notifier,
      builder: (context, settings, _) {
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'النماذج والمستندات',
          theme: AppTheme.build(settings),
          locale: const Locale('ar'),
          supportedLocales: const [Locale('ar')],
          localizationsDelegates: GlobalMaterialLocalizations.delegates,
          builder: (context, child) {
            return MediaQuery.withClampedTextScaling(
              minScaleFactor: 0.85,
              maxScaleFactor: 1.30,
              child: SafeArea(
                top: false,
                bottom: true,
                child: Directionality(
                  textDirection: TextDirection.rtl,
                  child: child ?? const SizedBox.shrink(),
                ),
              ),
            );
          },
          home: const WelcomeScreen(),
        );
      },
    );
  }
}
