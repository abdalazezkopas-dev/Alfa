# كتالوج الموارد والقوالب

- `assets/images/memo/internal_memo_full.png`: الأصل الرسمي للمذكرة الداخلية A4 المرفقة، 1241×1755 PNG بنسبة A4.
- `assets/images/form_template_top.png` و`form_template_bottom.png`: أصول طلب الصرف الحالي.
- `assets/images/customer_application_original.png`: الأصل الرسمي لنموذج تقديم المبيعات والعملاء، محول من `نموذج تقديم خاص للمبيعات (1).pdf`، مقاس Letter 612×792.
- `assets/fonts/`: الخطوط العربية واللاتينية المستخدمة في المعاينة وPDF.
- `lib/features/customer/screens/customer_application_screen.dart`: شاشة مستقلة لنموذج المبيعات والعملاء.
- `lib/features/settings/models/template_configuration.dart`: هويات القوالب وأبعادها المستقلة.
