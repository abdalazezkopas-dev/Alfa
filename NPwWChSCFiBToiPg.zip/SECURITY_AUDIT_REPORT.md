# Security Audit Report — Baseline

**Project:** alfa_expense_app  
**Application ID:** `com.shibapharma.formsuite`  
**Version:** `2.7.1+2`  
**Audit date:** 2026-09-23  
**Audit mode:** Static review only; no Flutter SDK is available in the current environment.

## Executive summary

The source preserves the Arabic RTL product identity and the existing document types, PDF templates, fonts, and application ID. It is not yet a production-security release. The most material findings are plaintext local persistence, plaintext JSON backups, untrusted imported attachment paths and payload sizes, and release configuration that explicitly uses the debug signing key.

No production secret, keystore, password, or token was found in the reviewed source tree. Generated/local files were removed from the secure working copy and are ignored by the project rules.

## Findings

| ID | Severity | Area | Finding | Required treatment |
|---|---|---|---|---|
| SEC-001 | Critical | Android release signing | `release` currently assigns `signingConfigs.debug`. | Replace with a CI/local ignored keystore configuration and fail closed when release credentials are absent. Never use debug signing for production. |
| SEC-002 | High | Local storage | Requests, notes, reminders, debts, settings, patterns, and quick statements use `SharedPreferences`/JSON. | Introduce an encrypted repository with Android Keystore-backed key protection and a validated migration. |
| SEC-003 | High | Backup export | Backup v3 is JSON and attachments are base64-embedded without authenticated encryption. | Add password-derived authenticated encryption and a versioned container format. Keep legacy JSON only behind an explicit import path and warning. |
| SEC-004 | High | Backup import | Imported counts, nesting, string sizes, attachment bytes, duplicate IDs, and foreign paths are not centrally bounded before restore. | Validate and stage all imported data before any live replacement. |
| SEC-005 | High | Attachment paths | Existing records carry arbitrary `attachmentPath` strings and import remapping trusts backup IDs. | Accept only managed attachment paths and never materialize an arbitrary imported path. |
| SEC-006 | Medium | Model decoders | Several decoders coerce arbitrary values to strings and silently discard malformed list entries. | Add typed bounded decoders and model-level limits without allowing one bad record to erase healthy records. |
| SEC-007 | Medium | Architecture | Stores rewrite whole collections and UI code calls persistence services directly. | Introduce repository/application boundaries incrementally, preserving legacy stores during migration. |
| SEC-008 | Medium | Notifications | Device/business timezone and reboot/update behavior require verification on a Flutter-enabled Android environment. | Add timezone and rescheduling tests; keep the current behavior documented until verified. |
| SEC-009 | Medium | Verification | Flutter/Dart are not installed in this environment. | Do not claim analyzer, test, or APK build success. Run the release gate in a Flutter-enabled CI/device environment. |

## Protected behavior

The following must remain unchanged during remediation: Arabic RTL layout, visible brand, application ID, expense requests, customer applications, clearance/service forms, internal memos, reports, notes, reminders, debts, calculator, PDF generation/preview/printing/sharing, attachments, and template customization. Expense-request geometry and bottom-copy behavior are protected from unrelated changes.

## Baseline commands

The following commands were requested but could not be run because `flutter` and `dart` are not installed in the current sandbox:

- `flutter pub get`
- `dart format --output=none --set-exit-if-changed lib test`
- `flutter analyze`
- `flutter test`
- `flutter build apk --release`

This report intentionally records the limitation rather than claiming success.

## Remediation order

1. Keep the isolated source copy and remove generated/local files.
2. Add bounded decoders and attachment-path policy with focused tests.
3. Add authenticated encrypted backup codec and explicit legacy-import handling.
4. Add encrypted repository and migration only after the codec and rollback tests are stable.
5. Harden Android release signing and permissions.
6. Run analyzer, tests, release build, certificate verification, and visual RTL/PDF verification in a Flutter-enabled environment.

## Residual risks before release

Production signing credentials are not present and must be supplied through protected CI secrets or an ignored local `key.properties`. Encryption migration cannot be accepted until it has been exercised against real legacy data and interrupted restore scenarios. Device-level notification, image-recovery, and PDF visual behavior require Android/Flutter integration verification.
