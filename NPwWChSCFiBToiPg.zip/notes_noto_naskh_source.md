تم التحقق من صفحة Google Fonts الرسمية لخط Noto Naskh Arabic بتاريخ 2026-08-27.
المصدر: https://fonts.google.com/noto/specimen/Noto+Naskh+Arabic
الصفحة تعرض Noto Naskh Arabic كخط Naskh عربي مناسب للنصوص العربية، وتذكر أنه خط Variable متعدد الأوزان ويحتوي على أوزان متعددة. الصفحة تربط بمستودع Google Fonts الرسمي: https://github.com/google/fonts
سيُستخدم الخط في واجهة التطبيق كخيار «نسخ واضح»، مع إبقاء Noto Sans Arabic كخط PDF الآمن عند الحاجة.
