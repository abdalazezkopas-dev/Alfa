# قائمة تحقق الإصدار الإنتاجي

## الهوية

- [ ] application ID هو `com.shibapharma.formsuite`.
- [ ] الإصدار والـ versionCode موثقين.
- [ ] RTL والعلامة العربية والقوالب لم تتغير دون طلب.

## الأمان

- [ ] لا توجد كلمات مرور أو tokens أو keystores داخل المستودع.
- [ ] Release لا يستخدم debug certificate.
- [ ] التوقيع يقرأ من CI secrets أو `android/key.properties` المستثنى.
- [ ] التخزين المحلي مشفر بمفتاح محمي عبر Android Keystore.
- [ ] النسخ الاحتياطية authenticated encrypted.
- [ ] الاستيراد staged وذري مع rollback.
- [ ] المسارات الخارجية للمرفقات مرفوضة.

## التحقق

- [ ] `flutter pub get`
- [ ] `dart format --output=none --set-exit-if-changed lib test`
- [ ] `flutter analyze`
- [ ] `flutter test`
- [ ] `flutter build apk --release`
- [ ] فحص شهادة APK ليس debug.
- [ ] فحص الصلاحيات وغياب network permissions غير المتوقعة.
- [ ] اختبار PDF واللغة العربية بصريًا.
- [ ] اختبار الترحيل والاستعادة وإعادة التشغيل والإشعارات على جهاز حقيقي.
