# Arabic font assets

The Arabic font files in this directory were downloaded from the Google Fonts repository. Google Fonts states that its catalog is released under open-source licenses and may be used in commercial and non-commercial projects.

Sources:

- Google Fonts: https://fonts.google.com
- Google Fonts developer information: https://developers.google.com/fonts
- Cairo specimen: https://fonts.google.com/specimen/Cairo
- Katibeh specimen: https://fonts.google.com/specimen/Katibeh
- Tajawal repository and OFL-1.1 license: https://github.com/googlefonts/tajawal

The corresponding OFL license texts downloaded from the Google Fonts repository are stored under `licenses/`.
