#!/usr/bin/env bash
set -Eeuo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPORT="${ROOT}/release_validation_report.txt"
FLUTTER_BIN="${FLUTTER_BIN:-flutter}"
DART_BIN="${DART_BIN:-}"
if [[ -z "$DART_BIN" && -x "$(dirname "$FLUTTER_BIN")/cache/dart-sdk/bin/dart" ]]; then
  DART_BIN="$(dirname "$FLUTTER_BIN")/cache/dart-sdk/bin/dart"
fi
DART_BIN="${DART_BIN:-dart}"

exec > >(tee "${REPORT}") 2>&1
printf 'Kabas release validation\n========================\n'
printf 'Source: %s\nDate: %s\n\n' "$ROOT" "$(date -Is)"

failures=0
run_step() {
  local name="$1"; shift
  printf '\n[%s]\n' "$name"
  if "$@"; then
    printf 'PASS: %s\n' "$name"
  else
    printf 'FAIL: %s\n' "$name"
    failures=$((failures + 1))
  fi
}

if ! command -v "$FLUTTER_BIN" >/dev/null 2>&1; then
  printf 'BLOCKED: Flutter SDK is not installed or FLUTTER_BIN is not on PATH.\n'
  printf 'Install Flutter, then rerun this script from the project root.\n'
  exit 2
fi

cd "$ROOT"
run_step 'Flutter pub get' "$FLUTTER_BIN" pub get
run_step 'Dart formatting' "$DART_BIN" format --output=none --set-exit-if-changed lib test
run_step 'Flutter analyze' "$FLUTTER_BIN" analyze
run_step 'Flutter tests' "$FLUTTER_BIN" test

printf '\n[Static Android release checks]\n'
grep -q 'applicationId = "com.shibapharma.formsuite"' android/app/build.gradle.kts
grep -q 'POST_NOTIFICATIONS' android/app/src/main/AndroidManifest.xml
gn=$(find . -type f \( -name key.properties -o -name '*.jks' -o -name '*.keystore' \) -print)
if [[ -n "$gn" ]]; then
  printf 'NOTICE: local signing material exists; do not commit it.\n'
else
  printf 'PASS: no local signing material found.\n'
fi

printf '\n[Release build]\n'
if "$FLUTTER_BIN" build apk --release; then
  apk=$(find build/app/outputs/flutter-apk -type f -name '*.apk' -print -quit)
  test -n "$apk"
  printf 'APK: %s\n' "$apk"
  if command -v apksigner >/dev/null 2>&1; then
    apksigner verify --verbose "$apk"
  else
    printf 'NOTICE: apksigner unavailable; certificate verification remains pending.\n'
  fi
else
  printf 'FAIL: release build.\n'
  failures=$((failures + 1))
fi

printf '\nSummary: failures=%s\n' "$failures"
if (( failures > 0 )); then exit 1; fi
